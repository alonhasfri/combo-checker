plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.combochecker"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.combochecker"
        minSdk = 26
        targetSdk = 34
        // Climbs every CI build so a newer APK installs over an older one as an update.
        versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
        versionName = System.getenv("VERSION_NAME") ?: "0.1"
    }

    // A fixed signing key so every build is signed the same way. Android only lets an APK
    // update another in place when both are signed with the same key, so this is what makes
    // "update" work instead of "uninstall + reinstall". The key is NOT stored in the repo:
    // CI writes it from a GitHub secret into app/combo.keystore before building. When it is
    // absent (e.g. a first build before the secret is set) the build falls back to the normal
    // debug signing and simply can't be installed as an update until the key is in place.
    val keystoreFile = file("combo.keystore")
    val hasKeystore = keystoreFile.exists()
    if (hasKeystore) {
        // Empty env strings (an unset GitHub secret resolves to "") must fall back too,
        // so treat blank the same as unset.
        val signPass = System.getenv("SIGNING_PASSWORD").takeUnless { it.isNullOrBlank() } ?: "combopass"
        val signAlias = System.getenv("SIGNING_ALIAS").takeUnless { it.isNullOrBlank() } ?: "combo"
        signingConfigs {
            create("app") {
                storeFile = keystoreFile
                storePassword = signPass
                keyAlias = signAlias
                keyPassword = signPass
            }
        }
    }

    buildTypes {
        debug {
            if (hasKeystore) signingConfig = signingConfigs.getByName("app")
        }
        release {
            isMinifyEnabled = false
            if (hasKeystore) signingConfig = signingConfigs.getByName("app")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // Firebase (free Spark plan): anonymous accounts, the shared database for the user counter
    // and leaderboard, and analytics. Users still bring their own AI key.
    implementation(platform("com.google.firebase:firebase-bom:33.5.1"))
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
}
