package com.combochecker

import android.content.Context

/**
 * Hidden "Gen Z mode" prank. When on, native labels are swapped for internet-slang versions and a
 * random emoji from 💔✌️🥀😭 is tacked onto the end of every sentence. Stays on until it's switched
 * off in Settings. The game screen and the AI's roast voice handle their own Gen Z text.
 */
object GenZ {
    fun isOn(c: Context): Boolean =
        c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("genz", false)

    fun setOn(c: Context, on: Boolean) =
        c.getSharedPreferences("combo", Context.MODE_PRIVATE).edit().putBoolean("genz", on).apply()

    private val emojis = listOf("💔", "✌️", "🥀", "😭")

    // Known UI strings → their Gen Z versions (before emoji are sprinkled on).
    private val dict = mapOf(
        "▶  Start the floating star" to "▶  deploy the lil guy",
        "Stop floating star" to "kill the star",
        "📷  Check a real-life photo" to "📷  scan ur irl grind",
        "📸  Before & after (clean-up)" to "📸  glow-up check",
        "🛍️  Shop — skins & abilities" to "🛍️  the drip shop",
        "🏆  Proof gallery" to "🧾  ur receipts",
        "📊  Stats & badges" to "📊  the lore & dubs",
        "📅  My week (recap)" to "📅  weekly wrapped",
        "🔊  Sound shop" to "🎧  aux shop",
        "😈  Prank a friend" to "😈  cook an opp",
        "🥇  Leaderboard" to "🥇  who's cracked",
        "Switch profile" to "swap accounts",
        "⚙  Settings & setup" to "⚙  the settings arc",
        "⚙  Hide settings" to "⚙  hide the arc",
        "AI key" to "the robot's password",
        "Goals and checks" to "the grind settings",
        "Save settings" to "lock it in",
        "Saved" to "bet",
        "Feedback" to "spill the tea",
        "Send feedback (email)" to "tell them the tea",
        "Backup & restore" to "save ur lore",
        "Back up my data" to "save ur lore",
        "Restore from a backup" to "load ur lore",
        "Appearance" to "the fit",
        "My voice (up to 4 seconds each)" to "ur yaps (4 secs each)",
        "Record my bonus cheer" to "record ur hype",
        "Record my finale cheer" to "record ur big hype",
        "Hear my cheers" to "play the yaps",
        "Delete my recordings" to "delete the evidence",
        "Creator key (unlocks hidden creator features)" to "creator key (unlocks hidden stuff)",
        "Unlock creator features" to "unlock creator stuff"
    )

    /** Translate a known label, then sprinkle emoji. Unknown text is just sprinkled. */
    fun say(c: Context, text: String): String {
        if (!isOn(c)) return text
        return spray(dict[text] ?: text)
    }

    /** Add a random emoji after each sentence (or at the end if there's no punctuation). */
    fun spray(text: String): String {
        if (text.isBlank()) return text
        val parts = text.trim().split(Regex("(?<=[.!?])\\s+"))
        return parts.joinToString(" ") { it.trim() + " " + emojis.random() }
    }
}
