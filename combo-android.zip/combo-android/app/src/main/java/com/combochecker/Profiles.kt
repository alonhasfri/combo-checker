package com.combochecker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Named user profiles. Each profile keeps its own state/gallery/proofs (namespaced keys);
 * the API key, parent PIN, rewards and approval settings stay shared across profiles.
 */
object Profiles {
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)

    fun list(c: Context): JSONArray =
        try { JSONArray(sp(c).getString("profiles", "[]")) } catch (e: Exception) { JSONArray() }

    fun ensureDefault(c: Context) {
        val arr = list(c)
        if (arr.length() == 0) {
            arr.put(JSONObject().put("id", "p0").put("name", "Me").put("emoji", "⭐").put("color", "#3a66d6"))
            sp(c).edit().putString("profiles", arr.toString()).putString("currentProfile", "p0").apply()
            migrateToP0(c)
        }
        val cur = currentId(c)
        if (cur.isEmpty() || find(c, cur) == null) {
            sp(c).edit().putString("currentProfile", list(c).getJSONObject(0).optString("id", "p0")).apply()
        }
    }

    private fun migrateToP0(c: Context) {
        val p = sp(c); val e = p.edit()
        for (base in listOf("state", "gallery", "proofs")) {
            val old = p.getString(base, null)
            if (old != null && p.getString(base + "__p0", null) == null) e.putString(base + "__p0", old)
        }
        e.apply()
    }

    fun currentId(c: Context): String = sp(c).getString("currentProfile", "") ?: ""
    fun select(c: Context, id: String) = sp(c).edit().putString("currentProfile", id).apply()

    fun find(c: Context, id: String): JSONObject? {
        val arr = list(c)
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") == id) return arr.getJSONObject(i)
        return null
    }

    fun current(c: Context): JSONObject =
        find(c, currentId(c)) ?: JSONObject().put("id", "p0").put("name", "Me").put("emoji", "⭐").put("color", "#3a66d6")

    fun add(c: Context, name: String, emoji: String, color: String): String {
        val arr = list(c)
        val id = "p" + System.currentTimeMillis()
        arr.put(JSONObject().put("id", id).put("name", name).put("emoji", emoji).put("color", color))
        sp(c).edit().putString("profiles", arr.toString()).apply()
        return id
    }

    fun remove(c: Context, id: String) {
        val arr = list(c); val out = JSONArray()
        for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") != id) out.put(arr.getJSONObject(i))
        val e = sp(c).edit().putString("profiles", out.toString())
        for (base in listOf("state", "gallery", "proofs")) e.remove(base + "__" + id)
        e.apply()
        if (currentId(c) == id && out.length() > 0) select(c, out.getJSONObject(0).optString("id"))
    }

    // ----- optional per-profile PIN lock (soft lock, stored on the phone) -----
    fun hasPin(c: Context, id: String): Boolean = (find(c, id)?.optString("pin") ?: "").isNotEmpty()

    fun checkPin(c: Context, id: String, entered: String): Boolean =
        (find(c, id)?.optString("pin") ?: "") == entered.trim()

    fun setPin(c: Context, id: String, pin: String) {
        val arr = list(c)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == id) {
                if (pin.isEmpty()) o.remove("pin") else o.put("pin", pin.trim())
                sp(c).edit().putString("profiles", arr.toString()).apply()
                return
            }
        }
    }

    fun stateKey(c: Context) = "state__" + currentId(c)
    fun galleryKey(c: Context) = "gallery__" + currentId(c)
    fun proofsKey(c: Context) = "proofs__" + currentId(c)
    fun stateKeyFor(id: String) = "state__" + id
}
