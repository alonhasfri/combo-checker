package com.combochecker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import java.io.File
import java.io.FileOutputStream
import kotlin.random.Random

/** Full-screen celebration (new rank, streak milestone) with confetti and a shareable picture. */
class CelebrateActivity : Activity() {
    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val emoji = intent.getStringExtra("emoji") ?: "🎉"
        val title = intent.getStringExtra("title") ?: ""
        val sub = intent.getStringExtra("sub") ?: ""

        val frame = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#3A5BD9"), Color.parseColor("#5A2FC7")))
        }
        // the card that becomes the shared picture
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPaddingRelative(d(28), d(36), d(28), d(30))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#3A5BD9"), Color.parseColor("#5A2FC7"))).apply { cornerRadius = d(28).toFloat() }
        }
        card.addView(Ui.text(this, emoji, 72f, Color.WHITE).apply { gravity = Gravity.CENTER })
        card.addView(Ui.text(this, title, 30f, Color.WHITE).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(14), 0, d(6)) })
        card.addView(Ui.text(this, sub, 17f, Color.parseColor("#DDE4FF"), bold = false).apply { gravity = Gravity.CENTER })
        val me = Profiles.current(this)
        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPaddingRelative(0, d(22), 0, 0) }
        brand.addView(CheckpointView(this).apply { colors = intArrayOf(Color.parseColor("#2B47B8"), Color.parseColor("#3A2690")) }, LinearLayout.LayoutParams(d(30), d(30)))
        brand.addView(Ui.text(this, "  " + me.optString("name") + " · Comboed", 15f, Color.WHITE))
        card.addView(brand)

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPaddingRelative(d(24), 0, d(24), 0) }
        col.addView(card, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        col.addView(Ui.button(this, Lang.t(this, "Share"), R.drawable.ui_share, Color.WHITE, Color.parseColor("#2B47B8"), 52) { share(card, title) }, Ui.lp(this, 26))
        col.addView(Ui.button(this, Lang.t(this, "Continue"), null, Color.parseColor("#33FFFFFF"), Color.WHITE, 48) { finish() }, Ui.lp(this, 10))
        frame.addView(col, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        setContentView(frame)
        frame.post { confetti(frame) }
        card.scaleX = 0.6f; card.scaleY = 0.6f; card.alpha = 0f
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(450).setInterpolator(android.view.animation.OvershootInterpolator(2f)).start()
    }

    private fun confetti(frame: FrameLayout) {
        val colors = listOf("#FFD23F", "#FF4F7B", "#3FD08A", "#3FD0F0", "#FFFFFF", "#FFB347")
        val w = frame.width; val h = frame.height
        repeat(70) {
            val v = View(this).apply {
                background = GradientDrawable().apply { setColor(Color.parseColor(colors.random())); cornerRadius = d(2).toFloat() }
                translationX = Random.nextInt(maxOf(1, w)).toFloat(); translationY = -d(40).toFloat(); rotation = Random.nextInt(360).toFloat()
            }
            frame.addView(v, 0, FrameLayout.LayoutParams(d(8), d(14)))
            v.animate().translationY(h + d(40).toFloat()).translationXBy((Random.nextInt(240) - 120).toFloat()).rotationBy(540f)
                .setStartDelay(Random.nextLong(900)).setDuration(1800L + Random.nextLong(1600)).start()
        }
    }

    /** Render the card to a PNG and open the share sheet. */
    private fun share(card: View, title: String) {
        try {
            val bmp = Bitmap.createBitmap(card.width, card.height, Bitmap.Config.ARGB_8888)
            card.draw(Canvas(bmp))
            val f = File(cacheDir, "comboed-celebration.png")
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, title + " — Comboed " + UpdateCheck.LATEST_APK).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, Lang.t(this, "Share")))
        } catch (e: Exception) {}
    }
}

/** Decides when to celebrate (once per new rank / streak milestone, per profile). */
object Celebrations {
    private val STREAKS = listOf(3, 7, 14, 30, 50, 100)
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)

    fun check(a: Activity) {
        val pid = Profiles.currentId(a)
        val lv = Progress.level(Progress.state(a).optInt("total", 0))
        val streak = Progress.dayStreak(a)
        val lk = "celebLevel__$pid"; val sk = "celebStreak__$pid"
        val e = sp(a).edit()
        // first time: remember where we are, celebrate only what comes next
        if (!sp(a).contains(lk)) { e.putInt(lk, lv).putInt(sk, STREAKS.filter { it <= streak }.maxOrNull() ?: 0).apply(); return }
        val he = Lang.isHebrew(a)
        if (lv > sp(a).getInt(lk, lv)) {
            e.putInt(lk, lv).apply()
            a.startActivity(Intent(a, CelebrateActivity::class.java).putExtra("emoji", "🏆")
                .putExtra("title", Progress.rank(a, lv))
                .putExtra("sub", if (he) "הגעת לשלב $lv!" else "You reached level $lv!"))
            return
        }
        val m = STREAKS.filter { it <= streak }.maxOrNull() ?: 0
        if (m > sp(a).getInt(sk, 0)) {
            e.putInt(sk, m).apply()
            a.startActivity(Intent(a, CelebrateActivity::class.java).putExtra("emoji", "🔥")
                .putExtra("title", if (he) "רצף של $m ימים!" else "$m-day streak!")
                .putExtra("sub", if (he) "$m ימים ברצף שעשית משהו. אל תעצור/י!" else "$m days in a row of getting things done. Keep going!"))
        }
    }
}
