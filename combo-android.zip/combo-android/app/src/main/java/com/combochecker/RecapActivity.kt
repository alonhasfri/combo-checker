package com.combochecker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** A friendly "this week" recap card for the current profile, with a Share button. */
class RecapActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val me = Profiles.current(this)
        val id = me.optString("id")

        val st = try { JSONObject(sp().getString("state__$id", "") ?: "") } catch (e: Exception) { JSONObject() }
        val gallery = try { JSONArray(sp().getString("gallery__$id", "[]")) } catch (e: Exception) { JSONArray() }
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        var tasks = 0; var points = 0; var bonuses = 0
        for (i in 0 until gallery.length()) {
            val o = gallery.getJSONObject(i)
            if (o.optLong("time") >= weekAgo) { tasks++; points += o.optInt("points"); bonuses += o.optInt("bonuses") }
        }
        val best = st.optInt("bestStreak", 0)
        val coins = st.optInt("coins", 0)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        // Card
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                cornerRadius = pad.toFloat()
                colors = intArrayOf(Color.parseColor("#2a1a5e"), Color.parseColor("#123a6b"))
                orientation = GradientDrawable.Orientation.TL_BR
            }
        }
        card.addView(TextView(this).apply {
            text = me.optString("emoji", "⭐") + "  " + me.optString("name", "Me") + "'s week"
            textSize = 22f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        })
        fun big(label: String, value: String) = card.addView(TextView(this).apply {
            text = value + "   " + label
            textSize = 20f; setTextColor(Color.WHITE); setPadding(0, pad / 2, 0, 0)
        })
        big("tasks finished", "✅ " + tasks)
        big("points earned", "⭐ " + points)
        big("bonuses earned", "🎯 " + bonuses)
        big("longest streak (all time)", "🔥 " + best)
        big("coins right now", "🪙 " + coins)
        root.addView(card)

        val summary = (me.optString("name", "Me")) + " did " + tasks + " task" + (if (tasks == 1) "" else "s") +
            " this week on Combo Checker, earning " + points + " points and " + bonuses + " bonuses! 🎉"

        root.addView(TextView(this).apply {
            text = if (tasks == 0) "No tasks yet this week — finish one and come back!" else summary
            textSize = 15f; setPadding(0, pad, 0, pad / 2)
        })

        root.addView(Button(this).apply {
            text = "Share my week"
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, summary)
                try { startActivity(Intent.createChooser(i, "Share")) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply { text = "Done"; setOnClickListener { finish() } })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
