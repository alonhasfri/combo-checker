package com.combochecker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** A short first-open intro: (1) who are you, (2) connect the AI, (3) try Checkpoint. */
class IntroActivity : Activity() {
    private var step = 0
    private var name = ""
    private var emoji = "⭐"
    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)
    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)

    companion object {
        /** New installs only: one untouched profile, no points, no key. Everyone else skips. */
        fun needed(c: Context): Boolean {
            val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
            if (sp.getBoolean("introDone", false)) return false
            val fresh = Profiles.list(c).length() <= 1 && Progress.state(c).optInt("total", 0) == 0 &&
                Progress.gallery(c).length() == 0 && (sp.getString("key", "") ?: "").isEmpty()
            if (!fresh) sp.edit().putBoolean("introDone", true).apply()
            return fresh
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        name = Profiles.current(this).optString("name").let { if (it == "Me") "" else it }
        render()
    }

    override fun onResume() { super.onResume(); if (step == 1 && (sp().getString("key", "") ?: "").isNotEmpty()) { step = 2; render() } }

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this).apply { setPaddingRelative(d(24), d(40), d(24), d(28)); gravity = Gravity.CENTER_HORIZONTAL }
        // progress dots
        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        for (i in 0..2) dots.addView(View(this).apply { background = Ui.rounded(if (i <= step) p.accent else p.track, d(4).toFloat()) },
            LinearLayout.LayoutParams(d(if (i == step) 26 else 10), d(8)).apply { marginStart = d(3); marginEnd = d(3) })
        page.addView(dots)

        when (step) {
            0 -> {
                page.addView(CheckpointView(this), LinearLayout.LayoutParams(d(84), d(84)).apply { topMargin = d(26) })
                page.addView(Ui.text(this, t("Welcome to Comboed"), 26f, p.ink).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(16), 0, d(8)) })
                page.addView(Ui.text(this, t("Finish real tasks, show proof, and the AI rewards you with points, coins and combos."), 15f, p.muted, bold = false).apply { gravity = Gravity.CENTER })
                val f = EditText(this).apply { hint = t("Your name"); setText(name); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS; gravity = Gravity.CENTER }
                page.addView(f, Ui.lp(this, 24))
                val grid = android.widget.GridLayout(this).apply { columnCount = 6 }
                val views = ArrayList<TextView>()
                for (e in listOf("⭐", "🚀", "🐱", "🐶", "🦄", "🦊", "🐉", "🎮", "🌟", "🔥", "🎈", "🐧")) {
                    val tv = TextView(this).apply {
                        text = e; textSize = 24f; gravity = Gravity.CENTER
                        background = Ui.rounded(if (e == emoji) p.accentSoft else 0, d(12).toFloat())
                        setOnClickListener { emoji = e; for (v in views) v.background = Ui.rounded(if (v.text == e) p.accentSoft else 0, d(12).toFloat()) }
                    }
                    views.add(tv)
                    grid.addView(tv, android.widget.GridLayout.LayoutParams().apply { width = d(46); height = d(46); setMargins(d(2), d(2), d(2), d(2)) })
                }
                page.addView(grid, LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { topMargin = d(12) })
                page.addView(Ui.button(this, t("Next"), null, p.accent, Color.WHITE, 52) {
                    name = f.text.toString().trim().ifEmpty { t("Me") }
                    val id = Profiles.currentId(this)
                    Profiles.rename(this, id, name)
                    val arr = Profiles.list(this)
                    for (i in 0 until arr.length()) if (arr.getJSONObject(i).optString("id") == id) arr.getJSONObject(i).put("emoji", emoji)
                    sp().edit().putString("profiles", arr.toString()).apply()
                    step = 1; render()
                }, Ui.lp(this, 24))
            }
            1 -> {
                page.addView(Ui.tile(this, R.drawable.ui_key, "blue", 72, 38).apply { (layoutParams as LinearLayout.LayoutParams).topMargin = d(30) })
                page.addView(Ui.text(this, t("Connect the AI (free)"), 24f, p.ink).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(16), 0, d(8)) })
                page.addView(Ui.text(this, t("The AI checks your proof. It needs a free key — about 2 minutes, no credit card. You can also skip and play in test mode."), 15f, p.muted, bold = false).apply { gravity = Gravity.CENTER })
                page.addView(Ui.button(this, t("Set up the free key"), R.drawable.ui_key, p.accent, Color.WHITE, 52) {
                    startActivity(Intent(this, KeySetupActivity::class.java))
                }, Ui.lp(this, 28))
                page.addView(Ui.button(this, t("Skip for now (test mode)"), null, p.track, p.ink, 48) {
                    sp().edit().putBoolean("keyOnboarded", true).apply(); step = 2; render()
                }, Ui.lp(this, 10))
            }
            else -> {
                page.addView(CheckpointView(this).apply { lit = 2 }, LinearLayout.LayoutParams(d(84), d(84)).apply { topMargin = d(26) })
                page.addView(Ui.text(this, t("Try Checkpoint"), 26f, p.ink).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(16), 0, d(8)) })
                val steps = listOf("Tap Start — a Checkpoint button floats over every app.", "Finish something, then tap Checkpoint.", "Circle what you did. The AI checks it and you get points!")
                steps.forEachIndexed { i, s ->
                    val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(0, d(6), 0, d(6)) }
                    r.addView(Ui.text(this, (i + 1).toString(), 14f, p.accentInk).apply { gravity = Gravity.CENTER; background = Ui.rounded(p.accentSoft, d(14).toFloat()) }, LinearLayout.LayoutParams(d(28), d(28)))
                    r.addView(Ui.text(this, t(s), 15f, p.ink, bold = false).apply { setPaddingRelative(d(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                    page.addView(r, Ui.lp(this, if (i == 0) 14 else 0))
                }
                page.addView(Ui.button(this, t("Start Checkpoint"), R.drawable.ui_checkpoint, p.accent, Color.WHITE, 52) { finishIntro(true) }, Ui.lp(this, 24))
                page.addView(Ui.button(this, t("Later"), null, p.track, p.ink, 48) { finishIntro(false) }, Ui.lp(this, 10))
            }
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); isFillViewport = true; addView(page) })
    }

    private fun finishIntro(start: Boolean) {
        sp().edit().putBoolean("introDone", true).putBoolean("keyOnboarded", true).apply()
        startActivity(Intent(this, MainActivity::class.java).putExtra("startCheckpoint", start))
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (step > 0) { step--; render() } else super.onBackPressed() }
}
