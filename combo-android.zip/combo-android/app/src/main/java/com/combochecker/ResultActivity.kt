package com.combochecker

import android.annotation.SuppressLint
import android.content.Intent
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.media.MediaPlayer
import android.media.PlaybackParams
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/** Full-screen screen: frozen screenshot, circle tool, then the combo animation (runs in a WebView). */
class ResultActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var shot: Bitmap? = null
    private var path: String? = null
    private var voicePlayer: MediaPlayer? = null
    private val extraPages = ArrayList<String>()
    private val pickPageCode = 77
    private var compareMode = false

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )

        path = intent.getStringExtra("path")
        shot = path?.let { decodeBounded(it, 2200) }
        if (shot == null) {
            finish()
            return
        }
        // Before/after mode: the "before" photo rides along as an extra page and the AI compares.
        intent.getStringExtra("beforePath")?.let { bp ->
            if (File(bp).exists()) { extraPages.add(bp); compareMode = true }
        }
        tts = TextToSpeech(this, this)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                val src = "file://$path?t=${System.currentTimeMillis()}"
                view?.evaluateJavascript("setImage('$src')", null)
                if (compareMode) {
                    view?.evaluateJavascript("onPageAdded(${extraPages.size})", null)
                    view?.evaluateJavascript("if(window.setCompareMode)setCompareMode()", null)
                }
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/combo.html")
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
    }

    /** Decode a file, downsampling so the longest side is about [maxSide]px — screenshots pass
     *  through untouched; big camera photos are shrunk so they don't run the app out of memory. */
    private fun decodeBounded(file: String, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file, bounds)
            var sample = 1
            val longest = maxOf(bounds.outWidth, bounds.outHeight)
            while (longest / sample > maxSide) sample *= 2
            BitmapFactory.decodeFile(file, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (e: Exception) {
            null
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun check(task: String, profileJson: String, fx: Double, fy: Double, fw: Double, fh: Double) {
            val bmp = shot
            Thread {
                val result = if (bmp == null) {
                    JSONObject().put("error", "No screenshot").toString()
                } else {
                    Checker.check(this@ResultActivity, task, profileJson, bmp, fx, fy, fw, fh, ArrayList(extraPages), compareMode)
                }
                runOnUiThread {
                    web.evaluateJavascript("onResult(${JSONObject.quote(result)})", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun speak(text: String, pitch: Double, rate: Double) {
            val t = tts ?: return
            if (!ttsReady) return
            t.setPitch(pitch.coerceIn(0.5, 3.0).toFloat())
            t.setSpeechRate(rate.coerceIn(0.5, 3.0).toFloat())
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "combo")
        }

        @JavascriptInterface
        fun vibrate(ms: Int) {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(VibrationEffect.createOneShot(ms.toLong(), VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION") v.vibrate(ms.toLong())
            }
        }

        // ----- saved points / level state (a JSON string owned by the page) -----
        @JavascriptInterface
        fun getState(): String = sp().getString(Profiles.stateKey(this@ResultActivity), "") ?: ""

        @JavascriptInterface
        fun setState(json: String) {
            sp().edit().putString(Profiles.stateKey(this@ResultActivity), json).apply()
        }

        @JavascriptInterface
        fun getGoal(): Int = sp().getInt("goal", 3)

        @JavascriptInterface
        fun getStrict(): Boolean = sp().getBoolean("strict", false)

        @JavascriptInterface
        fun getApproval(): Boolean = sp().getBoolean("approval", false)

        @JavascriptInterface
        fun isGenZ(): Boolean = sp().getBoolean("genz", false)

        @JavascriptInterface
        fun voiceMode(): String = Voice.active(this@ResultActivity)

        @JavascriptInterface
        fun lang(): String = Lang.code(this@ResultActivity)

        @JavascriptInterface
        fun isGaslight(): Boolean = sp().getBoolean("gaslight", false)

        @JavascriptInterface
        fun isAchieveSpam(): Boolean = sp().getBoolean("achievespam", false)

        @JavascriptInterface
        fun addPending(coins: Int, task: String, proof: String) {
            val me = Profiles.current(this@ResultActivity)
            val arr = JSONArray(sp().getString("pending", "[]"))
            arr.put(
                JSONObject()
                    .put("coins", coins)
                    .put("task", task)
                    .put("time", System.currentTimeMillis())
                    .put("profileId", me.optString("id"))
                    .put("profileName", me.optString("name"))
                    .put("proof", proof)
            )
            while (arr.length() > 200) arr.remove(0)
            sp().edit().putString("pending", arr.toString()).apply()
        }

        @JavascriptInterface
        fun pickPage() {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
                    startActivityForResult(Intent.createChooser(i, "Add a page"), pickPageCode)
                } catch (e: Exception) {}
            }
        }

        // ----- your own recorded cheers -----
        @JavascriptInterface
        fun hasVoice(kind: String): Boolean = File(filesDir, "voice_$kind.m4a").exists()

        @JavascriptInterface
        fun playVoice(kind: String, pitch: Double, rate: Double) {
            runOnUiThread {
                val f = File(filesDir, "voice_$kind.m4a")
                if (!f.exists()) return@runOnUiThread
                voicePlayer?.release()
                val mp = MediaPlayer()
                voicePlayer = mp
                try {
                    mp.setDataSource(f.absolutePath)
                    mp.prepare()
                    mp.playbackParams = PlaybackParams()
                        .setPitch(pitch.coerceIn(0.5, 2.0).toFloat())
                        .setSpeed(rate.coerceIn(0.5, 2.0).toFloat())
                    mp.start()
                } catch (e: Exception) {
                    runCatching { mp.release() }
                    voicePlayer = null
                }
            }
        }

        // ----- proof gallery -----
        @JavascriptInterface
        fun saveWin(file: String, task: String, points: Int, bonuses: Int) {
            val arr = JSONArray(sp().getString(Profiles.galleryKey(this@ResultActivity), "[]"))
            arr.put(
                JSONObject()
                    .put("file", file)
                    .put("task", task)
                    .put("points", points)
                    .put("bonuses", bonuses)
                    .put("time", System.currentTimeMillis())
            )
            while (arr.length() > 100) {
                val old = arr.getJSONObject(0)
                File(File(filesDir, "proofs"), old.getString("file")).delete()
                arr.remove(0)
            }
            sp().edit().putString(Profiles.galleryKey(this@ResultActivity), arr.toString()).apply()
        }

        @JavascriptInterface
        fun close() {
            runOnUiThread { finish() }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(req, resultCode, data)
        if (req == pickPageCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val bmp = BitmapFactory.decodeStream(contentResolver.openInputStream(uri)) ?: return
                val f = File(cacheDir, "page_" + System.currentTimeMillis() + ".jpg")
                FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                extraPages.add(f.absolutePath)
                if (::web.isInitialized) web.evaluateJavascript("onPageAdded(" + extraPages.size + ")", null)
            } catch (e: Exception) {}
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        finish()
    }

    override fun onDestroy() {
        BubbleService.setBubbleVisible(true)
        tts?.shutdown()
        voicePlayer?.release()
        if (::web.isInitialized) web.destroy()
        path?.let { runCatching { File(it).delete() } }
        super.onDestroy()
    }
}
