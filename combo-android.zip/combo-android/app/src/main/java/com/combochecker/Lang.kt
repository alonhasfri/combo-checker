package com.combochecker

import android.app.Activity
import android.content.Context
import android.view.View

/**
 * App language. English ("en") or Hebrew ("he"). Hebrew mode translates the whole UI (via the
 * dictionary below), flips the layout to right-to-left, and asks the AI to answer in Hebrew.
 *
 * Translation is by exact English string: [t] returns the Hebrew for a known string, or the English
 * unchanged if it isn't in the dictionary — so anything untranslated simply stays readable English.
 * The game (combo.html) and the sound shop carry their own matching Hebrew dictionaries in JS.
 */
object Lang {
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)

    /** "en" | "he" */
    fun code(c: Context): String = sp(c).getString("lang", "en") ?: "en"
    fun set(c: Context, value: String) = sp(c).edit().putString("lang", value).apply()
    fun isHebrew(c: Context): Boolean = code(c) == "he"
    fun rtl(c: Context): Boolean = isHebrew(c)

    /** Translate a known English UI string to the active language. Unknown strings pass through. */
    fun t(c: Context, en: String): String = if (isHebrew(c)) (HE[en] ?: en) else en

    /** Flip the window to RTL/LTR for the active language. Called from Appearance.apply for every screen. */
    fun applyDirection(a: Activity) {
        a.window.decorView.layoutDirection =
            if (rtl(a)) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    private val HE: Map<String, String> = mapOf(
        // ---- shared buttons / words ----
        "Done" to "סיום",
        "Cancel" to "ביטול",
        "OK" to "אישור",
        "Save" to "שמירה",
        "Saved" to "נשמר",
        "Delete" to "מחיקה",
        "Deleted" to "נמחק",
        "Added" to "נוסף",
        "Add" to "הוספה",
        "Back" to "חזרה",
        "Unlock" to "פתיחה",
        "Remove" to "הסרה",
        "Cleared" to "נוקה",
        "Approve" to "אישור",
        "Reject" to "דחייה",
        "Approve all" to "אישור הכול",
        "Wrong PIN" to "קוד שגוי",
        "Open" to "פתיחה",
        "Share" to "שיתוף",
        "coins" to "מטבעות",
        "ON" to "פעיל",
        "OFF" to "כבוי",
        "Couldn't open the camera:" to "לא ניתן היה לפתוח את המצלמה:",
        "Backup failed:" to "הגיבוי נכשל:",
        "Restore failed:" to "השחזור נכשל:",
        "Couldn't record:" to "לא ניתן היה להקליט:",
        "Couldn't play:" to "לא ניתן היה לנגן:",

        // ---- ProfileActivity ----
        "Who's using Comboed?" to "מי משתמש ב‑Comboed?",
        "Tap to open. Press and hold a profile to lock it with a PIN or delete it." to
            "הקישו כדי לפתוח. לחיצה ארוכה על פרופיל כדי לנעול אותו בקוד או למחוק אותו.",
        "➕ Add profile" to "➕ הוספת פרופיל",
        "For parents" to "להורים",
        "Parent zone" to "אזור הורים",
        "New profile" to "פרופיל חדש",
        "Name" to "שם",
        "Pick an icon" to "בחרו סמל",
        "Pick a colour" to "בחרו צבע",
        "Create" to "יצירה",
        "Enter a name" to "הזינו שם",
        "Colour set" to "הצבע נבחר",
        "🔒 Locked profile" to "🔒 פרופיל נעול",
        "Enter this profile's PIN to open it." to "הזינו את הקוד של הפרופיל כדי לפתוח אותו.",
        "✏️ Rename" to "✏️ שינוי שם",
        "Change PIN lock" to "שינוי קוד הנעילה",
        "🔒 Lock with a PIN" to "🔒 נעילה בקוד",
        "Remove PIN lock" to "הסרת קוד הנעילה",
        "Delete profile" to "מחיקת פרופיל",
        "Rename profile" to "שינוי שם הפרופיל",
        "Lock profile" to "נעילת פרופיל",
        "Only someone with this PIN can open the profile." to "רק מי שמכיר את הקוד יוכל לפתוח את הפרופיל.",
        "New PIN (4+ digits)" to "קוד חדש (4 ספרות ומעלה)",
        "Use at least 4 digits" to "השתמשו ב‑4 ספרות לפחות",
        "Profile locked 🔒" to "הפרופיל ננעל 🔒",
        "Current PIN" to "הקוד הנוכחי",
        "Lock removed" to "הנעילה הוסרה",
        "Delete profile?" to "למחוק פרופיל?",
        "This deletes the profile and all its points, coins and progress. This can't be undone." to
            "פעולה זו מוחקת את הפרופיל ואת כל הנקודות, המטבעות וההתקדמות שלו. לא ניתן לבטל.",
        "You need at least one profile" to "צריך לפחות פרופיל אחד",
        "Profile PIN" to "קוד הפרופיל",
        "Parent PIN" to "קוד הורים",
        "Enter the parent PIN." to "הזינו את קוד ההורים.",

        // ---- MainActivity ----
        "Switch profile" to "החלפת פרופיל",
        "👥 counting people…" to "👥 סופר משתמשים…",
        "Home" to "בית",
        "Shop" to "חנות",
        "Stats" to "נתונים",
        "Ranks" to "דירוג",
        "▶  Start the floating star" to "▶  הפעלת הכוכב הצף",
        "Stop floating star" to "עצירת הכוכב הצף",
        "📷  Check a real-life photo" to "📷  בדיקת תמונה מהמציאות",
        "📸  Before & after (clean-up)" to "📸  לפני ואחרי (ניקיון)",
        "🛍️  Shop — skins & abilities" to "🛍️  חנות — מראות ויכולות",
        "🏆  Proof gallery" to "🏆  גלריית הוכחות",
        "📊  Stats & badges" to "📊  נתונים ותגים",
        "📅  My week (recap)" to "📅  השבוע שלי (סיכום)",
        "🔊  Sound shop" to "🔊  חנות צלילים",
        "📄  Source code" to "📄  קוד מקור",
        "🥇  Leaderboard" to "🥇  טבלת מובילים",
        "⚙  Settings & setup" to "⚙  הגדרות",
        "⚙  Hide settings" to "⚙  הסתרת הגדרות",
        "Setup" to "הגדרה",
        "⚙  Settings" to "⚙  הגדרות",
        "Menu" to "תפריט",
        "Reminders" to "תזכורות",
        "Daily reminder to do a task (5 PM)" to "תזכורת יומית לבצע משימה (17:00)",
        "Daily reminder on" to "תזכורת יומית הופעלה",
        "⬇  More" to "⬇  עוד",
        "⬆  Hide extras" to "⬆  הסתרת העוד",
        "❓  Help & guide" to "❓  עזרה ומדריך",
        "Use the classic menu" to "מעבר לתפריט הישן",
        "Use the new menu" to "מעבר לתפריט החדש",
        "Terms of Service · Privacy Policy" to "תנאי שימוש · מדיניות פרטיות",
        "Terms of Service & Privacy Policy" to "תנאי שימוש ומדיניות פרטיות",
        "Last updated: today · Comboed" to "עודכן לאחרונה: היום · Comboed",
        "🧯 Turn off all pranks" to "🧯 כיבוי כל המתיחות",
        "🧯 Turn off all pranks (300 coins)" to "🧯 כיבוי כל המתיחות (300 מטבעות)",
        "All pranks turned off" to "כל המתיחות כובו",
        "All pranks turned off (−300 coins)" to "כל המתיחות כובו (−300 מטבעות)",
        "Not enough coins — you need 300 💸" to "אין מספיק מטבעות — צריך 300 💸",
        // start fresh
        "Start fresh" to "התחלה מחדש",
        "🧹 Start fresh (reset this profile)" to "🧹 התחלה מחדש (איפוס הפרופיל)",
        "Reset this profile — wipes its points, level, coins, study coins, shop items, gallery and achievements. The profile itself (name, icon, PIN) stays." to
            "איפוס הפרופיל — מוחק את הנקודות, הרמה, המטבעות, מטבעות הלימוד, פריטי החנות, הגלריה וההישגים. הפרופיל עצמו (שם, סמל, קוד) נשאר.",
        "Enter this profile's PIN to continue." to "הזינו את הקוד של הפרופיל כדי להמשיך.",
        "⚠️ Are you sure?" to "⚠️ בטוחים?",
        "This resets EVERYTHING for this profile — points, level, coins, study coins, shop items, gallery and achievements — back to zero.\n\nThis CANNOT be undone." to
            "פעולה זו מאפסת הכול בפרופיל הזה — נקודות, רמה, מטבעות, מטבעות לימוד, פריטי חנות, גלריה והישגים — לאפס.\n\nלא ניתן לבטל.",
        "Yes, reset" to "כן, לאפס",
        "Hold the button for 10 seconds to reset this profile. Let go to cancel." to
            "החזיקו את הכפתור 10 שניות כדי לאפס את הפרופיל. שחררו כדי לבטל.",
        "Hold to reset" to "החזיקו לאיפוס",
        "This profile has been reset." to "הפרופיל אופס.",
        // two coin types
        "🪙 general coins (any task) · 📚 study coins (school work)" to "🪙 מטבעות כלליים (כל משימה) · 📚 מטבעות לימוד (עבודת בית ספר)",
        "Not enough study coins" to "אין מספיק מטבעות לימוד",
        "Can only be bought with study coins 📚" to "אפשר לקנות רק במטבעות לימוד 📚",
        "Skins, abilities and \"both\" rewards can be paid with any mix of general and study coins. Study-only rewards must be paid with study coins." to
            "מראות, יכולות ופרסים \"משני הסוגים\" אפשר לשלם בכל שילוב של מטבעות כלליים ומטבעות לימוד. פרסים ללימוד בלבד חייבים להיות משולמים במטבעות לימוד.",
        // prank menu tidy
        "✨ Update tools" to "✨ כלי עדכון",
        "Tick the pranks you want, make one update key that carries them all, and share it — or paste a key a friend sent you. Modes stay on until turned off; gags play once." to
            "סמנו את המתיחות שתרצו, צרו מפתח עדכון אחד שנושא את כולן, ושתפו — או הדביקו מפתח שחבר שלח. מצבים נשארים פעילים עד שמכבים; גאגים משחקים פעם אחת.",
        "AI key" to "מפתח AI",
        "Save settings" to "שמירת הגדרות",
        "Feedback" to "משוב",
        "Goals and checks" to "יעדים ובדיקות",
        "Appearance" to "מראה",
        "Backup & restore" to "גיבוי ושחזור",
        "Back up my data" to "גיבוי הנתונים שלי",
        "Restore from a backup" to "שחזור מגיבוי",
        "Hear my cheers" to "השמעת העידודים שלי",
        "Delete my recordings" to "מחיקת ההקלטות שלי",
        "Unlock update features" to "פתיחת תכונות עדכון",
        "Send feedback (email)" to "שליחת משוב (אימייל)",
        "Developer" to "מפתח",
        "Developer PIN" to "קוד מפתח",
        "Enter the developer PIN to toggle debug mode." to "הזינו את קוד המפתח כדי להפעיל או לכבות מצב ניפוי.",
        "Debug mode OFF" to "מצב ניפוי כבוי",
        "🛠 Debug ON - infinite coins & all skins in the Shop" to "🛠 מצב ניפוי פעיל — מטבעות אינסופיים וכל המראות בחנות",
        "Game version 4.2.0" to "גרסת משחק 4.2.0",
        "🔄 Search for updates" to "🔄 חיפוש עדכונים",
        "Updating…" to "מעדכן…",
        "Checking for updates… a new version was found!\n\nDownloading update 4.2.1…\n\nEstimated time remaining: approximately 2,422 years. ⏳\n\nPlease keep the app open." to
            "בודק עדכונים… נמצאה גרסה חדשה!\n\nמוריד עדכון 4.2.1…\n\nזמן משוער שנותר: בערך 2,422 שנה. ⏳\n\nנא להשאיר את האפליקציה פתוחה.",
        "Allow \"Display over other apps\", then come back and press Start again" to
            "אשרו \"הצגה מעל אפליקציות אחרות\", ואז חזרו והקישו שוב על הפעלה",
        "Star is on. Switch to any app." to "הכוכב פעיל. עברו לכל אפליקציה.",
        "Tap the star over any app, circle your finished task, and the AI checks it. No key? It runs in test mode." to
            "הקישו על הכוכב מעל כל אפליקציה, הקיפו את המשימה שסיימתם, וה‑AI בודק אותה. אין מפתח? זה רץ במצב בדיקה.",
        "Snap homework, a drawing or anything on paper, then circle it or tap “Whole page”." to
            "צלמו שיעורי בית, ציור או כל דבר על נייר, ואז הקיפו אותו או הקישו על \"כל העמוד\".",
        "Take a BEFORE photo, tidy up, then take an AFTER photo — the AI rewards the improvement." to
            "צלמו תמונת \"לפני\", סדרו, ואז צלמו תמונת \"אחרי\" — ה‑AI מתגמל על השיפור.",
        "API key: free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant)" to
            "מפתח API: OpenRouter חינמי (‏sk-or-...‏), Google Gemini (‏AIza‏) או Anthropic (‏sk-ant‏)",
        "Model id (optional). For OpenRouter paste one, e.g. nvidia/nemotron-3.5-super-vl:free" to
            "מזהה מודל (לא חובה). ל‑OpenRouter הדביקו אחד, למשל nvidia/nemotron-3.5-super-vl:free",
        "Update key (unlocks hidden update features)" to "מפתח עדכון (פותח תכונות עדכון נסתרות)",
        "🔒 Pranks are blocked by a parent." to "🔒 המתיחות חסומות על‑ידי הורה.",
        "❌ Invalid update key." to "❌ מפתח עדכון לא תקין.",
        "✅ Update features unlocked." to "✅ תכונות העדכון נפתחו.",
        "Turn off" to "כיבוי",
        "Not enough coins — you need 300 to turn this off 💸" to "אין מספיק מטבעות — צריך 300 כדי לכבות 💸",
        "Turned off" to "כובה",
        "Turned off (−300 coins)" to "כובה (−300 מטבעות)",
        "🛒 Remove ads" to "🛒 הסרת פרסומות",
        "Remove ads" to "הסרת פרסומות",
        "Ads can only be removed by purchasing Ad-Free, or by spending 300 coins." to
            "אפשר להסיר פרסומות רק ברכישת גרסה ללא פרסומות, או בהוצאת 300 מטבעות.",
        "Spend 300 coins" to "להוציא 300 מטבעות",
        "Keep ads" to "להשאיר פרסומות",
        "Ads removed! (−300 coins)" to "הפרסומות הוסרו! (−300 מטבעות)",
        "Ads removed (developer)" to "הפרסומות הוסרו (מפתח)",
        "Not enough coins — you need 300 to remove ads 💸" to "אין מספיק מטבעות — צריך 300 כדי להסיר פרסומות 💸",
        "Daily goal: tasks per day" to "יעד יומי: משימות ביום",
        "Strict AI detector: no points when the proof looks AI-made (85%+). Off means a warning only." to
            "גלאי AI מחמיר: אין נקודות כשההוכחה נראית מעשה AI (85%+). כבוי = אזהרה בלבד.",
        "🔒 Strict AI detector:" to "🔒 גלאי AI מחמיר:",
        "set by a parent in the Parent zone." to "נקבע על‑ידי הורה באזור ההורים.",
        "Buy Ad-Free \$4.99" to "קניית גרסה ללא פרסומות \$4.99",
        "My voice (up to 4 seconds each)" to "הקול שלי (עד 4 שניות כל אחד)",
        "Record my bonus cheer" to "הקלטת עידוד בונוס",
        "Record my finale cheer" to "הקלטת עידוד סיום",
        "Recording... tap to stop" to "מקליט... הקישו לעצירה",
        "Delete recordings?" to "למחוק הקלטות?",
        "Your recorded cheers will be removed and the phone voice used again." to
            "העידודים שהקלטתם יימחקו ושוב ייעשה שימוש בקול הטלפון.",
        "Deleted. The phone voice is used again." to "נמחק. שוב נעשה שימוש בקול הטלפון.",
        "No recording yet" to "אין הקלטה עדיין",
        "Too short, try again" to "קצר מדי, נסו שוב",
        "Allow the microphone, then tap record again" to "אשרו את המיקרופון, ואז הקישו שוב על הקלטה",
        "No email app found. Email: hasfrialon@gmail.com" to "לא נמצאה אפליקציית אימייל. אימייל: hasfrialon@gmail.com",
        "Or email hasfrialon@gmail.com" to "או שלחו אימייל אל hasfrialon@gmail.com",
        "Send feedback" to "שליחת משוב",
        "Light" to "בהיר",
        "Dark" to "כהה",
        "Kid" to "ילדים",
        "Kid mode uses bigger text." to "מצב ילדים משתמש בטקסט גדול יותר.",
        "Language" to "שפה",
        "English" to "English",
        "עברית" to "עברית",
        "Back up all profiles, points, coins and settings to a file you can save or send to yourself. (Proof photos aren't included.)" to
            "גבו את כל הפרופילים, הנקודות, המטבעות וההגדרות לקובץ שאפשר לשמור או לשלוח לעצמכם. (תמונות הוכחה לא כלולות.)",
        "Pick a backup file" to "בחרו קובץ גיבוי",
        "Couldn't open the file picker" to "לא ניתן היה לפתוח את בוחר הקבצים",
        "Save or send your backup" to "שמירה או שליחה של הגיבוי",
        "That doesn't look like a Comboed backup" to "זה לא נראה כמו גיבוי של Comboed",
        "Restore backup?" to "לשחזר גיבוי?",
        "This replaces ALL current profiles, points, coins and settings on this phone with the backup. This can't be undone." to
            "פעולה זו מחליפה את כל הפרופילים, הנקודות, המטבעות וההגדרות בטלפון בגיבוי. לא ניתן לבטל.",
        "Restore" to "שחזור",
        "Restored. Restarting…" to "שוחזר. מתחיל מחדש…",
        "Before saved. Now tidy up, then take the AFTER photo." to "ה\"לפני\" נשמר. עכשיו סדרו, ואז צלמו את תמונת ה\"אחרי\".",
        "No photo was saved" to "לא נשמרה תמונה",
        "Couldn't get both photos" to "לא ניתן היה לקבל את שתי התמונות",
        "No camera app found" to "לא נמצאה אפליקציית מצלמה",

        // ---- ParentActivity ----
        "👪 Parent zone" to "👪 אזור הורים",
        "Set a parent PIN. You will need it to change rewards and settings. (Note: this is a soft lock stored on the phone, not high security.)" to
            "קבעו קוד הורים. תצטרכו אותו כדי לשנות פרסים והגדרות. (שימו לב: זו נעילה רכה ששמורה בטלפון, לא אבטחה חזקה.)",
        "Confirm PIN" to "אישור הקוד",
        "Save PIN" to "שמירת הקוד",
        "PINs do not match" to "הקודים אינם תואמים",
        "PIN set" to "הקוד נקבע",
        "Enter the parent PIN." to "הזינו את קוד ההורים.",
        "PIN" to "קוד",
        "AI art detector" to "גלאי אמנות AI",
        "Strict: no points when a proof looks AI-made (85%+). Off means a warning only. Kids can't change this while a parent PIN is set." to
            "מחמיר: אין נקודות כשהוכחה נראית מעשה AI (85%+). כבוי = אזהרה בלבד. ילדים לא יכולים לשנות זאת כשמוגדר קוד הורים.",
        "Approval mode" to "מצב אישור",
        "Hold coins earned until a parent approves them" to "החזקת המטבעות שהורווחו עד שהורה יאשר אותם",
        "Leaderboard" to "טבלת מובילים",
        "Hide the leaderboard from kids (avoids sibling pressure)" to "הסתרת טבלת המובילים מהילדים (למניעת לחץ בין אחים)",
        "Pranks" to "מתיחות",
        "Block pranks — kids can't be trolled (ignores update keys and turns off any active troll)" to
            "חסימת מתיחות — אי אפשר למתוח את הילדים (מתעלם ממפתחות עדכון ומכבה כל מתיחה פעילה)",
        "Nothing waiting." to "אין מה שממתין.",
        "Real-life rewards" to "פרסים מהמציאות",
        "The child buys these with coins in the Shop. Add a name and a coin cost." to
            "הילד קונה אותם במטבעות בחנות. הוסיפו שם ועלות במטבעות.",
        "Reward name (e.g. Ice cream)" to "שם הפרס (למשל גלידה)",
        "Coin cost" to "עלות במטבעות",
        "Add reward" to "הוספת פרס",
        "Enter a name and a cost" to "הזינו שם ועלות",
        "Nothing redeemed yet." to "עדיין לא מומש דבר.",
        "Clear log" to "ניקוי היומן",
        "Clear redemption log?" to "לנקות את יומן המימושים?",
        "This can't be undone." to "לא ניתן לבטל.",
        "Clear" to "ניקוי",
        "This week" to "השבוע",
        "Honesty report" to "דוח יושר",
        "No checks yet." to "עדיין אין בדיקות.",
        "Change PIN" to "שינוי קוד",
        "Set a new PIN" to "קבעו קוד חדש",
        "Approved" to "אושר",
        "Rejected" to "נדחה",
        "PIN" to "קוד",
        "Pending approvals" to "אישורים ממתינים",
        "Redeemed by child" to "מומש על‑ידי הילד",
        "Set a new PIN" to "קבעו קוד חדש",
        "Save PIN" to "שמירת הקוד",

        // ---- ShopActivity ----
        "🛍️ Shop" to "🛍️ חנות",
        "Earn coins every time a task passes. Spend them here. Buying a skin equips it." to
            "מרוויחים מטבעות בכל פעם שמשימה עוברת. מוציאים אותם כאן. קניית מראה גם מצמידה אותו.",
        "Abilities" to "יכולות",
        "Double Points" to "נקודות כפולות",
        "next check scores x2 points" to "הבדיקה הבאה מזכה בנקודות כפולות",
        "Coin Doubler" to "מכפיל מטבעות",
        "next check earns x2 coins" to "הבדיקה הבאה מזכה במטבעות כפולים",
        "Hint" to "רמז",
        "AI tips for the bonuses you miss, next check" to "טיפים מה‑AI לבונוסים שפספסתם, בבדיקה הבאה",
        "Retry token" to "אסימון ניסיון חוזר",
        "redo a failed check — used automatically" to "חזרה על בדיקה שנכשלה — נעשה שימוש אוטומטית",
        "Floating star" to "הכוכב הצף",
        "Circle colour" to "צבע ההקפה",
        "Confetti" to "קונפטי",
        "Win banner" to "כרזת ניצחון",
        "Set up by a parent. Redeeming shows a note to show them." to
            "הוגדר על‑ידי הורה. מימוש מציג הודעה שאפשר להראות להם.",
        "Not enough coins" to "אין מספיק מטבעות",
        "Buy one first" to "קנו אחד קודם",
        "Buy" to "קנייה",
        "Equip" to "הצמדה",
        "Arm" to "דריכה",
        "Redeem" to "מימוש",
        // skin & sound names
        "Classic Star" to "כוכב קלאסי",
        "Fire" to "אש",
        "Diamond" to "יהלום",
        "Rocket" to "טיל",
        "Crown" to "כתר",
        "Rainbow" to "קשת",
        "Pink" to "ורוד",
        "Cyan" to "תכלת",
        "Green" to "ירוק",
        "Red" to "אדום",
        "Gold" to "זהב",
        "Purple" to "סגול",
        "Party" to "מסיבה",
        "Ice" to "קרח",
        "Neon" to "ניאון",
        "Pink Glow" to "זוהר ורוד",
        "Classic bells" to "פעמונים קלאסיים",
        "Arcade 8-bit" to "ארקייד 8‑ביט",
        "Soft marimba" to "מרימבה רכה",
        "Crystal sparkle" to "נצנוץ קריסטל",
        "Robot" to "רובוט",

        // ---- StatsActivity ----
        "📊 Your stats" to "📊 הנתונים שלך",
        "Progress" to "התקדמות",
        "Badges" to "תגים",
        "Today's quests" to "המשימות של היום",
        // ranks
        "Rookie" to "טירון",
        "Apprentice" to "שוליה",
        "Doer" to "עושה",
        "Achiever" to "מצליחן",
        "Pro" to "מקצוען",
        "Expert" to "מומחה",
        "Master" to "רב‑אמן",
        "Champion" to "אלוף",
        "Legend" to "אגדה",
        "Mythic" to "מיתולוגי",
        // achievements
        "First Win" to "ניצחון ראשון",
        "10 Tasks Done" to "10 משימות הושלמו",
        "50 Tasks Done" to "50 משימות הושלמו",
        "Combo x3" to "קומבו x3",
        "Combo x5" to "קומבו x5",
        "Level 5" to "רמה 5",
        "Level 10" to "רמה 10",
        "Collector (3 skins)" to "אספן (3 מראות)",
        "Finish 3 tasks today" to "סיימו 3 משימות היום",
        "Land a combo (x1.5+)" to "השיגו קומבו (‏x1.5 ומעלה)",
        "Earn 2 bonuses in one check" to "הרוויחו 2 בונוסים בבדיקה אחת",

        // ---- GalleryActivity ----
        "🏆 Proof gallery" to "🏆 גלריית הוכחות",
        "Nothing here yet. Finish a task and your winning proof shows up here." to
            "עדיין אין כאן כלום. סיימו משימה וההוכחה המנצחת תופיע כאן.",
        "Clear gallery" to "ניקוי הגלריה",
        "Clear gallery?" to "לנקות את הגלריה?",
        "This permanently deletes every saved proof for this profile. This can't be undone." to
            "פעולה זו מוחקת לצמיתות כל הוכחה שמורה של הפרופיל הזה. לא ניתן לבטל.",
        "Delete all" to "מחיקת הכול",
        "Gallery cleared" to "הגלריה נוקתה",
        "(no task name)" to "(ללא שם משימה)",
        "Delete all" to "מחיקת הכול",

        // ---- LeaderboardActivity ----
        "🏆 Leaderboard" to "🏆 טבלת מובילים",
        "This week" to "השבוע",
        "All time" to "כל הזמנים",
        "Tasks finished in the last 7 days." to "משימות שהושלמו ב‑7 הימים האחרונים.",
        "Total points earned, all time." to "סך הנקודות שהורווחו, בכל הזמנים.",
        "🌍 Global" to "🌍 עולמי",
        "🌍 Loading players worldwide…" to "🌍 טוען שחקנים מכל העולם…",
        "No players yet — be the first! Finish a task to join the global board." to
            "עדיין אין שחקנים — היו הראשונים! סיימו משימה כדי להצטרף לטבלה העולמית.",
        "Top players worldwide, by points." to "השחקנים המובילים בעולם, לפי נקודות.",

        // ---- RecapActivity ----
        "Share my week" to "שיתוף השבוע שלי",
        "No tasks yet this week — finish one and come back!" to "עדיין אין משימות השבוע — סיימו אחת וחזרו!",

        // ---- Checker / game errors ----
        "You already used this proof for this task. Show something new." to
            "כבר השתמשת בהוכחה הזאת למשימה הזאת. הראו משהו חדש.",
        "Free limit reached. Wait a minute and try again." to "הגעתם למגבלת החינם. המתינו דקה ונסו שוב.",
        "Test mode: save an API key in the app for real checks." to "מצב בדיקה: שמרו מפתח API באפליקציה לבדיקות אמיתיות.",

        // ---- Ads (fake ads prank) ----
        "Sponsored" to "ממומן",
        "Tap to learn more ›" to "הקישו למידע נוסף ›",
        "ADVERTISEMENT" to "פרסומת",
        "tap the X to continue" to "הקישו על ה‑X כדי להמשיך",
        "tap the X to close" to "הקישו על ה‑X כדי לסגור",
        "Remove ads – \$4.99" to "הסרת פרסומות – \$4.99",
        "Secure checkout · \$4.99" to "תשלום מאובטח · \$4.99",
        "Name on card" to "שם בעל הכרטיס",
        "Card number" to "מספר כרטיס",
        "Pay \$4.99" to "לשלם \$4.99",
        "Payment declined ❌" to "התשלום נדחה ❌",
        "...ugh" to "...אוף",
        "Comboed keeps stopping" to "‏Comboed ממשיך להיעצר",
        "Close app" to "סגירת האפליקציה",
        "App info" to "פרטי האפליקציה",

        // ---- LoginWall (fake sign-in prank) ----
        "Sign in to continue" to "התחברו כדי להמשיך",
        "Create your account" to "צרו חשבון",
        "Check your email" to "בדקו את האימייל",
        "Email" to "אימייל",
        "Password" to "סיסמה",
        "Date of birth (MM/DD/YYYY)" to "תאריך לידה (MM/DD/YYYY)",
        "What state do you live in?" to "באיזו מדינה אתם גרים?",
        "6-letter code" to "קוד בן 6 אותיות",
        "Log in" to "התחברות",
        "Create account" to "יצירת חשבון",
        "Verify code" to "אימות הקוד",
        "I forgot my password" to "שכחתי את הסיסמה",
        "Don't have an account?  Sign up" to "אין לכם חשבון?  הרשמו",
        "Already have an account?  Log in" to "כבר יש לכם חשבון?  התחברו",
        "Resend code" to "שליחת הקוד מחדש",
        "Back to sign in" to "חזרה להתחברות",
        "I accept the Terms and Conditions" to "אני מסכים/ה לתנאים ולהגבלות",
        "I want to receive marketing emails" to "אני רוצה לקבל אימיילים שיווקיים",
        "Wrong password or email. Try again." to "סיסמה או אימייל שגויים. נסו שוב.",
        "You must accept the Terms and Conditions." to "עליכם להסכים לתנאים ולהגבלות.",
        "That code didn't work. Try again." to "הקוד הזה לא עבד. נסו שוב.",
        "Account created! Please log in." to "החשבון נוצר! נא להתחבר.",
        "your email" to "האימייל שלכם",

        // ---- PrankActivity (source-code decoy stays mostly as-is) ----
        "Modes (stay on until turned off)" to "מצבים (נשארים פעילים עד לכיבוי)",
        "One-shot gags (play once)" to "מתיחות חד‑פעמיות (פעם אחת)",
        "🔑 Make the update key" to "🔑 יצירת מפתח העדכון",
        "Got an update key?" to "יש לכם מפתח עדכון?",
        "Tick at least one troll first." to "סמנו לפחות מתיחה אחת קודם.",
        "Update key for:" to "מפתח עדכון עבור:",
        "Share key" to "שיתוף המפתח",
        "Try it on my phone" to "לנסות בטלפון שלי",
        "Paste a key, e.g. CRK-7K2P-9QF4" to "הדביקו מפתח, למשל CRK-7K2P-9QF4",
        "Send this to your friend. Tell them it's a secret Update key that unlocks hidden features — they paste it into Settings → Update key and tap Unlock. The code looks random, so it won't give the prank away. 😈" to
            "שלחו את זה לחבר. אמרו לו שזה מפתח עדכון סודי שפותח תכונות נסתרות — הוא מדביק אותו בהגדרות ← מפתח עדכון ומקיש על פתיחה. הקוד נראה אקראי, אז הוא לא יחשוף את המתיחה. 😈",
        "Here's a Comboed update key that unlocks hidden features — paste it in Settings → Update key and tap Unlock:" to
            "הנה מפתח עדכון של Comboed שפותח תכונות נסתרות — הדביקו אותו בהגדרות ← מפתח עדכון והקישו על פתיחה:"
    )
}
