package com.combochecker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** A simple, friendly guide to what Comboed is and how to use it. English or Hebrew. */
class HelpActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val he = Lang.isHebrew(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        root.addView(TextView(this).apply {
            text = if (he) "❓ עזרה ומדריך" else "❓ Help & guide"
            textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 0, 0, pad / 2)
        })

        for ((title, body) in sections(he)) {
            root.addView(TextView(this).apply {
                text = title; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
            })
            root.addView(TextView(this).apply { text = body; textSize = 15f; setPadding(0, 0, 0, pad / 4) })
        }

        root.addView(Button(this).apply {
            text = if (he) "סיום" else "Done"
            setPadding(0, pad, 0, 0)
            setOnClickListener { finish() }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun sections(he: Boolean): List<Pair<String, String>> = if (he) listOf(
        "מה זה Comboed?" to
            "Comboed הופך משימות אמיתיות למשחק. מסיימים משימה, מוכיחים אותה, ו‑AI בודק אם היא באמת הושלמה. על כל הצלחה מקבלים נקודות, מטבעות, רצפים (קומבו) ועליות רמה.",
        "איך בודקים משימה" to
            "יש שלוש דרכים:\n• הכוכב הצף — הקישו על \"הפעלת הכוכב הצף\", עברו לכל אפליקציה, הקישו על הכוכב והקיפו את מה שסיימתם.\n• תמונה מהמציאות — צלמו שיעורי בית, ציור או כל דבר על נייר.\n• לפני ואחרי — צלמו \"לפני\", סדרו, ואז \"אחרי\", וה‑AI מתגמל על השיפור.",
        "נקודות, מטבעות ורמות" to
            "משימה שעוברת מזכה בנקודות (לפי הקושי ולפי בונוסים), וברצף של משימות יש מכפיל קומבו. מטבעות אפשר להוציא בחנות על מראות, יכולות, צלילים ופרסים אמיתיים שהורה מגדיר.",
        "מפתח AI" to
            "כדי שהבדיקות יהיו אמיתיות צריך מפתח API (OpenRouter חינמי, Google Gemini או Anthropic). מזינים אותו ב\"הגדרה\". בלי מפתח המשחק רץ במצב בדיקה עם תוצאות אקראיות.",
        "אזור הורים" to
            "הורים יכולים לקבוע קוד, להגדיר פרסים אמיתיים, לדרוש אישור למטבעות, להפעיל גלאי AI מחמיר, ולחסום מתיחות. נכנסים דרך מסך הפרופילים ← אזור הורים.",
        "שפה ומראה" to
            "אפשר להחליף בין עברית לאנגלית ובין מצב בהיר/כהה/ילדים בהגדרות, וגם לעבור בין התפריט החדש לתפריט הישן."
    ) else listOf(
        "What is Comboed?" to
            "Comboed turns real tasks into a game. You finish a task, prove it, and an AI checks whether it's really done. Every win earns points, coins, combo streaks and level-ups.",
        "How to check a task" to
            "There are three ways:\n• The floating star — tap \"Start the floating star\", switch to any app, tap the star and circle what you finished.\n• Real-life photo — snap homework, a drawing or anything on paper.\n• Before & after — take a \"before\" photo, tidy up, then \"after\", and the AI rewards the improvement.",
        "Points, coins & levels" to
            "A passing task earns points (by difficulty and bonuses), and a streak of tasks builds a combo multiplier. Spend coins in the Shop on skins, abilities, sounds, and real-life rewards a parent sets up.",
        "AI key" to
            "For real checks you need an API key (free OpenRouter, Google Gemini, or Anthropic). Enter it under \"Setup\". Without a key the game runs in test mode with random results.",
        "Parent zone" to
            "Parents can set a PIN, add real-life rewards, require approval for coins, turn on the strict AI detector, and block pranks. Reach it from the profiles screen → Parent zone.",
        "Language & look" to
            "You can switch between English and Hebrew, and between Light/Dark/Kid mode, in Settings — and switch between the new menu and the classic menu."
    )
}
