package com.combochecker

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/**
 * First-open setup: explains what the AI key is and walks through getting a FREE one, with direct
 * links, then lets you paste it. Shown once on first open (and any time from Settings → AI key).
 */
class KeySetupActivity : Activity() {
    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)
    private var provider = 0 // 0 = OpenRouter, 1 = Google Gemini

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        render()
    }

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this).apply { setPaddingRelative(d(20), d(28), d(20), d(28)) }
        page.addView(Ui.tile(this, R.drawable.ui_key, "blue", 60, 32).apply { (layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_HORIZONTAL })
        page.addView(Ui.text(this, t("Connect the AI (free)"), 26f, p.ink).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(14), 0, d(6)) })
        page.addView(Ui.text(this, t("Comboed uses an AI to look at your proof and check the task. It needs a free “API key” — a password that lets the app talk to the AI. It takes about 2 minutes and needs no credit card."), 15f, p.muted, bold = false).apply { gravity = Gravity.CENTER })

        page.addView(Ui.segmented(this, listOf("OpenRouter", "Google Gemini"), provider) { provider = it; render() }, Ui.lp(this, 20))

        val steps = if (provider == 0) listOf(
            "Tap “Open the key page” below.",
            "Sign in (the Google button is the quickest).",
            "Tap “Create API key”, call it Comboed, and tap Create.",
            "Copy the key — it starts with sk-or-",
            "Come back here and tap “Paste”, then Save."
        ) else listOf(
            "Tap “Open the key page” below.",
            "Sign in with your Google account and accept the terms.",
            "Tap “Create API key”.",
            "Copy the key — it starts with AIza",
            "Come back here and tap “Paste”, then Save."
        )
        val card = Ui.card(this).apply { setPaddingRelative(d(16), d(14), d(16), d(16)) }
        steps.forEachIndexed { i, st ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(0, d(6), 0, d(6)) }
            r.addView(Ui.text(this, (i + 1).toString(), 14f, p.accentInk).apply {
                gravity = Gravity.CENTER; background = Ui.rounded(p.accentSoft, d(14).toFloat())
            }, LinearLayout.LayoutParams(d(28), d(28)))
            r.addView(Ui.text(this, t(st), 15f, p.ink, bold = false).apply { setPaddingRelative(d(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            card.addView(r)
        }
        card.addView(Ui.button(this, t("Open the key page"), R.drawable.ui_globe, p.accent, Color.WHITE) {
            val url = if (provider == 0) "https://openrouter.ai/keys" else "https://aistudio.google.com/app/apikey"
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {
                Toast.makeText(this, url, Toast.LENGTH_LONG).show()
            }
        }, Ui.lp(this, 12))
        page.addView(card, Ui.lp(this, 14))

        // paste + save
        val box = Ui.card(this).apply { setPaddingRelative(d(16), d(10), d(16), d(16)) }
        val field = EditText(this).apply {
            hint = if (provider == 0) "sk-or-…" else "AIza…"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setText(sp().getString("key", "") ?: "")
        }
        box.addView(field)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(this, t("Paste"), R.drawable.ui_file, p.track, p.ink, 46) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val txt = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
            if (txt.isEmpty()) Toast.makeText(this, t("Nothing copied yet"), Toast.LENGTH_SHORT).show() else field.setText(txt)
        }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginEnd = d(5) })
        row.addView(Ui.button(this, t("Save"), R.drawable.ui_check, p.accent, Color.WHITE, 46) { save(field.text.toString().trim()) },
            LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = d(5) })
        box.addView(row, Ui.lp(this, 10))
        page.addView(box, Ui.lp(this, 12))

        page.addView(Ui.text(this, t("Your key stays on this phone and is never included in cloud backups."), 12f, p.muted, bold = false).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(10), 0, 0) })
        page.addView(Ui.text(this, t("Skip for now (test mode)"), 15f, p.accentInk).apply {
            gravity = Gravity.CENTER; setPaddingRelative(0, d(18), 0, d(8)); isClickable = true
            setOnClickListener { sp().edit().putBoolean("keyOnboarded", true).apply(); finish() }
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
    }

    private fun save(key: String) {
        if (key.isEmpty()) { Toast.makeText(this, t("Paste your key first"), Toast.LENGTH_SHORT).show(); return }
        val looksOk = key.startsWith("sk-or-") || key.startsWith("AIza") || key.startsWith("sk-ant")
        val doSave = {
            val e = sp().edit().putString("key", key).putBoolean("keyOnboarded", true)
            e.apply()
            Toast.makeText(this, t("Saved! The AI is connected. ✅"), Toast.LENGTH_LONG).show()
            finish()
        }
        if (looksOk) doSave()
        else android.app.AlertDialog.Builder(this).setTitle(t("Is that the right key?"))
            .setMessage(t("Keys usually start with sk-or- (OpenRouter) or AIza (Google). Save it anyway?"))
            .setPositiveButton(t("Save")) { _, _ -> doSave() }.setNegativeButton(t("Cancel"), null).show()
    }
}
