package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Fake, harmless "ads" prank. Mini-categories (combinable creator-key flags):
 *  ads_banner   — a cheap ad strip at the bottom of the menu
 *  ads_dodge    — a full-screen interstitial whose close X runs from your finger
 *  ads_remove   — a "Remove ads $4.99" button that only roasts you
 *  ads_click    — tapping an ad fires a joke instead of going anywhere
 *  ads_escalate — ads get more frequent the longer it's on
 * Nothing here is real, networked, or able to touch points/data.
 */
object Ads {
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
    private fun on(c: Context, k: String) = sp(c).getBoolean(k, false)

    // Plain-English ad copy (default). Temu parody lines are shared by both.
    private val COPY = listOf(
        "🔥 Hot single goats in your area 🐐",
        "You're the 1,000,000th visitor! Claim your prize (it's homework)",
        "Doctors hate him! Local kid does chores and wins",
        "⚠️ Your battery is 1% emotionally. Upgrade now",
        "You really thought this ad was real?",
        "FREE V-BUCKS* (*not real) — tap here",
        "This banner is watching you 👁️",
        "Tap 3 more ads to unlock… more ads",
        "Congratulations! You've been selected for nothing 🎉",
        "Your phone has 1 (one) vibe. Tap to optimize",
        "🛍️ TEMU: Shop like a billionaire! 90% OFF everything",
        "⏰ TEMU flash sale ends in 00:03! (it won't)",
        "TEMU: Spin to win a FREE iPhone (you won't)",
        "🎁 TEMU: Your cart misses you — come back",
        "TEMU: 3,000,000 sold today! Buy more junk now 📦"
    )
    // Gen Z flavored copy, only used while Gen Z mode is on.
    private val COPY_GENZ = listOf(
        "🔥 Hot single GOATS in your area 🐐",
        "You're the 1,000,000th user! Claim your prize (it's homework) 😭",
        "Doctors HATE him! Local kid does chores, earns infinite aura 💀",
        "⚠️ Your rizz is critically low. Upgrade now ✌️",
        "Bro really thought this ad was real 😭",
        "FREE V-BUCKS* (*not real) — tap here 💔",
        "This banner is literally watching you 👁️",
        "Tap 3 more ads to unlock… more ads 🥀",
        "ngl you've been selected for nothing 🎉",
        "Your phone has 1 (one) vibe. optimize it 💀",
        "🛍️ TEMU: shop like a billionaire, 90% off fr 🤑",
        "⏰ TEMU flash sale ends in 00:03 💸 (it won't)",
        "TEMU: spin to win a free iPhone 📱 (you won't)",
        "🎁 TEMU: ur cart misses you 🥺 come back",
        "TEMU: 3,000,000 sold today, buy more junk 📦"
    )
    // Hebrew ad copy, used while the app language is Hebrew.
    private val COPY_HE = listOf(
        "🔥 עיזים רווקות לוהטות באזור שלך 🐐",
        "אתם המבקר ה‑1,000,000! ממשו את הפרס (זה שיעורי בית)",
        "רופאים שונאים אותו! ילד מהשכונה עושה מטלות ומנצח",
        "⚠️ הסוללה שלכם במצב רגשי של 1%. שדרגו עכשיו",
        "באמת חשבתם שהפרסומת הזאת אמיתית?",
        "וי‑באקס חינם* (*לא אמיתי) — הקישו כאן",
        "הבאנר הזה צופה בכם 👁️",
        "הקישו על עוד 3 פרסומות כדי לפתוח… עוד פרסומות",
        "מזל טוב! נבחרתם ללא כלום 🎉",
        "לטלפון שלכם יש וייב אחד (1). הקישו לאופטימיזציה",
        "🛍️ TEMU: לקנות כמו מיליארדר! 90% הנחה על הכול",
        "⏰ מבצע הבזק של TEMU מסתיים בעוד 00:03! (לא באמת)",
        "TEMU: סובבו וזכו באייפון חינם (לא תזכו)",
        "🎁 TEMU: העגלה שלכם מתגעגעת — חזרו",
        "TEMU: 3,000,000 נמכרו היום! קנו עוד ג'אנק 📦"
    )
    private fun copy(c: Context) = when {
        Lang.isHebrew(c) -> COPY_HE
        Voice.active(c) == "genz" -> COPY_GENZ
        else -> COPY
    }.random()

    private val AD_FLAGS = listOf("ads_banner", "ads_dodge", "ads_remove", "ads_escalate", "ads_click")
    fun anyOn(c: Context) = AD_FLAGS.any { on(c, it) }

    fun turnOff(c: Context) {
        val e = sp(c).edit()
        for (f in AD_FLAGS) e.putBoolean(f, false)
        e.putInt("adLevel", 0).apply()
    }

    /** Disable ads by "paying" 300 coins of the current profile. Returns true if it went through. */
    fun disableFor300(a: Activity): Boolean {
        val id = Profiles.currentId(a)
        val key = "state__$id"
        val st = try { org.json.JSONObject(sp(a).getString(key, "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        val coins = st.optInt("coins", 0)
        if (coins < 300) return false
        st.put("coins", coins - 300)
        sp(a).edit().putString(key, st.toString()).apply()
        turnOff(a)
        return true
    }

    /** A big banner view to pin at the bottom of the menu (bumps escalation). Null if no banner. */
    fun bannerView(a: Activity): View? {
        if (on(a, "ads_escalate")) {
            val lvl = sp(a).getInt("adLevel", 0) + 1
            sp(a).edit().putInt("adLevel", lvl).apply()
        }
        if (!on(a, "ads_banner")) return null
        val d = a.resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val banner = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
            minimumHeight = (96 * d).toInt()
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#13131c")); setStroke((2 * d).toInt(), Color.parseColor("#3a3a5a"))
            }
            isClickable = true
            setOnClickListener { showInterstitial(a, dodge = false) } // tapping a banner opens a normal ad
        }
        banner.addView(TextView(a).apply {
            text = Lang.t(a, "Sponsored"); textSize = 11f; setTextColor(Color.parseColor("#888888"))
        })
        banner.addView(TextView(a).apply {
            text = copy(a); textSize = 18f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt())
        })
        banner.addView(TextView(a).apply {
            text = Lang.t(a, "Tap to learn more ›"); textSize = 12f; setTextColor(Color.parseColor("#3ee6ff"))
        })
        return banner
    }

    /** Called after the menu is shown: usually pop a full-screen dodging-X interstitial. */
    fun maybeInterstitial(a: Activity) {
        if (!on(a, "ads_dodge")) return
        val base = 0.9
        val boost = if (on(a, "ads_escalate")) minOf(0.1, sp(a).getInt("adLevel", 0) * 0.02) else 0.0
        if (Math.random() > base + boost) return
        showInterstitial(a, dodge = true)
    }

    /** Force a dodging interstitial right away (e.g. the instant ads are unlocked). */
    fun forceInterstitial(a: Activity) {
        if (on(a, "ads_dodge")) showInterstitial(a, dodge = true)
    }

    private fun showInterstitial(a: Activity, dodge: Boolean) {
        val dlg = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val dm = a.resources.displayMetrics
        val pad = (20 * dm.density).toInt()
        val frame = FrameLayout(a).apply { setBackgroundColor(Color.parseColor("#0b0b14")) }

        val content = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        content.addView(TextView(a).apply {
            text = Lang.t(a, "ADVERTISEMENT"); textSize = 12f; setTextColor(Color.parseColor("#888888")); gravity = Gravity.CENTER
        })
        content.addView(TextView(a).apply {
            text = copy(a); textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad)
        })
        content.addView(TextView(a).apply {
            text = Lang.t(a, if (dodge) "tap the X to continue" else "tap the X to close")
            textSize = 13f; setTextColor(Color.parseColor("#aaaaaa")); gravity = Gravity.CENTER
        })
        if (on(a, "ads_remove")) {
            content.addView(Button(a).apply {
                text = Lang.t(a, "Remove ads – \$4.99"); setOnClickListener { fakePurchase(a) }
            })
        }
        frame.addView(content, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply { gravity = Gravity.CENTER })

        val xBtn = Button(a).apply { text = "✕"; textSize = 18f }
        val xSize = (52 * dm.density).toInt()
        val xlp = FrameLayout.LayoutParams(xSize, xSize)
        xlp.leftMargin = dm.widthPixels - xSize - pad
        xlp.topMargin = pad * 2
        frame.addView(xBtn, xlp)

        if (dodge) {
            var dodges = 0
            var lastDodge = 0L
            // Dodges a lot — more the longer ads have escalated.
            val maxDodge = 14 + if (on(a, "ads_escalate")) minOf(20, sp(a).getInt("adLevel", 0)) else 0
            fun flee(v: View) {
                val maxX = (frame.width.takeIf { it > 0 } ?: dm.widthPixels) - v.width
                val maxY = (frame.height.takeIf { it > 0 } ?: dm.heightPixels) - v.height
                v.x = (Math.random() * maxX).toFloat().coerceAtLeast(0f)
                v.y = (Math.random() * maxY).toFloat().coerceAtLeast(0f)
            }
            xBtn.setOnTouchListener { v, ev ->
                // One dodge per fresh tap (400ms cooldown); after maxDodge the X stops and closes.
                if (ev.action == MotionEvent.ACTION_DOWN && dodges < maxDodge) {
                    val now = android.os.SystemClock.uptimeMillis()
                    if (now - lastDodge >= 400) { lastDodge = now; dodges++; flee(v) }
                    true
                } else false
            }
        }
        xBtn.setOnClickListener { dlg.dismiss() }

        dlg.setContentView(frame)
        dlg.setCancelable(!dodge) // a normal ad can be dismissed; the dodging one must be out-tapped
        runCatching { dlg.show() }
    }

    // A FAKE payment screen. It is a prop: nothing typed here is ever read, stored, or sent
    // anywhere, and no money can change hands. It always "fails" and reveals the joke.
    fun fakePurchase(a: Activity) {
        val pad = (16 * a.resources.displayMetrics.density).toInt()
        val form = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, 0) }
        form.addView(TextView(a).apply { text = Lang.t(a, "Secure checkout · \$4.99"); textSize = 13f; setTextColor(Color.parseColor("#888888")) })
        fun mkField(hintText: String, numeric: Boolean) = android.widget.EditText(a).apply {
            hint = Lang.t(a, hintText)
            inputType = if (numeric) android.text.InputType.TYPE_CLASS_NUMBER else android.text.InputType.TYPE_CLASS_TEXT
        }
        val nameF = mkField("Name on card", false); form.addView(nameF)
        val numF = mkField("Card number", true); form.addView(numF)
        val rowL = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        rowL.addView(mkField("MM/YY", false).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        rowL.addView(mkField("CVV", true).apply { layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f) })
        form.addView(rowL)

        AlertDialog.Builder(a)
            .setTitle(Lang.t(a, "Remove ads – \$4.99"))
            .setView(form)
            .setPositiveButton(Lang.t(a, "Pay \$4.99")) { _, _ ->
                // We only check whether the fields are empty (never read, store or send the values).
                val empty = nameF.text.isNullOrBlank() && numF.text.isNullOrBlank()
                val genz = Voice.active(a) == "genz"
                val he = Lang.isHebrew(a)
                val msg = when {
                    he && empty -> "אפילו לא הקלדתם כרטיס — נדחה בכל מקרה.\n\nזו מתיחה: שום דבר לא הוזן, לא חויב ולא נשמר. הפרסומות חינם, והן לנצח."
                    he -> "זו מתיחה. שום דבר שהקלדתם לא נקרא, לא חויב ולא נשמר — הפרסומות חינם, והן לנצח. ניסיון יפה!"
                    empty && genz -> "you didn't even type a card 💀 declined anyway. it's a prank — nothing was entered, charged or saved. ads are free & forever 😈"
                    empty -> "You didn't enter a card — declined anyway.\n\nIt's a prank: nothing was entered, charged or saved. The ads are free, and they are forever."
                    genz -> "lmao you really typed ur card in 💀 it's a prank, nothing was entered, charged or saved. ads are free & forever 😈"
                    else -> "This is a prank. Nothing you typed was read, charged or saved — the ads are free, and they are forever. Nice try!"
                }
                AlertDialog.Builder(a)
                    .setTitle(Lang.t(a, "Payment declined ❌"))
                    .setMessage(msg)
                    .setPositiveButton(Lang.t(a, "...ugh"), null)
                    .show()
            }
            .setNegativeButton(Lang.t(a, "Cancel"), null)
            .show()
    }
}
