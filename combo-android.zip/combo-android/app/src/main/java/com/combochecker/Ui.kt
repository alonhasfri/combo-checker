package com.combochecker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Shared look for the redesigned screens: palette (light/dark), cards, settings rows, chips,
 * progress bars and the bottom tab bar (Home · Shop · Ranks · Me). Classic mode doesn't use this.
 */
object Ui {
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    class Pal(
        val bg: Int, val card: Int, val border: Int, val ink: Int, val muted: Int,
        val accent: Int, val accentInk: Int, val accentSoft: Int, val track: Int, val divider: Int,
        val danger: Int, val good: Int
    )

    private fun c(hex: Long) = hex.toInt()

    fun isDark(ctx: Context) = Appearance.mode(ctx) == "dark"

    fun pal(ctx: Context): Pal = if (isDark(ctx)) Pal(
        bg = c(0xFF0F1220), card = c(0xFF1A1F33), border = c(0xFF2A3048), ink = c(0xFFEEF1FA),
        muted = c(0xFFA3ABC2), accent = c(0xFF3A5BD9), accentInk = c(0xFFA9BBFF), accentSoft = c(0xFF263266),
        track = c(0xFF2A3048), divider = c(0xFF262C42), danger = c(0xFFFF9DA2), good = c(0xFF7FD9A6)
    ) else Pal(
        bg = c(0xFFF4F6FB), card = c(0xFFFFFFFF), border = c(0xFFE3E7F1), ink = c(0xFF141A2E),
        muted = c(0xFF5B6378), accent = c(0xFF3A5BD9), accentInk = c(0xFF2B47B8), accentSoft = c(0xFFE3E9FF),
        track = c(0xFFE6EAF5), divider = c(0xFFEEF0F6), danger = c(0xFFA8262C), good = c(0xFF17663A)
    )

    /** Icon-tile colors (background, icon) for a named tone. */
    fun tone(ctx: Context, name: String): Pair<Int, Int> {
        val dark = isDark(ctx)
        return when (name) {
            "purple" -> if (dark) Pair(c(0xFF34245E), c(0xFFC9B2FF)) else Pair(c(0xFFECE3FF), c(0xFF5A2FC7))
            "orange" -> if (dark) Pair(c(0xFF4A2A1C), c(0xFFFFB08A)) else Pair(c(0xFFFDE6DE), c(0xFFB23A0B))
            "green" -> if (dark) Pair(c(0xFF1D3A2A), c(0xFF7FD9A6)) else Pair(c(0xFFE3F4EA), c(0xFF17663A))
            "teal" -> if (dark) Pair(c(0xFF163646), c(0xFF8FD3F5)) else Pair(c(0xFFDDF0FB), c(0xFF0E6A9E))
            "red" -> if (dark) Pair(c(0xFF4A1E22), c(0xFFFF9DA2)) else Pair(c(0xFFFBE3E4), c(0xFFA8262C))
            "gray" -> if (dark) Pair(c(0xFF2A3048), c(0xFFC3C9DA)) else Pair(c(0xFFEEF0F6), c(0xFF3A4157))
            "gold" -> if (dark) Pair(c(0xFF3F3218), c(0xFFF2C66B)) else Pair(c(0xFFFFF0D1), c(0xFF8A5A00))
            else -> if (dark) Pair(c(0xFF263266), c(0xFFA9BBFF)) else Pair(c(0xFFE3E9FF), c(0xFF2B47B8))
        }
    }

    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radius: Float, stroke: Int = 0, strokePx: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
        if (strokePx > 0) setStroke(strokePx, stroke)
    }

    fun icon(ctx: Context, res: Int, color: Int): ImageView = ImageView(ctx).apply {
        setImageResource(res)
        setColorFilter(color, PorterDuff.Mode.SRC_IN)
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        // Chevrons and the back arrow point the other way in right-to-left (Hebrew).
        if ((res == R.drawable.ui_chevron || res == R.drawable.ui_back) && Lang.rtl(ctx)) scaleX = -1f
    }

    fun text(ctx: Context, s: String, sp: Float, color: Int, bold: Boolean = true) = TextView(ctx).apply {
        text = s; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun lp(ctx: Context, topDp: Int = 0, w: Int = MATCH) =
        LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dp(ctx, topDp) }

    fun card(ctx: Context): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        val p = pal(ctx)
        background = rounded(p.card, dp(ctx, 20).toFloat(), p.border, dp(ctx, 1))
        clipToOutline = true
    }

    fun ripple(ctx: Context, v: View) {
        val tv = TypedValue()
        if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) v.foreground = ctx.getDrawable(tv.resourceId)
    }

    fun page(ctx: Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(ctx, 20), dp(ctx, 18), dp(ctx, 20), dp(ctx, 28))
    }

    fun tile(ctx: Context, res: Int, toneName: String, boxDp: Int = 34, iconDp: Int = 19): FrameLayout {
        val (bg, ink) = tone(ctx, toneName)
        return FrameLayout(ctx).apply {
            background = rounded(bg, dp(ctx, 10).toFloat())
            addView(icon(ctx, res, ink), FrameLayout.LayoutParams(dp(ctx, iconDp), dp(ctx, iconDp), Gravity.CENTER))
            layoutParams = LinearLayout.LayoutParams(dp(ctx, boxDp), dp(ctx, boxDp))
        }
    }

    fun sectionTitle(ctx: Context, s: String) = text(ctx, s.uppercase(), 13f, pal(ctx).muted).apply {
        letterSpacing = 0.04f
        setPadding(dp(ctx, 4), dp(ctx, 20), dp(ctx, 4), dp(ctx, 8))
    }

    /** A settings-style row: icon tile, label, optional value, optional chevron. */
    fun row(
        ctx: Context, res: Int, toneName: String, label: String, value: String? = null,
        valueColor: Int? = null, chevron: Boolean = true, danger: Boolean = false, onClick: (() -> Unit)? = null
    ): LinearLayout {
        val p = pal(ctx)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(ctx, 56)
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            addView(tile(ctx, res, if (danger) "red" else toneName))
            addView(text(ctx, label, 15f, if (danger) p.danger else p.ink).apply {
                setPadding(dp(ctx, 12), 0, dp(ctx, 8), 0)
            }, LinearLayout.LayoutParams(0, WRAP, 1f))
            if (!value.isNullOrEmpty()) addView(text(ctx, value, 14f, valueColor ?: p.muted).apply {
                maxLines = 1; maxWidth = dp(ctx, 150); ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, 0, dp(ctx, 4), 0)
            })
            if (chevron) addView(icon(ctx, R.drawable.ui_chevron, p.muted), LinearLayout.LayoutParams(dp(ctx, 18), dp(ctx, 18)))
            if (onClick != null) {
                isClickable = true; isFocusable = true
                contentDescription = if (value.isNullOrEmpty()) label else "$label, $value"
                ripple(ctx, this)
                setOnClickListener { onClick() }
            }
        }
    }

    /** A row with an on/off switch and an optional second line. */
    fun switchRow(
        ctx: Context, res: Int, toneName: String, label: String, sub: String?, checked: Boolean,
        enabled: Boolean = true, onChange: (Boolean) -> Unit
    ): LinearLayout {
        val p = pal(ctx)
        val sw = Switch(ctx).apply {
            isChecked = checked; isEnabled = enabled; contentDescription = label
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(ctx, 56)
            setPadding(dp(ctx, 14), dp(ctx, 8), dp(ctx, 14), dp(ctx, 8))
            addView(tile(ctx, res, toneName))
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(ctx, 12), 0, dp(ctx, 8), 0)
                addView(text(ctx, label, 15f, p.ink))
                if (!sub.isNullOrEmpty()) addView(text(ctx, sub, 13f, p.muted, bold = false))
            }
            addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            addView(sw)
            if (enabled) { isClickable = true; ripple(ctx, this); setOnClickListener { sw.toggle() } }
        }
    }

    fun divider(ctx: Context) = View(ctx).apply {
        setBackgroundColor(pal(ctx).divider)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(ctx, 1)).apply { marginStart = dp(ctx, 60) }
    }

    /** A rounded card holding rows separated by thin dividers. */
    fun group(ctx: Context, rows: List<View>): LinearLayout = card(ctx).apply {
        rows.forEachIndexed { i, r ->
            if (i > 0) addView(divider(ctx))
            addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    /** A small rounded pill: icon + text (streak, coins). */
    fun chip(ctx: Context, res: Int, iconColor: Int, label: String): LinearLayout {
        val p = pal(ctx)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(p.card, dp(ctx, 999).toFloat(), p.border, dp(ctx, 1))
            setPadding(dp(ctx, 11), dp(ctx, 7), dp(ctx, 13), dp(ctx, 7))
            addView(icon(ctx, res, iconColor), LinearLayout.LayoutParams(dp(ctx, 17), dp(ctx, 17)))
            addView(text(ctx, label, 14f, p.ink).apply { setPadding(dp(ctx, 6), 0, 0, 0) })
        }
    }

    /** A clickable pill button with an optional icon. */
    fun button(
        ctx: Context, label: String, res: Int?, bg: Int, fg: Int, heightDp: Int = 50,
        stroke: Int = 0, onClick: () -> Unit
    ): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
        background = rounded(bg, dp(ctx, 15).toFloat(), stroke, if (stroke != 0) dp(ctx, 1) else 0)
        minimumHeight = dp(ctx, heightDp)
        setPadding(dp(ctx, 12), 0, dp(ctx, 12), 0)
        if (res != null) addView(icon(ctx, res, fg), LinearLayout.LayoutParams(dp(ctx, 19), dp(ctx, 19)).apply { marginEnd = dp(ctx, 7) })
        addView(text(ctx, label, 15f, fg).apply { maxLines = 1 })
        isClickable = true; isFocusable = true; contentDescription = label
        ripple(ctx, this)
        clipToOutline = true
        setOnClickListener { onClick() }
    }

    /** A 46dp square icon button (e.g. the settings gear in a corner). */
    fun iconButton(ctx: Context, res: Int, desc: String, onClick: () -> Unit): FrameLayout {
        val p = pal(ctx)
        return FrameLayout(ctx).apply {
            background = rounded(p.card, dp(ctx, 14).toFloat(), p.border, dp(ctx, 1))
            addView(icon(ctx, res, p.ink), FrameLayout.LayoutParams(dp(ctx, 22), dp(ctx, 22), Gravity.CENTER))
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 46), dp(ctx, 46))
            isClickable = true; isFocusable = true; contentDescription = desc
            ripple(ctx, this); clipToOutline = true
            setOnClickListener { onClick() }
        }
    }

    /** Big screen title with an optional settings gear in the corner. */
    fun header(a: Activity, title: String, gear: Boolean): LinearLayout = LinearLayout(a).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(text(a, title, 28f, pal(a).ink), LinearLayout.LayoutParams(0, WRAP, 1f))
        if (gear) addView(iconButton(a, R.drawable.ui_gear, Lang.t(a, "Settings")) {
            a.startActivity(Intent(a, SettingsActivity::class.java))
        })
    }

    fun avatar(ctx: Context, profile: JSONObject, sizeDp: Int): TextView = TextView(ctx).apply {
        text = profile.optString("emoji", "⭐"); textSize = sizeDp * 0.42f; gravity = Gravity.CENTER
        val col = try { android.graphics.Color.parseColor(profile.optString("color", "#3a66d6")) } catch (e: Exception) { pal(ctx).accent }
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(col) }
        layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    /** A rounded progress bar (fraction 0..1). */
    fun bar(ctx: Context, fraction: Float, fill: Int, track: Int): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        background = rounded(track, dp(ctx, 5).toFloat())
        val f = fraction.coerceIn(0f, 1f)
        addView(View(ctx).apply { background = rounded(fill, dp(ctx, 5).toFloat()) }, LinearLayout.LayoutParams(0, dp(ctx, 10), f))
        addView(View(ctx), LinearLayout.LayoutParams(0, dp(ctx, 10), 1f - f))
    }

    // ----- bottom tab bar -----
    private val TABS = listOf(
        Triple("home", R.drawable.ui_home, "Home"),
        Triple("shop", R.drawable.ui_bag, "Shop"),
        Triple("ranks", R.drawable.ui_trophy, "Ranks"),
        Triple("me", R.drawable.ui_user, "Me")
    )

    private fun target(key: String): Class<*> = when (key) {
        "shop" -> ShopActivity::class.java
        "ranks" -> LeaderboardActivity::class.java
        "me" -> MeActivity::class.java
        else -> MainActivity::class.java
    }

    /** Home is the base screen; the other tabs open on top of it and replace each other. */
    private fun go(a: Activity, from: String, to: String) {
        if (from == to) return
        if (to == "home") { a.finish(); a.overridePendingTransition(0, 0); return }
        a.startActivity(Intent(a, target(to)))
        a.overridePendingTransition(0, 0)
        if (from != "home") a.finish()
    }

    fun bottomNav(a: Activity, active: String): LinearLayout {
        val p = pal(a)
        val bar = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(p.card)
            setPadding(dp(a, 6), dp(a, 8), dp(a, 6), dp(a, 12))
        }
        for ((key, res, label) in TABS) {
            val on = key == active
            val name = Lang.t(a, label)
            val item = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true; isFocusable = true
                contentDescription = name
                isSelected = on
                setOnClickListener { go(a, active, key) }
            }
            val pill = FrameLayout(a).apply { if (on) background = rounded(p.accentSoft, dp(a, 15).toFloat()) }
            pill.addView(icon(a, res, if (on) p.accentInk else p.muted), FrameLayout.LayoutParams(dp(a, 21), dp(a, 21), Gravity.CENTER))
            item.addView(pill, LinearLayout.LayoutParams(dp(a, 58), dp(a, 30)))
            item.addView(text(a, name, 12f, if (on) p.accentInk else p.muted).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(a, 3), 0, 0)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
            bar.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        return LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            addView(View(a).apply { setBackgroundColor(p.border) }, LinearLayout.LayoutParams(MATCH, dp(a, 1)))
            addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    /** A tab screen: scrolling content above the bottom tab bar. */
    fun tabScreen(a: Activity, content: View, active: String) {
        val p = pal(a)
        val scroll = ScrollView(a).apply { setBackgroundColor(p.bg); isFillViewport = true; addView(content) }
        val outer = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(p.bg) }
        outer.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        outer.addView(bottomNav(a, active), LinearLayout.LayoutParams(MATCH, WRAP))
        a.setContentView(outer)
    }
}

/** Levels, streaks, today's goal and weekly totals for the current profile. */
object Progress {
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)

    fun state(c: Context): JSONObject =
        try { JSONObject(sp(c).getString(Profiles.stateKey(c), "") ?: "") } catch (e: Exception) { JSONObject() }

    fun gallery(c: Context): JSONArray =
        try { JSONArray(sp(c).getString(Profiles.galleryKey(c), "[]")) } catch (e: Exception) { JSONArray() }

    fun level(total: Int) = Math.floor(Math.sqrt(total / 25.0)).toInt() + 1

    private val RANKS = listOf("Rookie", "Apprentice", "Doer", "Achiever", "Pro", "Expert", "Master", "Champion", "Legend", "Mythic")
    fun rank(c: Context, level: Int) = Lang.t(c, RANKS[minOf(level, RANKS.size) - 1])

    /** Points still needed for the next level, and progress through the current level (0..1). */
    fun toNext(total: Int): Pair<Int, Float> {
        val l = level(total)
        val lo = 25 * (l - 1) * (l - 1)
        val hi = 25 * l * l
        return Pair(hi - total, (total - lo).toFloat() / (hi - lo).toFloat())
    }

    // Same key format as the game (combo.html): year-month-day, no zero padding.
    fun dayKey(cal: Calendar) = "" + cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1) + "-" + cal.get(Calendar.DAY_OF_MONTH)
    fun todayKey() = dayKey(Calendar.getInstance())

    fun goal(c: Context) = sp(c).getInt("goal", 3)

    fun todayCount(c: Context): Int {
        val st = state(c)
        return if (st.optString("day") == todayKey()) st.optInt("dayCount", 0) else 0
    }

    fun questDone(c: Context, i: Int): Boolean {
        val q = state(c).optJSONObject("quests") ?: return false
        if (q.optString("day") != todayKey()) return false
        return q.optJSONArray("done")?.optBoolean(i) ?: false
    }

    /** Consecutive days with at least one finished task, ending today (or yesterday). */
    fun dayStreak(c: Context): Int {
        val g = gallery(c)
        val days = HashSet<String>()
        for (i in 0 until g.length()) {
            val t = g.optJSONObject(i)?.optLong("time") ?: 0L
            if (t > 0) { val cal = Calendar.getInstance(); cal.timeInMillis = t; days.add(dayKey(cal)) }
        }
        val cal = Calendar.getInstance()
        if (!days.contains(dayKey(cal))) cal.add(Calendar.DAY_OF_MONTH, -1)
        var n = 0
        while (days.contains(dayKey(cal))) { n++; cal.add(Calendar.DAY_OF_MONTH, -1) }
        return n
    }

    /** Last 7 days: tasks, points, bonuses. */
    fun week(c: Context): IntArray {
        val g = gallery(c)
        val since = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        var tasks = 0; var points = 0; var bonuses = 0
        for (i in 0 until g.length()) {
            val o = g.optJSONObject(i) ?: continue
            if (o.optLong("time") >= since) { tasks++; points += o.optInt("points"); bonuses += o.optInt("bonuses") }
        }
        return intArrayOf(tasks, points, bonuses)
    }

    /** A friendly weekly coaching line + tip (local, no AI key). */
    fun coach(c: Context): String {
        val w = week(c); val tasks = w[0]; val points = w[1]; val bonuses = w[2]
        return if (Lang.isHebrew(c)) when {
            tasks == 0 -> "עדיין לא התחלת השבוע — תתחילו בקטן: משימה אחת מהירה היום מתחילה את הרצף. 🌱"
            tasks >= 5 -> "שבוע אלוף! $tasks משימות ו‑$points נקודות. 🔥 טיפ: כוונו לבונוס נוסף בכל בדיקה — עבודה מסודרת ומלאה."
            bonuses == 0 -> "יופי של התחלה — $tasks משימות השבוע. 💪 טיפ: נסו להרוויח בונוס אחד בבדיקה הבאה (מסודר, שלם, מדויק)."
            else -> "המשיכו ככה — $tasks משימות ו‑$bonuses בונוסים! 💪 טיפ: עוד משימה קטנה היום שומרת על הרצף."
        } else when {
            tasks == 0 -> "Nothing yet this week — start small: one quick task today gets your streak going. 🌱"
            tasks >= 5 -> "Champion week! $tasks tasks and $points points. 🔥 Tip: aim for one extra bonus each check — go for neat, complete work."
            bonuses == 0 -> "Nice start — $tasks tasks this week. 💪 Tip: try to earn one bonus next check (neat, complete, accurate)."
            else -> "Keep it up — $tasks tasks and $bonuses bonuses! 💪 Tip: one more small task today keeps your streak alive."
        }
    }
}
