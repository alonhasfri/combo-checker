package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri

/** Which edition this is (safe = public, full = with pranks) and how to switch. */
object Edition {
    val FULL: Boolean = BuildConfig.FULL
    const val SAFE_APK = "https://github.com/alonhasfri/combo-checker/releases/latest/download/combo-checker.apk"
    const val FULL_APK = "https://github.com/alonhasfri/combo-checker/releases/latest/download/comboed-full.apk"

    fun title(a: Activity) = Lang.t(a, if (FULL) "Full version" else "Safe version")

    /** Explain the two versions and let the person choose (download the other one). */
    fun showSwitch(a: Activity) {
        val he = Lang.isHebrew(a)
        if (!FULL) {
            AlertDialog.Builder(a)
                .setTitle(if (he) "🔓 הגרסה המלאה" else "🔓 The full version")
                .setMessage(if (he)
                    "הגרסה המלאה מוסיפה את התוספות המצחיקות: מתיחות לחברים (מסכי התחברות, קריסות ופרסומות מזויפים), מפתחות עדכון וקולות מצחיקים.\n\n⚠️ שימו לב: בגלל התוספות האלה, Google עלולה להציג הודעה שהאפליקציה \"עלולה להזיק\". היא לא מזיקה — המתיחות לא שומרות ולא שולחות שום דבר — אבל אם אתם לא סומכים עלינו, הישארו בגרסה הבטוחה. זה בסדר גמור.\n\nההורדה מתקינה את הגרסה המלאה מעל הנוכחית, וכל ההתקדמות נשמרת."
                else
                    "The full version adds the fun extras: pranks for friends (fake login, fake crashes, fake ads), update keys and funny voices.\n\n⚠️ Beware: because of these extras, Google may show a warning that the app \"might be harmful\". It isn't — the pranks don't save or send anything — but if you don't trust us, stay on the safe version. That's completely fine.\n\nThe download installs the full version over this one and keeps all your progress.")
                .setPositiveButton(if (he) "הורדת הגרסה המלאה" else "Download the full version") { _, _ -> open(a, FULL_APK) }
                .setNegativeButton(if (he) "להישאר בגרסה הבטוחה" else "Stay on the safe version", null)
                .show()
        } else {
            AlertDialog.Builder(a)
                .setTitle(if (he) "🛡️ הגרסה הבטוחה" else "🛡️ The safe version")
                .setMessage(if (he) "את/ה בגרסה המלאה. הגרסה הבטוחה זהה אבל בלי המתיחות והקולות המצחיקים, ולכן Google פחות מזהירה עליה. ההורדה מתקינה אותה מעל הנוכחית והכול נשמר."
                    else "You're on the full version. The safe version is the same app without the pranks and funny voices, so Google is less likely to warn about it. The download installs it over this one and keeps everything.")
                .setPositiveButton(if (he) "הורדת הגרסה הבטוחה" else "Download the safe version") { _, _ -> open(a, SAFE_APK) }
                .setNegativeButton(Lang.t(a, "Cancel"), null).show()
        }
    }

    private fun open(a: Activity, url: String) {
        try { a.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
    }
}
