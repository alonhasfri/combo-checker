package com.combochecker

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream

/** Grabs a single full-screen frame via MediaProjection, saves it, and reports the file path. */
class CaptureService : Service() {

    companion object {
        @Volatile
        var onDone: ((String?) -> Unit)? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification(this, "Capturing the screen", false)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(2, n)
        }

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent.parcelableIntent("data")
        if (data == null) {
            finishWith(null)
            return START_NOT_STICKY
        }
        // Wait briefly so the system permission dialog is fully gone before the frame is taken.
        handler.postDelayed({ capture(code, data) }, 450)
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun capture(code: Int, data: Intent) {
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val projection = mpm.getMediaProjection(code, data)
            // Android 14+ requires a callback to be registered before creating the virtual display.
            projection.registerCallback(object : MediaProjection.Callback() {}, handler)

            val dm = DisplayMetrics()
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            val w = dm.widthPixels
            val h = dm.heightPixels

            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            val display = projection.createVirtualDisplay(
                "combo-capture", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface, null, handler
            )

            var done = false
            fun cleanup() {
                runCatching { display.release() }
                runCatching { reader.close() }
                runCatching { projection.stop() }
            }

            reader.setOnImageAvailableListener({ r ->
                if (done) return@setOnImageAvailableListener
                val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
                done = true
                var path: String? = null
                try {
                    val plane = image.planes[0]
                    val rowPadding = plane.rowStride - plane.pixelStride * w
                    val wide = Bitmap.createBitmap(
                        w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888
                    )
                    wide.copyPixelsFromBuffer(plane.buffer)
                    val shot = Bitmap.createBitmap(wide, 0, 0, w, h)
                    val file = File(cacheDir, "shot.jpg")
                    FileOutputStream(file).use { shot.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                    path = file.absolutePath
                } catch (e: Exception) {
                    path = null
                } finally {
                    image.close()
                    cleanup()
                }
                finishWith(path)
            }, handler)

            // Safety net in case no frame ever arrives.
            handler.postDelayed({
                if (!done) {
                    done = true
                    cleanup()
                    finishWith(null)
                }
            }, 4000)
        } catch (e: Exception) {
            finishWith(null)
        }
    }

    private fun finishWith(path: String?) {
        onDone?.invoke(path)
        onDone = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }
}
