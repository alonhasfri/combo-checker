package com.combochecker

import android.app.Activity
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.io.File
import java.text.DateFormat
import java.util.Date

/** Shows the proofs of every task you completed, newest first. Everything stays on the phone. */
class GalleryActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        Profiles.ensureDefault(this)
        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()

        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        list.addView(TextView(this).apply {
            text = "🏆 Proof gallery"
            textSize = 24f
        })

        val arr = JSONArray(prefs.getString(Profiles.galleryKey(this), "[]"))
        val dir = File(filesDir, "proofs")

        if (arr.length() == 0) {
            list.addView(TextView(this).apply {
                text = "Nothing here yet. Finish a task and your winning proof shows up here."
                textSize = 15f
                setPadding(0, pad, 0, pad)
            })
        } else {
            list.addView(Button(this).apply {
                text = "Clear gallery"
                setOnClickListener {
                    android.app.AlertDialog.Builder(this@GalleryActivity)
                        .setTitle("Clear gallery?")
                        .setMessage("This permanently deletes every saved proof for this profile. This can't be undone.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete all") { _, _ ->
                            for (j in 0 until arr.length()) {
                                runCatching { File(dir, arr.getJSONObject(j).getString("file")).delete() }
                            }
                            prefs.edit().putString(Profiles.galleryKey(this@GalleryActivity), "[]").apply()
                            Toast.makeText(this@GalleryActivity, "Gallery cleared", Toast.LENGTH_SHORT).show()
                            finish()
                        }
                        .show()
                }
            })
        }

        // Newest first, at most 40 shown so the screen stays light
        var shown = 0
        for (i in arr.length() - 1 downTo 0) {
            if (shown >= 40) break
            val o = arr.getJSONObject(i)
            val file = File(dir, o.getString("file"))

            if (file.exists()) {
                val opts = BitmapFactory.Options().apply { inSampleSize = 3 }
                val bmp = BitmapFactory.decodeFile(file.absolutePath, opts)
                if (bmp != null) {
                    list.addView(ImageView(this).apply {
                        setImageBitmap(bmp)
                        adjustViewBounds = true
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = pad }
                    })
                }
            }

            val task = o.optString("task").ifBlank { "(no task name)" }
            val date = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)
                .format(Date(o.optLong("time")))
            list.addView(TextView(this).apply {
                text = "$task\n+${o.optInt("points")} pts · ${o.optInt("bonuses")} bonuses · $date"
                textSize = 14f
                setPadding(0, pad / 4, 0, 0)
            })
            shown++
        }

        setContentView(ScrollView(this).apply { addView(list) })
    }
}
