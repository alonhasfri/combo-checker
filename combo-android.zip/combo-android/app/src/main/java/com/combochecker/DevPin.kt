package com.combochecker

import java.security.MessageDigest

/** Developer PIN check. Only a salted SHA-256 of the PIN is stored, so the PIN isn't readable in the code. */
object DevPin {
    private const val HASH = "36011b300dd5718f27cc2b36e36eb909ffb85297be541dfbfd9c03a292d721c7"
    fun ok(entered: String): Boolean {
        val d = MessageDigest.getInstance("SHA-256").digest(("comboed-dev:" + entered.trim()).toByteArray())
        return d.joinToString("") { "%02x".format(it) } == HASH
    }
}
