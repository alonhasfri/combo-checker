package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context

/**
 * Fake "Crash mode". Shows a convincing but harmless "Combo Checker keeps stopping" system-style
 * dialog on every open. It never actually crashes, loses data, or closes the app — the buttons just
 * dismiss it, so the victim can still reach Settings to turn it off.
 */
object Crash {
    private fun on(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("crash", false)

    fun maybeShow(a: Activity) {
        if (!on(a)) return
        show(a)
    }

    private fun show(a: Activity) {
        AlertDialog.Builder(a)
            .setTitle("Combo Checker keeps stopping")
            .setNegativeButton("Close app") { d, _ -> d.dismiss() }
            .setPositiveButton("App info") { d, _ -> d.dismiss() }
            .setCancelable(false)
            .show()
    }
}
