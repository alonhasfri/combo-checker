package com.combochecker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Read-only stats and badges for the player. */
class StatsActivity : Activity() {

    private val ranks = listOf(
        "Rookie", "Apprentice", "Doer", "Achiever", "Pro",
        "Expert", "Master", "Champion", "Legend", "Mythic"
    )
    private val achNames = linkedMapOf(
        "first_win" to "First Win", "wins10" to "10 Tasks Done", "wins50" to "50 Tasks Done",
        "combo3" to "Combo x3", "combo5" to "Combo x5", "level5" to "Level 5",
        "level10" to "Level 10", "collector" to "Collector (3 skins)"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val sp = getSharedPreferences("combo", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        Profiles.ensureDefault(this)
        val st = try { JSONObject(sp.getString(Profiles.stateKey(this), "") ?: "") } catch (e: Exception) { JSONObject() }
        val total = st.optInt("total", 0)
        val level = Math.floor(Math.sqrt(total / 25.0)).toInt() + 1
        val rank = ranks[minOf(level, ranks.size) - 1]
        val coins = st.optInt("coins", 0)
        val wins = st.optInt("wins", 0)
        val best = st.optInt("bestStreak", 0)

        val gallery = try { JSONArray(sp.getString(Profiles.galleryKey(this), "[]")) } catch (e: Exception) { JSONArray() }
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        var weekTasks = 0
        for (i in 0 until gallery.length()) if (gallery.getJSONObject(i).optLong("time") >= weekAgo) weekTasks++

        val isHe = Lang.isHebrew(this)
        fun tr(s: String) = Lang.t(this, s)
        fun he(e: String, h: String) = if (isHe) h else e
        fun head(t: String) = root.addView(TextView(this).apply {
            text = tr(t); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
        fun line(t: String) = root.addView(TextView(this).apply { text = t; textSize = 16f; setPadding(0, pad / 6, 0, 0) })

        root.addView(TextView(this).apply {
            text = tr("📊 Your stats"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })

        head("Progress")
        line(he("Level", "רמה") + " " + level + " — " + tr(rank))
        line(he("Points:", "נקודות:") + " " + total)
        line(he("Coins:", "מטבעות:") + " " + coins)
        line(he("Tasks passed:", "משימות שעברו:") + " " + wins)
        line(he("Longest streak:", "הרצף הארוך ביותר:") + " " + best + " " + he("in a row", "ברצף"))
        line(he("Tasks this week:", "משימות השבוע:") + " " + weekTasks)

        head("Badges")
        val achv = st.optJSONArray("achv") ?: JSONArray()
        val unlocked = HashSet<String>()
        for (i in 0 until achv.length()) unlocked.add(achv.optString(i))
        line(he("Unlocked:", "נפתחו:") + " " + unlocked.size + " / " + achNames.size)
        for ((id, name) in achNames) line((if (unlocked.contains(id)) "✅ " else "🔒 ") + tr(name))

        head("Today's quests")
        val quests = st.optJSONObject("quests")
        val done = quests?.optJSONArray("done")
        val active = quests?.optString("day") == todayKey()
        val qtexts = listOf("Finish 3 tasks today", "Land a combo (x1.5+)", "Earn 2 bonuses in one check")
        for (i in qtexts.indices) {
            val d = active && done != null && i < done.length() && done.optBoolean(i)
            line((if (d) "✅ " else "• ") + tr(qtexts[i]))
        }

        root.addView(Button(this).apply { text = tr("Done"); setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun todayKey(): String {
        val c = java.util.Calendar.getInstance()
        return "" + c.get(java.util.Calendar.YEAR) + "-" +
            (c.get(java.util.Calendar.MONTH) + 1) + "-" + c.get(java.util.Calendar.DAY_OF_MONTH)
    }
}
