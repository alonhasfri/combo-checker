package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** "Who's using?" launcher screen: pick / add / remove named profiles, or enter the Parent zone. */
class ProfileActivity : Activity() {

    private val emojis = listOf("⭐", "🚀", "🐱", "🐶", "🦄", "🐧", "🦊", "🐉", "🎈", "🎮", "🌟", "🔥")
    private val colors = listOf("#3a66d6", "#2a7d46", "#D62F9B", "#E8491D", "#6A2FE8", "#E8B500", "#0a9cc0", "#c0392b")
    private var pad = 0
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = Lang.t(this@ProfileActivity, "Who's using Comboed?"); textSize = 24f; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, pad / 4)
        })
        root.addView(TextView(this).apply {
            text = Lang.t(this@ProfileActivity, "Tap to open. Press and hold a profile to lock it with a PIN or delete it.")
            textSize = 13f; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, pad)
        })

        val arr = Profiles.list(this)
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            root.addView(profileRow(p.optString("id"), p.optString("name"), p.optString("emoji", "⭐"), p.optString("color", "#3a66d6")))
        }

        root.addView(Button(this).apply {
            text = Lang.t(this@ProfileActivity, "➕ Add profile")
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
            setOnClickListener { addProfileDialog() }
        })

        root.addView(TextView(this).apply {
            text = Lang.t(this@ProfileActivity, "For parents"); textSize = 16f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
        root.addView(profileRow("__parent__", Lang.t(this, "Parent zone"), "👪", "#555770"))
    }

    private fun profileRow(id: String, name: String, emoji: String, color: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        val avatarSize = (46 * resources.displayMetrics.density).toInt()
        row.addView(TextView(this).apply {
            text = emoji; textSize = 22f; gravity = Gravity.CENTER
            width = avatarSize; height = avatarSize
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(color)) }
        })
        val locked = id != "__parent__" && Profiles.hasPin(this, id)
        row.addView(TextView(this).apply {
            text = "   " + name + (if (locked) "  🔒" else "")
            textSize = 20f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.setOnClickListener {
            when {
                id == "__parent__" -> openParent()
                locked -> promptProfilePin(id)
                else -> openProfile(id)
            }
        }
        if (id != "__parent__") row.setOnLongClickListener { manageProfileDialog(id, name); true }
        return row
    }

    private fun addProfileDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val nameF = EditText(this).apply { hint = Lang.t(this@ProfileActivity, "Name"); inputType = InputType.TYPE_CLASS_TEXT }
        box.addView(nameF)
        var chosenEmoji = emojis[0]; var chosenColor = colors[0]
        box.addView(TextView(this).apply { text = Lang.t(this@ProfileActivity, "Pick an icon"); setPadding(0, pad / 2, 0, 0) })
        val emojiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val emojiScroll = ScrollView(this)
        val emojiWrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (e in emojis) emojiWrap.addView(Button(this).apply { text = e; setOnClickListener { chosenEmoji = e; Toast.makeText(this@ProfileActivity, "Icon: $e", Toast.LENGTH_SHORT).show() } })
        val hs = android.widget.HorizontalScrollView(this); hs.addView(emojiWrap); box.addView(hs)
        box.addView(TextView(this).apply { text = Lang.t(this@ProfileActivity, "Pick a colour"); setPadding(0, pad / 2, 0, 0) })
        val colorWrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (col in colors) colorWrap.addView(Button(this).apply {
            text = "  "; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(col)) }
            val sz = (40 * resources.displayMetrics.density).toInt(); width = sz; height = sz
            setOnClickListener { chosenColor = col; Toast.makeText(this@ProfileActivity, Lang.t(this@ProfileActivity, "Colour set"), Toast.LENGTH_SHORT).show() }
        })
        val hc = android.widget.HorizontalScrollView(this); hc.addView(colorWrap); box.addView(hc)

        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "New profile"))
            .setView(box)
            .setPositiveButton(Lang.t(this, "Create")) { _, _ ->
                val nm = nameF.text.toString().trim()
                if (nm.isEmpty()) { Toast.makeText(this, Lang.t(this, "Enter a name"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val id = Profiles.add(this, nm, chosenEmoji, chosenColor)
                Profiles.select(this, id)
                render()
                startActivity(Intent(this, MainActivity::class.java))
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    private fun openProfile(id: String) {
        Profiles.select(this, id)
        startActivity(Intent(this, MainActivity::class.java))
    }

    /** Ask for a locked profile's PIN before opening it. */
    private fun promptProfilePin(id: String) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = Lang.t(this@ProfileActivity, "Profile PIN")
        }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "🔒 Locked profile"))
            .setMessage(Lang.t(this, "Enter this profile's PIN to open it."))
            .setView(input)
            .setPositiveButton(Lang.t(this, "Open")) { _, _ ->
                if (Profiles.checkPin(this, id, input.text.toString())) openProfile(id)
                else Toast.makeText(this, Lang.t(this, "Wrong PIN"), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    /** Long-press menu: set / remove a PIN lock, or delete the profile. */
    private fun manageProfileDialog(id: String, name: String) {
        val locked = Profiles.hasPin(this, id)
        val options = mutableListOf("✏️ Rename", if (locked) "Change PIN lock" else "🔒 Lock with a PIN")
        if (locked) options.add("Remove PIN lock")
        options.add("Delete profile")
        val shown = options.map { Lang.t(this, it) }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(shown) { _, which ->
                when (options[which]) {
                    "✏️ Rename" -> renameDialog(id, name)
                    "Delete profile" -> removeProfileDialog(id, name)
                    "Remove PIN lock" -> promptRemovePin(id)
                    else -> setPinDialog(id)
                }
            }
            .show()
    }

    private fun renameDialog(id: String, name: String) {
        val input = EditText(this).apply { setText(name); inputType = InputType.TYPE_CLASS_TEXT }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Rename profile"))
            .setView(input)
            .setPositiveButton(Lang.t(this, "Save")) { _, _ ->
                val nm = input.text.toString().trim()
                if (nm.isEmpty()) { Toast.makeText(this, Lang.t(this, "Enter a name"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Profiles.rename(this, id, nm); render()
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    private fun setPinDialog(id: String) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = Lang.t(this@ProfileActivity, "New PIN (4+ digits)")
        }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Lock profile"))
            .setMessage(Lang.t(this, "Only someone with this PIN can open the profile."))
            .setView(input)
            .setPositiveButton(Lang.t(this, "Save")) { _, _ ->
                val p = input.text.toString().trim()
                if (p.length < 4) { Toast.makeText(this, Lang.t(this, "Use at least 4 digits"), Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                Profiles.setPin(this, id, p); Toast.makeText(this, Lang.t(this, "Profile locked 🔒"), Toast.LENGTH_SHORT).show(); render()
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    private fun promptRemovePin(id: String) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = Lang.t(this@ProfileActivity, "Current PIN")
        }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Remove PIN lock"))
            .setView(input)
            .setPositiveButton(Lang.t(this, "Remove")) { _, _ ->
                if (Profiles.checkPin(this, id, input.text.toString())) {
                    Profiles.setPin(this, id, ""); Toast.makeText(this, Lang.t(this, "Lock removed"), Toast.LENGTH_SHORT).show(); render()
                } else Toast.makeText(this, Lang.t(this, "Wrong PIN"), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    private fun removeProfileDialog(id: String, name: String) {
        if (Profiles.list(this).length() <= 1) { Toast.makeText(this, Lang.t(this, "You need at least one profile"), Toast.LENGTH_SHORT).show(); return }
        val msg = if (Lang.isHebrew(this)) Lang.t(this, "This deletes the profile and all its points, coins and progress. This can't be undone.")
        else "Delete \"$name\" and all its points, coins and progress? This can't be undone."
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Delete profile?"))
            .setMessage(msg)
            .setPositiveButton(Lang.t(this, "Delete")) { _, _ -> Profiles.remove(this, id); render() }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    private fun openParent() {
        val sp = getSharedPreferences("combo", MODE_PRIVATE)
        val pin = sp.getString("parentPin", "") ?: ""
        if (pin.isEmpty()) { startActivity(Intent(this, ParentActivity::class.java)); return }
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = Lang.t(this@ProfileActivity, "Parent PIN") }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Parent zone"))
            .setMessage(Lang.t(this, "Enter the parent PIN."))
            .setView(input)
            .setPositiveButton(Lang.t(this, "Unlock")) { _, _ ->
                if (input.text.toString().trim() == pin) startActivity(Intent(this, ParentActivity::class.java))
                else Toast.makeText(this, Lang.t(this, "Wrong PIN"), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }
}
