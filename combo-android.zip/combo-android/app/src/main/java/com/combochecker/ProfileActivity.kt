package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** "Who's using?" launcher screen: pick / add / remove named profiles, or enter the Parent zone. */
class ProfileActivity : Activity() {

    private val emojis = listOf("⭐", "🚀", "🐱", "🐶", "🦄", "🐧", "🦊", "🐉", "🎈", "🎮", "🌟", "🔥")
    private val colors = listOf("#3a66d6", "#2a7d46", "#D62F9B", "#E8491D", "#6A2FE8", "#E8B500", "#0a9cc0", "#c0392b")
    private var pad = 0
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Profiles.ensureDefault(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "Who's using Combo Checker?"; textSize = 24f; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, pad)
        })

        val arr = Profiles.list(this)
        for (i in 0 until arr.length()) {
            val p = arr.getJSONObject(i)
            root.addView(profileRow(p.optString("id"), p.optString("name"), p.optString("emoji", "⭐"), p.optString("color", "#3a66d6")))
        }

        root.addView(Button(this).apply {
            text = "➕ Add profile"
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
            setOnClickListener { addProfileDialog() }
        })

        root.addView(TextView(this).apply {
            text = "For parents"; textSize = 16f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
        root.addView(profileRow("__parent__", "Parent zone", "👪", "#555770"))
    }

    private fun profileRow(id: String, name: String, emoji: String, color: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        val avatarSize = (46 * resources.displayMetrics.density).toInt()
        row.addView(TextView(this).apply {
            text = emoji; textSize = 22f; gravity = Gravity.CENTER
            width = avatarSize; height = avatarSize
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(color)) }
        })
        row.addView(TextView(this).apply {
            text = "   " + name; textSize = 20f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        row.setOnClickListener {
            if (id == "__parent__") openParent()
            else { Profiles.select(this, id); startActivity(Intent(this, MainActivity::class.java)) }
        }
        if (id != "__parent__") row.setOnLongClickListener { removeProfileDialog(id, name); true }
        return row
    }

    private fun addProfileDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        val nameF = EditText(this).apply { hint = "Name"; inputType = InputType.TYPE_CLASS_TEXT }
        box.addView(nameF)
        var chosenEmoji = emojis[0]; var chosenColor = colors[0]
        box.addView(TextView(this).apply { text = "Pick an icon"; setPadding(0, pad / 2, 0, 0) })
        val emojiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val emojiScroll = ScrollView(this)
        val emojiWrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (e in emojis) emojiWrap.addView(Button(this).apply { text = e; setOnClickListener { chosenEmoji = e; Toast.makeText(this@ProfileActivity, "Icon: $e", Toast.LENGTH_SHORT).show() } })
        val hs = android.widget.HorizontalScrollView(this); hs.addView(emojiWrap); box.addView(hs)
        box.addView(TextView(this).apply { text = "Pick a colour"; setPadding(0, pad / 2, 0, 0) })
        val colorWrap = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (col in colors) colorWrap.addView(Button(this).apply {
            text = "  "; background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(col)) }
            val sz = (40 * resources.displayMetrics.density).toInt(); width = sz; height = sz
            setOnClickListener { chosenColor = col; Toast.makeText(this@ProfileActivity, "Colour set", Toast.LENGTH_SHORT).show() }
        })
        val hc = android.widget.HorizontalScrollView(this); hc.addView(colorWrap); box.addView(hc)

        AlertDialog.Builder(this)
            .setTitle("New profile")
            .setView(box)
            .setPositiveButton("Create") { _, _ ->
                val nm = nameF.text.toString().trim()
                if (nm.isEmpty()) { Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                val id = Profiles.add(this, nm, chosenEmoji, chosenColor)
                Profiles.select(this, id)
                render()
                startActivity(Intent(this, MainActivity::class.java))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeProfileDialog(id: String, name: String) {
        if (Profiles.list(this).length() <= 1) { Toast.makeText(this, "You need at least one profile", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this)
            .setTitle("Delete profile?")
            .setMessage("Delete \"$name\" and all its points, coins and progress? This can't be undone.")
            .setPositiveButton("Delete") { _, _ -> Profiles.remove(this, id); render() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openParent() {
        val sp = getSharedPreferences("combo", MODE_PRIVATE)
        val pin = sp.getString("parentPin", "") ?: ""
        if (pin.isEmpty()) { startActivity(Intent(this, ParentActivity::class.java)); return }
        val input = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = "Parent PIN" }
        AlertDialog.Builder(this)
            .setTitle("Parent zone")
            .setMessage("Enter the parent PIN.")
            .setView(input)
            .setPositiveButton("Unlock") { _, _ ->
                if (input.text.toString().trim() == pin) startActivity(Intent(this, ParentActivity::class.java))
                else Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
