package com.combochecker

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.OvershootInterpolator

/**
 * The Checkpoint logo: the Comboed "C" built from 4 segments (a combo meter) with a check inside.
 * Drawn in code so it's sharp at any size. [lit] = how many C segments glow (0..4);
 * [animateCheck] draws the check in and pulses, used after a task check.
 */
class CheckpointView(ctx: Context) : View(ctx) {
    var colors: IntArray = Checkpoint.CLASSIC
        set(v) { field = v; shader = null; invalidate() }
    var lit: Int = 4
        set(v) { field = v.coerceIn(0, 4); invalidate() }
    var checkProgress: Float = 1f
        set(v) { field = v; invalidate() }
    var rounded = false // app-icon style (rounded square) instead of a circle

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Color.WHITE
    }
    private var shader: Shader? = null
    private val oval = RectF()
    private val check = Path()
    private val part = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { shader = null }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat()
        if (s <= 0f) return
        val k = s / 100f
        if (shader == null) {
            shader = if (colors.size == 1) null
                else LinearGradient(0f, 0f, s, s, colors, null, Shader.TileMode.CLAMP)
        }
        bg.shader = shader
        if (shader == null) bg.color = colors[0]
        if (rounded) c.drawRoundRect(0f, 0f, s, s, 22 * k, 22 * k, bg) else c.drawCircle(s / 2, s / 2, s / 2, bg)

        stroke.strokeWidth = 9 * k
        val r = 27 * k
        oval.set(s / 2 - r, s / 2 - r, s / 2 + r, s / 2 + r)
        // top → left → bottom (lights up in that order)
        Checkpoint.SEGMENTS.forEachIndexed { i, seg ->
            stroke.alpha = if (i < lit) 255 else 115
            c.drawArc(oval, seg[0], seg[1] - seg[0], false, stroke)
        }
        stroke.alpha = 255
        check.reset()
        check.moveTo(36 * k, 55 * k); check.lineTo(45.5f * k, 64.5f * k); check.lineTo(65.5f * k, 42.5f * k)
        if (checkProgress >= 1f) c.drawPath(check, stroke)
        else if (checkProgress > 0f) {
            val pm = PathMeasure(check, false)
            part.reset()
            // a two-contour path: measure both legs
            var total = 0f; do { total += pm.length } while (pm.nextContour())
            var left = total * checkProgress
            val pm2 = PathMeasure(check, false)
            do {
                val l = pm2.length
                val take = minOf(l, left)
                if (take > 0) pm2.getSegment(0f, take, part, true)
                left -= take
            } while (left > 0 && pm2.nextContour())
            c.drawPath(part, stroke)
        }
    }

    /** Draw the check in, then a little pulse. */
    fun animateCheck() {
        checkProgress = 0f
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420; startDelay = 120
            addUpdateListener { checkProgress = it.animatedValue as Float }
            start()
        }
        scaleX = 0.85f; scaleY = 0.85f
        animate().scaleX(1f).scaleY(1f).setStartDelay(420).setDuration(380).setInterpolator(OvershootInterpolator(3f)).start()
    }
}

/** Checkpoint styles (bought in the Shop; the old star-skin ids are kept so purchases carry over). */
object Checkpoint {
    val SEGMENTS = listOf(floatArrayOf(268f, 320f), floatArrayOf(192f, 244f), floatArrayOf(116f, 168f), floatArrayOf(40f, 92f))
    private fun c(vararg hex: String) = hex.map { Color.parseColor(it) }.toIntArray()
    val CLASSIC = c("#3A5BD9", "#5A2FC7")
    val STYLES: Map<String, IntArray> = mapOf(
        "star_default" to CLASSIC,
        "star_fire" to c("#FF8A3D", "#E8301D"),
        "star_diamond" to c("#3FD0F0", "#1E6FE8"),
        "star_rocket" to c("#2A3048", "#0F1220"),
        "star_crown" to c("#F7C948", "#C98A00"),
        "star_rainbow" to c("#FF4F7B", "#FFB347", "#3FD08A", "#3A9BE8", "#8A4AE8")
    )
    fun colorsFor(id: String) = STYLES[id] ?: CLASSIC

    /** Combo segments lit for the current profile: the streak, if the last task was within 30 min. */
    fun litFor(st: org.json.JSONObject): Int {
        val last = st.optLong("lastTs", 0L)
        return if (last > 0 && System.currentTimeMillis() - last <= 30L * 60 * 1000) minOf(4, st.optInt("streak", 0)) else 0
    }
}
