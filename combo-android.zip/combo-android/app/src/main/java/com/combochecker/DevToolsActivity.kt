package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.firebase.crashlytics.FirebaseCrashlytics
import org.json.JSONArray
import org.json.JSONObject

/**
 * Developer tests (developer mode only): one tap triggers each feature so it can be checked
 * without waiting for the real situation. Results show as a toast or a dialog.
 */
class DevToolsActivity : Activity() {
    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private fun d(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun result(title: String, msg: String) = AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        render()
    }

    private fun state(): JSONObject = Progress.state(this)
    private fun saveState(o: JSONObject) = sp().edit().putString(Profiles.stateKey(this), o.toString()).apply()

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, "Back") { finish() })
        head.addView(Ui.text(this, "Developer tests", 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        page.addView(head)
        page.addView(Ui.text(this, "Each row triggers one feature. Build " + Changelog.build(this) + " · profile " + Profiles.currentId(this) +
            " · uid " + (Backend.uidNow()?.take(8) ?: "…"), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(10), d(4), 0) })

        fun section(title: String, rows: List<View>) { page.addView(Ui.sectionTitle(this, title)); page.addView(Ui.group(this, rows)) }
        fun r(res: Int, tone: String, label: String, sub: String? = null, go: () -> Unit) = Ui.row(this, res, tone, label, sub, onClick = go)

        section("Crash reports", listOf(
            r(R.drawable.ui_zap, "red", "Test crash", "App closes; reopen it to send") {
                AlertDialog.Builder(this).setTitle("Test crash").setMessage("The app will close on purpose. Open it again and the report reaches Firebase Crashlytics within a few minutes.")
                    .setPositiveButton("Crash now") { _, _ -> throw RuntimeException("Comboed test crash (developer button)") }
                    .setNegativeButton("Cancel", null).show()
            },
            r(R.drawable.ui_shield, "orange", "Test non-fatal error", "Reported without closing the app") {
                FirebaseCrashlytics.getInstance().recordException(IllegalStateException("Comboed test non-fatal (developer button)"))
                FirebaseCrashlytics.getInstance().sendUnsentReports()
                toast("Non-fatal error recorded and sent. Check Crashlytics → Non-fatals in a few minutes.")
            }
        ))

        section("Notifications", listOf(
            r(R.drawable.ui_bell, "orange", "Daily reminder now") {
                Reminders.ensureChannel(this); sendBroadcast(Intent(this, ReminderReceiver::class.java)); toast("Reminder sent — check your notifications.")
            },
            r(R.drawable.ui_download, "orange", "Update notification now", "Pretends a newer build exists") {
                sp().edit().putInt("latestBuild", Changelog.build(this) + 1).putInt("notifiedBuild", 0).putBoolean("updateNotify", true).apply()
                UpdateCheck.notifyIfNew(this); toast("Update notification sent. (Clear it below.)")
            },
            r(R.drawable.ui_download, "blue", "Show the update card on Home") {
                sp().edit().putInt("latestBuild", Changelog.build(this) + 1).putLong("updateCheckedAt", System.currentTimeMillis()).apply()
                toast("Go back to Home: the \"Update available\" card is there.")
            },
            r(R.drawable.ui_reset, "gray", "Clear the fake update") {
                sp().edit().remove("latestBuild").remove("updateCheckedAt").remove("notifiedBuild").apply(); toast("Cleared.")
            }
        ))

        section("Screens & pop-ups", listOf(
            r(R.drawable.ui_key, "blue", "First-open AI key setup") { startActivity(Intent(this, KeySetupActivity::class.java)) },
            r(R.drawable.ui_spark, "blue", "\"What's new\" pop-up") { sp().edit().putInt("lastSeenBuild", maxOf(1, Changelog.build(this) - 1)).apply(); Changelog.maybeShow(this) },
            r(R.drawable.ui_download, "blue", "Update steps pop-up") { UpdateCheck.showDialog(this) },
            r(R.drawable.ui_calendar, "blue", "Updates & what's new screen") { startActivity(Intent(this, UpdatesActivity::class.java)) },
            r(R.drawable.ui_help, "blue", "Help guide") { startActivity(Intent(this, HelpActivity::class.java)) },
            r(R.drawable.ui_users, "purple", "High-five / nudge pop-up (sample)") {
                AlertDialog.Builder(this).setTitle("Test group").setMessage("⭐ Alex " + Lang.t(this, "sent you a high-five! 🙌") + "\n\n📣 🍎 Teacher: We miss you! One small task today? 💪\n\n🏅 " + Lang.t(this, "You're Student of the week in") + " Test group!")
                    .setPositiveButton(Lang.t(this, "Nice!"), null).show()
            }
        ))

        section("Checkpoint button", listOf(
            r(R.drawable.ui_checkpoint, "blue", "Combo x1 → x4 (lights the C)", "Then start Checkpoint to see it") {
                val st = state(); val next = (if (Checkpoint.litFor(st) >= 4) 0 else Checkpoint.litFor(st)) + 1
                st.put("streak", next).put("lastTs", System.currentTimeMillis()); saveState(st)
                BubbleService.setBubbleVisible(true); toast("Combo set to x$next (tap again for the next).")
            },
            r(R.drawable.ui_check, "green", "Play the check animation") {
                BubbleService.setBubbleVisible(false); window.decorView.postDelayed({ BubbleService.setBubbleVisible(true) }, 300)
                toast("Watch the Checkpoint button (it must be running).")
            },
            r(R.drawable.ui_reset, "gray", "Reset combo") { val st = state(); st.put("streak", 0).put("lastTs", 0); saveState(st); BubbleService.setBubbleVisible(true); toast("Combo reset.") }
        ))

        section("Points & progress", listOf(
            r(R.drawable.ui_star, "gold", "+100 points") { val st = state(); st.put("total", st.optInt("total") + 100); saveState(st); toast("Total: " + st.optInt("total") + " (Lv " + Progress.level(st.optInt("total")) + " " + Progress.rank(this, Progress.level(st.optInt("total"))) + ")") },
            r(R.drawable.ui_coin, "gold", "+100 coins") { val st = state(); st.put("coins", st.optInt("coins") + 100); saveState(st); toast("Coins: " + st.optInt("coins")) },
            r(R.drawable.ui_book, "green", "+50 study coins") { val st = state(); st.put("scoins", st.optInt("scoins") + 50); saveState(st); toast("Study coins: " + st.optInt("scoins")) },
            r(R.drawable.ui_check, "green", "Add a test approval request", "Shows in the Parent zone") {
                val me = Profiles.current(this)
                val arr = try { JSONArray(sp().getString("pending", "[]")) } catch (e: Exception) { JSONArray() }
                arr.put(JSONObject().put("rid", java.util.UUID.randomUUID().toString()).put("coins", 25).put("task", "Test task (developer)")
                    .put("time", System.currentTimeMillis()).put("profileId", me.optString("id")).put("profileName", me.optString("name")).put("proof", "").put("study", false))
                sp().edit().putString("pending", arr.toString()).apply(); toast("Added. Open the Parent zone to approve it.")
            }
        ))

        section("Server (Firebase)", listOf(
            r(R.drawable.ui_globe, "teal", "Connection test") {
                val t0 = System.currentTimeMillis()
                Backend.ensureUid { uid -> Backend.fetchUserCount { n -> result("Server OK ✅", "Signed in as ${uid.take(10)}…\n$n installs\n${System.currentTimeMillis() - t0} ms") } }
                toast("Testing…")
            },
            r(R.drawable.ui_globe, "teal", "World stats") { Backend.fetchWorld { day, week -> result("World stats", "Today: $day tasks\nThis week: $week tasks") } },
            r(R.drawable.ui_trophy, "teal", "Leaderboard titles", "Checks the global top 3 now") {
                Titles.lastCheck = 0
                Titles.refresh(this) { result("My title", Titles.forProfile(this).ifEmpty { "No title (not in the global top 3, never was)." } +
                    "\n\nlbPos=" + sp().getInt("lbPos", 0) + " · best=" + sp().getInt("lbBest", 0) + " · profile=" + sp().getString("lbPid", "")) }
            },
            r(R.drawable.ui_trophy, "gold", "Preview: Top 1 title", "Local only, until the next real check") {
                sp().edit().putString("lbPid", Profiles.currentId(this)).putInt("lbPos", 1).apply(); toast("Home & Me now show 🥇 Top 1 (next real check resets it).")
            },
            r(R.drawable.ui_trophy, "gray", "Preview: Retired Top 2") {
                sp().edit().putString("lbPid", Profiles.currentId(this)).putInt("lbPos", 0).putInt("lbBest", 2).apply(); toast("Shows 🎖️ Retired Top 2.")
            },
            r(R.drawable.ui_users, "purple", "Group sync now", "Approvals, high-fives, pranks, news") {
                Groups.lastSync = 0; Groups.sync(this) { toast("Group sync: something changed (go back to Home).") }
                toast("Group sync started — ${Groups.memberships(this).length()} group(s).")
            },
            r(R.drawable.ui_upload, "teal", "Daily backup now") {
                if (!Groups.autoBackupOn(this)) { toast("Turn on Settings → Your data → Daily automatic backup first."); return@r }
                Backend.autoBackup(Groups.autoBackupCode(this), Groups.backupJson(this)) { ok -> result(if (ok) "Backup OK ✅" else "Backup failed ❌", "Code: " + Groups.autoBackupCode(this)) }
            },
            r(R.drawable.ui_download, "teal", "Check GitHub for updates") {
                UpdateCheck.checkNow(this, force = true) { avail -> result("Update check", "This build: " + Changelog.build(this) + "\nLatest on GitHub: " + UpdateCheck.latestKnown(this) + "\n" + if (avail) "Update available" else "Up to date") }
            },
            r(R.drawable.ui_share, "teal", "My friend code") { Backend.friendCode(this) { result("Friend code", it) } }
        ))

        section("Pranks", listOf(
            r(R.drawable.ui_spark, "purple", "Open the update tools (all trolls & gags)") { startActivity(Intent(this, PrankActivity::class.java)) }
        ))

        page.addView(Ui.text(this, "Tests change only this phone (except the server tests, which write normal app data).", 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), d(4), 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
    }
}
