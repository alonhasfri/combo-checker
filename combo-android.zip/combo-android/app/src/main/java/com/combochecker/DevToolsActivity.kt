package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import com.google.firebase.crashlytics.FirebaseCrashlytics
import org.json.JSONArray
import org.json.JSONObject

/**
 * Developer tests (developer mode only): one tap triggers each feature so it can be checked
 * without waiting for the real situation. Results show as a toast or a dialog.
 */
class DevToolsActivity : Activity() {
    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private fun d(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun result(title: String, msg: String) = AlertDialog.Builder(this).setTitle(title).setMessage(msg).setPositiveButton("OK", null).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        render()
    }

    private fun state(): JSONObject = Progress.state(this)
    private fun saveState(o: JSONObject) = sp().edit().putString(Profiles.stateKey(this), o.toString()).apply()

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, "Back") { finish() })
        head.addView(Ui.text(this, "Developer tests", 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        page.addView(head)
        page.addView(Ui.text(this, "Each row triggers one feature. Build " + Changelog.build(this) + " · profile " + Profiles.currentId(this) +
            " · uid " + (Backend.uidNow()?.take(8) ?: "…"), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(10), d(4), 0) })

        fun section(title: String, rows: List<View>) { page.addView(Ui.sectionTitle(this, title)); page.addView(Ui.group(this, rows)) }
        fun r(res: Int, tone: String, label: String, sub: String? = null, go: () -> Unit) = Ui.row(this, res, tone, label, sub, onClick = go)

        section("Crash reports", listOf(
            r(R.drawable.ui_zap, "red", "Test crash", "App closes; reopen it to send") {
                AlertDialog.Builder(this).setTitle("Test crash").setMessage("The app will close on purpose. Open it again and the report reaches Firebase Crashlytics within a few minutes.")
                    .setPositiveButton("Crash now") { _, _ -> throw RuntimeException("Comboed test crash (developer button)") }
                    .setNegativeButton("Cancel", null).show()
            },
            r(R.drawable.ui_shield, "orange", "Test non-fatal error", "Reported without closing the app") {
                FirebaseCrashlytics.getInstance().recordException(IllegalStateException("Comboed test non-fatal (developer button)"))
                FirebaseCrashlytics.getInstance().sendUnsentReports()
                toast("Non-fatal error recorded and sent. Check Crashlytics → Non-fatals in a few minutes.")
            }
        ))

        section("Notifications", listOf(
            r(R.drawable.ui_bell, "orange", "Daily reminder now") {
                Reminders.ensureChannel(this); sendBroadcast(Intent(this, ReminderReceiver::class.java)); toast("Reminder sent — check your notifications.")
            },
            r(R.drawable.ui_download, "orange", "Update notification now", "Pretends a newer build exists") {
                sp().edit().putInt("latestBuild", Changelog.build(this) + 1).putInt("notifiedBuild", 0).putBoolean("updateNotify", true).apply()
                UpdateCheck.notifyIfNew(this); toast("Update notification sent. (Clear it below.)")
            },
            r(R.drawable.ui_download, "blue", "Show the update card on Home") {
                sp().edit().putInt("latestBuild", Changelog.build(this) + 1).putLong("updateCheckedAt", System.currentTimeMillis()).apply()
                toast("Go back to Home: the \"Update available\" card is there.")
            },
            r(R.drawable.ui_reset, "gray", "Clear the fake update") {
                sp().edit().remove("latestBuild").remove("updateCheckedAt").remove("notifiedBuild").apply(); toast("Cleared.")
            }
        ))

        section("Screens & pop-ups", listOf(
            r(R.drawable.ui_key, "blue", "First-open AI key setup") { startActivity(Intent(this, KeySetupActivity::class.java)) },
            r(R.drawable.ui_spark, "blue", "\"What's new\" pop-up") { sp().edit().putInt("lastSeenBuild", maxOf(1, Changelog.build(this) - 1)).apply(); Changelog.maybeShow(this) },
            r(R.drawable.ui_download, "blue", "Update steps pop-up") { UpdateCheck.showDialog(this) },
            r(R.drawable.ui_calendar, "blue", "Updates & what's new screen") { startActivity(Intent(this, UpdatesActivity::class.java)) },
            r(R.drawable.ui_help, "blue", "Help guide") { startActivity(Intent(this, HelpActivity::class.java)) },
            r(R.drawable.ui_users, "purple", "High-five / nudge pop-up (sample)") {
                AlertDialog.Builder(this).setTitle("Test group").setMessage("⭐ Alex " + Lang.t(this, "sent you a high-five! 🙌") + "\n\n📣 🍎 Teacher: We miss you! One small task today? 💪\n\n🏅 " + Lang.t(this, "You're Student of the week in") + " Test group!")
                    .setPositiveButton(Lang.t(this, "Nice!"), null).show()
            }
        ))

        section("Checkpoint button", listOf(
            r(R.drawable.ui_checkpoint, "blue", "Combo x1 → x4 (lights the C)", "Then start Checkpoint to see it") {
                val st = state(); val next = (if (Checkpoint.litFor(st) >= 4) 0 else Checkpoint.litFor(st)) + 1
                st.put("streak", next).put("lastTs", System.currentTimeMillis()); saveState(st)
                BubbleService.setBubbleVisible(true); toast("Combo set to x$next (tap again for the next).")
            },
            r(R.drawable.ui_check, "green", "Play the check animation") {
                BubbleService.setBubbleVisible(false); window.decorView.postDelayed({ BubbleService.setBubbleVisible(true) }, 300)
                toast("Watch the Checkpoint button (it must be running).")
            },
            r(R.drawable.ui_reset, "gray", "Reset combo") { val st = state(); st.put("streak", 0).put("lastTs", 0); saveState(st); BubbleService.setBubbleVisible(true); toast("Combo reset.") }
        ))

        section("Points & progress", listOf(
            r(R.drawable.ui_star, "gold", "+100 points") { val st = state(); st.put("total", st.optInt("total") + 100); saveState(st); toast("Total: " + st.optInt("total") + " (Lv " + Progress.level(st.optInt("total")) + " " + Progress.rank(this, Progress.level(st.optInt("total"))) + ")") },
            r(R.drawable.ui_coin, "gold", "+100 coins") { val st = state(); st.put("coins", st.optInt("coins") + 100); saveState(st); toast("Coins: " + st.optInt("coins")) },
            r(R.drawable.ui_book, "green", "+50 study coins") { val st = state(); st.put("scoins", st.optInt("scoins") + 50); saveState(st); toast("Study coins: " + st.optInt("scoins")) },
            r(R.drawable.ui_check, "green", "Add a test approval request", "Shows in the Parent zone") {
                val me = Profiles.current(this)
                val arr = try { JSONArray(sp().getString("pending", "[]")) } catch (e: Exception) { JSONArray() }
                arr.put(JSONObject().put("rid", java.util.UUID.randomUUID().toString()).put("coins", 25).put("task", "Test task (developer)")
                    .put("time", System.currentTimeMillis()).put("profileId", me.optString("id")).put("profileName", me.optString("name")).put("proof", "").put("study", false))
                sp().edit().putString("pending", arr.toString()).apply(); toast("Added. Open the Parent zone to approve it.")
            }
        ))

        section("Server (Firebase)", listOf(
            r(R.drawable.ui_globe, "teal", "Connection test") {
                val t0 = System.currentTimeMillis()
                Backend.ensureUid { uid -> Backend.fetchUserCount { n -> result("Server OK ✅", "Signed in as ${uid.take(10)}…\n$n installs\n${System.currentTimeMillis() - t0} ms") } }
                toast("Testing…")
            },
            r(R.drawable.ui_globe, "teal", "World stats") { Backend.fetchWorld { day, week -> result("World stats", "Today: $day tasks\nThis week: $week tasks") } },
            r(R.drawable.ui_trophy, "teal", "Leaderboard titles", "Checks the global top 3 now") {
                Titles.lastCheck = 0
                Titles.refresh(this) { result("My title", Titles.forProfile(this).ifEmpty { "No title (not in the global top 3, never was)." } +
                    "\n\nlbPos=" + sp().getInt("lbPos", 0) + " · best=" + sp().getInt("lbBest", 0) + " · profile=" + sp().getString("lbPid", "")) }
            },
            r(R.drawable.ui_trophy, "gold", "Preview: Top 1 title", "Local only, until the next real check") {
                sp().edit().putString("lbPid", Profiles.currentId(this)).putInt("lbPos", 1).apply(); toast("Home & Me now show 🥇 Top 1 (next real check resets it).")
            },
            r(R.drawable.ui_trophy, "gray", "Preview: Retired Top 2") {
                sp().edit().putString("lbPid", Profiles.currentId(this)).putInt("lbPos", 0).putInt("lbBest", 2).apply(); toast("Shows 🎖️ Retired Top 2.")
            },
            r(R.drawable.ui_users, "purple", "Group sync now", "Approvals, high-fives, pranks, news") {
                Groups.lastSync = 0; Groups.sync(this) { toast("Group sync: something changed (go back to Home).") }
                toast("Group sync started — ${Groups.memberships(this).length()} group(s).")
            },
            r(R.drawable.ui_upload, "teal", "Daily backup now") {
                if (!Groups.autoBackupOn(this)) { toast("Turn on Settings → Your data → Daily automatic backup first."); return@r }
                Backend.autoBackup(Groups.autoBackupCode(this), Groups.backupJson(this)) { ok -> result(if (ok) "Backup OK ✅" else "Backup failed ❌", "Code: " + Groups.autoBackupCode(this)) }
            },
            r(R.drawable.ui_download, "teal", "Check GitHub for updates") {
                UpdateCheck.checkNow(this, force = true) { avail -> result("Update check", "This build: " + Changelog.build(this) + "\nLatest on GitHub: " + UpdateCheck.latestKnown(this) + "\n" + if (avail) "Update available" else "Up to date") }
            },
            r(R.drawable.ui_share, "teal", "My friend code") { Backend.friendCode(this) { result("Friend code", it) } }
        ))

        section("Newest features", listOf(
            r(R.drawable.ui_book, "purple", "Create a test class", "With homework, tasks (one repeating) and a class reward") { makeTestClass() },
            r(R.drawable.ui_users, "purple", "Open the test class as a STUDENT", "Should show no teacher controls") { openTestClass(false) },
            r(R.drawable.ui_book, "purple", "Open the test class as the TEACHER") { openTestClass(true) },
            r(R.drawable.ui_check, "green", "Show my To-do list") {
                val items = Todo.items(this)
                result("To-do (${items.count { !it.done }} open)", items.joinToString("\n") { (if (it.done) "✓ " else "○ ") + it.title + "  —  " + it.sub })
            },
            r(R.drawable.ui_bell, "orange", "Due reminder in 10 seconds") {
                val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                var flags = android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
                val i = Intent(this, DueReceiver::class.java).putExtra("title", if (Lang.isHebrew(this)) "נשארו שעתיים" else "2 hours left").putExtra("text", "Test task (developer)").putExtra("key", "devtest")
                am.set(android.app.AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 10_000, android.app.PendingIntent.getBroadcast(this, 4242, i, flags))
                toast("Wait 10 seconds (you can leave the app).")
            },
            r(R.drawable.ui_calendar, "orange", "Reschedule all due reminders") {
                Todo.schedule(this)
                val n = (sp().getString("dueKeys", "") ?: "").split("\n").count { it.isNotEmpty() }
                result("Due reminders", "$n reminder(s) scheduled.\n\n" + (sp().getString("dueKeys", "") ?: "").replace("|", " · "))
            },
            r(R.drawable.ui_spark, "purple", "Show coach tips") { result("Your coach", Progress.coach(this)) },
            r(R.drawable.ui_trophy, "gold", "Rank-up celebration") {
                val lv = Progress.level(state().optInt("total", 0))
                startActivity(Intent(this, CelebrateActivity::class.java).putExtra("emoji", "🏆").putExtra("title", Progress.rank(this, lv)).putExtra("sub", "Level $lv (test)"))
            },
            r(R.drawable.ui_flame, "orange", "Streak celebration (7 days)") {
                startActivity(Intent(this, CelebrateActivity::class.java).putExtra("emoji", "🔥").putExtra("title", if (Lang.isHebrew(this)) "רצף של 7 ימים!" else "7-day streak!").putExtra("sub", "(test)"))
            },
            r(R.drawable.ui_reset, "gray", "Reset celebrations", "The next level / streak celebrates again") {
                val pid = Profiles.currentId(this)
                sp().edit().putInt("celebLevel__$pid", maxOf(1, Progress.level(state().optInt("total", 0)) - 1)).putInt("celebStreak__$pid", 0).apply()
                toast("Go back to Home: the rank celebration should appear.")
            },
            r(R.drawable.ui_star, "blue", "Show the 3-step intro", "Step 1 renames this profile") { startActivity(Intent(this, IntroActivity::class.java)) },
            r(R.drawable.ui_lock, "green", "Open the Parent zone (family overview)") { startActivity(Intent(this, ParentActivity::class.java)) },
            r(R.drawable.ui_gift, "teal", "Open Shop → Rewards", "Class rewards + partner offers") { startActivity(Intent(this, ShopActivity::class.java).putExtra("tab", 3)) }
        ))

        section("Partner offers (admin)", listOf(
            r(R.drawable.ui_gift, "gold", "Manage partner offers", "Add / edit / turn off") { requireAdmin { partnersAdmin() } },
            r(R.drawable.ui_file, "gold", "Redeemed coupons", "Check a code, mark it used") { requireAdmin { redemptionsAdmin() } },
            r(R.drawable.ui_key, "gray", "Become an admin", "Shows the one-time setup") { adminHelp() }
        ))

        section("Pranks", listOf(
            r(R.drawable.ui_spark, "purple", "Open the update tools (all trolls & gags)") { startActivity(Intent(this, PrankActivity::class.java)) }
        ))

        page.addView(Ui.text(this, "Tests change only this phone (except the server tests, which write normal app data).", 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), d(4), 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
    }

    // ===================== partner admin =====================
    private val CATS = arrayOf("Sports & fitness", "Shows & culture", "Bikes & outdoor", "Games & toys", "Food & treats", "Learning", "Experiences", "Other")

    private fun adminHelp() {
        Backend.ensureUid { uid ->
            AlertDialog.Builder(this).setTitle("Become an admin (one time)")
                .setMessage("1. Open Firebase → Firestore → Data.\n2. Start collection: admins\n3. Document ID: paste the id below (no fields needed) → Save.\n\nYour id:\n$uid")
                .setPositiveButton("Copy id") { _, _ ->
                    (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("uid", uid))
                    toast("Copied")
                }.setNegativeButton("Close", null).show()
        }
    }

    private fun requireAdmin(go: () -> Unit) {
        Backend.isAdmin { ok -> if (ok) go() else { toast("Not an admin on this phone yet."); adminHelp() } }
    }

    private fun partnersAdmin() {
        Backend.listPartners { docs ->
            val list = docs ?: emptyList()
            val labels = list.map { (if (it.data["active"] == false) "⏸ " else "") + (it.data["emoji"] ?: "🎟️") + " " + (it.data["name"] ?: "") + " — " + (it.data["cost"] ?: 0) + " coins" } + listOf("➕ Add a partner offer")
            AlertDialog.Builder(this).setTitle("Partner offers (${list.size})")
                .setItems(labels.toTypedArray()) { _, w -> editPartner(list.getOrNull(w)) }
                .setNegativeButton("Close", null).show()
        }
    }

    private fun editPartner(doc: Backend.Doc?) {
        val dt = doc?.data ?: emptyMap()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(6), d(20), 0) }
        fun f(h: String, v: Any?, num: Boolean = false) = android.widget.EditText(this).apply {
            hint = h; setText(v?.toString() ?: ""); inputType = if (num) android.text.InputType.TYPE_CLASS_NUMBER else android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val name = f("Business name (e.g. Kiddy Climb)", dt["name"])
        val offer = f("Offer (e.g. 20% off a climbing session)", dt["offer"])
        val cost = f("Coin price", dt["cost"] ?: 300, true)
        val emoji = f("Emoji (e.g. 🧗)", dt["emoji"] ?: "🎟️")
        val howTo = f("How to use (e.g. Show the code at the front desk)", dt["howTo"])
        var cat = (dt["category"] as? String) ?: CATS[0]
        val catBtn = android.widget.Button(this).apply { text = "Category: $cat"; isAllCaps = false }
        catBtn.setOnClickListener { AlertDialog.Builder(this).setItems(CATS) { _, w -> cat = CATS[w]; catBtn.text = "Category: $cat" }.show() }
        val active = android.widget.CheckBox(this).apply { text = "Active (kids can see it)"; isChecked = dt["active"] != false }
        listOf(name, offer, cost, emoji, howTo, catBtn, active).forEach { col.addView(it) }
        val b = AlertDialog.Builder(this).setTitle(if (doc == null) "New partner offer" else "Edit offer").setView(ScrollView(this).apply { addView(col) })
            .setPositiveButton("Save") { _, _ ->
                if (name.text.isBlank() || offer.text.isBlank()) { toast("Name and offer are needed."); return@setPositiveButton }
                Backend.savePartner(doc?.id, mapOf("name" to name.text.toString().trim(), "offer" to offer.text.toString().trim(),
                    "cost" to (cost.text.toString().toIntOrNull() ?: 300), "emoji" to emoji.text.toString().trim().ifEmpty { "🎟️" },
                    "howTo" to howTo.text.toString().trim(), "category" to cat, "active" to active.isChecked)) { ok -> toast(if (ok) "Saved ✅" else "Couldn't save (are you an admin?)") }
            }.setNegativeButton("Cancel", null)
        b.show()
    }

    private fun redemptionsAdmin() {
        Backend.listRedemptions { docs ->
            val list = docs ?: run { toast("Couldn't load."); return@listRedemptions }
            if (list.isEmpty()) { result("Redeemed coupons", "None yet."); return@listRedemptions }
            val fmt = java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault())
            val labels = list.map { (if (it.data["used"] == true) "✔ " else "• ") + it.id + " · " + (it.data["partner"] ?: "") + " · " + (it.data["profileName"] ?: "") + " · " + fmt.format(java.util.Date((it.data["ts"] as? Number)?.toLong() ?: 0L)) }
            AlertDialog.Builder(this).setTitle("Redeemed coupons (${list.size})")
                .setItems(labels.toTypedArray()) { _, w ->
                    val r = list[w]
                    AlertDialog.Builder(this).setTitle(r.id).setMessage("${r.data["partner"]}\n${r.data["offer"]}\n${r.data["cost"]} coins · ${r.data["profileName"]}\nUsed: ${r.data["used"] == true}")
                        .setPositiveButton(if (r.data["used"] == true) "Mark NOT used" else "Mark used") { _, _ ->
                            com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("redemptions").document(r.id)
                                .update("used", r.data["used"] != true).addOnSuccessListener { toast("Updated") }.addOnFailureListener { toast("Couldn't update") }
                        }.setNegativeButton("Close", null).show()
                }.setNegativeButton("Close", null).show()
        }
    }

    // ===================== test class =====================
    private fun testCode() = sp().getString("devTestClass", "") ?: ""

    private fun openTestClass(asOwner: Boolean) {
        val code = testCode()
        if (code.isEmpty()) { toast("Create the test class first."); return }
        startActivity(Intent(this, GroupActivity::class.java).putExtra("code", code).putExtra("asOwner", asOwner))
    }

    /** A class owned by this phone, with the current profile as a student, plus sample homework/tasks/reward. */
    private fun makeTestClass() {
        toast("Creating…")
        Backend.createGroup("Test class (developer)", "class") { code ->
            if (code == null) { toast("Couldn't create it. Check your connection."); return@createGroup }
            Groups.addOwned(this, code, "Test class (developer)", "class")
            sp().edit().putString("devTestClass", code).apply()
            val tomorrow = System.currentTimeMillis() + 24L * 3600 * 1000
            Backend.updateGroup(code, mapOf(
                "homework" to listOf(mapOf("id" to "devhw1", "title" to "Math page 42 (test)", "due" to tomorrow)),
                "rewards" to listOf(mapOf("id" to "devrw1", "name" to "Homework pass (test)", "cost" to 50)),
                "goalTitle" to "Pizza party (test)", "goalTarget" to 500, "nudges" to true, "certificate" to true, "parentView" to true
            )) {
                Backend.postTask(code, "Water the plants (test, daily)", 20, 3, { }, "daily")
                Backend.postTask(code, "Take out the trash (test)", 30, 24, { })
                Groups.join(this, code, Profiles.currentId(this)) { _, _ ->
                    result("Test class ready ✅", "Code: $code\n\nNow try:\n• Open as STUDENT: take a task, mark homework done, buy the class reward in Shop → Rewards\n• Open as TEACHER: approve, see the task board, post more\n\nGroups.sync also fills your To-do list (back on Home).")
                    Groups.lastSync = 0
                }
            }
        }
    }
}
