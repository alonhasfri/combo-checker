package com.combochecker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val cameraCode = 88
    private val restoreCode = 89
    private val beforeCode = 90
    private val afterCode = 91
    private var pendingPhoto: File? = null
    private var beforePhoto: File? = null
    private var recorder: MediaRecorder? = null
    private var recordingKind: String? = null
    private var recordingButton: Button? = null
    private var recordingIdleText = ""
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        Profiles.ensureDefault(this)
        applySneakyModes(prefs)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun header(label: String): TextView = TextView(this).apply {
            this.text = Voice.say(this@MainActivity, label)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad, 0, pad / 4)
        }

        val titleView = TextView(this).apply {
            text = "⭐ Combo Checker"
            textSize = 26f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        var titleTaps = 0
        titleView.setOnClickListener {
            titleTaps++
            if (titleTaps >= 7) {
                titleTaps = 0
                val input = EditText(this@MainActivity).apply {
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                    hint = "Developer PIN"
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Developer")
                    .setMessage("Enter the developer PIN to toggle debug mode.")
                    .setView(input)
                    .setPositiveButton("OK") { _, _ ->
                        if (input.text.toString().trim() == "3939") {
                            val stx = try { org.json.JSONObject(prefs.getString(Profiles.stateKey(this@MainActivity), "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
                            val now = !stx.optBoolean("debug", false)
                            stx.put("debug", now)
                            prefs.edit().putString(Profiles.stateKey(this@MainActivity), stx.toString()).apply()
                            Toast.makeText(
                                this@MainActivity,
                                if (now) "🛠 Debug ON - infinite coins & all skins in the Shop" else "Debug mode OFF",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(this@MainActivity, "Wrong PIN", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        // Fake "update available" prank: a version + "Search for updates" row above the title.
        if (prefs.getBoolean("update", false)) {
            val verRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            verRow.addView(TextView(this).apply {
                text = "Game version 4.2.0" + if (Math.random() < 0.5) "   🔴" else ""
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            verRow.addView(Button(this).apply {
                text = "🔄 Search for updates"
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Updating…")
                        .setMessage("Checking for updates… a new version was found!\n\nDownloading update 4.2.1…\n\nEstimated time remaining: approximately 2,422 years. ⏳\n\nPlease keep the app open.")
                        .setPositiveButton("OK", null)
                        .show()
                }
            })
            root.addView(verRow)
        }

        root.addView(titleView)

        // ----- who's playing -----
        val me = Profiles.current(this)
        val profileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, pad / 2, 0, pad / 2)
        }
        profileRow.addView(TextView(this).apply {
            text = me.optString("emoji", "⭐") + "  " + me.optString("name", "Me")
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        profileRow.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Switch profile")
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                finish()
            }
        })
        root.addView(profileRow)

        // ----- the one big button -----
        root.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "▶  Start the floating star")
            textSize = 18f
            setPadding(pad / 2, pad, pad / 2, pad)
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Allow \"Display over other apps\", then come back and press Start again",
                        Toast.LENGTH_LONG
                    ).show()
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
                Toast.makeText(this@MainActivity, "Star is on. Switch to any app.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Tap the star over any app, circle your finished task, and the AI checks it. No key? It runs in test mode."
            textSize = 13f
            setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Stop floating star")
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, BubbleService::class.java).setAction(BubbleService.ACTION_STOP)
                )
            }
        })

        // ----- check a real-life photo with the camera -----
        root.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "📷  Check a real-life photo")
            setOnClickListener { launchCamera(cameraCode) }
        })
        root.addView(TextView(this).apply {
            text = "Snap homework, a drawing or anything on paper, then circle it or tap “Whole page”."
            textSize = 13f
            setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "📸  Before & after (clean-up)")
            setOnClickListener { launchCamera(beforeCode) }
        })
        root.addView(TextView(this).apply {
            text = "Take a BEFORE photo, tidy up, then take an AFTER photo — the AI rewards the improvement."
            textSize = 13f
            setPadding(0, 0, 0, pad / 2)
        })

        // ----- quick tiles -----
        fun navButton(label: String, target: Class<*>) = Button(this).apply {
            text = Voice.say(this@MainActivity, label)
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
        root.addView(navButton("🛍️  Shop — skins & abilities", ShopActivity::class.java))
        root.addView(navButton("🏆  Proof gallery", GalleryActivity::class.java))
        root.addView(navButton("📊  Stats & badges", StatsActivity::class.java))
        root.addView(navButton("📅  My week (recap)", RecapActivity::class.java))
        root.addView(navButton("🔊  Sound shop", SoundGalleryActivity::class.java))
        root.addView(navButton("😈  Prank a friend", PrankActivity::class.java))
        // Leaderboard can be hidden by a parent (e.g. to avoid sibling pressure).
        if (!prefs.getBoolean("hideLeaderboard", false)) {
            root.addView(navButton("🥇  Leaderboard", LeaderboardActivity::class.java))
        }

        // ----- everything else lives under a collapsed section -----
        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = android.view.View.GONE
        }
        val settingsToggle = Button(this).apply { text = Voice.say(this@MainActivity, "⚙  Settings & setup") }
        settingsToggle.setOnClickListener {
            val showing = settings.visibility == android.view.View.VISIBLE
            settings.visibility = if (showing) android.view.View.GONE else android.view.View.VISIBLE
            settingsToggle.text = Voice.say(this@MainActivity, if (showing) "⚙  Settings & setup" else "⚙  Hide settings")
        }
        root.addView(settingsToggle)
        root.addView(settings)

        // ----- AI key -----
        settings.addView(header("AI key"))
        val keyField = EditText(this).apply {
            hint = "API key: free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        settings.addView(keyField)

        val modelField = EditText(this).apply {
            hint = "Model id (optional). For OpenRouter paste one, e.g. nvidia/nemotron-3.5-super-vl:free"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("gmodel", ""))
        }
        settings.addView(modelField)

        // "Creator key": an official-looking field that unlocks a friend's prank gag. It stores
        // nothing and does nothing else — it's the bait for the shareable creator keys.
        val creatorField = EditText(this).apply {
            hint = "Creator key (unlocks hidden creator features)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        settings.addView(creatorField)
        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Unlock creator features")
            setOnClickListener {
                val set = Pranks.decode(creatorField.text.toString())
                if (set.isNullOrEmpty()) {
                    Toast.makeText(this@MainActivity, "❌ Invalid creator key.", Toast.LENGTH_SHORT).show()
                } else {
                    // Silent: turn on any persistent modes; play one gag if the key had one.
                    val gag = Pranks.applyPersistent(this@MainActivity, set)
                    creatorField.setText("")
                    if (gag != null) startActivity(Intent(this@MainActivity, PrankActivity::class.java).putExtra("gag", gag))
                    else Toast.makeText(this@MainActivity, "✅ Creator features unlocked.", Toast.LENGTH_SHORT).show()
                    if (set.any { it.persist }) recreate()
                }
            }
        })
        // Off-switches for whatever modes are on. Labelled plainly so a victim can eventually
        // find them in here — that's the game.
        for (t in Pranks.persistentModes) {
            if (prefs.getBoolean(t.id, false)) {
                settings.addView(Button(this).apply {
                    text = "Turn off " + t.label
                    setOnClickListener {
                        prefs.edit().putBoolean(t.id, false).apply()
                        Toast.makeText(this@MainActivity, "Turned off", Toast.LENGTH_SHORT).show()
                        recreate()
                    }
                })
            }
        }

        // ----- goals and checks -----
        settings.addView(header("Goals and checks"))
        val goalField = EditText(this).apply {
            hint = "Daily goal: tasks per day"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("goal", 3).toString())
        }
        settings.addView(goalField)

        // Strict AI detector: once a parent PIN is set, only a parent can change this
        // (in the Parent zone), so kids can't switch off the AI-art detector.
        val parentMode = (prefs.getString("parentPin", "") ?: "").isNotEmpty()
        val strictBox: CheckBox?
        if (parentMode) {
            strictBox = null
            settings.addView(TextView(this).apply {
                text = "🔒 Strict AI detector: " + (if (prefs.getBoolean("strict", false)) "ON" else "OFF") +
                    " — set by a parent in the Parent zone."
                textSize = 14f
                setPadding(0, pad / 3, 0, pad / 3)
            })
        } else {
            strictBox = CheckBox(this).apply {
                text = "Strict AI detector: no points when the proof looks AI-made (85%+). Off means a warning only."
                isChecked = prefs.getBoolean("strict", false)
            }
            settings.addView(strictBox)
        }

        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Save settings")
            setOnClickListener {
                val e = prefs.edit()
                    .putString("key", keyField.text.toString().trim())
                    .putString("gmodel", modelField.text.toString().trim())
                    .putInt("goal", goalField.text.toString().toIntOrNull()?.coerceIn(1, 50) ?: 3)
                if (strictBox != null) e.putBoolean("strict", strictBox.isChecked)
                e.apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        // ----- my voice -----
        settings.addView(header("My voice (up to 4 seconds each)"))
        val bonusText = "Record my bonus cheer"
        val finaleText = "Record my finale cheer"

        val bonusBtn = Button(this)
        bonusBtn.text = bonusText
        bonusBtn.setOnClickListener { toggleRecord("bonus", bonusBtn, bonusText) }
        settings.addView(bonusBtn)

        val finaleBtn = Button(this)
        finaleBtn.text = finaleText
        finaleBtn.setOnClickListener { toggleRecord("finale", finaleBtn, finaleText) }
        settings.addView(finaleBtn)

        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Hear my cheers")
            setOnClickListener { playVoice("bonus", "finale") }
        })
        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Delete my recordings")
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Delete recordings?")
                    .setMessage("Your recorded cheers will be removed and the phone voice used again.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        File(filesDir, "voice_bonus.m4a").delete()
                        File(filesDir, "voice_finale.m4a").delete()
                        Toast.makeText(this@MainActivity, "Deleted. The phone voice is used again.", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
        })

        // ----- feedback -----
        settings.addView(header("Feedback"))
        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Send feedback (email)")
            setOnClickListener {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:hasfrialon@gmail.com"))
                    .putExtra(Intent.EXTRA_SUBJECT, "Combo Checker feedback")
                try {
                    startActivity(Intent.createChooser(i, "Send feedback"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "No email app found. Email: hasfrialon@gmail.com", Toast.LENGTH_LONG).show()
                }
            }
        })
        settings.addView(TextView(this).apply {
            text = "Or email hasfrialon@gmail.com"
            textSize = 13f
            setPadding(0, pad / 4, 0, 0)
        })

        // ----- appearance -----
        settings.addView(header("Appearance"))
        val appRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun appButton(label: String, value: String) = Button(this).apply {
            text = label
            isEnabled = prefs.getString("appearance", "light") != value
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener {
                prefs.edit().putString("appearance", value).apply()
                recreate()
            }
        }
        appRow.addView(appButton("Light", "light"))
        appRow.addView(appButton("Dark", "dark"))
        appRow.addView(appButton("Kid", "kid"))
        settings.addView(appRow)
        settings.addView(TextView(this).apply {
            text = "Kid mode uses bigger text."
            textSize = 13f; setPadding(0, 0, 0, pad / 4)
        })

        // ----- backup & restore -----
        settings.addView(header("Backup & restore"))
        settings.addView(TextView(this).apply {
            text = "Back up all profiles, points, coins and settings to a file you can save or send to yourself. (Proof photos aren't included.)"
            textSize = 13f; setPadding(0, 0, 0, pad / 4)
        })
        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Back up my data")
            setOnClickListener { exportBackup() }
        })
        settings.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Restore from a backup")
            setOnClickListener {
                try {
                    val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                    startActivityForResult(Intent.createChooser(i, "Pick a backup file"), restoreCode)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Couldn't open the file picker", Toast.LENGTH_SHORT).show()
                }
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ----- sneaky slow-killer modes that act when the app opens -----
    private val sillyNames = listOf("Sir Dumpling", "Lil Goblin", "Captain Toes", "Mr Bungus", "Princess Snorlax", "Big Noodle", "Sir Yaps-a-lot")

    private fun applySneakyModes(prefs: android.content.SharedPreferences) {
        val id = Profiles.currentId(this)
        // Ghost coins: coins quietly tick down by 1 on roughly a third of opens.
        if (prefs.getBoolean("ghostcoins", false) && Math.random() < 0.34) {
            val key = "state__$id"
            val st = try { org.json.JSONObject(prefs.getString(key, "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
            val coins = st.optInt("coins", 0)
            if (coins > 0) { st.put("coins", coins - 1); prefs.edit().putString(key, st.toString()).apply() }
        }
        // Sticky rename: the profile keeps reverting to a silly name (stable per profile).
        if (prefs.getBoolean("stickyrename", false)) {
            val silly = sillyNames[Math.abs(id.hashCode()) % sillyNames.size]
            if (Profiles.current(this).optString("name") != silly) Profiles.rename(this, id, silly)
        }
    }

    // ----- real-life photo via the camera -----
    private fun launchCamera(code: Int) {
        try {
            val f = File(cacheDir, "camera_${System.currentTimeMillis()}.jpg")
            pendingPhoto = f
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, code)
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(this, "No camera app found", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open the camera: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Rewrite a captured photo upright (apply EXIF rotation) and shrink it, so the proof the
     *  user circles and the image the AI sees match and stay a reasonable size. Best-effort. */
    private fun normalizePhoto(f: File) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2200) sample *= 2
            var bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return

            val orient = ExifInterface(f.absolutePath)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val m = Matrix()
            when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            if (!m.isIdentity) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            java.io.FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        } catch (e: Exception) {
            // keep the original file as-is if anything goes wrong
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(req, resultCode, data)
        if (req == cameraCode && resultCode == RESULT_OK) {
            val f = pendingPhoto
            if (f != null && f.exists() && f.length() > 0) {
                normalizePhoto(f)
                startActivity(Intent(this, ResultActivity::class.java).putExtra("path", f.absolutePath))
            } else {
                Toast.makeText(this, "No photo was saved", Toast.LENGTH_SHORT).show()
            }
            pendingPhoto = null
        } else if (req == beforeCode && resultCode == RESULT_OK) {
            val f = pendingPhoto
            if (f != null && f.exists() && f.length() > 0) {
                normalizePhoto(f)
                beforePhoto = f
                pendingPhoto = null
                Toast.makeText(this, "Before saved. Now tidy up, then take the AFTER photo.", Toast.LENGTH_LONG).show()
                launchCamera(afterCode)
            } else {
                Toast.makeText(this, "No photo was saved", Toast.LENGTH_SHORT).show()
            }
        } else if (req == afterCode && resultCode == RESULT_OK) {
            val after = pendingPhoto
            val before = beforePhoto
            if (after != null && after.exists() && after.length() > 0 && before != null && before.exists()) {
                normalizePhoto(after)
                startActivity(
                    Intent(this, ResultActivity::class.java)
                        .putExtra("path", after.absolutePath)
                        .putExtra("beforePath", before.absolutePath)
                )
            } else {
                Toast.makeText(this, "Couldn't get both photos", Toast.LENGTH_SHORT).show()
            }
            pendingPhoto = null
            beforePhoto = null
        } else if (req == restoreCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val text = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (e: Exception) { "" }
            confirmRestore(text)
        }
    }

    // ----- backup & restore of all saved data (SharedPreferences) -----
    private fun exportBackup() {
        try {
            val all = getSharedPreferences("combo", MODE_PRIVATE).all
            val root = org.json.JSONObject()
            for ((k, v) in all) {
                val e = org.json.JSONObject()
                when (v) {
                    is String -> e.put("t", "s").put("v", v)
                    is Int -> e.put("t", "i").put("v", v)
                    is Long -> e.put("t", "l").put("v", v)
                    is Boolean -> e.put("t", "b").put("v", v)
                    is Float -> e.put("t", "f").put("v", v.toDouble())
                    else -> continue
                }
                root.put(k, e)
            }
            val wrap = org.json.JSONObject().put("combo_backup", 1).put("data", root)
            val f = File(cacheDir, "combo-backup.json")
            f.writeText(wrap.toString())
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(Intent.ACTION_SEND).setType("application/json")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, "Combo Checker backup")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Save or send your backup"))
        } catch (e: Exception) {
            Toast.makeText(this, "Backup failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmRestore(text: String) {
        val data = try {
            val o = org.json.JSONObject(text)
            if (o.optInt("combo_backup", 0) != 1) null else o.getJSONObject("data")
        } catch (e: Exception) { null }
        if (data == null) {
            Toast.makeText(this, "That doesn't look like a Combo Checker backup", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Restore backup?")
            .setMessage("This replaces ALL current profiles, points, coins and settings on this phone with the backup. This can't be undone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Restore") { _, _ -> applyRestore(data) }
            .show()
    }

    private fun applyRestore(data: org.json.JSONObject) {
        try {
            val ed = getSharedPreferences("combo", MODE_PRIVATE).edit()
            ed.clear()
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val e = data.getJSONObject(k)
                when (e.optString("t")) {
                    "s" -> ed.putString(k, e.optString("v"))
                    "i" -> ed.putInt(k, e.optInt("v"))
                    "l" -> ed.putLong(k, e.optLong("v"))
                    "b" -> ed.putBoolean(k, e.optBoolean("v"))
                    "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                }
            }
            ed.apply()
            Toast.makeText(this, "Restored. Restarting…", Toast.LENGTH_SHORT).show()
            val i = Intent(this, ProfileActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(i)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Restore failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ----- recording your own cheers -----

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord(kind: String, btn: Button, idleText: String) {
        if (recordingKind != null) {
            stopRecording()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            Toast.makeText(this, "Allow the microphone, then tap record again", Toast.LENGTH_LONG).show()
            return
        }
        val file = File(filesDir, "voice_$kind.m4a")
        var created: MediaRecorder? = null
        try {
            val rec = newRecorder()
            created = rec
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingKind = kind
            recordingButton = btn
            recordingIdleText = idleText
            btn.text = "Recording... tap to stop"
            handler.postDelayed({ if (recordingKind == kind) stopRecording() }, 4000)
        } catch (e: Exception) {
            runCatching { created?.release() }
            file.delete()
            Toast.makeText(this, "Couldn't record: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        val rec = recorder ?: return
        val kind = recordingKind
        handler.removeCallbacksAndMessages(null)
        val file = if (kind != null) File(filesDir, "voice_$kind.m4a") else null
        try {
            rec.stop()
        } catch (e: Exception) {
            file?.delete() // stopped too quickly: nothing usable was recorded
        }
        runCatching { rec.release() }
        recorder = null
        recordingKind = null
        recordingButton?.text = recordingIdleText
        val ok = file != null && file.exists()
        Toast.makeText(this, if (ok) "Saved" else "Too short, try again", Toast.LENGTH_SHORT).show()
    }

    private fun playVoice(first: String, second: String?) {
        val f = File(filesDir, "voice_$first.m4a")
        if (!f.exists()) {
            if (second != null) playVoice(second, null)
            else Toast.makeText(this, "No recording yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            if (second != null) mp.setOnCompletionListener { playVoice(second, null) }
            mp.start()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't play: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { recorder?.release() }
        runCatching { player?.release() }
        super.onDestroy()
    }
}
