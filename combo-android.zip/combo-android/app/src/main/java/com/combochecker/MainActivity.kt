package com.combochecker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val cameraCode = 88
    private val restoreCode = 89
    private val beforeCode = 90
    private val afterCode = 91
    private var pendingPhoto: File? = null
    private var beforePhoto: File? = null
    private var recorder: MediaRecorder? = null
    private var recordingKind: String? = null
    private var recordingButton: Button? = null
    private var recordingIdleText = ""
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        Profiles.ensureDefault(this)
        applySneakyModes(prefs)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val dev = isDeveloper(prefs)
        val classic = prefs.getBoolean("classicMenu", false)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun header(label: String): TextView = TextView(this).apply {
            this.text = Voice.say(this@MainActivity, label)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad, 0, pad / 4)
        }

        val titleView = TextView(this).apply {
            text = "Comboed"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_HORIZONTAL
        }
        var titleTaps = 0
        titleView.setOnClickListener {
            titleTaps++
            if (titleTaps >= 7) {
                titleTaps = 0
                val input = EditText(this@MainActivity).apply {
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                    hint = Lang.t(this@MainActivity, "Developer PIN")
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(Lang.t(this@MainActivity, "Developer"))
                    .setMessage(Lang.t(this@MainActivity, "Enter the developer PIN to toggle debug mode."))
                    .setView(input)
                    .setPositiveButton(Lang.t(this@MainActivity, "OK")) { _, _ ->
                        if (input.text.toString().trim() == "3939") {
                            val stx = try { org.json.JSONObject(prefs.getString(Profiles.stateKey(this@MainActivity), "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
                            val now = !stx.optBoolean("debug", false)
                            stx.put("debug", now)
                            prefs.edit().putString(Profiles.stateKey(this@MainActivity), stx.toString()).apply()
                            Toast.makeText(
                                this@MainActivity,
                                Lang.t(this@MainActivity, if (now) "🛠 Debug ON - infinite coins & all skins in the Shop" else "Debug mode OFF"),
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Wrong PIN"), Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton(Lang.t(this@MainActivity, "Cancel"), null)
                    .show()
            }
        }
        // Fake "update available" prank: a version + "Search for updates" row above the title.
        if (prefs.getBoolean("update", false)) {
            val verRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            verRow.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Game version 4.2.0") + if (Math.random() < 0.5) "   🔴" else ""
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            verRow.addView(Button(this).apply {
                text = Lang.t(this@MainActivity, "🔄 Search for updates")
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(Lang.t(this@MainActivity, "Updating…"))
                        .setMessage(Lang.t(this@MainActivity, "Checking for updates… a new version was found!\n\nDownloading update 4.2.1…\n\nEstimated time remaining: approximately 2,422 years. ⏳\n\nPlease keep the app open."))
                        .setPositiveButton(Lang.t(this@MainActivity, "OK"), null)
                        .show()
                }
            })
            root.addView(verRow)
        }

        root.addView(titleView)

        // ----- who's playing -----
        val me = Profiles.current(this)
        val profileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, pad / 2, 0, pad / 2)
        }
        profileRow.addView(TextView(this).apply {
            text = me.optString("emoji", "⭐") + "  " + me.optString("name", "Me")
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        profileRow.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Switch profile")
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                finish()
            }
        })
        root.addView(profileRow)

        // ===== reusable fields (declared before the builders below use them) =====
        val keyField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "API key: free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant)")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val modelField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "Model id (optional). For OpenRouter paste one, e.g. nvidia/nemotron-3.5-super-vl:free")
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("gmodel", ""))
        }
        val creatorField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "Creator key (unlocks hidden creator features)")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val goalField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "Daily goal: tasks per day")
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("goal", 3).toString())
        }
        val parentMode = (prefs.getString("parentPin", "") ?: "").isNotEmpty()
        val strictBox: CheckBox? = if (parentMode) null else CheckBox(this).apply {
            text = Lang.t(this@MainActivity, "Strict AI detector: no points when the proof looks AI-made (85%+). Off means a warning only.")
            isChecked = prefs.getBoolean("strict", false)
        }

        fun saveAll() {
            val e = prefs.edit()
                .putString("key", keyField.text.toString().trim())
                .putString("gmodel", modelField.text.toString().trim())
                .putInt("goal", goalField.text.toString().toIntOrNull()?.coerceIn(1, 50) ?: 3)
            if (strictBox != null) e.putBoolean("strict", strictBox.isChecked)
            e.apply()
            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Saved"), Toast.LENGTH_SHORT).show()
        }

        fun navButton(label: String, target: Class<*>) = Button(this).apply {
            text = Voice.say(this@MainActivity, label)
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }

        // A labelled collapsible section (used for "Settings & setup" / "More").
        fun collapsible(container: LinearLayout, closed: String, open: String, build: (LinearLayout) -> Unit) {
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            val toggle = Button(this)
            toggle.text = Voice.say(this@MainActivity, closed)
            toggle.setOnClickListener {
                val showing = body.visibility == View.VISIBLE
                body.visibility = if (showing) View.GONE else View.VISIBLE
                toggle.text = Voice.say(this@MainActivity, if (showing) closed else open)
            }
            container.addView(toggle); container.addView(body)
            build(body)
        }

        // ----- the primary actions (shared by both layouts) -----
        fun addPrimary(c: LinearLayout) {
            c.addView(Button(this).apply {
                tag = "primary"
                text = Voice.say(this@MainActivity, "▶  Start the floating star")
                textSize = 18f
                setPadding(pad / 2, pad, pad / 2, pad)
                setOnClickListener {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Allow \"Display over other apps\", then come back and press Start again"), Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        return@setOnClickListener
                    }
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    }
                    startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
                    Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Star is on. Switch to any app."), Toast.LENGTH_SHORT).show()
                }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Tap the star over any app, circle your finished task, and the AI checks it. No key? It runs in test mode.")
                textSize = 13f; setPadding(0, 0, 0, pad / 2)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Stop floating star")
                setOnClickListener { startService(Intent(this@MainActivity, BubbleService::class.java).setAction(BubbleService.ACTION_STOP)) }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "📷  Check a real-life photo")
                setOnClickListener { launchCamera(cameraCode) }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Snap homework, a drawing or anything on paper, then circle it or tap “Whole page”.")
                textSize = 13f; setPadding(0, 0, 0, pad / 2)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "📸  Before & after (clean-up)")
                setOnClickListener { launchCamera(beforeCode) }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Take a BEFORE photo, tidy up, then take an AFTER photo — the AI rewards the improvement.")
                textSize = 13f; setPadding(0, 0, 0, pad / 2)
            })
        }

        // ----- turning pranks off (free in developer mode, else 300 coins) -----
        fun addPrankOff(c: LinearLayout) {
            val activeTrolls = Pranks.persistentModes.filter { !it.id.startsWith("ads_") && prefs.getBoolean(it.id, false) }
            val adsOn = Ads.anyOn(this)
            if (activeTrolls.isEmpty() && !adsOn) return
            // One master switch that always clears everything — free for developers.
            c.addView(Button(this).apply {
                text = if (dev) Lang.t(this@MainActivity, "🧯 Turn off all pranks")
                       else Lang.t(this@MainActivity, "🧯 Turn off all pranks (300 coins)")
                setOnClickListener {
                    if (dev || spendCoins(300)) {
                        val e = prefs.edit()
                        for (t in Pranks.persistentModes) e.putBoolean(t.id, false)
                        e.apply()
                        Ads.turnOff(this@MainActivity)
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, if (dev) "All pranks turned off" else "All pranks turned off (−300 coins)"), Toast.LENGTH_SHORT).show()
                        recreate()
                    } else {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Not enough coins — you need 300 💸"), Toast.LENGTH_LONG).show()
                    }
                }
            })
            for (t in activeTrolls) {
                c.addView(Button(this).apply {
                    val off = Lang.t(this@MainActivity, "Turn off")
                    text = if (dev) "$off ${t.label}" else "$off ${t.label} (300 " + Lang.t(this@MainActivity, "coins") + ")"
                    setOnClickListener {
                        if (dev || spendCoins(300)) {
                            prefs.edit().putBoolean(t.id, false).apply()
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, if (dev) "Turned off" else "Turned off (−300 coins)"), Toast.LENGTH_SHORT).show()
                            recreate()
                        } else {
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Not enough coins — you need 300 to turn this off 💸"), Toast.LENGTH_LONG).show()
                        }
                    }
                })
            }
            if (adsOn) {
                c.addView(Button(this).apply {
                    text = Lang.t(this@MainActivity, "🛒 Remove ads")
                    setOnClickListener {
                        if (dev) {
                            Ads.turnOff(this@MainActivity)
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Ads removed (developer)"), Toast.LENGTH_SHORT).show()
                            recreate()
                        } else {
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle(Lang.t(this@MainActivity, "Remove ads"))
                                .setMessage(Lang.t(this@MainActivity, "Ads can only be removed by purchasing Ad-Free, or by spending 300 coins."))
                                .setPositiveButton(Lang.t(this@MainActivity, "Buy Ad-Free \$4.99")) { _, _ -> Ads.fakePurchase(this@MainActivity) }
                                .setNegativeButton(Lang.t(this@MainActivity, "Spend 300 coins")) { _, _ ->
                                    if (Ads.disableFor300(this@MainActivity)) {
                                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Ads removed! (−300 coins)"), Toast.LENGTH_SHORT).show()
                                        recreate()
                                    } else {
                                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Not enough coins — you need 300 to remove ads 💸"), Toast.LENGTH_LONG).show()
                                    }
                                }
                                .setNeutralButton(Lang.t(this@MainActivity, "Keep ads"), null)
                                .show()
                        }
                    }
                })
            }
        }

        // ----- setup: the keys, at the top -----
        fun addKeys(c: LinearLayout) {
            c.addView(header("Setup"))
            c.addView(keyField)
            c.addView(modelField)
            c.addView(creatorField)
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Unlock creator features")
                setOnClickListener {
                    val set = Pranks.decode(creatorField.text.toString())
                    if (prefs.getBoolean("trollsBlocked", false)) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "🔒 Pranks are blocked by a parent."), Toast.LENGTH_LONG).show()
                    } else if (set.isNullOrEmpty()) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "❌ Invalid creator key."), Toast.LENGTH_SHORT).show()
                    } else {
                        val gag = Pranks.applyPersistent(this@MainActivity, set)
                        creatorField.setText("")
                        if (set.any { it.id.startsWith("ads_") }) prefs.edit().putBoolean("adsJustUnlocked", true).apply()
                        if (gag != null) startActivity(Intent(this@MainActivity, PrankActivity::class.java).putExtra("gag", gag))
                        else Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "✅ Creator features unlocked."), Toast.LENGTH_SHORT).show()
                        if (set.any { it.persist }) recreate()
                    }
                }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Save settings")
                setOnClickListener { saveAll() }
            })
            addPrankOff(c)
        }

        fun addShop(c: LinearLayout) {
            c.addView(navButton("🛍️  Shop — skins & abilities", ShopActivity::class.java))
            c.addView(navButton("🏆  Proof gallery", GalleryActivity::class.java))
        }

        fun addHelp(c: LinearLayout) {
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "❓  Help & guide")
                setOnClickListener { startActivity(Intent(this@MainActivity, HelpActivity::class.java)) }
            })
        }

        // Less-important screens, kept lower down.
        fun addExtras(c: LinearLayout) {
            c.addView(navButton("📊  Stats & badges", StatsActivity::class.java))
            c.addView(navButton("📅  My week (recap)", RecapActivity::class.java))
            c.addView(navButton("🔊  Sound shop", SoundGalleryActivity::class.java))
            if (!prefs.getBoolean("hideLeaderboard", false)) c.addView(navButton("🥇  Leaderboard", LeaderboardActivity::class.java))
        }

        fun addPrefs(c: LinearLayout) {
            // goals and checks
            c.addView(header("Goals and checks"))
            c.addView(goalField)
            if (strictBox != null) c.addView(strictBox) else c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "🔒 Strict AI detector:") + " " +
                    (if (prefs.getBoolean("strict", false)) Lang.t(this@MainActivity, "ON") else Lang.t(this@MainActivity, "OFF")) +
                    " — " + Lang.t(this@MainActivity, "set by a parent in the Parent zone.")
                textSize = 14f; setPadding(0, pad / 3, 0, pad / 3)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Save settings")
                setOnClickListener { saveAll() }
            })

            // my voice
            c.addView(header("My voice (up to 4 seconds each)"))
            val bonusText = Lang.t(this@MainActivity, "Record my bonus cheer")
            val finaleText = Lang.t(this@MainActivity, "Record my finale cheer")
            val bonusBtn = Button(this); bonusBtn.text = bonusText
            bonusBtn.setOnClickListener { toggleRecord("bonus", bonusBtn, bonusText) }
            c.addView(bonusBtn)
            val finaleBtn = Button(this); finaleBtn.text = finaleText
            finaleBtn.setOnClickListener { toggleRecord("finale", finaleBtn, finaleText) }
            c.addView(finaleBtn)
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Hear my cheers")
                setOnClickListener { playVoice("bonus", "finale") }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Delete my recordings")
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(Lang.t(this@MainActivity, "Delete recordings?"))
                        .setMessage(Lang.t(this@MainActivity, "Your recorded cheers will be removed and the phone voice used again."))
                        .setNegativeButton(Lang.t(this@MainActivity, "Cancel"), null)
                        .setPositiveButton(Lang.t(this@MainActivity, "Delete")) { _, _ ->
                            File(filesDir, "voice_bonus.m4a").delete()
                            File(filesDir, "voice_finale.m4a").delete()
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Deleted. The phone voice is used again."), Toast.LENGTH_SHORT).show()
                        }
                        .show()
                }
            })

            // feedback
            c.addView(header("Feedback"))
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Send feedback (email)")
                setOnClickListener {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:hasfrialon@gmail.com")).putExtra(Intent.EXTRA_SUBJECT, "Comboed feedback")
                    try { startActivity(Intent.createChooser(i, Lang.t(this@MainActivity, "Send feedback"))) }
                    catch (e: Exception) { Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "No email app found. Email: hasfrialon@gmail.com"), Toast.LENGTH_LONG).show() }
                }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Or email hasfrialon@gmail.com"); textSize = 13f; setPadding(0, pad / 4, 0, 0)
            })

            // appearance
            c.addView(header("Appearance"))
            val appRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun appButton(label: String, value: String) = Button(this).apply {
                text = label
                isEnabled = prefs.getString("appearance", "light") != value
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { prefs.edit().putString("appearance", value).apply(); recreate() }
            }
            appRow.addView(appButton(Lang.t(this, "Light"), "light"))
            appRow.addView(appButton(Lang.t(this, "Dark"), "dark"))
            appRow.addView(appButton(Lang.t(this, "Kid"), "kid"))
            c.addView(appRow)
            c.addView(TextView(this).apply { text = Lang.t(this@MainActivity, "Kid mode uses bigger text."); textSize = 13f; setPadding(0, 0, 0, pad / 4) })

            // language
            c.addView(header("Language"))
            val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun langButton(label: String, value: String) = Button(this).apply {
                text = label
                isEnabled = Lang.code(this@MainActivity) != value
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { Lang.set(this@MainActivity, value); recreate() }
            }
            langRow.addView(langButton("English", "en"))
            langRow.addView(langButton("עברית", "he"))
            c.addView(langRow)

            // menu layout (switch between the new and the classic menu)
            c.addView(header("Menu"))
            c.addView(Button(this).apply {
                text = if (classic) Lang.t(this@MainActivity, "Use the new menu") else Lang.t(this@MainActivity, "Use the classic menu")
                setOnClickListener { prefs.edit().putBoolean("classicMenu", !classic).apply(); recreate() }
            })

            // backup & restore
            c.addView(header("Backup & restore"))
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Back up all profiles, points, coins and settings to a file you can save or send to yourself. (Proof photos aren't included.)")
                textSize = 13f; setPadding(0, 0, 0, pad / 4)
            })
            c.addView(Button(this).apply { text = Voice.say(this@MainActivity, "Back up my data"); setOnClickListener { exportBackup() } })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Restore from a backup")
                setOnClickListener {
                    try {
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                        startActivityForResult(Intent.createChooser(i, Lang.t(this@MainActivity, "Pick a backup file")), restoreCode)
                    } catch (e: Exception) { Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Couldn't open the file picker"), Toast.LENGTH_SHORT).show() }
                }
            })
        }

        // A tiny, legal-looking footer. It's the hidden door to the creator menu (press it).
        fun addFooter(c: LinearLayout) {
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Terms of Service · Privacy Policy")
                textSize = 10f
                setTextColor(Color.parseColor("#9aa3bf"))
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, pad, 0, pad / 2)
                isClickable = true
                setOnClickListener { startActivity(Intent(this@MainActivity, PrankActivity::class.java)) }
            })
        }

        // ===== assemble the screen =====
        addPrimary(root)
        if (classic) {
            // The old flat menu, kept available via Settings → Menu.
            addShop(root)
            addExtras(root)
            addHelp(root)
            collapsible(root, "⚙  Settings & setup", "⚙  Hide settings") { s -> addKeys(s); addPrefs(s) }
        } else {
            // Important things up top; the rest tucked into "More".
            addKeys(root)
            addShop(root)
            addHelp(root)
            collapsible(root, "⬇  More", "⬆  Hide extras") { s -> addExtras(s); addPrefs(s) }
        }
        addFooter(root)

        beautify(root)
        val scroll = ScrollView(this).apply {
            addView(root)
            background = screenBackground()
        }
        val banner = Ads.bannerView(this)
        if (banner != null) {
            // Pin the banner below the scroll area so it stays covering the bottom while you scroll.
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = screenBackground() }
            wrap.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            wrap.addView(banner, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            setContentView(wrap)
        } else {
            setContentView(scroll)
        }
        // The login wall blocks everything until escaped; skip the other pop-ups while it's up.
        if (!LoginWall.maybeShow(this)) {
            Crash.maybeShow(this)
            root.post {
                if (prefs.getBoolean("adsJustUnlocked", false)) {
                    prefs.edit().remove("adsJustUnlocked").apply()
                    Ads.forceInterstitial(this)
                } else Ads.maybeInterstitial(this)
            }
        }
    }

    // ----- visual polish (theme-aware) -----
    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun isDarkTheme() = Appearance.mode(this) == "dark"
    private fun roundedBg(hex: String) = GradientDrawable().apply { setColor(Color.parseColor(hex)); cornerRadius = dpi(14).toFloat() }

    private fun screenBackground(): GradientDrawable {
        val dark = isDarkTheme()
        val top = if (dark) "#0d0f1a" else "#eef2f9"
        val bot = if (dark) "#141a2e" else "#dbe4f3"
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor(top), Color.parseColor(bot)))
    }

    /** Give every button a consistent rounded look; the primary (tagged) button gets the accent. */
    private fun beautify(root: View) {
        val surface = if (isDarkTheme()) "#1c2138" else "#ffffff"
        styleButtons(root, surface)
    }

    private fun styleButtons(v: View, surface: String) {
        if (v is Button) {
            val primary = v.tag == "primary"
            v.background = roundedBg(if (primary) "#3a66d6" else surface)
            v.setAllCaps(false)
            if (primary) { v.setTextColor(Color.WHITE); v.setTypeface(v.typeface, Typeface.BOLD) }
            val p = dpi(14); v.setPadding(p, dpi(12), p, dpi(12))
            v.minimumHeight = dpi(48)
            (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.topMargin = dpi(8); v.layoutParams = it }
        } else if (v is ViewGroup) {
            for (i in 0 until v.childCount) styleButtons(v.getChildAt(i), surface)
        }
    }

    // Developer mode = the current profile's debug flag (title 7-tap + PIN 3939).
    private fun isDeveloper(prefs: android.content.SharedPreferences): Boolean {
        val id = Profiles.currentId(this)
        val st = try { org.json.JSONObject(prefs.getString("state__$id", "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        return st.optBoolean("debug", false)
    }

    /** Spend coins from the current profile; false (no change) if there aren't enough. */
    private fun spendCoins(amount: Int): Boolean {
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        val id = Profiles.currentId(this)
        val key = "state__$id"
        val st = try { org.json.JSONObject(prefs.getString(key, "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        val coins = st.optInt("coins", 0)
        if (coins < amount) return false
        st.put("coins", coins - amount)
        prefs.edit().putString(key, st.toString()).apply()
        return true
    }

    // ----- sneaky slow-killer modes that act when the app opens -----
    private val sillyNames = listOf("Sir Dumpling", "Lil Goblin", "Captain Toes", "Mr Bungus", "Princess Snorlax", "Big Noodle", "Sir Yaps-a-lot")

    private fun applySneakyModes(prefs: android.content.SharedPreferences) {
        val id = Profiles.currentId(this)
        // Ghost coins: coins quietly tick down by 1 on roughly a third of opens.
        if (prefs.getBoolean("ghostcoins", false) && Math.random() < 0.34) {
            val key = "state__$id"
            val st = try { org.json.JSONObject(prefs.getString(key, "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
            val coins = st.optInt("coins", 0)
            if (coins > 0) { st.put("coins", coins - 1); prefs.edit().putString(key, st.toString()).apply() }
        }
        // Sticky rename: the profile keeps reverting to a silly name (stable per profile). The real
        // name is saved the first time so it can be restored when the troll is turned off.
        val origKey = "origname__$id"
        if (prefs.getBoolean("stickyrename", false)) {
            val silly = sillyNames[Math.floorMod(id.hashCode(), sillyNames.size)]
            val cur = Profiles.current(this).optString("name")
            if (cur != silly) {
                if (!prefs.contains(origKey)) prefs.edit().putString(origKey, cur).apply()
                Profiles.rename(this, id, silly)
            }
        } else if (prefs.contains(origKey)) {
            // Troll is off — put the real name back.
            prefs.getString(origKey, null)?.let { Profiles.rename(this, id, it) }
            prefs.edit().remove(origKey).apply()
        }
    }

    // ----- real-life photo via the camera -----
    private fun launchCamera(code: Int) {
        try {
            val f = File(cacheDir, "camera_${System.currentTimeMillis()}.jpg")
            pendingPhoto = f
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, code)
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(this, Lang.t(this, "No camera app found"), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Couldn't open the camera:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Rewrite a captured photo upright (apply EXIF rotation) and shrink it, so the proof the
     *  user circles and the image the AI sees match and stay a reasonable size. Best-effort. */
    private fun normalizePhoto(f: File) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2200) sample *= 2
            var bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return

            val orient = ExifInterface(f.absolutePath)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val m = Matrix()
            when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            if (!m.isIdentity) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            java.io.FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        } catch (e: Exception) {
            // keep the original file as-is if anything goes wrong
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(req, resultCode, data)
        if (req == cameraCode && resultCode == RESULT_OK) {
            val f = pendingPhoto
            if (f != null && f.exists() && f.length() > 0) {
                normalizePhoto(f)
                startActivity(Intent(this, ResultActivity::class.java).putExtra("path", f.absolutePath))
            } else {
                Toast.makeText(this, Lang.t(this, "No photo was saved"), Toast.LENGTH_SHORT).show()
            }
            pendingPhoto = null
        } else if (req == beforeCode && resultCode == RESULT_OK) {
            val f = pendingPhoto
            if (f != null && f.exists() && f.length() > 0) {
                normalizePhoto(f)
                beforePhoto = f
                pendingPhoto = null
                Toast.makeText(this, Lang.t(this, "Before saved. Now tidy up, then take the AFTER photo."), Toast.LENGTH_LONG).show()
                launchCamera(afterCode)
            } else {
                Toast.makeText(this, Lang.t(this, "No photo was saved"), Toast.LENGTH_SHORT).show()
            }
        } else if (req == afterCode && resultCode == RESULT_OK) {
            val after = pendingPhoto
            val before = beforePhoto
            if (after != null && after.exists() && after.length() > 0 && before != null && before.exists()) {
                normalizePhoto(after)
                startActivity(
                    Intent(this, ResultActivity::class.java)
                        .putExtra("path", after.absolutePath)
                        .putExtra("beforePath", before.absolutePath)
                )
            } else {
                Toast.makeText(this, Lang.t(this, "Couldn't get both photos"), Toast.LENGTH_SHORT).show()
            }
            pendingPhoto = null
            beforePhoto = null
        } else if (req == restoreCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val text = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (e: Exception) { "" }
            confirmRestore(text)
        }
    }

    // ----- backup & restore of all saved data (SharedPreferences) -----
    private fun exportBackup() {
        try {
            val all = getSharedPreferences("combo", MODE_PRIVATE).all
            val root = org.json.JSONObject()
            for ((k, v) in all) {
                val e = org.json.JSONObject()
                when (v) {
                    is String -> e.put("t", "s").put("v", v)
                    is Int -> e.put("t", "i").put("v", v)
                    is Long -> e.put("t", "l").put("v", v)
                    is Boolean -> e.put("t", "b").put("v", v)
                    is Float -> e.put("t", "f").put("v", v.toDouble())
                    else -> continue
                }
                root.put(k, e)
            }
            val wrap = org.json.JSONObject().put("combo_backup", 1).put("data", root)
            val f = File(cacheDir, "combo-backup.json")
            f.writeText(wrap.toString())
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(Intent.ACTION_SEND).setType("application/json")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, "Comboed backup")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, Lang.t(this, "Save or send your backup")))
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Backup failed:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmRestore(text: String) {
        val data = try {
            val o = org.json.JSONObject(text)
            if (o.optInt("combo_backup", 0) != 1) null else o.getJSONObject("data")
        } catch (e: Exception) { null }
        if (data == null) {
            Toast.makeText(this, Lang.t(this, "That doesn't look like a Comboed backup"), Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Restore backup?"))
            .setMessage(Lang.t(this, "This replaces ALL current profiles, points, coins and settings on this phone with the backup. This can't be undone."))
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .setPositiveButton(Lang.t(this, "Restore")) { _, _ -> applyRestore(data) }
            .show()
    }

    private fun applyRestore(data: org.json.JSONObject) {
        try {
            val ed = getSharedPreferences("combo", MODE_PRIVATE).edit()
            ed.clear()
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val e = data.getJSONObject(k)
                when (e.optString("t")) {
                    "s" -> ed.putString(k, e.optString("v"))
                    "i" -> ed.putInt(k, e.optInt("v"))
                    "l" -> ed.putLong(k, e.optLong("v"))
                    "b" -> ed.putBoolean(k, e.optBoolean("v"))
                    "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                }
            }
            ed.apply()
            Toast.makeText(this, Lang.t(this, "Restored. Restarting…"), Toast.LENGTH_SHORT).show()
            val i = Intent(this, ProfileActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(i)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Restore failed:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ----- recording your own cheers -----

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord(kind: String, btn: Button, idleText: String) {
        if (recordingKind != null) {
            stopRecording()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            Toast.makeText(this, Lang.t(this, "Allow the microphone, then tap record again"), Toast.LENGTH_LONG).show()
            return
        }
        val file = File(filesDir, "voice_$kind.m4a")
        var created: MediaRecorder? = null
        try {
            val rec = newRecorder()
            created = rec
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingKind = kind
            recordingButton = btn
            recordingIdleText = idleText
            btn.text = Lang.t(this, "Recording... tap to stop")
            handler.postDelayed({ if (recordingKind == kind) stopRecording() }, 4000)
        } catch (e: Exception) {
            runCatching { created?.release() }
            file.delete()
            Toast.makeText(this, Lang.t(this, "Couldn't record:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        val rec = recorder ?: return
        val kind = recordingKind
        handler.removeCallbacksAndMessages(null)
        val file = if (kind != null) File(filesDir, "voice_$kind.m4a") else null
        try {
            rec.stop()
        } catch (e: Exception) {
            file?.delete() // stopped too quickly: nothing usable was recorded
        }
        runCatching { rec.release() }
        recorder = null
        recordingKind = null
        recordingButton?.text = recordingIdleText
        val ok = file != null && file.exists()
        Toast.makeText(this, Lang.t(this, if (ok) "Saved" else "Too short, try again"), Toast.LENGTH_SHORT).show()
    }

    private fun playVoice(first: String, second: String?) {
        val f = File(filesDir, "voice_$first.m4a")
        if (!f.exists()) {
            if (second != null) playVoice(second, null)
            else Toast.makeText(this, Lang.t(this, "No recording yet"), Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            if (second != null) mp.setOnCompletionListener { playVoice(second, null) }
            mp.start()
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Couldn't play:") + " ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { recorder?.release() }
        runCatching { player?.release() }
        super.onDestroy()
    }
}
