package com.combochecker

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var recorder: MediaRecorder? = null
    private var recordingKind: String? = null
    private var recordingButton: Button? = null
    private var recordingIdleText = ""
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun header(label: String): TextView = TextView(this).apply {
            this.text = label
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad, 0, pad / 4)
        }

        root.addView(TextView(this).apply {
            text = "⭐ Combo Checker"
            textSize = 26f
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "A floating star stays on your screen. Tap it, circle the proof that a task is done, and the AI checks it. Earn points, combos, levels and ranks. Without a key it runs in test mode with random bonuses."
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 2)
        })

        // ----- AI key -----
        root.addView(header("AI key"))
        val keyField = EditText(this).apply {
            hint = "API key: free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        root.addView(keyField)

        val modelField = EditText(this).apply {
            hint = "Model id (optional). For OpenRouter paste one, e.g. nvidia/nemotron-3.5-super-vl:free"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("gmodel", ""))
        }
        root.addView(modelField)

        // ----- goals and checks -----
        root.addView(header("Goals and checks"))
        val goalField = EditText(this).apply {
            hint = "Daily goal: tasks per day"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("goal", 3).toString())
        }
        root.addView(goalField)

        val strictBox = CheckBox(this).apply {
            text = "Strict AI detector: no points when the proof looks AI-made (85%+). Off means a warning only."
            isChecked = prefs.getBoolean("strict", false)
        }
        root.addView(strictBox)

        root.addView(Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                prefs.edit()
                    .putString("key", keyField.text.toString().trim())
                    .putString("gmodel", modelField.text.toString().trim())
                    .putInt("goal", goalField.text.toString().toIntOrNull()?.coerceIn(1, 50) ?: 3)
                    .putBoolean("strict", strictBox.isChecked)
                    .apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        // ----- my voice -----
        root.addView(header("My voice (up to 4 seconds each)"))
        val bonusText = "Record my bonus cheer"
        val finaleText = "Record my finale cheer"

        val bonusBtn = Button(this)
        bonusBtn.text = bonusText
        bonusBtn.setOnClickListener { toggleRecord("bonus", bonusBtn, bonusText) }
        root.addView(bonusBtn)

        val finaleBtn = Button(this)
        finaleBtn.text = finaleText
        finaleBtn.setOnClickListener { toggleRecord("finale", finaleBtn, finaleText) }
        root.addView(finaleBtn)

        root.addView(Button(this).apply {
            text = "Hear my cheers"
            setOnClickListener { playVoice("bonus", "finale") }
        })
        root.addView(Button(this).apply {
            text = "Delete my recordings"
            setOnClickListener {
                File(filesDir, "voice_bonus.m4a").delete()
                File(filesDir, "voice_finale.m4a").delete()
                Toast.makeText(this@MainActivity, "Deleted. The phone voice is used again.", Toast.LENGTH_SHORT).show()
            }
        })

        // ----- gallery -----
        root.addView(header("Your wins"))
        root.addView(Button(this).apply {
            text = "Open proof gallery"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, GalleryActivity::class.java))
            }
        })

        // ----- floating star -----
        root.addView(header("Floating star"))
        root.addView(Button(this).apply {
            text = "Start floating star"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Allow \"Display over other apps\", then come back and press Start again",
                        Toast.LENGTH_LONG
                    ).show()
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
                Toast.makeText(this@MainActivity, "Star is on. Switch to any app.", Toast.LENGTH_SHORT).show()
            }
        })

        root.addView(Button(this).apply {
            text = "Stop floating star"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, BubbleService::class.java).setAction(BubbleService.ACTION_STOP)
                )
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ----- recording your own cheers -----

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord(kind: String, btn: Button, idleText: String) {
        if (recordingKind != null) {
            stopRecording()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            Toast.makeText(this, "Allow the microphone, then tap record again", Toast.LENGTH_LONG).show()
            return
        }
        val file = File(filesDir, "voice_$kind.m4a")
        var created: MediaRecorder? = null
        try {
            val rec = newRecorder()
            created = rec
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingKind = kind
            recordingButton = btn
            recordingIdleText = idleText
            btn.text = "Recording... tap to stop"
            handler.postDelayed({ if (recordingKind == kind) stopRecording() }, 4000)
        } catch (e: Exception) {
            runCatching { created?.release() }
            file.delete()
            Toast.makeText(this, "Couldn't record: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        val rec = recorder ?: return
        val kind = recordingKind
        handler.removeCallbacksAndMessages(null)
        val file = if (kind != null) File(filesDir, "voice_$kind.m4a") else null
        try {
            rec.stop()
        } catch (e: Exception) {
            file?.delete() // stopped too quickly: nothing usable was recorded
        }
        runCatching { rec.release() }
        recorder = null
        recordingKind = null
        recordingButton?.text = recordingIdleText
        val ok = file != null && file.exists()
        Toast.makeText(this, if (ok) "Saved" else "Too short, try again", Toast.LENGTH_SHORT).show()
    }

    private fun playVoice(first: String, second: String?) {
        val f = File(filesDir, "voice_$first.m4a")
        if (!f.exists()) {
            if (second != null) playVoice(second, null)
            else Toast.makeText(this, "No recording yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            if (second != null) mp.setOnCompletionListener { playVoice(second, null) }
            mp.start()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't play: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { recorder?.release() }
        runCatching { player?.release() }
        super.onDestroy()
    }
}
