package com.combochecker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.media.ExifInterface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

open class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private val cameraCode = 88
    private val restoreCode = 89
    private val beforeCode = 90
    private val afterCode = 91
    private var pendingPhoto: File? = null
    private var beforePhoto: File? = null
    private var recorder: MediaRecorder? = null
    private var recordingKind: String? = null
    private var recordingButton: TextView? = null
    private var recordingIdleText = ""
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        Profiles.ensureDefault(this)
        if (this is SettingsActivity) { buildSettings(prefs, isDeveloper(prefs)); return }
        applySneakyModes(prefs)
        ComboWidget.refresh(this)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val dev = isDeveloper(prefs)
        val classic = prefs.getBoolean("classicMenu", false)
        if (!classic) { buildModernHome(prefs); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun header(label: String): TextView = TextView(this).apply {
            this.text = Voice.say(this@MainActivity, label)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad, 0, pad / 4)
        }

        val titleView = TextView(this).apply {
            text = "Comboed"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_HORIZONTAL
        }
        var titleTaps = 0
        titleView.setOnClickListener {
            titleTaps++
            if (titleTaps >= 7) {
                titleTaps = 0
                val input = EditText(this@MainActivity).apply {
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                    hint = Lang.t(this@MainActivity, "Developer PIN")
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(Lang.t(this@MainActivity, "Developer"))
                    .setMessage(Lang.t(this@MainActivity, "Enter the developer PIN to toggle debug mode."))
                    .setView(input)
                    .setPositiveButton(Lang.t(this@MainActivity, "OK")) { _, _ ->
                        if (input.text.toString().trim() == "3939") {
                            val stx = try { org.json.JSONObject(prefs.getString(Profiles.stateKey(this@MainActivity), "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
                            val now = !stx.optBoolean("debug", false)
                            stx.put("debug", now)
                            prefs.edit().putString(Profiles.stateKey(this@MainActivity), stx.toString()).apply()
                            Toast.makeText(
                                this@MainActivity,
                                Lang.t(this@MainActivity, if (now) "🛠 Debug ON - infinite coins & all skins in the Shop" else "Debug mode OFF"),
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Wrong PIN"), Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton(Lang.t(this@MainActivity, "Cancel"), null)
                    .show()
            }
        }
        // Fake "update available" prank: a version + "Search for updates" row above the title.
        if (prefs.getBoolean("update", false)) {
            val verRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            verRow.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Game version 4.2.0") + if (Math.random() < 0.5) "   🔴" else ""
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            verRow.addView(Button(this).apply {
                text = Lang.t(this@MainActivity, "🔄 Search for updates")
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(Lang.t(this@MainActivity, "Updating…"))
                        .setMessage(Lang.t(this@MainActivity, "Checking for updates… a new version was found!\n\nDownloading update 4.2.1…\n\nEstimated time remaining: approximately 2,422 years. ⏳\n\nPlease keep the app open."))
                        .setPositiveButton(Lang.t(this@MainActivity, "OK"), null)
                        .show()
                }
            })
            root.addView(verRow)
        }

        root.addView(titleView)

        // ----- live global user counter (anonymous; from the free Firebase backend) -----
        val counterView = TextView(this).apply {
            text = Lang.t(this@MainActivity, "👥 counting people…")
            textSize = 13f; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, pad / 6, 0, pad / 6)
        }
        root.addView(counterView)
        Backend.registerThenCount(this) { n ->
            counterView.text = if (Lang.isHebrew(this)) "👥 $n משתמשים ב‑Comboed" else "👥 $n people use Comboed"
        }
        publishBestProfile()

        // ----- who's playing -----
        val me = Profiles.current(this)
        val profileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, pad / 2, 0, pad / 2)
        }
        profileRow.addView(TextView(this).apply {
            text = me.optString("emoji", "⭐") + "  " + me.optString("name", "Me")
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        profileRow.addView(Button(this).apply {
            text = Voice.say(this@MainActivity, "Switch profile")
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                finish()
            }
        })
        root.addView(profileRow)

        // ===== reusable fields (declared before the builders below use them) =====
        val keyField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "API key: free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant)")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val modelField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "Model id (optional). For OpenRouter paste one, e.g. nvidia/nemotron-3.5-super-vl:free")
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("gmodel", ""))
        }
        val creatorField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "Update key (unlocks hidden update features)")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        val goalField = EditText(this).apply {
            hint = Lang.t(this@MainActivity, "Daily goal: tasks per day")
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("goal", 3).toString())
        }
        val parentMode = (prefs.getString("parentPin", "") ?: "").isNotEmpty()
        val strictBox: CheckBox? = if (parentMode) null else CheckBox(this).apply {
            text = Lang.t(this@MainActivity, "Strict AI detector: no points when the proof looks AI-made (85%+). Off means a warning only.")
            isChecked = prefs.getBoolean("strict", false)
        }

        fun saveAll() {
            val e = prefs.edit()
                .putString("key", keyField.text.toString().trim())
                .putString("gmodel", modelField.text.toString().trim())
                .putInt("goal", goalField.text.toString().toIntOrNull()?.coerceIn(1, 50) ?: 3)
            if (strictBox != null) e.putBoolean("strict", strictBox.isChecked)
            e.apply()
            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Saved"), Toast.LENGTH_SHORT).show()
        }

        fun navButton(label: String, target: Class<*>) = Button(this).apply {
            text = Voice.say(this@MainActivity, label)
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }

        // A labelled collapsible section (used for "Settings & setup" / "More").
        fun collapsible(container: LinearLayout, closed: String, open: String, build: (LinearLayout) -> Unit) {
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            val toggle = Button(this)
            toggle.text = Voice.say(this@MainActivity, closed)
            toggle.setOnClickListener {
                val showing = body.visibility == View.VISIBLE
                body.visibility = if (showing) View.GONE else View.VISIBLE
                toggle.text = Voice.say(this@MainActivity, if (showing) closed else open)
            }
            container.addView(toggle); container.addView(body)
            build(body)
        }

        // ----- the primary actions (shared by both layouts) -----
        fun addPrimary(c: LinearLayout) {
            c.addView(Button(this).apply {
                tag = "primary"
                text = Voice.say(this@MainActivity, "▶  Start the floating star")
                textSize = 18f
                setPadding(pad / 2, pad, pad / 2, pad)
                setOnClickListener {
                    if (!Settings.canDrawOverlays(this@MainActivity)) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Allow \"Display over other apps\", then come back and press Start again"), Toast.LENGTH_LONG).show()
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        return@setOnClickListener
                    }
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                    }
                    startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
                    Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Star is on. Switch to any app."), Toast.LENGTH_SHORT).show()
                }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Tap the star over any app, circle your finished task, and the AI checks it. No key? It runs in test mode.")
                textSize = 13f; setPadding(0, 0, 0, pad / 2)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Stop floating star")
                setOnClickListener { startService(Intent(this@MainActivity, BubbleService::class.java).setAction(BubbleService.ACTION_STOP)) }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "📷  Check a real-life photo")
                setOnClickListener { launchCamera(cameraCode) }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Snap homework, a drawing or anything on paper, then circle it or tap “Whole page”.")
                textSize = 13f; setPadding(0, 0, 0, pad / 2)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "📸  Before & after (clean-up)")
                setOnClickListener { launchCamera(beforeCode) }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Take a BEFORE photo, tidy up, then take an AFTER photo — the AI rewards the improvement.")
                textSize = 13f; setPadding(0, 0, 0, pad / 2)
            })
        }

        // ----- turning pranks off (free in developer mode, else 300 coins) -----
        fun addPrankOff(c: LinearLayout) {
            val activeTrolls = Pranks.persistentModes.filter { !it.id.startsWith("ads_") && prefs.getBoolean(it.id, false) }
            val adsOn = Ads.anyOn(this)
            if (activeTrolls.isEmpty() && !adsOn) return
            // One master switch that always clears everything — free for developers.
            c.addView(Button(this).apply {
                text = if (dev) Lang.t(this@MainActivity, "🧯 Turn off all pranks")
                       else Lang.t(this@MainActivity, "🧯 Turn off all pranks (300 coins)")
                setOnClickListener {
                    if (dev || spendCoins(300)) {
                        val e = prefs.edit()
                        for (t in Pranks.persistentModes) e.putBoolean(t.id, false)
                        e.apply()
                        Ads.turnOff(this@MainActivity)
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, if (dev) "All pranks turned off" else "All pranks turned off (−300 coins)"), Toast.LENGTH_SHORT).show()
                        recreate()
                    } else {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Not enough coins — you need 300 💸"), Toast.LENGTH_LONG).show()
                    }
                }
            })
            for (t in activeTrolls) {
                c.addView(Button(this).apply {
                    val off = Lang.t(this@MainActivity, "Turn off")
                    text = if (dev) "$off ${t.label}" else "$off ${t.label} (300 " + Lang.t(this@MainActivity, "coins") + ")"
                    setOnClickListener {
                        if (dev || spendCoins(300)) {
                            prefs.edit().putBoolean(t.id, false).apply()
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, if (dev) "Turned off" else "Turned off (−300 coins)"), Toast.LENGTH_SHORT).show()
                            recreate()
                        } else {
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Not enough coins — you need 300 to turn this off 💸"), Toast.LENGTH_LONG).show()
                        }
                    }
                })
            }
            if (adsOn) {
                c.addView(Button(this).apply {
                    text = Lang.t(this@MainActivity, "🛒 Remove ads")
                    setOnClickListener {
                        if (dev) {
                            Ads.turnOff(this@MainActivity)
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Ads removed (developer)"), Toast.LENGTH_SHORT).show()
                            recreate()
                        } else {
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle(Lang.t(this@MainActivity, "Remove ads"))
                                .setMessage(Lang.t(this@MainActivity, "Ads can only be removed by purchasing Ad-Free, or by spending 300 coins."))
                                .setPositiveButton(Lang.t(this@MainActivity, "Buy Ad-Free \$4.99")) { _, _ -> Ads.fakePurchase(this@MainActivity) }
                                .setNegativeButton(Lang.t(this@MainActivity, "Spend 300 coins")) { _, _ ->
                                    if (Ads.disableFor300(this@MainActivity)) {
                                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Ads removed! (−300 coins)"), Toast.LENGTH_SHORT).show()
                                        recreate()
                                    } else {
                                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Not enough coins — you need 300 to remove ads 💸"), Toast.LENGTH_LONG).show()
                                    }
                                }
                                .setNeutralButton(Lang.t(this@MainActivity, "Keep ads"), null)
                                .show()
                        }
                    }
                })
            }
        }

        // ----- setup: the keys, at the top -----
        fun addKeys(c: LinearLayout) {
            c.addView(header("Setup"))
            c.addView(keyField)
            c.addView(modelField)
            c.addView(creatorField)
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Unlock update features")
                setOnClickListener {
                    val set = Pranks.decode(creatorField.text.toString())
                    if (prefs.getBoolean("trollsBlocked", false)) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "🔒 Pranks are blocked by a parent."), Toast.LENGTH_LONG).show()
                    } else if (set.isNullOrEmpty()) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "❌ Invalid update key."), Toast.LENGTH_SHORT).show()
                    } else {
                        val gag = Pranks.applyPersistent(this@MainActivity, set)
                        creatorField.setText("")
                        if (set.any { it.id.startsWith("ads_") }) prefs.edit().putBoolean("adsJustUnlocked", true).apply()
                        if (gag != null) startActivity(Intent(this@MainActivity, PrankActivity::class.java).putExtra("gag", gag))
                        else Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "✅ Update features unlocked."), Toast.LENGTH_SHORT).show()
                        if (set.any { it.persist }) recreate()
                    }
                }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Save settings")
                setOnClickListener { saveAll() }
            })
            addPrankOff(c)
        }

        fun addShop(c: LinearLayout) {
            c.addView(navButton("🛍️  Shop — skins & abilities", ShopActivity::class.java))
            c.addView(navButton("🏆  Proof gallery", GalleryActivity::class.java))
        }

        fun addHelp(c: LinearLayout) {
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "❓  Help & guide")
                setOnClickListener { startActivity(Intent(this@MainActivity, HelpActivity::class.java)) }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "📣  Invite friends")
                setOnClickListener {
                    val msg = Lang.t(this@MainActivity, "I'm using Comboed — it turns real tasks into a game with points and rewards! Try it:") +
                        " https://github.com/alonhasfri/combo-checker/releases/latest"
                    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg)
                    try { startActivity(Intent.createChooser(i, Lang.t(this@MainActivity, "Invite friends"))) } catch (e: Exception) {}
                }
            })
        }

        // Less-important screens, kept lower down.
        fun addExtras(c: LinearLayout) {
            c.addView(navButton("📊  Stats & badges", StatsActivity::class.java))
            c.addView(navButton("📅  My week (recap)", RecapActivity::class.java))
            c.addView(navButton("🔊  Sound shop", SoundGalleryActivity::class.java))
            if (!prefs.getBoolean("hideLeaderboard", false)) c.addView(navButton("🥇  Leaderboard", LeaderboardActivity::class.java))
        }

        fun addPrefs(c: LinearLayout) {
            // goals and checks
            c.addView(header("Goals and checks"))
            c.addView(goalField)
            if (strictBox != null) c.addView(strictBox) else c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "🔒 Strict AI detector:") + " " +
                    (if (prefs.getBoolean("strict", false)) Lang.t(this@MainActivity, "ON") else Lang.t(this@MainActivity, "OFF")) +
                    " — " + Lang.t(this@MainActivity, "set by a parent in the Parent zone.")
                textSize = 14f; setPadding(0, pad / 3, 0, pad / 3)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Save settings")
                setOnClickListener { saveAll() }
            })

            // my voice
            c.addView(header("My voice (up to 4 seconds each)"))
            val bonusText = Lang.t(this@MainActivity, "Record my bonus cheer")
            val finaleText = Lang.t(this@MainActivity, "Record my finale cheer")
            val bonusBtn = Button(this); bonusBtn.text = bonusText
            bonusBtn.setOnClickListener { toggleRecord("bonus", bonusBtn, bonusText) }
            c.addView(bonusBtn)
            val finaleBtn = Button(this); finaleBtn.text = finaleText
            finaleBtn.setOnClickListener { toggleRecord("finale", finaleBtn, finaleText) }
            c.addView(finaleBtn)
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Hear my cheers")
                setOnClickListener { playVoice("bonus", "finale") }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Delete my recordings")
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(Lang.t(this@MainActivity, "Delete recordings?"))
                        .setMessage(Lang.t(this@MainActivity, "Your recorded cheers will be removed and the phone voice used again."))
                        .setNegativeButton(Lang.t(this@MainActivity, "Cancel"), null)
                        .setPositiveButton(Lang.t(this@MainActivity, "Delete")) { _, _ ->
                            File(filesDir, "voice_bonus.m4a").delete()
                            File(filesDir, "voice_finale.m4a").delete()
                            Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Deleted. The phone voice is used again."), Toast.LENGTH_SHORT).show()
                        }
                        .show()
                }
            })

            // feedback
            c.addView(header("Feedback"))
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Send feedback (email)")
                setOnClickListener {
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:hasfrialon@gmail.com")).putExtra(Intent.EXTRA_SUBJECT, "Comboed feedback")
                    try { startActivity(Intent.createChooser(i, Lang.t(this@MainActivity, "Send feedback"))) }
                    catch (e: Exception) { Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "No email app found. Email: hasfrialon@gmail.com"), Toast.LENGTH_LONG).show() }
                }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Or email hasfrialon@gmail.com"); textSize = 13f; setPadding(0, pad / 4, 0, 0)
            })

            // appearance
            c.addView(header("Appearance"))
            val appRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun appButton(label: String, value: String) = Button(this).apply {
                text = label
                isEnabled = prefs.getString("appearance", "light") != value
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { prefs.edit().putString("appearance", value).apply(); recreate() }
            }
            appRow.addView(appButton(Lang.t(this, "Light"), "light"))
            appRow.addView(appButton(Lang.t(this, "Dark"), "dark"))
            appRow.addView(appButton(Lang.t(this, "Kid"), "kid"))
            c.addView(appRow)
            c.addView(TextView(this).apply { text = Lang.t(this@MainActivity, "Kid mode uses bigger text."); textSize = 13f; setPadding(0, 0, 0, pad / 4) })

            // language
            c.addView(header("Language"))
            val langRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun langButton(label: String, value: String) = Button(this).apply {
                text = label
                isEnabled = Lang.code(this@MainActivity) != value
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { Lang.set(this@MainActivity, value); recreate() }
            }
            langRow.addView(langButton("English", "en"))
            langRow.addView(langButton("עברית", "he"))
            c.addView(langRow)

            // reminders (free, on-device daily notification)
            c.addView(header("Reminders"))
            c.addView(CheckBox(this).apply {
                text = Lang.t(this@MainActivity, "Daily reminder to do a task (5 PM)")
                isChecked = Reminders.isOn(this@MainActivity)
                setOnCheckedChangeListener { _, on ->
                    Reminders.setEnabled(this@MainActivity, on)
                    if (on) {
                        Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Daily reminder on"), Toast.LENGTH_SHORT).show()
                        if (Build.VERSION.SDK_INT >= 33 &&
                            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                        }
                    }
                }
            })

            // menu layout (switch between the new and the classic menu)
            c.addView(header("Menu"))
            c.addView(Button(this).apply {
                text = if (classic) Lang.t(this@MainActivity, "Use the new menu") else Lang.t(this@MainActivity, "Use the classic menu")
                setOnClickListener { prefs.edit().putBoolean("classicMenu", !classic).apply(); recreate() }
            })

            // start fresh (reset THIS profile's progress; the profile itself stays)
            c.addView(header("Start fresh"))
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Reset this profile — wipes its points, level, coins, study coins, shop items, gallery and achievements. The profile itself (name, icon, PIN) stays.")
                textSize = 13f; setPadding(0, 0, 0, pad / 4)
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "🧹 Start fresh (reset this profile)")
                setOnClickListener { startFreshFlow() }
            })

            // backup & restore
            c.addView(header("Backup & restore"))
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Back up all profiles, points, coins and settings to a file you can save or send to yourself. (Proof photos aren't included.)")
                textSize = 13f; setPadding(0, 0, 0, pad / 4)
            })
            c.addView(Button(this).apply { text = Voice.say(this@MainActivity, "Back up my data"); setOnClickListener { exportBackup() } })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "Restore from a backup")
                setOnClickListener {
                    try {
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                        startActivityForResult(Intent.createChooser(i, Lang.t(this@MainActivity, "Pick a backup file")), restoreCode)
                    } catch (e: Exception) { Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Couldn't open the file picker"), Toast.LENGTH_SHORT).show() }
                }
            })
            // cloud transfer code (move data to another phone without a login)
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "☁  Back up to cloud (get a code)")
                setOnClickListener {
                    Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Uploading…"), Toast.LENGTH_SHORT).show()
                    Backend.cloudBackup(buildBackupJson(true)) { code ->
                        if (code != null) showCloudCode(code)
                        else Toast.makeText(this@MainActivity, Lang.t(this@MainActivity, "Cloud backup failed. Check your connection."), Toast.LENGTH_LONG).show()
                    }
                }
            })
            c.addView(Button(this).apply {
                text = Voice.say(this@MainActivity, "☁  Restore with a code")
                setOnClickListener { cloudRestoreDialog() }
            })
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Cloud backup gives you a code to type on another phone. Your AI key and parent PIN are never uploaded.")
                textSize = 13f; setPadding(0, 0, 0, pad / 4)
            })
        }

        // A tiny, legal-looking footer. It's the hidden door to the creator menu (press it).
        fun addFooter(c: LinearLayout) {
            c.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, "Terms of Service · Privacy Policy")
                textSize = 10f
                setTextColor(Color.parseColor("#9aa3bf"))
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, pad, 0, pad / 2)
                isClickable = true
                setOnClickListener { startActivity(Intent(this@MainActivity, PrankActivity::class.java)) }
            })
        }

        // ===== assemble the screen =====
        addPrimary(root)
        if (classic) {
            // The old flat menu, kept available via Settings → Menu.
            addShop(root)
            addExtras(root)
            addHelp(root)
            collapsible(root, "⚙  Settings & setup", "⚙  Hide settings") { s -> addKeys(s); addPrefs(s) }
        } else {
            // Important things up top: Setup, then Settings, then Shop and Help. The
            // less-important screens (Stats, My week, Sound shop, Leaderboard) sit at the bottom.
            addKeys(root)
            collapsible(root, "⚙  Settings", "⚙  Hide settings") { s -> addPrefs(s) }
            addShop(root)
            addHelp(root)
            collapsible(root, "⬇  More", "⬆  Hide extras") { s -> addExtras(s) }
        }
        addFooter(root)

        // The classic menu is the original plain, generic look: no gradient background and no
        // rounded-button makeover. The new menu gets the polished styling.
        if (!classic) beautify(root)
        val scroll = ScrollView(this).apply {
            addView(root)
            if (!classic) background = screenBackground()
        }
        val banner = Ads.bannerView(this)
        val nav = if (!classic) bottomNav() else null
        if (banner == null && nav == null) {
            setContentView(scroll)
        } else {
            // Pin the ad banner (if any) and the bottom nav below the scrolling content.
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; if (!classic) background = screenBackground() }
            wrap.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            if (banner != null) wrap.addView(banner, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            if (nav != null) wrap.addView(nav, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            setContentView(wrap)
        }
        // The login wall blocks everything until escaped; skip the other pop-ups while it's up.
        if (!LoginWall.maybeShow(this)) {
            Crash.maybeShow(this)
            root.post {
                if (prefs.getBoolean("adsJustUnlocked", false)) {
                    prefs.edit().remove("adsJustUnlocked").apply()
                    Ads.forceInterstitial(this)
                } else Ads.maybeInterstitial(this)
            }
        }
    }

    // ----- app-like bottom navigation bar (new menu only) -----
    private fun bottomNav(): LinearLayout {
        val dark = isDarkTheme()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply { setColor(Color.parseColor(if (dark) "#141a2e" else "#ffffff")) }
            setPadding(0, dpi(6), 0, dpi(6))
        }
        fun item(icon: String, label: String, onTap: (() -> Unit)?) {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(0, dpi(6), 0, dpi(6))
                if (onTap != null) { isClickable = true; setOnClickListener { onTap() } }
            }
            col.addView(TextView(this).apply { text = icon; textSize = 20f; gravity = Gravity.CENTER })
            col.addView(TextView(this).apply {
                text = Lang.t(this@MainActivity, label); textSize = 11f; gravity = Gravity.CENTER
                setTextColor(Color.parseColor(if (dark) "#c9cfe0" else "#3a3f52"))
            })
            bar.addView(col)
        }
        item("🏠", "Home", null)
        item("🛍️", "Shop") { startActivity(Intent(this, ShopActivity::class.java)) }
        item("📊", "Stats") { startActivity(Intent(this, StatsActivity::class.java)) }
        item("🥇", "Ranks") { startActivity(Intent(this, LeaderboardActivity::class.java)) }
        return bar
    }

    // ----- visual polish (theme-aware) -----
    private fun dpi(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun isDarkTheme() = Appearance.mode(this) == "dark"
    private fun roundedBg(hex: String) = GradientDrawable().apply { setColor(Color.parseColor(hex)); cornerRadius = dpi(14).toFloat() }

    private fun screenBackground(): GradientDrawable {
        val dark = isDarkTheme()
        val top = if (dark) "#0d0f1a" else "#eef2f9"
        val bot = if (dark) "#141a2e" else "#dbe4f3"
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor(top), Color.parseColor(bot)))
    }

    /** Give every button a consistent rounded look; the primary (tagged) button gets the accent. */
    private fun beautify(root: View) {
        val surface = if (isDarkTheme()) "#1c2138" else "#ffffff"
        styleButtons(root, surface)
    }

    private fun styleButtons(v: View, surface: String) {
        if (v is Button) {
            val primary = v.tag == "primary"
            v.background = roundedBg(if (primary) "#3a66d6" else surface)
            v.setAllCaps(false)
            if (primary) { v.setTextColor(Color.WHITE); v.setTypeface(v.typeface, Typeface.BOLD) }
            val p = dpi(14); v.setPadding(p, dpi(12), p, dpi(12))
            v.minimumHeight = dpi(48)
            (v.layoutParams as? LinearLayout.LayoutParams)?.let { it.topMargin = dpi(8); v.layoutParams = it }
        } else if (v is ViewGroup) {
            for (i in 0 until v.childCount) styleButtons(v.getChildAt(i), surface)
        }
    }

    /** Publish this device's highest-scoring profile to the global leaderboard (only if it has points). */
    private fun publishBestProfile() {
        try {
            val prefs = getSharedPreferences("combo", MODE_PRIVATE)
            val arr = Profiles.list(this)
            var best: org.json.JSONObject? = null
            var bestTotal = 0
            for (i in 0 until arr.length()) {
                val p = arr.getJSONObject(i)
                val st = try { org.json.JSONObject(prefs.getString("state__" + p.optString("id"), "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
                val total = st.optInt("total", 0)
                if (total > bestTotal) { bestTotal = total; best = p }
            }
            val b = best ?: return
            if (bestTotal <= 0) return
            val level = Math.floor(Math.sqrt(bestTotal / 25.0)).toInt() + 1
            Backend.publishLeaderboard(b.optString("name", "Me"), b.optString("emoji", "⭐"), bestTotal, level)
        } catch (e: Exception) {
        }
    }

    // Developer mode = the current profile's debug flag (title 7-tap + PIN 3939).
    private fun isDeveloper(prefs: android.content.SharedPreferences): Boolean {
        val id = Profiles.currentId(this)
        val st = try { org.json.JSONObject(prefs.getString("state__$id", "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        return st.optBoolean("debug", false)
    }

    /** Spend from the current profile's combined purse (general first, then study coins);
     *  false (no change) if the two balances together aren't enough. */
    private fun spendCoins(amount: Int): Boolean {
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        val id = Profiles.currentId(this)
        val key = "state__$id"
        val st = try { org.json.JSONObject(prefs.getString(key, "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        val gen = st.optInt("coins", 0)
        val study = st.optInt("scoins", 0)
        if (gen + study < amount) return false
        val fromGen = minOf(gen, amount)
        st.put("coins", gen - fromGen)
        val rem = amount - fromGen
        if (rem > 0) st.put("scoins", study - rem)
        prefs.edit().putString(key, st.toString()).apply()
        return true
    }

    // ----- "start fresh": reset the current profile's progress -----
    /** If the profile is PIN-locked, require that same PIN first; then the big warning. */
    private fun startFreshFlow() {
        val id = Profiles.currentId(this)
        if (Profiles.hasPin(this, id)) {
            val input = EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                hint = Lang.t(this@MainActivity, "Profile PIN")
            }
            AlertDialog.Builder(this)
                .setTitle(Lang.t(this, "🔒 Locked profile"))
                .setMessage(Lang.t(this, "Enter this profile's PIN to continue."))
                .setView(input)
                .setPositiveButton(Lang.t(this, "OK")) { _, _ ->
                    if (Profiles.checkPin(this, id, input.text.toString())) warnReset()
                    else Toast.makeText(this, Lang.t(this, "Wrong PIN"), Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(Lang.t(this, "Cancel"), null)
                .show()
        } else warnReset()
    }

    private fun warnReset() {
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "⚠️ Are you sure?"))
            .setMessage(Lang.t(this, "This resets EVERYTHING for this profile — points, level, coins, study coins, shop items, gallery and achievements — back to zero.\n\nThis CANNOT be undone."))
            .setPositiveButton(Lang.t(this, "Yes, reset")) { _, _ -> holdToReset() }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    /** Final safeguard: a button you must hold for 10 seconds while a bar fills. Let go to cancel. */
    private fun holdToReset() {
        val d = resources.displayMetrics.density
        val p = (20 * d).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p, p, p) }
        col.addView(TextView(this).apply {
            text = Lang.t(this@MainActivity, "Hold the button for 10 seconds to reset this profile. Let go to cancel.")
            textSize = 16f
        })
        val barBg = FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#33888888")); cornerRadius = 12 * d }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (20 * d).toInt()).apply { topMargin = (16 * d).toInt() }
        }
        val fill = View(this).apply {
            background = GradientDrawable().apply { setColor(Color.parseColor("#d62f2f")); cornerRadius = 12 * d }
            layoutParams = FrameLayout.LayoutParams(0, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        barBg.addView(fill)
        col.addView(barBg)
        val holdBtn = Button(this).apply {
            text = Lang.t(this@MainActivity, "Hold to reset")
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (16 * d).toInt() }
        }
        col.addView(holdBtn)

        val dlg = AlertDialog.Builder(this)
            .setView(col)
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .create()

        val durationMs = 10000L
        var startT = 0L
        val h = Handler(Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                val elapsed = System.currentTimeMillis() - startT
                val frac = (elapsed.toFloat() / durationMs).coerceIn(0f, 1f)
                val w = (barBg.width * frac).toInt()
                fill.layoutParams = FrameLayout.LayoutParams(w, FrameLayout.LayoutParams.MATCH_PARENT)
                if (frac >= 1f) {
                    runCatching { dlg.dismiss() }
                    doReset()
                } else h.postDelayed(this, 30)
            }
        }
        holdBtn.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    startT = System.currentTimeMillis()
                    h.post(tick); true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    h.removeCallbacks(tick)
                    fill.layoutParams = FrameLayout.LayoutParams(0, FrameLayout.LayoutParams.MATCH_PARENT)
                    true
                }
                else -> false
            }
        }
        dlg.setOnDismissListener { h.removeCallbacks(tick) }
        dlg.show()
    }

    private fun doReset() {
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        val id = Profiles.currentId(this)
        prefs.edit()
            .remove("state__$id")
            .remove("gallery__$id")
            .remove("proofs__$id")
            .remove("origname__$id")
            .apply()
        Toast.makeText(this, Lang.t(this, "This profile has been reset."), Toast.LENGTH_LONG).show()
        val i = Intent(this, ProfileActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(i)
        finish()
    }

    // ----- sneaky slow-killer modes that act when the app opens -----
    private val sillyNames = listOf("Sir Dumpling", "Lil Goblin", "Captain Toes", "Mr Bungus", "Princess Snorlax", "Big Noodle", "Sir Yaps-a-lot")

    private fun applySneakyModes(prefs: android.content.SharedPreferences) {
        val id = Profiles.currentId(this)
        // Ghost coins: coins quietly tick down by 1 on roughly a third of opens.
        if (prefs.getBoolean("ghostcoins", false) && Math.random() < 0.34) {
            val key = "state__$id"
            val st = try { org.json.JSONObject(prefs.getString(key, "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
            val coins = st.optInt("coins", 0)
            if (coins > 0) { st.put("coins", coins - 1); prefs.edit().putString(key, st.toString()).apply() }
        }
        // Sticky rename: the profile keeps reverting to a silly name (stable per profile). The real
        // name is saved the first time so it can be restored when the troll is turned off.
        val origKey = "origname__$id"
        if (prefs.getBoolean("stickyrename", false)) {
            val silly = sillyNames[Math.floorMod(id.hashCode(), sillyNames.size)]
            val cur = Profiles.current(this).optString("name")
            if (cur != silly) {
                if (!prefs.contains(origKey)) prefs.edit().putString(origKey, cur).apply()
                Profiles.rename(this, id, silly)
            }
        } else if (prefs.contains(origKey)) {
            // Troll is off — put the real name back.
            prefs.getString(origKey, null)?.let { Profiles.rename(this, id, it) }
            prefs.edit().remove(origKey).apply()
        }
    }

    // ----- real-life photo via the camera -----
    private fun launchCamera(code: Int) {
        try {
            val f = File(cacheDir, "camera_${System.currentTimeMillis()}.jpg")
            pendingPhoto = f
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                .putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, code)
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(this, Lang.t(this, "No camera app found"), Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Couldn't open the camera:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Rewrite a captured photo upright (apply EXIF rotation) and shrink it, so the proof the
     *  user circles and the image the AI sees match and stay a reasonable size. Best-effort. */
    private fun normalizePhoto(f: File) {
        try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2200) sample *= 2
            var bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return

            val orient = ExifInterface(f.absolutePath)
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val m = Matrix()
            when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            if (!m.isIdentity) {
                bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            java.io.FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        } catch (e: Exception) {
            // keep the original file as-is if anything goes wrong
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(req, resultCode, data)
        if (req == cameraCode && resultCode == RESULT_OK) {
            val f = pendingPhoto
            if (f != null && f.exists() && f.length() > 0) {
                normalizePhoto(f)
                startActivity(Intent(this, ResultActivity::class.java).putExtra("path", f.absolutePath))
            } else {
                Toast.makeText(this, Lang.t(this, "No photo was saved"), Toast.LENGTH_SHORT).show()
            }
            pendingPhoto = null
        } else if (req == beforeCode && resultCode == RESULT_OK) {
            val f = pendingPhoto
            if (f != null && f.exists() && f.length() > 0) {
                normalizePhoto(f)
                beforePhoto = f
                pendingPhoto = null
                Toast.makeText(this, Lang.t(this, "Before saved. Now tidy up, then take the AFTER photo."), Toast.LENGTH_LONG).show()
                launchCamera(afterCode)
            } else {
                Toast.makeText(this, Lang.t(this, "No photo was saved"), Toast.LENGTH_SHORT).show()
            }
        } else if (req == afterCode && resultCode == RESULT_OK) {
            val after = pendingPhoto
            val before = beforePhoto
            if (after != null && after.exists() && after.length() > 0 && before != null && before.exists()) {
                normalizePhoto(after)
                startActivity(
                    Intent(this, ResultActivity::class.java)
                        .putExtra("path", after.absolutePath)
                        .putExtra("beforePath", before.absolutePath)
                )
            } else {
                Toast.makeText(this, Lang.t(this, "Couldn't get both photos"), Toast.LENGTH_SHORT).show()
            }
            pendingPhoto = null
            beforePhoto = null
        } else if (req == restoreCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val text = try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (e: Exception) { "" }
            confirmRestore(text)
        }
    }

    // ----- backup & restore of all saved data (SharedPreferences) -----
    private fun exportBackup() {
        try {
            val all = getSharedPreferences("combo", MODE_PRIVATE).all
            val root = org.json.JSONObject()
            for ((k, v) in all) {
                val e = org.json.JSONObject()
                when (v) {
                    is String -> e.put("t", "s").put("v", v)
                    is Int -> e.put("t", "i").put("v", v)
                    is Long -> e.put("t", "l").put("v", v)
                    is Boolean -> e.put("t", "b").put("v", v)
                    is Float -> e.put("t", "f").put("v", v.toDouble())
                    else -> continue
                }
                root.put(k, e)
            }
            val wrap = org.json.JSONObject().put("combo_backup", 1).put("data", root)
            val f = File(cacheDir, "combo-backup.json")
            f.writeText(wrap.toString())
            val uri = Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(Intent.ACTION_SEND).setType("application/json")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, "Comboed backup")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, Lang.t(this, "Save or send your backup")))
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Backup failed:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Build the backup JSON. When [excludeSecrets], the AI key and parent PIN are left out
     *  (used for cloud backups, which travel to another device). */
    private fun buildBackupJson(excludeSecrets: Boolean): String {
        val all = getSharedPreferences("combo", MODE_PRIVATE).all
        val root = org.json.JSONObject()
        for ((k, v) in all) {
            if (excludeSecrets && k in Groups.NOT_BACKED_UP) continue
            val e = org.json.JSONObject()
            when (v) {
                is String -> e.put("t", "s").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Boolean -> e.put("t", "b").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                else -> continue
            }
            root.put(k, e)
        }
        return org.json.JSONObject().put("combo_backup", 1).put("data", root).toString()
    }

    private fun showCloudCode(code: String) {
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "☁ Your transfer code"))
            .setMessage(Lang.t(this, "On another phone, open Settings → “Restore with a code” and type:") + "\n\n" + code + "\n\n" +
                Lang.t(this, "Keep it private — anyone with the code can load your data."))
            .setPositiveButton(Lang.t(this, "Share")) { _, _ ->
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, code)
                try { startActivity(Intent.createChooser(i, Lang.t(this, "Share"))) } catch (e: Exception) {}
            }
            .setNegativeButton(Lang.t(this, "OK"), null)
            .show()
    }

    private fun cloudRestoreDialog() {
        val input = EditText(this).apply {
            hint = "CMB-XXXXXX"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "☁ Restore with a code"))
            .setMessage(Lang.t(this, "Type the transfer code from your other phone."))
            .setView(input)
            .setPositiveButton(Lang.t(this, "Restore")) { _, _ ->
                val code = input.text.toString().trim()
                if (code.isEmpty()) return@setPositiveButton
                Toast.makeText(this, Lang.t(this, "Looking for your backup…"), Toast.LENGTH_SHORT).show()
                Backend.cloudRestore(code) { json ->
                    if (json == null) Toast.makeText(this, Lang.t(this, "No backup found for that code."), Toast.LENGTH_LONG).show()
                    else confirmRestore(json)
                }
            }
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .show()
    }

    private fun confirmRestore(text: String) {
        val data = try {
            val o = org.json.JSONObject(text)
            if (o.optInt("combo_backup", 0) != 1) null else o.getJSONObject("data")
        } catch (e: Exception) { null }
        if (data == null) {
            Toast.makeText(this, Lang.t(this, "That doesn't look like a Comboed backup"), Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(Lang.t(this, "Restore backup?"))
            .setMessage(Lang.t(this, "This replaces ALL current profiles, points, coins and settings on this phone with the backup. This can't be undone."))
            .setNegativeButton(Lang.t(this, "Cancel"), null)
            .setPositiveButton(Lang.t(this, "Restore")) { _, _ -> applyRestore(data) }
            .show()
    }

    private fun applyRestore(data: org.json.JSONObject) {
        try {
            val ed = getSharedPreferences("combo", MODE_PRIVATE).edit()
            ed.clear()
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val e = data.getJSONObject(k)
                when (e.optString("t")) {
                    "s" -> ed.putString(k, e.optString("v"))
                    "i" -> ed.putInt(k, e.optInt("v"))
                    "l" -> ed.putLong(k, e.optLong("v"))
                    "b" -> ed.putBoolean(k, e.optBoolean("v"))
                    "f" -> ed.putFloat(k, e.optDouble("v").toFloat())
                }
            }
            ed.apply()
            Toast.makeText(this, Lang.t(this, "Restored. Restarting…"), Toast.LENGTH_SHORT).show()
            val i = Intent(this, ProfileActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(i)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Restore failed:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ----- recording your own cheers -----

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord(kind: String, btn: TextView, idleText: String) {
        if (recordingKind != null) {
            stopRecording()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            Toast.makeText(this, Lang.t(this, "Allow the microphone, then tap record again"), Toast.LENGTH_LONG).show()
            return
        }
        val file = File(filesDir, "voice_$kind.m4a")
        var created: MediaRecorder? = null
        try {
            val rec = newRecorder()
            created = rec
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingKind = kind
            recordingButton = btn
            recordingIdleText = idleText
            btn.text = Lang.t(this, "Recording... tap to stop")
            handler.postDelayed({ if (recordingKind == kind) stopRecording() }, 4000)
        } catch (e: Exception) {
            runCatching { created?.release() }
            file.delete()
            Toast.makeText(this, Lang.t(this, "Couldn't record:") + " ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        val rec = recorder ?: return
        val kind = recordingKind
        handler.removeCallbacksAndMessages(null)
        val file = if (kind != null) File(filesDir, "voice_$kind.m4a") else null
        try {
            rec.stop()
        } catch (e: Exception) {
            file?.delete() // stopped too quickly: nothing usable was recorded
        }
        runCatching { rec.release() }
        recorder = null
        recordingKind = null
        recordingButton?.text = recordingIdleText
        val ok = file != null && file.exists()
        Toast.makeText(this, Lang.t(this, if (ok) "Saved" else "Too short, try again"), Toast.LENGTH_SHORT).show()
    }

    private fun playVoice(first: String, second: String?) {
        val f = File(filesDir, "voice_$first.m4a")
        if (!f.exists()) {
            if (second != null) playVoice(second, null)
            else Toast.makeText(this, Lang.t(this, "No recording yet"), Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            if (second != null) mp.setOnCompletionListener { playVoice(second, null) }
            mp.start()
        } catch (e: Exception) {
            Toast.makeText(this, Lang.t(this, "Couldn't play:") + " ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { recorder?.release() }
        runCatching { player?.release() }
        super.onDestroy()
    }

    // =====================================================================
    // ===== Redesigned screens (new menu): Home dashboard + Settings =====
    // =====================================================================

    private var homeChips: LinearLayout? = null
    private var homeGoal: LinearLayout? = null
    private var homeWins: LinearLayout? = null
    private var homeHello: TextView? = null
    private var homeName: TextView? = null
    private var homeAvatar: FrameLayout? = null
    private var homeExtras: LinearLayout? = null
    private var homeNews: LinearLayout? = null
    private var worldDay = -1
    private var worldWeek = -1
    private var devNews: Pair<String, String>? = null

    private var homeFresh = false

    private var settingsBuilt = false

    companion object {
        /** Settings scroll position carried across a rebuild/recreate. */
        private var pendingSettingsY = -1
    }

    override fun onResume() {
        super.onResume()
        if (this is SettingsActivity) {
            // Coming back from a sub-screen (Parent zone, Sound shop…): refresh the values, keep the scroll.
            if (settingsBuilt) refreshSettings()
            settingsBuilt = true
            return
        }
        if (homeChips == null) return
        refreshOnline()
        if (homeFresh) { homeFresh = false; return }
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        if (prefs.getBoolean("homeDirty", false)) {
            prefs.edit().remove("homeDirty").apply()
            recreate()
        } else fillHome()
    }

    private fun t(s: String) = Voice.say(this, s)

    private fun buildModernHome(prefs: android.content.SharedPreferences) {
        val p = Ui.pal(this)
        prefs.edit().remove("homeDirty").apply()
        val page = Ui.page(this)

        // Fake "update available" prank row (kept from the old menu).
        if (prefs.getBoolean("update", false)) {
            page.addView(Ui.row(this, R.drawable.ui_download, "red",
                t("Game version 4.2.0") + if (Math.random() < 0.5) "   🔴" else "", t("🔄 Search for updates")) {
                AlertDialog.Builder(this)
                    .setTitle(t("Updating…"))
                    .setMessage(t("Checking for updates… a new version was found!\n\nDownloading update 4.2.1…\n\nEstimated time remaining: approximately 2,422 years. ⏳\n\nPlease keep the app open."))
                    .setPositiveButton(t("OK"), null).show()
            }.apply { background = Ui.rounded(p.card, Ui.dp(this@MainActivity, 16).toFloat(), p.border, Ui.dp(this@MainActivity, 1)) },
                Ui.lp(this, 0).apply { bottomMargin = Ui.dp(this@MainActivity, 12) })
        }

        // --- header: avatar (switch profile) · greeting/name (7 taps = developer) · gear ---
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val av = FrameLayout(this).apply {
            isClickable = true; contentDescription = t("Switch profile")
            setOnClickListener { startActivity(Intent(this@MainActivity, ProfileActivity::class.java)); finish() }
        }
        homeAvatar = av
        head.addView(av, LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(Ui.dp(this@MainActivity, 12), 0, Ui.dp(this@MainActivity, 8), 0) }
        val hello = Ui.text(this, "", 14f, p.muted, bold = false)
        val name = Ui.text(this, "", 22f, p.ink)
        homeHello = hello; homeName = name
        names.addView(hello); names.addView(name)
        var taps = 0
        names.setOnClickListener { taps++; if (taps >= 7) { taps = 0; showDevDialog(prefs) } }
        head.addView(names, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        head.addView(Ui.iconButton(this, R.drawable.ui_gear, t("Settings")) {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        page.addView(head)

        // --- chips: streak · coins · study coins ---
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        homeChips = chips
        page.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; addView(chips)
        }, Ui.lp(this, 16))
        val newsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeNews = newsBox
        page.addView(newsBox)

        // --- hero card: the main action ---
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#3A5BD9"), Color.parseColor("#5A2FC7"))).apply { cornerRadius = Ui.dp(this@MainActivity, 24).toFloat() }
            setPaddingRelative(Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 20))
        }
        hero.addView(Ui.text(this, t("Finished a task?"), 22f, Color.WHITE))
        hero.addView(Ui.text(this, t("Prove it — the AI checks it in seconds."), 14f, Color.parseColor("#DDE4FF"), bold = false).apply { setPaddingRelative(0, Ui.dp(this@MainActivity, 4), 0, Ui.dp(this@MainActivity, 14)) })
        hero.addView(Ui.button(this, t("Start the floating star"), R.drawable.ui_star, Color.WHITE, Color.parseColor("#2B47B8"), 52) { startStar() })
        val two = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val glass = Color.parseColor("#33FFFFFF")
        two.addView(Ui.button(this, t("Photo check"), R.drawable.ui_camera, glass, Color.WHITE, 46) { launchCamera(cameraCode) },
            LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginEnd = Ui.dp(this@MainActivity, 5) })
        two.addView(Ui.button(this, t("Before & after"), R.drawable.ui_columns, glass, Color.WHITE, 46) {
            Toast.makeText(this, t("Take a BEFORE photo, tidy up, then take an AFTER photo — the AI rewards the improvement."), Toast.LENGTH_LONG).show()
            launchCamera(beforeCode)
        }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = Ui.dp(this@MainActivity, 5) })
        hero.addView(two, Ui.lp(this, 10))
        hero.addView(Ui.text(this, t("Stop the star"), 13f, Color.parseColor("#DDE4FF")).apply {
            gravity = Gravity.CENTER; setPaddingRelative(0, Ui.dp(this@MainActivity, 12), 0, 0)
            isClickable = true
            setOnClickListener {
                startService(Intent(this@MainActivity, BubbleService::class.java).setAction(BubbleService.ACTION_STOP))
                Toast.makeText(this@MainActivity, t("Star stopped"), Toast.LENGTH_SHORT).show()
            }
        })
        page.addView(hero, Ui.lp(this, 16))

        // --- today's goal + daily quests ---
        val goal = Ui.card(this).apply { setPaddingRelative(Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 16), Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 16)) }
        homeGoal = goal
        page.addView(goal, Ui.lp(this, 16))
        val extras = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeExtras = extras
        page.addView(extras)

        // --- recent wins ---
        val winsHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        winsHead.addView(Ui.text(this, t("Recent wins"), 18f, p.ink), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        winsHead.addView(Ui.text(this, t("See all"), 14f, p.accentInk).apply {
            isClickable = true; setPaddingRelative(Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 6), 0, Ui.dp(this@MainActivity, 6))
            setOnClickListener { startActivity(Intent(this@MainActivity, GalleryActivity::class.java)) }
        })
        page.addView(winsHead, Ui.lp(this, 22))
        val wins = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        homeWins = wins
        page.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(wins) }, Ui.lp(this, 10))

        // --- live counter, quiet at the bottom ---
        val counter = Ui.text(this, t("👥 counting people…"), 12f, p.muted, bold = false).apply { gravity = Gravity.CENTER; setPaddingRelative(0, Ui.dp(this@MainActivity, 22), 0, 0) }
        page.addView(counter)
        Backend.registerThenCount(this) { n ->
            counter.text = if (Lang.isHebrew(this)) "👥 $n משתמשים ב‑Comboed" else "👥 $n people use Comboed"
        }
        publishBestProfile()
        Backend.fetchNews { id, text -> devNews = Pair(id, text); fillHome() }

        fillHome()
        homeFresh = true
        refreshOnline()

        // Screen = scroll + (ad banner) + bottom tabs.
        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) }
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(p.bg) }
        outer.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        Ads.bannerView(this)?.let { outer.addView(it, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP)) }
        outer.addView(Ui.bottomNav(this, "home"), LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        setContentView(outer)

        if (!LoginWall.maybeShow(this)) {
            Crash.maybeShow(this)
            outer.post {
                if (prefs.getBoolean("adsJustUnlocked", false)) {
                    prefs.edit().remove("adsJustUnlocked").apply()
                    Ads.forceInterstitial(this)
                } else Ads.maybeInterstitial(this)
            }
        }
    }

    /** Pull the online bits: group sync (approvals, high-fives, pranks, backup) and world stats. */
    private fun refreshOnline() {
        Groups.sync(this) { fillHome() }
        Backend.fetchWorld { day, week -> worldDay = day; worldWeek = week; fillHome() }
    }

    private fun newsCard(title: String, body: String, tone: String, onClose: (() -> Unit)?, onTap: (() -> Unit)? = null): LinearLayout {
        val p = Ui.pal(this)
        val c = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; setPaddingRelative(Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 12), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 12)) }
        c.addView(Ui.tile(this, R.drawable.ui_megaphone, tone))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(Ui.dp(this@MainActivity, 12), 0, Ui.dp(this@MainActivity, 4), 0) }
        col.addView(Ui.text(this, title, 14f, p.ink))
        col.addView(Ui.text(this, body, 14f, p.ink, bold = false).apply { maxLines = 4; ellipsize = android.text.TextUtils.TruncateAt.END })
        c.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        if (onClose != null) c.addView(Ui.text(this, "✕", 16f, p.muted).apply {
            setPaddingRelative(Ui.dp(this@MainActivity, 8), 0, Ui.dp(this@MainActivity, 6), 0); isClickable = true
            contentDescription = t("Dismiss"); setOnClickListener { onClose() }
        })
        if (onTap != null) { c.isClickable = true; Ui.ripple(this, c); c.setOnClickListener { onTap() } }
        return c
    }

    private fun fillOnline() {
        val p = Ui.pal(this)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        homeNews?.let { box ->
            box.removeAllViews()
            devNews?.let { (id, text) ->
                if (prefs.getString("newsSeen", "") != id) box.addView(newsCard(t("News"), text, "orange", { prefs.edit().putString("newsSeen", id).apply(); fillHome() }), Ui.lp(this, 12))
            }
            val mine = Groups.memberships(this)
            for (i in 0 until mine.length()) {
                val m = mine.optJSONObject(i) ?: continue
                val news = m.optString("news"); val code = m.optString("code")
                val seenKey = "gnewsSeen__$code"
                if (news.isNotBlank() && prefs.getString(seenKey, "") != news)
                    box.addView(newsCard(m.optString("name"), news, "purple", { prefs.edit().putString(seenKey, news).apply(); fillHome() }) {
                        startActivity(Intent(this, GroupActivity::class.java).putExtra("code", code))
                    }, Ui.lp(this, 12))
            }
        }
        homeExtras?.let { box ->
            box.removeAllViews()
            // community challenge (everyone, worldwide)
            if (worldWeek >= 0) {
                val targets = listOf(300, 500, 750, 1000)
                val target = targets[Math.floorMod(Backend.weekKey().hashCode(), targets.size)]
                val c = Ui.card(this).apply { setPaddingRelative(Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 14), Ui.dp(this@MainActivity, 18), Ui.dp(this@MainActivity, 16)) }
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(Ui.tile(this, R.drawable.ui_globe, "teal"))
                top.addView(Ui.text(this, t("Community challenge"), 16f, p.ink).apply { setPaddingRelative(Ui.dp(this@MainActivity, 12), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                top.addView(Ui.text(this, "${minOf(worldWeek, target)} / $target", 14f, if (worldWeek >= target) p.good else p.muted))
                c.addView(top)
                val line = if (Lang.isHebrew(this)) "כולם ביחד: $target משימות השבוע בכל העולם. כל משימה שלך נספרת!" else "Everyone together: $target tasks worldwide this week. Every task you finish counts!"
                c.addView(Ui.text(this, if (worldWeek >= target) t("Challenge complete! 🎉 Thanks for helping.") else line, 13f, p.muted, bold = false).apply { setPaddingRelative(0, Ui.dp(this@MainActivity, 8), 0, 0) })
                c.addView(Ui.bar(this, worldWeek.toFloat() / target, Ui.tone(this, "teal").second, p.track), Ui.lp(this, 10))
                if (worldDay >= 0) c.addView(Ui.text(this, if (Lang.isHebrew(this)) "🌍 $worldDay משימות הושלמו היום בעולם" else "🌍 $worldDay tasks finished worldwide today", 12f, p.muted, bold = false).apply { setPaddingRelative(0, Ui.dp(this@MainActivity, 8), 0, 0) })
                box.addView(c, Ui.lp(this, 16))
            }
            // my groups
            val mine = Groups.memberships(this)
            if (mine.length() > 0) {
                val rows = ArrayList<View>()
                for (i in 0 until minOf(mine.length(), 4)) {
                    val m = mine.optJSONObject(i) ?: continue
                    val type = m.optString("type"); val code = m.optString("code")
                    val (res, tone) = when (type) { "class" -> Pair(R.drawable.ui_book, "purple"); "family" -> Pair(R.drawable.ui_home, "green"); else -> Pair(R.drawable.ui_users, "orange") }
                    val goal = m.optInt("goalTarget")
                    rows.add(Ui.row(this, res, tone, m.optString("name"), if (goal > 0) t("Team goal") else Groups.typeLabel(this, type)) {
                        startActivity(Intent(this, GroupActivity::class.java).putExtra("code", code))
                    })
                }
                box.addView(Ui.sectionTitle(this, t("My groups")))
                box.addView(Ui.group(this, rows))
            }
        }
    }

    /** Refresh the live parts of Home (after a check, purchase, profile change…). */
    private fun fillHome() {
        fillOnline()
        val p = Ui.pal(this)
        val me = Profiles.current(this)
        val st = Progress.state(this)
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        homeHello?.text = t(when { hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" })
        homeName?.text = me.optString("name", "Me")
        homeAvatar?.let { it.removeAllViews(); it.addView(Ui.avatar(this, me, 48).apply { layoutParams = FrameLayout.LayoutParams(Ui.dp(this@MainActivity, 48), Ui.dp(this@MainActivity, 48)) }) }

        homeChips?.let { c ->
            c.removeAllViews()
            val streak = Progress.dayStreak(this)
            val chipLp = { LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { marginEnd = Ui.dp(this@MainActivity, 8) } }
            val sLabel = if (Lang.isHebrew(this)) "רצף $streak ימים" else "$streak-day streak"
            c.addView(Ui.chip(this, R.drawable.ui_flame, Ui.tone(this, "orange").second, sLabel), chipLp())
            c.addView(Ui.chip(this, R.drawable.ui_coin, Ui.tone(this, "gold").second, st.optInt("coins", 0).toString()).apply {
                contentDescription = st.optInt("coins", 0).toString() + " " + t("coins")
            }, chipLp())
            c.addView(Ui.chip(this, R.drawable.ui_book, Ui.tone(this, "green").second, st.optInt("scoins", 0).toString() + " " + t("study")), chipLp())
        }

        homeGoal?.let { g ->
            g.removeAllViews()
            val goal = Progress.goal(this)
            val done = Progress.todayCount(this)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(Ui.tile(this, R.drawable.ui_target, "green"))
            top.addView(Ui.text(this, t("Today's goal"), 16f, p.ink).apply { setPaddingRelative(Ui.dp(this@MainActivity, 12), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            val of = if (Lang.isHebrew(this)) "$done מתוך $goal משימות" else "$done of $goal tasks"
            top.addView(Ui.text(this, of, 14f, if (done >= goal) p.good else p.muted))
            g.addView(top)
            g.addView(Ui.bar(this, done.toFloat() / maxOf(1, goal), Ui.tone(this, "green").second, p.track), Ui.lp(this, 12))
            val quests = listOf(Pair("Finish 3 tasks today", 50), Pair("Land a combo (x1.5 or more)", 30), Pair("Earn 2 bonuses in one check", 40))
            g.addView(Ui.text(this, t("Daily quests"), 13f, p.muted).apply { setPaddingRelative(0, Ui.dp(this@MainActivity, 14), 0, Ui.dp(this@MainActivity, 2)) })
            quests.forEachIndexed { i, (q, reward) ->
                val ok = Progress.questDone(this, i)
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(0, Ui.dp(this@MainActivity, 6), 0, Ui.dp(this@MainActivity, 6)) }
                r.addView(Ui.icon(this, if (ok) R.drawable.ui_check else R.drawable.ui_circle, if (ok) p.good else p.muted), LinearLayout.LayoutParams(Ui.dp(this, 20), Ui.dp(this, 20)))
                r.addView(Ui.text(this, t(q), 14f, if (ok) p.muted else p.ink, bold = false).apply {
                    setPaddingRelative(Ui.dp(this@MainActivity, 10), 0, Ui.dp(this@MainActivity, 8), 0)
                    if (ok) paintFlags = paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
                }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                r.addView(Ui.text(this, "+$reward", 13f, Ui.tone(this, "gold").second))
                g.addView(r)
            }
        }

        homeWins?.let { w ->
            w.removeAllViews()
            val arr = Progress.gallery(this)
            if (arr.length() == 0) {
                w.addView(Ui.text(this, t("No wins yet — finish a task and it shows up here."), 14f, p.muted, bold = false))
                return@let
            }
            val dir = File(filesDir, "proofs")
            var shown = 0
            var i = arr.length() - 1
            while (i >= 0 && shown < 6) {
                val o = arr.optJSONObject(i); i--
                if (o == null) continue
                shown++
                val card = Ui.card(this)
                val img = android.widget.ImageView(this).apply {
                    scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                    setBackgroundColor(p.track)
                    try {
                        val f = File(dir, o.optString("file"))
                        if (f.exists()) {
                            val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                            setImageBitmap(BitmapFactory.decodeFile(f.absolutePath, opts))
                        }
                    } catch (e: Exception) {}
                }
                card.addView(img, LinearLayout.LayoutParams(Ui.MATCH, Ui.dp(this, 84)))
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 10), Ui.dp(this@MainActivity, 10)) }
                info.addView(Ui.text(this, o.optString("task", t("Task")).ifEmpty { t("Task") }, 14f, p.ink).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                info.addView(Ui.text(this, "+" + o.optInt("points") + " " + t("pts"), 13f, p.good))
                card.addView(info)
                card.isClickable = true
                Ui.ripple(this, card)
                card.setOnClickListener { startActivity(Intent(this, GalleryActivity::class.java)) }
                w.addView(card, LinearLayout.LayoutParams(Ui.dp(this, 132), Ui.WRAP).apply { marginEnd = Ui.dp(this@MainActivity, 10) })
            }
        }
    }

    private fun startStar() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, t("Allow \"Display over other apps\", then come back and press Start again"), Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        Toast.makeText(this, t("Star is on. Switch to any app."), Toast.LENGTH_SHORT).show()
    }

    private fun showDevDialog(prefs: android.content.SharedPreferences) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = t("Developer PIN")
        }
        AlertDialog.Builder(this)
            .setTitle(t("Developer"))
            .setMessage(t("Enter the developer PIN to toggle debug mode."))
            .setView(input)
            .setPositiveButton(t("OK")) { _, _ ->
                if (input.text.toString().trim() == "3939") {
                    val stx = Progress.state(this)
                    val now = !stx.optBoolean("debug", false)
                    stx.put("debug", now)
                    prefs.edit().putString(Profiles.stateKey(this), stx.toString()).apply()
                    Toast.makeText(this, t(if (now) "🛠 Debug ON - infinite coins & all skins in the Shop" else "Debug mode OFF"), Toast.LENGTH_LONG).show()
                } else Toast.makeText(this, t("Wrong PIN"), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(t("Cancel"), null)
            .show()
    }

    // ----- Settings screen (SettingsActivity runs this) -----
    private fun markHomeDirty() = getSharedPreferences("combo", MODE_PRIVATE).edit().putBoolean("homeDirty", true).apply()

    private fun pick(title: String, options: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this).setTitle(title)
            .setSingleChoiceItems(options.toTypedArray(), current) { d, w -> d.dismiss(); onPick(w) }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun textDialog(title: String, msg: String?, hintText: String, value: String, type: Int, onOk: (String) -> Unit) {
        val input = EditText(this).apply { hint = hintText; inputType = type; setText(value); setSelection(text.length) }
        val box = FrameLayout(this).apply { setPaddingRelative(Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 6), Ui.dp(this@MainActivity, 20), 0); addView(input) }
        AlertDialog.Builder(this).setTitle(title).apply { if (msg != null) setMessage(msg) }
            .setView(box)
            .setPositiveButton(t("Save")) { _, _ -> onOk(input.text.toString().trim()) }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun buildSettings(prefs: android.content.SharedPreferences, dev: Boolean) {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val TXT = InputType.TYPE_CLASS_TEXT

        // header: back arrow + title
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        head.addView(Ui.text(this, t("Settings"), 26f, p.ink).apply { setPaddingRelative(Ui.dp(this@MainActivity, 14), 0, 0, 0) })
        page.addView(head)

        fun section(title: String, rows: List<View>) {
            page.addView(Ui.sectionTitle(this, t(title)))
            page.addView(Ui.group(this, rows))
        }

        // --- AI & keys (first, as asked) ---
        val key = prefs.getString("key", "") ?: ""
        val model = prefs.getString("gmodel", "") ?: ""
        section("AI & keys", listOf(
            Ui.row(this, R.drawable.ui_key, "blue", t("AI key"),
                if (key.isEmpty()) t("Not set (test mode)") else t("Connected"),
                if (key.isEmpty()) p.muted else p.good) {
                textDialog(t("AI key"), t("Free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant). Leave empty for test mode."),
                    "sk-or-…", key, TXT or InputType.TYPE_TEXT_VARIATION_PASSWORD) {
                    prefs.edit().putString("key", it).apply(); Toast.makeText(this, t("Saved"), Toast.LENGTH_SHORT).show(); refreshSettings()
                }
            },
            Ui.row(this, R.drawable.ui_cpu, "blue", t("Model"), if (model.isEmpty()) t("Free default") else model) {
                textDialog(t("Model"), t("Optional. For OpenRouter paste a model id, e.g. nvidia/nemotron-3.5-super-vl:free"),
                    "nvidia/nemotron-3.5-super-vl:free", model, TXT) {
                    prefs.edit().putString("gmodel", it).apply(); Toast.makeText(this, t("Saved"), Toast.LENGTH_SHORT).show(); refreshSettings()
                }
            },
            Ui.row(this, R.drawable.ui_gift, "blue", t("Update key"), t("Enter key")) {
                textDialog(t("Update key"), t("Unlocks hidden update features."), "XXXX-XXXX", "",
                    TXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS) { code ->
                    val set = Pranks.decode(code)
                    if (prefs.getBoolean("trollsBlocked", false)) {
                        Toast.makeText(this, t("🔒 Pranks are blocked by a parent."), Toast.LENGTH_LONG).show()
                    } else if (set.isNullOrEmpty()) {
                        Toast.makeText(this, t("❌ Invalid update key."), Toast.LENGTH_SHORT).show()
                    } else {
                        val gag = Pranks.applyPersistent(this, set)
                        if (set.any { it.id.startsWith("ads_") }) prefs.edit().putBoolean("adsJustUnlocked", true).apply()
                        markHomeDirty()
                        if (gag != null) startActivity(Intent(this, PrankActivity::class.java).putExtra("gag", gag))
                        else Toast.makeText(this, t("✅ Update features unlocked."), Toast.LENGTH_SHORT).show()
                        if (set.any { it.persist }) refreshSettings()
                    }
                }
            }
        ))

        // --- active pranks (only when something is on) ---
        val activeTrolls = Pranks.persistentModes.filter { !it.id.startsWith("ads_") && prefs.getBoolean(it.id, false) }
        val adsOn = Ads.anyOn(this)
        if (activeTrolls.isNotEmpty() || adsOn) {
            val cost = if (dev) t("Free (developer)") else "300 " + t("coins")
            val rows = ArrayList<View>()
            rows.add(Ui.row(this, R.drawable.ui_shield, "red", t("Turn off all pranks"), cost) {
                if (dev || spendCoins(300)) {
                    val e = prefs.edit(); for (tr in Pranks.persistentModes) e.putBoolean(tr.id, false); e.apply()
                    Ads.turnOff(this); markHomeDirty()
                    Toast.makeText(this, t(if (dev) "All pranks turned off" else "All pranks turned off (−300 coins)"), Toast.LENGTH_SHORT).show()
                    refreshSettings()
                } else Toast.makeText(this, t("Not enough coins — you need 300 💸"), Toast.LENGTH_LONG).show()
            })
            for (tr in activeTrolls) rows.add(Ui.row(this, R.drawable.ui_zap, "orange", t("Turn off") + " " + tr.label, cost) {
                if (dev || spendCoins(300)) {
                    prefs.edit().putBoolean(tr.id, false).apply(); markHomeDirty()
                    Toast.makeText(this, t(if (dev) "Turned off" else "Turned off (−300 coins)"), Toast.LENGTH_SHORT).show()
                    refreshSettings()
                } else Toast.makeText(this, t("Not enough coins — you need 300 to turn this off 💸"), Toast.LENGTH_LONG).show()
            })
            if (adsOn) rows.add(Ui.row(this, R.drawable.ui_megaphone, "orange", t("Remove ads"), null) {
                if (dev) {
                    Ads.turnOff(this); markHomeDirty()
                    Toast.makeText(this, t("Ads removed (developer)"), Toast.LENGTH_SHORT).show(); refreshSettings()
                } else AlertDialog.Builder(this)
                    .setTitle(t("Remove ads"))
                    .setMessage(t("Ads can only be removed by purchasing Ad-Free, or by spending 300 coins."))
                    .setPositiveButton(t("Buy Ad-Free \$4.99")) { _, _ -> Ads.fakePurchase(this) }
                    .setNegativeButton(t("Spend 300 coins")) { _, _ ->
                        if (Ads.disableFor300(this)) {
                            markHomeDirty(); Toast.makeText(this, t("Ads removed! (−300 coins)"), Toast.LENGTH_SHORT).show(); refreshSettings()
                        } else Toast.makeText(this, t("Not enough coins — you need 300 to remove ads 💸"), Toast.LENGTH_LONG).show()
                    }
                    .setNeutralButton(t("Keep ads"), null).show()
            })
            section("Active pranks", rows)
        }

        // --- look & language ---
        val modes = listOf("light", "dark", "kid")
        val modeNames = listOf(t("Light"), t("Dark"), t("Kid (bigger text)"))
        val curMode = maxOf(0, modes.indexOf(prefs.getString("appearance", "light")))
        val classic = prefs.getBoolean("classicMenu", false)
        section("Look & language", listOf(
            Ui.row(this, R.drawable.ui_sun, "purple", t("Theme"), modeNames[curMode]) {
                pick(t("Theme"), modeNames, curMode) { prefs.edit().putString("appearance", modes[it]).apply(); markHomeDirty(); recreateKeepScroll() }
            },
            Ui.row(this, R.drawable.ui_globe, "purple", t("Language"), if (Lang.isHebrew(this)) "עברית" else "English") {
                pick(t("Language"), listOf("English", "עברית"), if (Lang.isHebrew(this)) 1 else 0) {
                    Lang.set(this, if (it == 1) "he" else "en"); markHomeDirty(); recreateKeepScroll()
                }
            },
            Ui.row(this, R.drawable.ui_layout, "purple", t("Menu style"), if (classic) t("Classic") else t("New")) {
                pick(t("Menu style"), listOf(t("New"), t("Classic (the original plain menu)")), if (classic) 1 else 0) {
                    prefs.edit().putBoolean("classicMenu", it == 1).apply(); markHomeDirty(); recreateKeepScroll()
                }
            }
        ))

        // --- notifications ---
        section("Notifications", listOf(
            Ui.switchRow(this, R.drawable.ui_bell, "orange", t("Daily reminder"), t("A nudge at 5 PM to do a task"), Reminders.isOn(this)) { on ->
                Reminders.setEnabled(this, on)
                if (on) {
                    Toast.makeText(this, t("Daily reminder on"), Toast.LENGTH_SHORT).show()
                    if (Build.VERSION.SDK_INT >= 33 &&
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
                    }
                }
            }
        ))

        // --- goals & checks ---
        val goal = prefs.getInt("goal", 3)
        val parentMode = (prefs.getString("parentPin", "") ?: "").isNotEmpty()
        val strictOn = prefs.getBoolean("strict", false)
        section("Goals & checks", listOf(
            Ui.row(this, R.drawable.ui_target, "green", t("Daily goal"), if (Lang.isHebrew(this)) "$goal משימות" else "$goal " + t("tasks")) {
                textDialog(t("Daily goal"), t("How many tasks per day?"), "3", goal.toString(), InputType.TYPE_CLASS_NUMBER) {
                    prefs.edit().putInt("goal", it.toIntOrNull()?.coerceIn(1, 50) ?: 3).apply(); markHomeDirty(); refreshSettings()
                }
            },
            Ui.switchRow(this, R.drawable.ui_spark, "green", t("Strict AI detector"),
                if (parentMode) t("Set by a parent in the Parent zone.") else t("No points when the proof looks AI-made (85%+). Off = warning only."),
                strictOn, enabled = !parentMode) { on -> prefs.edit().putBoolean("strict", on).apply() }
        ))

        // --- family ---
        section("Family", listOf(
            Ui.row(this, R.drawable.ui_lock, "green", t("Parent zone"), if (parentMode) t("PIN set") else t("No PIN yet")) { openParentZone(prefs) },
            Ui.row(this, R.drawable.ui_users, "green", t("Profiles"), Profiles.list(this).length().toString()) {
                startActivity(Intent(this, ProfileActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }
        ))

        // --- sounds & voice ---
        fun recRow(kind: String, label: String): LinearLayout {
            val r = Ui.row(this, R.drawable.ui_mic, "teal", t(label), t("4 sec"))
            val v = r.getChildAt(2) as TextView
            r.isClickable = true; Ui.ripple(this, r)
            r.setOnClickListener { toggleRecord(kind, v, t("4 sec")) }
            return r
        }
        val bonusRow = recRow("bonus", "Record my bonus cheer")
        val finaleRow = recRow("finale", "Record my finale cheer")
        section("Sounds & voice", listOf(
            Ui.row(this, R.drawable.ui_music, "teal", t("Sound shop"), null) { startActivity(Intent(this, SoundGalleryActivity::class.java)) },
            bonusRow, finaleRow,
            Ui.row(this, R.drawable.ui_play, "teal", t("Hear my cheers"), null) { playVoice("bonus", "finale") },
            Ui.row(this, R.drawable.ui_trash, "teal", t("Delete my recordings"), null) {
                AlertDialog.Builder(this)
                    .setTitle(t("Delete recordings?"))
                    .setMessage(t("Your recorded cheers will be removed and the phone voice used again."))
                    .setNegativeButton(t("Cancel"), null)
                    .setPositiveButton(t("Delete")) { _, _ ->
                        File(filesDir, "voice_bonus.m4a").delete(); File(filesDir, "voice_finale.m4a").delete()
                        Toast.makeText(this, t("Deleted. The phone voice is used again."), Toast.LENGTH_SHORT).show()
                    }.show()
            }
        ))

        // --- your data ---
        section("Your data", listOf(
            Ui.row(this, R.drawable.ui_upload, "teal", t("Back up to cloud"), t("Get a code")) {
                Toast.makeText(this, t("Uploading…"), Toast.LENGTH_SHORT).show()
                Backend.cloudBackup(buildBackupJson(true)) { code ->
                    if (code != null) showCloudCode(code)
                    else Toast.makeText(this, t("Cloud backup failed. Check your connection."), Toast.LENGTH_LONG).show()
                }
            },
            Ui.switchRow(this, R.drawable.ui_calendar, "teal", t("Daily automatic backup"),
                if (Groups.autoBackupOn(this)) t("Restore code:") + " " + Groups.autoBackupCode(this) else t("Backs up to the cloud once a day"), Groups.autoBackupOn(this)) { on ->
                prefs.edit().putBoolean("autoBackup", on).apply()
                if (on) { Groups.autoBackupIfDue(this, force = true); Toast.makeText(this, t("Restore code:") + " " + Groups.autoBackupCode(this), Toast.LENGTH_LONG).show() }
                refreshSettings()
            },
            Ui.row(this, R.drawable.ui_download, "teal", t("Restore with a code"), null) { cloudRestoreDialog() },
            Ui.row(this, R.drawable.ui_file, "teal", t("Backup file"), t("Save or restore")) {
                pick(t("Backup file"), listOf(t("Back up my data"), t("Restore from a backup")), -1) {
                    if (it == 0) exportBackup() else try {
                        val i = Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE)
                        startActivityForResult(Intent.createChooser(i, t("Pick a backup file")), restoreCode)
                    } catch (e: Exception) { Toast.makeText(this, t("Couldn't open the file picker"), Toast.LENGTH_SHORT).show() }
                }
            },
            Ui.row(this, R.drawable.ui_reset, "red", t("Start fresh"), null, danger = true) { startFreshFlow() }
        ))
        page.addView(Ui.text(this, t("Cloud backup gives you a code to type on another phone. Your AI key and parent PIN are never uploaded."), 12f, p.muted, bold = false).apply { setPaddingRelative(Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 8), Ui.dp(this@MainActivity, 4), 0) })

        // --- about ---
        section("About", listOf(
            Ui.row(this, R.drawable.ui_help, "gray", t("Help & guide"), null) { startActivity(Intent(this, HelpActivity::class.java)) },
            Ui.row(this, R.drawable.ui_share, "gray", t("Invite friends"), null) {
                val msg = t("I'm using Comboed — it turns real tasks into a game with points and rewards! Try it:") +
                    " https://github.com/alonhasfri/combo-checker/releases/latest"
                val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg)
                try { startActivity(Intent.createChooser(i, t("Invite friends"))) } catch (e: Exception) {}
            },
            Ui.row(this, R.drawable.ui_mail, "gray", t("Send feedback"), null) {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:hasfrialon@gmail.com")).putExtra(Intent.EXTRA_SUBJECT, "Comboed feedback")
                try { startActivity(Intent.createChooser(i, t("Send feedback"))) }
                catch (e: Exception) { Toast.makeText(this, t("No email app found. Email: hasfrialon@gmail.com"), Toast.LENGTH_LONG).show() }
            }
        ))

        // --- tiny footer: the hidden door ---
        page.addView(Ui.text(this, t("Terms of Service · Privacy Policy"), 10f, Color.parseColor("#9aa3bf"), bold = false).apply {
            gravity = Gravity.CENTER; setPaddingRelative(0, Ui.dp(this@MainActivity, 26), 0, Ui.dp(this@MainActivity, 2))
            isClickable = true
            setOnClickListener { startActivity(Intent(this@MainActivity, PrankActivity::class.java)) }
        })
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
        page.addView(Ui.text(this, "Comboed · " + t("version") + " " + ver, 10f, Color.parseColor("#9aa3bf"), bold = false).apply { gravity = Gravity.CENTER })

        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) }
        setContentView(scroll)
        if (pendingSettingsY > 0) { val y = pendingSettingsY; pendingSettingsY = -1; scroll.post { scroll.scrollTo(0, y) } }
    }

    private fun settingsScrollY(): Int =
        ((findViewById<View>(android.R.id.content) as? ViewGroup)?.getChildAt(0) as? ScrollView)?.scrollY ?: 0

    /** Rebuild Settings in place after a change, staying where you were. */
    private fun refreshSettings() {
        pendingSettingsY = settingsScrollY()
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        buildSettings(prefs, isDeveloper(prefs))
    }

    /** Theme / language / menu need a real restart of the screen; keep the scroll position too. */
    private fun recreateKeepScroll() {
        pendingSettingsY = settingsScrollY()
        recreate()
    }

    private fun openParentZone(prefs: android.content.SharedPreferences) {
        // The Parent zone asks for the PIN itself (once).
        startActivity(Intent(this, ParentActivity::class.java))
    }
}
