package com.combochecker

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var recorder: MediaRecorder? = null
    private var recordingKind: String? = null
    private var recordingButton: Button? = null
    private var recordingIdleText = ""
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("combo", MODE_PRIVATE)
        Profiles.ensureDefault(this)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun header(label: String): TextView = TextView(this).apply {
            this.text = label
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, pad, 0, pad / 4)
        }

        val titleView = TextView(this).apply {
            text = "⭐ Combo Checker"
            textSize = 26f
            gravity = Gravity.CENTER_HORIZONTAL
        }
        var titleTaps = 0
        titleView.setOnClickListener {
            titleTaps++
            if (titleTaps >= 7) {
                titleTaps = 0
                val input = EditText(this@MainActivity).apply {
                    inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
                    hint = "Developer PIN"
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Developer")
                    .setMessage("Enter the developer PIN to toggle debug mode.")
                    .setView(input)
                    .setPositiveButton("OK") { _, _ ->
                        if (input.text.toString().trim() == "3939") {
                            val stx = try { org.json.JSONObject(prefs.getString(Profiles.stateKey(this@MainActivity), "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
                            val now = !stx.optBoolean("debug", false)
                            stx.put("debug", now)
                            prefs.edit().putString(Profiles.stateKey(this@MainActivity), stx.toString()).apply()
                            Toast.makeText(
                                this@MainActivity,
                                if (now) "🛠 Debug ON - infinite coins & all skins in the Shop" else "Debug mode OFF",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            Toast.makeText(this@MainActivity, "Wrong PIN", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        root.addView(titleView)

        // ----- who's playing -----
        val me = Profiles.current(this)
        val profileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, pad / 2, 0, pad / 2)
        }
        profileRow.addView(TextView(this).apply {
            text = me.optString("emoji", "⭐") + "  " + me.optString("name", "Me")
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        profileRow.addView(Button(this).apply {
            text = "Switch profile"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                finish()
            }
        })
        root.addView(profileRow)

        // ----- the one big button -----
        root.addView(Button(this).apply {
            text = "▶  Start the floating star"
            textSize = 18f
            setPadding(pad / 2, pad, pad / 2, pad)
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(
                        this@MainActivity,
                        "Allow \"Display over other apps\", then come back and press Start again",
                        Toast.LENGTH_LONG
                    ).show()
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
                Toast.makeText(this@MainActivity, "Star is on. Switch to any app.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(TextView(this).apply {
            text = "Tap the star over any app, circle your finished task, and the AI checks it. No key? It runs in test mode."
            textSize = 13f
            setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "Stop floating star"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, BubbleService::class.java).setAction(BubbleService.ACTION_STOP)
                )
            }
        })

        // ----- quick tiles -----
        fun navButton(label: String, target: Class<*>) = Button(this).apply {
            text = label
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
        root.addView(navButton("🛍️  Shop — skins & abilities", ShopActivity::class.java))
        root.addView(navButton("🏆  Proof gallery", GalleryActivity::class.java))
        root.addView(navButton("📊  Stats & badges", StatsActivity::class.java))
        root.addView(navButton("🔊  Sound shop", SoundGalleryActivity::class.java))

        // ----- everything else lives under a collapsed section -----
        val settings = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = android.view.View.GONE
        }
        val settingsToggle = Button(this).apply { text = "⚙  Settings & setup" }
        settingsToggle.setOnClickListener {
            val showing = settings.visibility == android.view.View.VISIBLE
            settings.visibility = if (showing) android.view.View.GONE else android.view.View.VISIBLE
            settingsToggle.text = if (showing) "⚙  Settings & setup" else "⚙  Hide settings"
        }
        root.addView(settingsToggle)
        root.addView(settings)

        // ----- AI key -----
        settings.addView(header("AI key"))
        val keyField = EditText(this).apply {
            hint = "API key: free OpenRouter (sk-or-...), Google Gemini (AIza), or Anthropic (sk-ant)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        settings.addView(keyField)

        val modelField = EditText(this).apply {
            hint = "Model id (optional). For OpenRouter paste one, e.g. nvidia/nemotron-3.5-super-vl:free"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(prefs.getString("gmodel", ""))
        }
        settings.addView(modelField)

        // ----- goals and checks -----
        settings.addView(header("Goals and checks"))
        val goalField = EditText(this).apply {
            hint = "Daily goal: tasks per day"
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("goal", 3).toString())
        }
        settings.addView(goalField)

        // Strict AI detector: once a parent PIN is set, only a parent can change this
        // (in the Parent zone), so kids can't switch off the AI-art detector.
        val parentMode = (prefs.getString("parentPin", "") ?: "").isNotEmpty()
        val strictBox: CheckBox?
        if (parentMode) {
            strictBox = null
            settings.addView(TextView(this).apply {
                text = "🔒 Strict AI detector: " + (if (prefs.getBoolean("strict", false)) "ON" else "OFF") +
                    " — set by a parent in the Parent zone."
                textSize = 14f
                setPadding(0, pad / 3, 0, pad / 3)
            })
        } else {
            strictBox = CheckBox(this).apply {
                text = "Strict AI detector: no points when the proof looks AI-made (85%+). Off means a warning only."
                isChecked = prefs.getBoolean("strict", false)
            }
            settings.addView(strictBox)
        }

        settings.addView(Button(this).apply {
            text = "Save settings"
            setOnClickListener {
                val e = prefs.edit()
                    .putString("key", keyField.text.toString().trim())
                    .putString("gmodel", modelField.text.toString().trim())
                    .putInt("goal", goalField.text.toString().toIntOrNull()?.coerceIn(1, 50) ?: 3)
                if (strictBox != null) e.putBoolean("strict", strictBox.isChecked)
                e.apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })

        // ----- my voice -----
        settings.addView(header("My voice (up to 4 seconds each)"))
        val bonusText = "Record my bonus cheer"
        val finaleText = "Record my finale cheer"

        val bonusBtn = Button(this)
        bonusBtn.text = bonusText
        bonusBtn.setOnClickListener { toggleRecord("bonus", bonusBtn, bonusText) }
        settings.addView(bonusBtn)

        val finaleBtn = Button(this)
        finaleBtn.text = finaleText
        finaleBtn.setOnClickListener { toggleRecord("finale", finaleBtn, finaleText) }
        settings.addView(finaleBtn)

        settings.addView(Button(this).apply {
            text = "Hear my cheers"
            setOnClickListener { playVoice("bonus", "finale") }
        })
        settings.addView(Button(this).apply {
            text = "Delete my recordings"
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Delete recordings?")
                    .setMessage("Your recorded cheers will be removed and the phone voice used again.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        File(filesDir, "voice_bonus.m4a").delete()
                        File(filesDir, "voice_finale.m4a").delete()
                        Toast.makeText(this@MainActivity, "Deleted. The phone voice is used again.", Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
        })

        // ----- feedback -----
        settings.addView(header("Feedback"))
        settings.addView(Button(this).apply {
            text = "Send feedback (email)"
            setOnClickListener {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:hasfrialon@gmail.com"))
                    .putExtra(Intent.EXTRA_SUBJECT, "Combo Checker feedback")
                try {
                    startActivity(Intent.createChooser(i, "Send feedback"))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "No email app found. Email: hasfrialon@gmail.com", Toast.LENGTH_LONG).show()
                }
            }
        })
        settings.addView(TextView(this).apply {
            text = "Or email hasfrialon@gmail.com"
            textSize = 13f
            setPadding(0, pad / 4, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    // ----- recording your own cheers -----

    @Suppress("DEPRECATION")
    private fun newRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()

    private fun toggleRecord(kind: String, btn: Button, idleText: String) {
        if (recordingKind != null) {
            stopRecording()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            Toast.makeText(this, "Allow the microphone, then tap record again", Toast.LENGTH_LONG).show()
            return
        }
        val file = File(filesDir, "voice_$kind.m4a")
        var created: MediaRecorder? = null
        try {
            val rec = newRecorder()
            created = rec
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingKind = kind
            recordingButton = btn
            recordingIdleText = idleText
            btn.text = "Recording... tap to stop"
            handler.postDelayed({ if (recordingKind == kind) stopRecording() }, 4000)
        } catch (e: Exception) {
            runCatching { created?.release() }
            file.delete()
            Toast.makeText(this, "Couldn't record: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopRecording() {
        val rec = recorder ?: return
        val kind = recordingKind
        handler.removeCallbacksAndMessages(null)
        val file = if (kind != null) File(filesDir, "voice_$kind.m4a") else null
        try {
            rec.stop()
        } catch (e: Exception) {
            file?.delete() // stopped too quickly: nothing usable was recorded
        }
        runCatching { rec.release() }
        recorder = null
        recordingKind = null
        recordingButton?.text = recordingIdleText
        val ok = file != null && file.exists()
        Toast.makeText(this, if (ok) "Saved" else "Too short, try again", Toast.LENGTH_SHORT).show()
    }

    private fun playVoice(first: String, second: String?) {
        val f = File(filesDir, "voice_$first.m4a")
        if (!f.exists()) {
            if (second != null) playVoice(second, null)
            else Toast.makeText(this, "No recording yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(f.absolutePath)
            mp.prepare()
            if (second != null) mp.setOnCompletionListener { playVoice(second, null) }
            mp.start()
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't play: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { recorder?.release() }
        runCatching { player?.release() }
        super.onDestroy()
    }
}
