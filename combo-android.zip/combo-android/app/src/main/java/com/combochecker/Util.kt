package com.combochecker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build

private const val CHANNEL_ID = "combo_checker"

fun buildNotification(ctx: Context, text: String, withStop: Boolean): Notification {
    val nm = ctx.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(
        NotificationChannel(CHANNEL_ID, "Comboed", NotificationManager.IMPORTANCE_LOW)
    )
    val b = Notification.Builder(ctx, CHANNEL_ID)
        .setContentTitle("Comboed")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.btn_star_big_on)
        .setOngoing(true)
    if (withStop) {
        val stop = PendingIntent.getService(
            ctx, 0,
            Intent(ctx, BubbleService::class.java).setAction(BubbleService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        b.addAction(
            Notification.Action.Builder(
                Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel),
                "Stop", stop
            ).build()
        )
    }
    return b.build()
}

@Suppress("DEPRECATION")
fun Intent?.parcelableIntent(key: String): Intent? {
    if (this == null) return null
    return if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, Intent::class.java)
    else getParcelableExtra(key)
}
