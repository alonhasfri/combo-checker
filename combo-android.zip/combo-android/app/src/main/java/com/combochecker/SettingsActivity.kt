package com.combochecker

/** The grouped Settings screen. It reuses MainActivity's helpers (backup, recording, reset…);
 *  MainActivity.onCreate builds the settings page when it runs as this class. */
class SettingsActivity : MainActivity()
