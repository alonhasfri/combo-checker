package com.combochecker

import android.app.Activity
import android.content.Context
import android.content.res.Configuration

/**
 * App-wide look: Light, Dark, or Kid (light + bigger text). Applied per activity in onCreate
 * before the views are built. The native screens use theme-default colors, so switching the
 * platform theme recolors them; Kid mode also bumps the font scale so everything is larger.
 */
object Appearance {
    fun mode(c: Context): String =
        c.getSharedPreferences("combo", Context.MODE_PRIVATE).getString("appearance", "light") ?: "light"

    fun apply(a: Activity) {
        // The classic menu keeps the plain stock look; the new menu gets matching rounded dialogs.
        val classic = a.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("classicMenu", false)
        when (mode(a)) {
            "dark" -> a.setTheme(if (classic) android.R.style.Theme_Material_NoActionBar else R.style.AppDark)
            else -> a.setTheme(if (classic) android.R.style.Theme_Material_Light_NoActionBar else R.style.AppLight)
        }
        // updateConfiguration mutates the shared Resources, so always set an explicit scale
        // (otherwise leaving Kid mode would keep the enlarged text).
        val cfg = Configuration(a.resources.configuration)
        cfg.fontScale = if (mode(a) == "kid") 1.25f else 1.0f
        @Suppress("DEPRECATION")
        a.resources.updateConfiguration(cfg, a.resources.displayMetrics)
        // Right-to-left layout when the app language is Hebrew (every screen calls apply()).
        Lang.applyDirection(a)
    }
}
