package com.combochecker

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray

/**
 * One to-do list for today: homework from your groups, task-board jobs you've taken, daily quests
 * and the daily goal. Also schedules local reminders (no server push): homework due tomorrow, and
 * "2 hours left" on a task you took.
 */
object Todo {
    data class Item(val kind: String, val title: String, val sub: String, val done: Boolean, val code: String = "", val due: Long = 0L)

    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)

    fun items(c: Context): List<Item> {
        val out = ArrayList<Item>()
        val now = System.currentTimeMillis()
        val he = Lang.isHebrew(c)
        val mine = Groups.memberships(c)
        for (i in 0 until mine.length()) {
            val m = mine.optJSONObject(i) ?: continue
            val code = m.optString("code"); val gname = m.optString("name")
            val done = Groups.hwDoneLocal(c, code)
            val hw = m.optJSONArray("hwItems") ?: JSONArray()
            for (j in 0 until hw.length()) {
                val h = hw.optJSONObject(j) ?: continue
                val due = h.optLong("due")
                if (due in 1 until now - 24L * 3600 * 1000) continue // long overdue: drop
                val isDone = done.contains(h.optString("id"))
                out.add(Item("hw", h.optString("title"), gname + " · " + dueText(c, due), isDone, code, due))
            }
            val tasks = m.optJSONArray("myTasks") ?: JSONArray()
            for (j in 0 until tasks.length()) {
                val t = tasks.optJSONObject(j) ?: continue
                val until = t.optLong("until")
                if (t.optString("state") == "claimed" && until < now) continue // time ran out
                val waiting = t.optString("state") == "submitted"
                out.add(Item("task", t.optString("title"), gname + " · " + if (waiting) Lang.t(c, "Waiting for OK") else left(c, until), false, code, until))
            }
        }
        val quests = listOf("Finish 3 tasks today", "Land a combo (x1.5 or more)", "Earn 2 bonuses in one check")
        quests.forEachIndexed { i, q -> out.add(Item("quest", Lang.t(c, q), Lang.t(c, "Daily quest"), Progress.questDone(c, i))) }
        val goal = Progress.goal(c); val today = Progress.todayCount(c)
        out.add(0, Item("goal", Lang.t(c, "Today's goal"), if (he) "$today מתוך $goal משימות" else "$today of $goal tasks", today >= goal))
        // open things first (by due time), finished ones last
        return out.sortedWith(compareBy<Item>({ it.done }, { if (it.due == 0L) Long.MAX_VALUE else it.due }))
    }

    fun dueText(c: Context, due: Long): String {
        if (due <= 0) return ""
        val cal = java.util.Calendar.getInstance(); val today = cal.get(java.util.Calendar.DAY_OF_YEAR); val year = cal.get(java.util.Calendar.YEAR)
        cal.timeInMillis = due
        val days = (cal.get(java.util.Calendar.YEAR) - year) * 365 + cal.get(java.util.Calendar.DAY_OF_YEAR) - today
        val he = Lang.isHebrew(c)
        return when {
            days < 0 -> if (he) "באיחור" else "overdue"
            days == 0 -> if (he) "להיום" else "due today"
            days == 1 -> if (he) "למחר" else "due tomorrow"
            else -> if (he) "בעוד $days ימים" else "due in $days days"
        }
    }

    fun left(c: Context, until: Long): String {
        val mins = ((until - System.currentTimeMillis()) / 60000).coerceAtLeast(0)
        val he = Lang.isHebrew(c)
        return if (mins >= 60) (if (he) "עוד ${mins / 60} שע׳" else "${mins / 60}h left") else (if (he) "עוד $mins דק׳" else "${mins}m left")
    }

    // ----- due reminders (local alarms) -----
    const val CHANNEL = "comboed_due"
    fun enabled(c: Context) = sp(c).getBoolean("dueReminders", true)
    fun setEnabled(c: Context, on: Boolean) { sp(c).edit().putBoolean("dueReminders", on).apply(); if (on) schedule(c) else cancelAll(c) }

    private fun pi(c: Context, key: String, title: String, text: String): PendingIntent {
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        val i = Intent(c, DueReceiver::class.java).putExtra("title", title).putExtra("text", text).putExtra("key", key)
        return PendingIntent.getBroadcast(c, key.hashCode(), i, flags)
    }

    /** (Re)schedule reminders for every open homework and taken task. Safe to call often. */
    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        cancelAll(c)
        if (!enabled(c)) return
        val now = System.currentTimeMillis()
        val he = Lang.isHebrew(c)
        val keys = ArrayList<String>()
        for (it in items(c)) {
            if (it.done || it.due <= 0) continue
            val (at, title, text) = when (it.kind) {
                "hw" -> Triple(it.due - 24L * 3600 * 1000, if (he) "שיעורי בית למחר" else "Homework due tomorrow", it.title)
                "task" -> Triple(it.due - 2L * 3600 * 1000, if (he) "נשארו שעתיים" else "2 hours left", it.title + if (he) " — סיימו או ויתרו כדי שאחרים יוכלו לקחת" else " — finish it or give it up so someone else can")
                else -> continue
            }
            if (at <= now) continue
            val key = it.kind + "|" + it.code + "|" + it.title + "|" + it.due
            keys.add(key)
            am.set(AlarmManager.RTC_WAKEUP, at, pi(c, key, title, text))
        }
        sp(c).edit().putString("dueKeys", keys.joinToString("\n")).apply()
    }

    private fun cancelAll(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        for (k in (sp(c).getString("dueKeys", "") ?: "").split("\n").filter { it.isNotEmpty() }) am.cancel(pi(c, k, "", ""))
    }
}

/** Posts a due reminder. */
class DueReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent?) {
        if (Build.VERSION.SDK_INT >= 26) {
            c.getSystemService(NotificationManager::class.java)?.createNotificationChannel(
                NotificationChannel(Todo.CHANNEL, if (Lang.isHebrew(c)) "תזכורות להגשה" else "Due reminders", NotificationManager.IMPORTANCE_DEFAULT))
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(c, 3, Intent(c, ProfileActivity::class.java), flags)
        val n = Notification.Builder(c, Todo.CHANNEL).setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(intent?.getStringExtra("title") ?: "Comboed").setContentText(intent?.getStringExtra("text") ?: "")
            .setAutoCancel(true).setContentIntent(open).build()
        try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify((intent?.getStringExtra("key") ?: "").hashCode(), n) } catch (e: Exception) {}
    }
}
