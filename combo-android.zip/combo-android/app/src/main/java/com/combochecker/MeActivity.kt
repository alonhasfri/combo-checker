package com.combochecker

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout

/** "Me" tab: profile + level, a stats grid, the weekly coach and links to the personal screens. */
class MeActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun t(s: String) = Voice.say(this, s)

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        page.addView(Ui.header(this, t("Me"), gear = true))

        val me = Profiles.current(this)
        val st = Progress.state(this)
        val total = st.optInt("total", 0)
        val level = Progress.level(total)
        val (need, frac) = Progress.toNext(total)

        // profile card
        val card = Ui.card(this).apply { setPaddingRelative(Ui.dp(this@MeActivity, 18), Ui.dp(this@MeActivity, 18), Ui.dp(this@MeActivity, 18), Ui.dp(this@MeActivity, 18)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.avatar(this, me, 60))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(Ui.dp(this@MeActivity, 14), 0, 0, 0) }
        col.addView(Ui.text(this, me.optString("name", "Me"), 22f, p.ink))
        col.addView(Ui.text(this, t("Level") + " $level · " + Progress.rank(this, level), 14f, p.accentInk))
        top.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        card.addView(top)
        card.addView(Ui.bar(this, frac, p.accent, p.track), Ui.lp(this, 16))
        val nextTxt = if (Lang.isHebrew(this)) "עוד $need נקודות לשלב ${level + 1}" else "$need points to Level ${level + 1}"
        card.addView(Ui.text(this, nextTxt, 13f, p.muted, bold = false).apply { setPaddingRelative(0, Ui.dp(this@MeActivity, 8), 0, 0) })
        page.addView(card, Ui.lp(this, 16))

        // stats grid (2 x 2)
        val badges = st.optJSONArray("achv")?.length() ?: 0
        val streak = Progress.dayStreak(this)
        val stats = listOf(
            Pair(Progress.gallery(this).length().toString(), t("Tasks done")),
            Pair(if (Lang.isHebrew(this)) "$streak ימים" else "$streak " + (if (streak == 1) "day" else "days"), t("Day streak")),
            Pair(String.format("%,d", total), t("Points")),
            Pair("$badges / 8", t("Badges"))
        )
        for (r in 0 until 2) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 2) {
                val (v, label) = stats[r * 2 + c]
                val box = Ui.card(this).apply { setPaddingRelative(Ui.dp(this@MeActivity, 16), Ui.dp(this@MeActivity, 14), Ui.dp(this@MeActivity, 16), Ui.dp(this@MeActivity, 14)) }
                box.addView(Ui.text(this, v, 22f, p.ink))
                box.addView(Ui.text(this, label, 13f, p.muted, bold = false))
                line.addView(box, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply {
                    if (c == 0) marginEnd = Ui.dp(this@MeActivity, 5) else marginStart = Ui.dp(this@MeActivity, 5)
                })
            }
            page.addView(line, Ui.lp(this, 10))
        }

        // weekly coach
        val coach = Ui.card(this).apply { setPaddingRelative(Ui.dp(this@MeActivity, 16), Ui.dp(this@MeActivity, 14), Ui.dp(this@MeActivity, 16), Ui.dp(this@MeActivity, 16)) }
        val ch = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        ch.addView(Ui.tile(this, R.drawable.ui_spark, "purple"))
        ch.addView(Ui.text(this, t("Your coach"), 16f, p.ink).apply { setPaddingRelative(Ui.dp(this@MeActivity, 12), 0, 0, 0) })
        coach.addView(ch)
        coach.addView(Ui.text(this, Progress.coach(this), 14f, p.ink, bold = false).apply { setPaddingRelative(0, Ui.dp(this@MeActivity, 10), 0, 0); setLineSpacing(0f, 1.15f) })
        page.addView(coach, Ui.lp(this, 12))

        // links
        page.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_image, "blue", t("Proof gallery"), Progress.gallery(this).length().toString()) {
                startActivity(Intent(this, GalleryActivity::class.java))
            },
            Ui.row(this, R.drawable.ui_calendar, "purple", t("My week"), null) { startActivity(Intent(this, RecapActivity::class.java)) },
            Ui.row(this, R.drawable.ui_star, "gold", t("Stats & badges"), null) { startActivity(Intent(this, StatsActivity::class.java)) },
            Ui.row(this, R.drawable.ui_users, "green", t("Switch profile"), null) {
                startActivity(Intent(this, ProfileActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }
        )), Ui.lp(this, 16))

        Ui.tabScreen(this, page, "me")
    }
}
