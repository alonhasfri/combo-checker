package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Harmless, opt-in friend pranks. Tick the trolls you want, get ONE "creator key" that carries them
 * all, and share it. A friend who chooses to paste it into their own Settings → Creator key unlocks
 * the whole set on their own phone. It never touches anyone's points, coins or data — there's no
 * server and no access to another phone.
 */
class PrankActivity : Activity() {

    private var pad = 0
    private lateinit var rootScroll: ScrollView
    private val checks = HashMap<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        rootScroll = ScrollView(this)
        setContentView(rootScroll)
        // A valid one-shot gag id passed from the Settings unlock jumps straight to playing it.
        val auto = intent.getStringExtra("gag")
        if (auto != null) playGag(auto) else showMenu()
    }

    private fun showMenu() {
        checks.clear()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        // Decoy: this screen masquerades as a read-only "source code" viewer. The real prank menu
        // is buried far below the wall of (fake) code — scroll aaaall the way down to reach it.
        root.addView(TextView(this).apply {
            text = "📄 source_code.kt"; textSize = 20f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Read-only · combo_checker_core · 4,812 lines"
            textSize = 12f; setTextColor(Color.parseColor("#888888")); setPadding(0, 0, 0, pad / 2)
        })
        root.addView(TextView(this).apply {
            text = fakeSource()
            textSize = 11f
            setTypeface(Typeface.MONOSPACE, Typeface.NORMAL)
            setTextColor(Color.parseColor("#7ad17a"))
            setTextIsSelectable(true)
        })
        root.addView(TextView(this).apply {
            text = "\n\n// ───────────────────────────────\n// internal debug build — dev flags\n// ───────────────────────────────\n"
            textSize = 11f; setTypeface(Typeface.MONOSPACE, Typeface.NORMAL); setTextColor(Color.parseColor("#888888"))
        })

        root.addView(header("Modes (stay on until turned off)"))
        for (t in Pranks.trolls) if (t.persist && t.implemented) root.addView(trollCheck(t))

        root.addView(header("One-shot gags (play once)"))
        for (t in Pranks.trolls) if (!t.persist && t.implemented) root.addView(trollCheck(t))

        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "🔑 Make the creator key")
            setPadding(0, pad, 0, pad)
            setOnClickListener { makeKey() }
        })

        root.addView(header("Got a creator key?"))
        val input = EditText(this).apply {
            hint = Lang.t(this@PrankActivity, "Paste a key, e.g. CRK-7K2P-9QF4")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "Unlock")
            setOnClickListener {
                val set = Pranks.decode(input.text.toString())
                if (set.isNullOrEmpty()) { Toast.makeText(this@PrankActivity, Lang.t(this@PrankActivity, "❌ Invalid creator key."), Toast.LENGTH_SHORT).show() }
                else applySet(set)
            }
        })

        root.addView(Button(this).apply { text = Lang.t(this@PrankActivity, "Done"); setOnClickListener { finish() }; setPadding(0, pad, 0, 0) })

        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun trollCheck(t: Pranks.Troll): CheckBox {
        val cb = CheckBox(this).apply { text = t.label }
        checks[t.id] = cb
        return cb
    }

    private fun selectedIds(): MutableSet<String> =
        checks.filterValues { it.isChecked }.keys.toMutableSet()

    private fun makeKey() {
        val ids = selectedIds()
        if (ids.isEmpty()) { Toast.makeText(this, Lang.t(this, "Tick at least one troll first."), Toast.LENGTH_SHORT).show(); return }
        val code = Pranks.codeFor(ids)
        val chosen = Pranks.trolls.filter { ids.contains(it.id) }.joinToString("\n") { "• " + it.label }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Creator key for:"); textSize = 16f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply { text = chosen; textSize = 15f; setPadding(0, pad / 4, 0, pad / 4) })
        root.addView(TextView(this).apply {
            text = code; textSize = 32f; gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(Color.parseColor("#ff4fb8"))
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Send this to your friend. Tell them it's a secret Creator key that unlocks hidden features — they paste it into Settings → Creator key and tap Unlock. The code looks random, so it won't give the prank away. 😈")
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "Share key")
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, Lang.t(this@PrankActivity, "Here's a Comboed creator key that unlocks hidden features — paste it in Settings → Creator key and tap Unlock:") + "  $code")
                try { startActivity(Intent.createChooser(i, Lang.t(this@PrankActivity, "Share"))) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "Try it on my phone")
            setOnClickListener { Pranks.decode(code)?.let { applySet(it) } }
        })
        root.addView(Button(this).apply { text = Lang.t(this@PrankActivity, "Back"); setOnClickListener { showMenu() } })
        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    /** Turn on any persistent modes, then play one gag if the set had one. */
    private fun applySet(set: List<Pranks.Troll>) {
        val gag = Pranks.applyPersistent(this, set)
        val modes = set.filter { it.persist }
        if (gag != null) playGag(gag)
        else {
            Toast.makeText(this, Lang.t(this, "✅ Creator features unlocked."), Toast.LENGTH_SHORT).show()
            if (modes.isNotEmpty()) showMenu()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun playGag(gag: String) {
        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0b0b14"))
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(object {
            @JavascriptInterface fun close() { runOnUiThread { showMenu() } }
        }, "Prank")
        setContentView(web)
        web.loadUrl("file:///android_asset/prank.html#$gag")
    }

    override fun onBackPressed() {
        if (rootScroll.parent == null) { setContentView(rootScroll); showMenu() } else super.onBackPressed()
    }

    private fun header(label: String): TextView = TextView(this).apply {
        text = Lang.t(this@PrankActivity, label); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
    }

    /** A big block of plausible-but-fake engine code, so the screen reads like a real source viewer. */
    private fun fakeSource(): String {
        val sb = StringBuilder()
        sb.append("package com.combochecker.core\n\n")
        sb.append("import android.graphics.Canvas\nimport android.graphics.Paint\nimport kotlin.math.*\n")
        sb.append("import kotlinx.coroutines.*\nimport org.json.JSONObject\n\n")
        sb.append("private const val FRAME_BUDGET_NS = 16_666_667L\nprivate const val SEED = 0x9E3779B97F4A7C15uL\n\n")
        val types = listOf("Int", "Long", "Float", "Double", "Boolean")
        val verbs = listOf("compute", "resolve", "render", "encode", "decode", "quantize", "dispatch",
            "accumulate", "interpolate", "normalize", "rebalance", "flush", "coalesce", "sample", "project")
        val nouns = listOf("Frame", "Streak", "Proof", "Combo", "Particle", "Gradient", "Vector", "Token",
            "Histogram", "Buffer", "Session", "Payload", "Transform", "Lattice", "Spectrum")
        val r = java.util.Random(42)
        for (i in 0 until 46) {
            val v = verbs[r.nextInt(verbs.size)]
            val n = nouns[r.nextInt(nouns.size)]
            val t = types[r.nextInt(types.size)]
            sb.append("/** ${v.replaceFirstChar { it.uppercase() }}s the $n layer for pass #$i. */\n")
            sb.append("internal fun $v$n$i(src: $t, bias: Int = ${r.nextInt(512)}): $t {\n")
            sb.append("    val k = (src.hashCode() * 0x${Integer.toHexString(r.nextInt())}.toInt()) xor (bias shl ${1 + r.nextInt(15)})\n")
            sb.append("    var acc = ${r.nextInt(1000)}\n")
            sb.append("    for (q in 0 until ${8 + r.nextInt(120)}) acc = (acc * 31 + k) and 0x7FFFFFFF\n")
            sb.append("    return ${if (t == "Boolean") "(acc and 1) == 0" else "acc as? $t ?: src"}\n")
            sb.append("}\n\n")
        }
        sb.append("object PipelineGraph {\n")
        for (i in 0 until 14) sb.append("    val node$i = Stage($i, weight = ${r.nextInt(100)} / 100.0)\n")
        sb.append("}\n")
        return sb.toString()
    }
}
