package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Harmless, opt-in friend pranks. Tick the trolls you want, get ONE "creator key" that carries them
 * all, and share it. A friend who chooses to paste it into their own Settings → Creator key unlocks
 * the whole set on their own phone. It never touches anyone's points, coins or data — there's no
 * server and no access to another phone.
 */
class PrankActivity : Activity() {

    private var pad = 0
    private lateinit var rootScroll: ScrollView
    private val checks = HashMap<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        rootScroll = ScrollView(this)
        setContentView(rootScroll)
        // A valid one-shot gag id passed from the Settings unlock jumps straight to playing it.
        val auto = intent.getStringExtra("gag")
        if (auto != null) playGag(auto) else showMenu()
    }

    private fun showMenu() {
        checks.clear()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        // Decoy: this screen masquerades as a boring "Terms of Service" page. The real creator menu
        // is buried far below the legal text — scroll aaaall the way down to reach it.
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Terms of Service & Privacy Policy"); textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Last updated: today · Comboed")
            textSize = 12f; setTextColor(Color.parseColor("#888888")); setPadding(0, 0, 0, pad / 2)
        })
        root.addView(TextView(this).apply {
            text = legalText()
            textSize = 13f; setTextColor(Color.parseColor("#9aa3bf")); setPadding(0, 0, 0, pad)
        })

        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "✨ Update tools")
            textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 8)
        })
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Tick the pranks you want, make one update key that carries them all, and share it — or paste a key a friend sent you. Modes stay on until turned off; gags play once.")
            textSize = 13f; setPadding(0, 0, 0, pad / 2)
        })

        root.addView(header("Modes (stay on until turned off)"))
        for (t in Pranks.trolls) if (t.persist && t.implemented) root.addView(trollCheck(t))

        root.addView(header("One-shot gags (play once)"))
        for (t in Pranks.trolls) if (!t.persist && t.implemented) root.addView(trollCheck(t))

        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "🔑 Make the update key")
            setPadding(0, pad, 0, pad)
            setOnClickListener { makeKey() }
        })

        root.addView(header("Got an update key?"))
        val input = EditText(this).apply {
            hint = Lang.t(this@PrankActivity, "Paste a key, e.g. CRK-7K2P-9QF4")
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "Unlock")
            setOnClickListener {
                val set = Pranks.decode(input.text.toString())
                if (set.isNullOrEmpty()) { Toast.makeText(this@PrankActivity, Lang.t(this@PrankActivity, "❌ Invalid update key."), Toast.LENGTH_SHORT).show() }
                else applySet(set)
            }
        })

        root.addView(Button(this).apply { text = Lang.t(this@PrankActivity, "Done"); setOnClickListener { finish() }; setPadding(0, pad, 0, 0) })

        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun trollCheck(t: Pranks.Troll): CheckBox {
        val cb = CheckBox(this).apply { text = t.label }
        checks[t.id] = cb
        return cb
    }

    private fun selectedIds(): MutableSet<String> =
        checks.filterValues { it.isChecked }.keys.toMutableSet()

    private fun makeKey() {
        val ids = selectedIds()
        if (ids.isEmpty()) { Toast.makeText(this, Lang.t(this, "Tick at least one troll first."), Toast.LENGTH_SHORT).show(); return }
        val code = Pranks.codeFor(ids)
        val chosen = Pranks.trolls.filter { ids.contains(it.id) }.joinToString("\n") { "• " + it.label }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Update key for:"); textSize = 16f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply { text = chosen; textSize = 15f; setPadding(0, pad / 4, 0, pad / 4) })
        root.addView(TextView(this).apply {
            text = code; textSize = 32f; gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(Color.parseColor("#ff4fb8"))
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = Lang.t(this@PrankActivity, "Send this to your friend. Tell them it's a secret Update key that unlocks hidden features — they paste it into Settings → Update key and tap Unlock. The code looks random, so it won't give the prank away. 😈")
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "Share key")
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, Lang.t(this@PrankActivity, "Here's a Comboed update key that unlocks hidden features — paste it in Settings → Update key and tap Unlock:") + "  $code")
                try { startActivity(Intent.createChooser(i, Lang.t(this@PrankActivity, "Share"))) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "📮 Send straight to a friend code")
            setOnClickListener {
                val f = android.widget.EditText(this@PrankActivity).apply { hint = "ABC123"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS }
                android.app.AlertDialog.Builder(this@PrankActivity)
                    .setTitle(Lang.t(this@PrankActivity, "Friend code"))
                    .setMessage(Lang.t(this@PrankActivity, "Their code is in Me → My friend code. The prank lands the next time they open the app."))
                    .setView(f)
                    .setPositiveButton(Lang.t(this@PrankActivity, "Send")) { _, _ ->
                        Backend.sendToInbox(f.text.toString(), code) { ok ->
                            Toast.makeText(this@PrankActivity, Lang.t(this@PrankActivity, if (ok) "Sent! 😈" else "No one has that friend code (or you're offline)."), Toast.LENGTH_LONG).show()
                        }
                    }
                    .setNegativeButton(Lang.t(this@PrankActivity, "Cancel"), null).show()
            }
        })
        root.addView(Button(this).apply {
            text = Lang.t(this@PrankActivity, "Try it on my phone")
            setOnClickListener { Pranks.decode(code)?.let { applySet(it) } }
        })
        root.addView(Button(this).apply { text = Lang.t(this@PrankActivity, "Back"); setOnClickListener { showMenu() } })
        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    /** Turn on any persistent modes, then play one gag if the set had one. */
    private fun applySet(set: List<Pranks.Troll>) {
        val gag = Pranks.applyPersistent(this, set)
        val modes = set.filter { it.persist }
        if (gag != null) playGag(gag)
        else {
            Toast.makeText(this, Lang.t(this, "✅ Update features unlocked."), Toast.LENGTH_SHORT).show()
            if (modes.isNotEmpty()) showMenu()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun playGag(gag: String) {
        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0b0b14"))
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(object {
            @JavascriptInterface fun close() { runOnUiThread { showMenu() } }
        }, "Prank")
        setContentView(web)
        web.loadUrl("file:///android_asset/prank.html#$gag")
    }

    override fun onBackPressed() {
        if (rootScroll.parent == null) { setContentView(rootScroll); showMenu() } else super.onBackPressed()
    }

    private fun header(label: String): TextView = TextView(this).apply {
        text = Lang.t(this@PrankActivity, label); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
    }

    /** Boring, plausible legal boilerplate so the screen reads like a real Terms page. */
    private fun legalText(): String {
        if (Lang.isHebrew(this)) {
            return "ברוכים הבאים ל‑Comboed. השימוש באפליקציה כפוף לתנאים הבאים. " +
                "1. חשבון. הפרופילים והנתונים שלכם נשמרים במכשיר בלבד. " +
                "2. פרטיות. איננו אוספים מידע אישי ואיננו שולחים נתונים לשרת; תמונות ההוכחה נשארות אצלכם. " +
                "3. שימוש הוגן. אין להשתמש באפליקציה לרעה או להתחזות לאחרים. " +
                "4. תוכן. אתם אחראים לתוכן שאתם מצלמים ובודקים. " +
                "5. בקרת הורים. ניתן להגדיר קוד הורים כדי לנהל פרסים ואישורים. " +
                "6. אחריות. האפליקציה מסופקת \"כפי שהיא\", ללא כל אחריות. " +
                "7. שינויים. אנו עשויים לעדכן תנאים אלה מעת לעת. " +
                "8. יצירת קשר. לשאלות: hasfrialon@gmail.com. " +
                "המשך השימוש מהווה הסכמה לתנאים אלה ולמדיניות הפרטיות."
        }
        return "Welcome to Comboed. Your use of this app is subject to the following terms. " +
            "1. Account. Your profiles and data are stored only on this device. " +
            "2. Privacy. We do not collect personal information and we do not send data to any server; your proof photos stay with you. " +
            "3. Fair use. Do not misuse the app or impersonate others. " +
            "4. Content. You are responsible for the content you photograph and check. " +
            "5. Parental controls. A parent PIN can be set to manage rewards and approvals. " +
            "6. Warranty. The app is provided \"as is\", without warranties of any kind. " +
            "7. Changes. We may update these terms from time to time. " +
            "8. Contact. Questions: hasfrialon@gmail.com. " +
            "By continuing to use the app you agree to these terms and the privacy policy."
    }
}
