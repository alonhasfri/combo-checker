package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Harmless, opt-in friend pranks. Tick the trolls you want, get ONE "creator key" that carries them
 * all, and share it. A friend who chooses to paste it into their own Settings → Creator key unlocks
 * the whole set on their own phone. It never touches anyone's points, coins or data — there's no
 * server and no access to another phone.
 */
class PrankActivity : Activity() {

    private var pad = 0
    private lateinit var rootScroll: ScrollView
    private val checks = HashMap<String, CheckBox>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        rootScroll = ScrollView(this)
        setContentView(rootScroll)
        // A valid one-shot gag id passed from the Settings unlock jumps straight to playing it.
        val auto = intent.getStringExtra("gag")
        if (auto != null) playGag(auto) else showMenu()
    }

    private fun showMenu() {
        checks.clear()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        root.addView(TextView(this).apply {
            text = "😈 Prank a friend"; textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "Tick the trolls you want, then make ONE creator key with all of them. Tell your friend it " +
                "unlocks hidden creator features — when they paste it into Settings → Creator key, the whole set " +
                "turns on. It can't touch their points or data."
            textSize = 14f; setPadding(0, pad / 2, 0, pad / 2)
        })

        root.addView(header("Modes (stay on until turned off)"))
        for (t in Pranks.trolls) if (t.persist && t.implemented) root.addView(trollCheck(t))

        root.addView(header("One-shot gags (play once)"))
        for (t in Pranks.trolls) if (!t.persist && t.implemented) root.addView(trollCheck(t))

        root.addView(Button(this).apply {
            text = "🔑 Make the creator key"
            setPadding(0, pad, 0, pad)
            setOnClickListener { makeKey() }
        })

        root.addView(header("Got a creator key?"))
        val input = EditText(this).apply {
            hint = "Paste a key, e.g. CRK-7K2P-9QF4"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "Unlock"
            setOnClickListener {
                val set = Pranks.decode(input.text.toString())
                if (set.isNullOrEmpty()) { Toast.makeText(this@PrankActivity, "❌ Invalid creator key.", Toast.LENGTH_SHORT).show() }
                else applySet(set)
            }
        })

        root.addView(Button(this).apply { text = "Done"; setOnClickListener { finish() }; setPadding(0, pad, 0, 0) })

        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun trollCheck(t: Pranks.Troll): CheckBox {
        val cb = CheckBox(this).apply { text = t.label }
        checks[t.id] = cb
        return cb
    }

    private fun selectedIds(): MutableSet<String> {
        val ids = checks.filterValues { it.isChecked }.keys.toMutableSet()
        // Ad copy is Gen Z flavored, so any ad mini-category also turns on Gen Z.
        if (ids.any { it.startsWith("ads_") }) ids.add("genz")
        return ids
    }

    private fun makeKey() {
        val ids = selectedIds()
        if (ids.isEmpty()) { Toast.makeText(this, "Tick at least one troll first.", Toast.LENGTH_SHORT).show(); return }
        val code = Pranks.codeFor(ids)
        val chosen = Pranks.trolls.filter { ids.contains(it.id) }.joinToString("\n") { "• " + it.label }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply {
            text = "Creator key for:"; textSize = 16f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply { text = chosen; textSize = 15f; setPadding(0, pad / 4, 0, pad / 4) })
        root.addView(TextView(this).apply {
            text = code; textSize = 32f; gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(Color.parseColor("#ff4fb8"))
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = "Send this to your friend. Tell them it's a secret Creator key that unlocks hidden features — " +
                "they paste it into Settings → Creator key and tap Unlock. The code looks random, so it won't give " +
                "the prank away. 😈"
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "Share key"
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Here's a Combo Checker creator key that unlocks hidden features — " +
                        "paste it in Settings → Creator key and tap Unlock:  $code")
                try { startActivity(Intent.createChooser(i, "Share")) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply {
            text = "Try it on my phone"
            setOnClickListener { Pranks.decode(code)?.let { applySet(it) } }
        })
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { showMenu() } })
        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    /** Turn on any persistent modes, then play one gag if the set had one. */
    private fun applySet(set: List<Pranks.Troll>) {
        val gag = Pranks.applyPersistent(this, set)
        val modes = set.filter { it.persist }
        if (gag != null) playGag(gag)
        else {
            Toast.makeText(this, "✅ Creator features unlocked.", Toast.LENGTH_SHORT).show()
            if (modes.isNotEmpty()) showMenu()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun playGag(gag: String) {
        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0b0b14"))
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(object {
            @JavascriptInterface fun close() { runOnUiThread { showMenu() } }
        }, "Prank")
        setContentView(web)
        web.loadUrl("file:///android_asset/prank.html#$gag")
    }

    override fun onBackPressed() {
        if (rootScroll.parent == null) { setContentView(rootScroll); showMenu() } else super.onBackPressed()
    }

    private fun header(label: String): TextView = TextView(this).apply {
        text = label; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
    }
}
