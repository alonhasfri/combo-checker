package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Harmless, opt-in friend pranks. You pick a gag and get a code to share; a friend who CHOOSES to
 * type that code into THEIR app sees the gag on their own screen only. It never touches anyone's
 * points, coins or data — there's no server and no access to another phone.
 */
class PrankActivity : Activity() {

    // Each gag maps to a word used at the start of a shareable code.
    private val gags = linkedMapOf(
        "CONFETTI" to Pair("confetti", "🎉 Confetti bomb"),
        "FART" to Pair("fart", "💨 Fart sound"),
        "LEVELUP" to Pair("levelup", "🆙 Fake LEVEL 99"),
        "FLIP" to Pair("flip", "🙃 Upside-down screen"),
        "RAINBOW" to Pair("rainbow", "🌈 Rainbow freak-out")
    )
    private var pad = 0
    private lateinit var rootScroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        rootScroll = ScrollView(this)
        setContentView(rootScroll)
        showMenu()
    }

    private fun showMenu() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        root.addView(TextView(this).apply {
            text = "😈 Prank a friend"; textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "Pick a gag to get a code. Send it to a friend — when THEY type it into their own app, " +
                "the gag plays on their screen. It's just for laughs: it can't touch their points or data."
            textSize = 14f; setPadding(0, pad / 2, 0, pad / 2)
        })

        root.addView(header("Make a prank code"))
        for ((word, g) in gags) {
            root.addView(Button(this).apply {
                text = g.second
                setOnClickListener { showCode(word, g.second) }
            })
        }

        root.addView(header("Got a code from a friend?"))
        val input = EditText(this).apply {
            hint = "Type the code, e.g. CONFETTI-7QX"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "Run it!"
            setOnClickListener {
                val gag = parseCode(input.text.toString())
                if (gag == null) Toast.makeText(this@PrankActivity, "Hmm, that code didn't work. Check the spelling.", Toast.LENGTH_SHORT).show()
                else playGag(gag)
            }
        })

        root.addView(Button(this).apply { text = "Done"; setOnClickListener { finish() }; setPadding(0, pad, 0, 0) })

        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun showCode(word: String, label: String) {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val suffix = (1..3).map { alphabet[alphabet.indices.random()] }.joinToString("")
        val code = "$word-$suffix"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply {
            text = label; textSize = 20f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = code; textSize = 40f; gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(Color.parseColor("#ff4fb8"))
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = "Send this code to your friend. When they type it into their Prank screen and tap Run, the gag plays on their phone. (The letters after the dash are just for fun.)"
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "Share code"
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Type this into Combo Checker's Prank screen and tap Run 😈  →  $code")
                try { startActivity(Intent.createChooser(i, "Share")) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply { text = "Try it on my phone"; setOnClickListener { playGag(gags[word]!!.first) } })
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { showMenu() } })
        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun parseCode(raw: String): String? {
        val word = raw.trim().uppercase().substringBefore("-").trim()
        return gags[word]?.first
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun playGag(gag: String) {
        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0b0b14"))
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(object {
            @JavascriptInterface fun close() { runOnUiThread { showMenu() } }
        }, "Prank")
        setContentView(web)
        web.loadUrl("file:///android_asset/prank.html#$gag")
    }

    override fun onBackPressed() {
        // If a gag is showing, go back to the menu instead of leaving.
        if (rootScroll.parent == null) { setContentView(rootScroll); showMenu() } else super.onBackPressed()
    }

    private fun header(label: String): TextView = TextView(this).apply {
        text = label; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
    }
}
