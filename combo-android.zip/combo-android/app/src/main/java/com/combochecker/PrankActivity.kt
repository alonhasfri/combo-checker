package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Harmless, opt-in friend pranks. You pick a gag and get a code to share; a friend who CHOOSES to
 * type that code into THEIR app sees the gag on their own screen only. It never touches anyone's
 * points, coins or data — there's no server and no access to another phone.
 */
class PrankActivity : Activity() {

    private var pad = 0
    private lateinit var rootScroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        rootScroll = ScrollView(this)
        setContentView(rootScroll)
        // A valid "creator key" entered elsewhere (e.g. the Settings field) jumps straight to its gag.
        val auto = intent.getStringExtra("gag")
        if (auto != null) playGag(auto) else showMenu()
    }

    private fun showMenu() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }

        root.addView(TextView(this).apply {
            text = "😈 Prank a friend"; textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "Pick a gag to get a secret \"Creator key\". Send it to a friend and tell them it unlocks hidden " +
                "creator features — when they paste it into Settings → Creator key and tap Unlock, the gag plays " +
                "on their screen. It's just for laughs: it can't touch their points or data."
            textSize = 14f; setPadding(0, pad / 2, 0, pad / 2)
        })

        root.addView(header("Make a creator key"))
        Pranks.gags.forEachIndexed { idx, g ->
            root.addView(Button(this).apply {
                text = g.label
                setOnClickListener { showCode(idx, g.label) }
            })
        }
        root.addView(Button(this).apply {
            text = "🧠 Gen Z mode (sneaky, no reveal)"
            setOnClickListener { showGenZCode() }
        })

        root.addView(header("Got a creator key?"))
        val input = EditText(this).apply {
            hint = "Paste a key, e.g. CRK-4471-8832"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "Unlock"
            setOnClickListener {
                val gag = Pranks.gagForCode(input.text.toString())
                if (gag == null) Toast.makeText(this@PrankActivity, "❌ Invalid creator key.", Toast.LENGTH_SHORT).show()
                else playGag(gag)
            }
        })

        root.addView(Button(this).apply { text = "Done"; setOnClickListener { finish() }; setPadding(0, pad, 0, 0) })

        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun showCode(index: Int, label: String) {
        val code = Pranks.codeFor(index)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply {
            text = "Creator key for:\n" + label; textSize = 18f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = code; textSize = 34f; gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(Color.parseColor("#ff4fb8"))
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = "Send this to your friend. Tell them it's a secret Creator key that unlocks hidden features — " +
                "they paste it into Settings → Creator key and tap Unlock. The code looks random, so it won't give " +
                "the gag away. 😈"
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "Share key"
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Here's a Combo Checker creator key that unlocks hidden features — " +
                        "paste it in Settings → Creator key and tap Unlock:  $code")
                try { startActivity(Intent.createChooser(i, "Share")) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply { text = "Try it on my phone"; setOnClickListener { playGag(Pranks.gags[index].id) } })
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { showMenu() } })
        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    private fun showGenZCode() {
        val code = Pranks.codeForGenZ()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        root.addView(TextView(this).apply {
            text = "🧠 Gen Z mode key"; textSize = 20f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = code; textSize = 34f; gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD); setTextColor(Color.parseColor("#7dff6b"))
            setPadding(0, pad, 0, pad)
        })
        root.addView(TextView(this).apply {
            text = "This one is the slow-burn. When your friend unlocks it, NOTHING obvious happens — but the " +
                "whole app quietly starts talking in Gen Z slang with emoji everywhere, and the AI roasts them. " +
                "It stays on until they dig into Settings and find \"Turn off Gen Z mode\". 😈"
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })
        root.addView(Button(this).apply {
            text = "Share key"
            setOnClickListener {
                val i = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "Here's a Combo Checker creator key that unlocks hidden features — " +
                        "paste it in Settings → Creator key and tap Unlock:  $code")
                try { startActivity(Intent.createChooser(i, "Share")) } catch (e: Exception) {}
            }
        })
        root.addView(Button(this).apply {
            text = "Turn it on here (to preview)"
            setOnClickListener {
                GenZ.setOn(this@PrankActivity, true)
                Toast.makeText(this@PrankActivity, "✅ Creator features unlocked.", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply { text = "Back"; setOnClickListener { showMenu() } })
        rootScroll.removeAllViews(); rootScroll.addView(root)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun playGag(gag: String) {
        val web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0b0b14"))
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(object {
            @JavascriptInterface fun close() { runOnUiThread { showMenu() } }
        }, "Prank")
        setContentView(web)
        web.loadUrl("file:///android_asset/prank.html#$gag")
    }

    override fun onBackPressed() {
        // If a gag is showing, go back to the menu instead of leaving.
        if (rootScroll.parent == null) { setContentView(rootScroll); showMenu() } else super.onBackPressed()
    }

    private fun header(label: String): TextView = TextView(this).apply {
        text = label; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
    }
}
