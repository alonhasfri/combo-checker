package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject

/** Sound shop: preview the packs, then buy and equip them with coins. */
class SoundGalleryActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)

    private fun loadState(): JSONObject {
        val s = sp().getString(Profiles.stateKey(this), "") ?: ""
        val o = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        if (!o.has("coins")) o.put("coins", 0)
        if (!o.has("owned")) o.put("owned", JSONArray())
        if (!o.has("sound")) o.put("sound", "sound_default")
        return o
    }

    private fun saveState(o: JSONObject) = sp().edit().putString(Profiles.stateKey(this), o.toString()).apply()

    private fun owns(o: JSONObject, id: String): Boolean {
        if (id == "sound_default") return true
        val arr = o.optJSONArray("owned") ?: return false
        for (i in 0 until arr.length()) if (arr.optString(i) == id) return true
        return false
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Profiles.ensureDefault(this)
        val web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Shop")
        setContentView(web)
        web.loadUrl("file:///android_asset/sounds.html")
    }

    private inner class Bridge {
        @JavascriptInterface
        fun isDebug(): Boolean = loadState().optBoolean("debug", false)

        @JavascriptInterface
        fun coins(): Int = loadState().optInt("coins", 0)

        @JavascriptInterface
        fun equipped(): String = loadState().optString("sound", "sound_default")

        @JavascriptInterface
        fun owns(id: String): Boolean = loadState().let { it.optBoolean("debug", false) || owns(it, id) }

        /** Returns "ok", "owned", "equipped" or "poor". */
        @JavascriptInterface
        fun buy(id: String, cost: Int): String {
            val s = loadState()
            val debug = s.optBoolean("debug", false)
            if (owns(s, id)) { s.put("sound", id); saveState(s); return "equipped" }
            if (!debug && s.optInt("coins", 0) < cost) return "poor"
            if (!debug) s.put("coins", s.optInt("coins", 0) - cost)
            val arr = s.optJSONArray("owned") ?: JSONArray()
            arr.put(id); s.put("owned", arr); s.put("sound", id)
            saveState(s)
            return "ok"
        }

        @JavascriptInterface
        fun equip(id: String): Boolean {
            val s = loadState()
            if (!owns(s, id) && !s.optBoolean("debug", false)) return false
            s.put("sound", id); saveState(s); return true
        }
    }
}
