package com.combochecker

import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Update checks against GitHub releases. Only builds from main are "latest", so this always points
 * at the finished version. Checked when the app opens (at most every 6 hours) and once a day in the
 * background; a newer build shows a card on Home and one notification per build.
 */
object UpdateCheck {
    /** One permanent link that always downloads the newest finished version. */
    const val LATEST_APK = "https://github.com/alonhasfri/combo-checker/releases/latest/download/combo-checker.apk"
    const val CHANNEL = "comboed_updates"
    private const val REQ = 7002
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("updateNotify", true)
    fun setEnabled(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("updateNotify", on).apply()
        if (on) schedule(c) else cancel(c)
    }

    /** Newest build number seen on GitHub (0 if unknown). */
    fun latestKnown(c: Context) = sp(c).getInt("latestBuild", 0)
    fun updateAvailable(c: Context) = latestKnown(c) > Changelog.build(c) && Changelog.build(c) > 0

    /** Blocking network call: the newest main build number, or -1. */
    fun fetchLatest(): Int = try {
        val conn = URL("https://api.github.com/repos/alonhasfri/combo-checker/releases/latest").openConnection() as HttpURLConnection
        conn.connectTimeout = 8000; conn.readTimeout = 8000
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        o.optString("tag_name").substringAfter("build-").toIntOrNull() ?: -1
    } catch (e: Exception) { -1 }

    /** Check in the background thread; [onDone] runs on the calling activity's UI thread. */
    fun checkNow(a: Activity, force: Boolean = false, onDone: (Boolean) -> Unit = {}) {
        val last = sp(a).getLong("updateCheckedAt", 0L)
        if (!force && System.currentTimeMillis() - last < 6L * 3600 * 1000) { onDone(updateAvailable(a)); return }
        Thread {
            val n = fetchLatest()
            if (n > 0) sp(a).edit().putInt("latestBuild", n).putLong("updateCheckedAt", System.currentTimeMillis()).apply()
            a.runOnUiThread { if (!a.isFinishing) onDone(updateAvailable(a)) }
        }.start()
    }

    fun steps(c: Context): String = if (Lang.isHebrew(c))
        "1. הקישו על ״הורדה״.\n2. כשההורדה מסתיימת, פתחו את הקובץ (מההתראה או מתיקיית ההורדות).\n3. אם מבקשים — אשרו ״התקנה מאפליקציות לא מוכרות״ לדפדפן.\n4. הקישו ״עדכון״. כל ההתקדמות נשמרת."
    else
        "1. Tap Download.\n2. When it finishes, open the file (from the notification or your Downloads).\n3. If asked, allow \"Install unknown apps\" for your browser.\n4. Tap Update. All your progress stays."

    fun download(c: Context) {
        try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(LATEST_APK)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    /** The "how to update" pop-up with a Download button. */
    fun showDialog(a: Activity) {
        val title = if (Lang.isHebrew(a)) "גרסה ${latestKnown(a)} זמינה" else "Build ${latestKnown(a)} is available"
        AlertDialog.Builder(a).setTitle("⬇️ " + title).setMessage(steps(a))
            .setPositiveButton(Lang.t(a, "Download")) { _, _ -> download(a) }
            .setNeutralButton(Lang.t(a, "What's new")) { _, _ -> a.startActivity(Intent(a, UpdatesActivity::class.java)) }
            .setNegativeButton(Lang.t(a, "Later"), null).show()
    }

    // ----- daily background check -----
    private fun pending(c: Context): PendingIntent {
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(c, REQ, Intent(c, UpdateReceiver::class.java), flags)
    }

    fun schedule(c: Context) {
        if (!enabled(c)) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + AlarmManager.INTERVAL_HOUR, AlarmManager.INTERVAL_DAY, pending(c))
    }

    fun cancel(c: Context) {
        (c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager)?.cancel(pending(c))
    }

    /** One notification per new build. */
    fun notifyIfNew(c: Context) {
        val latest = latestKnown(c)
        if (!enabled(c) || latest <= Changelog.build(c) || sp(c).getInt("notifiedBuild", 0) >= latest) return
        sp(c).edit().putInt("notifiedBuild", latest).apply()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(NotificationChannel(CHANNEL, if (Lang.isHebrew(c)) "עדכונים" else "Updates", NotificationManager.IMPORTANCE_DEFAULT))
        }
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(c, 2, Intent(c, UpdatesActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), flags)
        val he = Lang.isHebrew(c)
        val n = Notification.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(if (he) "עדכון ל‑Comboed זמין" else "Comboed update available")
            .setContentText(if (he) "גרסה $latest מוכנה — הקישו לעדכון" else "Build $latest is ready — tap to update")
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1002, n) } catch (e: Exception) {}
    }
}

/** Daily background check for a newer build. */
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent?) {
        val result = goAsync()
        Thread {
            try {
                val n = UpdateCheck.fetchLatest()
                if (n > 0) {
                    c.getSharedPreferences("combo", Context.MODE_PRIVATE).edit().putInt("latestBuild", n).putLong("updateCheckedAt", System.currentTimeMillis()).apply()
                    UpdateCheck.notifyIfNew(c)
                }
            } finally { result.finish() }
        }.start()
    }
}
