package com.combochecker

/** Skins and abilities sold in the Shop. Ids are stored in the saved "state" JSON. */
object ShopCatalog {
    data class Skin(val id: String, val name: String, val cost: Int, val extra: String = "")

    val stars = listOf(
        Skin("star_default", "Classic", 0),
        Skin("star_fire", "Fire", 80),
        Skin("star_diamond", "Ice", 120),
        Skin("star_rocket", "Night", 120),
        Skin("star_crown", "Gold", 150),
        Skin("star_rainbow", "Rainbow", 200)
    )
    val starColor = mapOf(
        "star_default" to "#D62F9B", "star_fire" to "#E8491D", "star_diamond" to "#19A7E8",
        "star_rocket" to "#6A2FE8", "star_crown" to "#E8B500", "star_rainbow" to "#E82FA7"
    )
    val circles = listOf(
        Skin("circle_default", "Pink", 0), Skin("circle_cyan", "Cyan", 60),
        Skin("circle_green", "Green", 60), Skin("circle_red", "Red", 60),
        Skin("circle_gold", "Gold", 80), Skin("circle_purple", "Purple", 80)
    )
    val confetti = listOf(
        Skin("confetti_default", "Party", 0), Skin("confetti_fire", "Fire", 100),
        Skin("confetti_ice", "Ice", 100), Skin("confetti_gold", "Gold", 120),
        Skin("confetti_neon", "Neon", 120)
    )
    val banners = listOf(
        Skin("banner_default", "Pink Glow", 0), Skin("banner_gold", "Gold", 100),
        Skin("banner_cyan", "Cyan", 100), Skin("banner_fire", "Fire", 120),
        Skin("banner_rainbow", "Rainbow", 150)
    )
    val sounds = listOf(
        Skin("sound_default", "Classic bells", 0, "🔔"),
        Skin("sound_arcade", "Arcade 8-bit", 80, "🕹️"),
        Skin("sound_marimba", "Soft marimba", 80, "🎵"),
        Skin("sound_crystal", "Crystal sparkle", 120, "💎"),
        Skin("sound_robot", "Robot", 120, "🤖")
    )

    const val DOUBLE_POINTS_COST = 100
    const val COIN_DOUBLER_COST = 80
    const val HINT_COST = 50
    const val RETRY_COST = 60
}
