package com.combochecker

/** The skins and the one ability sold in the Shop. Ids are stored in the saved "state" JSON. */
object ShopCatalog {
    data class Skin(val id: String, val name: String, val cost: Int, val extra: String = "")

    // Floating-star skins: extra = emoji, colour from starColor.
    val stars = listOf(
        Skin("star_default", "Classic Star", 0, "\u2B50"),
        Skin("star_fire", "Fire", 80, "\uD83D\uDD25"),
        Skin("star_diamond", "Diamond", 120, "\uD83D\uDC8E"),
        Skin("star_rocket", "Rocket", 120, "\uD83D\uDE80"),
        Skin("star_crown", "Crown", 150, "\uD83D\uDC51"),
        Skin("star_rainbow", "Rainbow", 200, "\uD83C\uDF08")
    )
    val starColor = mapOf(
        "star_default" to "#D62F9B", "star_fire" to "#E8491D", "star_diamond" to "#19A7E8",
        "star_rocket" to "#6A2FE8", "star_crown" to "#E8B500", "star_rainbow" to "#E82FA7"
    )

    val circles = listOf(
        Skin("circle_default", "Pink", 0),
        Skin("circle_cyan", "Cyan", 60),
        Skin("circle_green", "Green", 60),
        Skin("circle_red", "Red", 60),
        Skin("circle_gold", "Gold", 80),
        Skin("circle_purple", "Purple", 80)
    )

    val confetti = listOf(
        Skin("confetti_default", "Party", 0),
        Skin("confetti_fire", "Fire", 100),
        Skin("confetti_ice", "Ice", 100),
        Skin("confetti_gold", "Gold", 120),
        Skin("confetti_neon", "Neon", 120)
    )

    val banners = listOf(
        Skin("banner_default", "Pink Glow", 0),
        Skin("banner_gold", "Gold", 100),
        Skin("banner_cyan", "Cyan", 100),
        Skin("banner_fire", "Fire", 120),
        Skin("banner_rainbow", "Rainbow", 150)
    )

    const val DOUBLE_POINTS_COST = 100
}
