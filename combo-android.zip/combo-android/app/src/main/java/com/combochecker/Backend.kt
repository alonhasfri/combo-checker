package com.combochecker

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions

/**
 * Tiny Firebase backend (free Spark plan). On first launch the app signs in anonymously and records
 * one "install" document; the global user counter is just the number of those documents, read with a
 * cheap server-side aggregate count. No personal data is collected — only an anonymous id and a
 * timestamp. Everything else about the app stays on the phone.
 */
object Backend {
    private var started = false

    /** Sign in anonymously (once) and record this install. Safe to call on every screen. */
    fun init(c: Context) {
        if (started) return
        started = true
        try {
            val auth = FirebaseAuth.getInstance()
            val uid = auth.currentUser?.uid
            if (uid != null) registerInstall(uid)
            else auth.signInAnonymously().addOnSuccessListener { registerInstall(it.user?.uid) }
        } catch (e: Exception) {
            // Offline or misconfigured: the app works fine without the backend.
        }
    }

    private fun registerInstall(uid: String?) {
        if (uid.isNullOrEmpty()) return
        try {
            FirebaseFirestore.getInstance()
                .collection("installs").document(uid)
                .set(mapOf("ts" to FieldValue.serverTimestamp()), SetOptions.merge())
        } catch (e: Exception) {
        }
    }

    /** Fetch the total number of installs. Calls back (on the main thread) only on success. */
    fun fetchUserCount(onResult: (Int) -> Unit) {
        try {
            FirebaseFirestore.getInstance().collection("installs")
                .count().get(AggregateSource.SERVER)
                .addOnSuccessListener { snap -> onResult(snap.count.toInt()) }
        } catch (e: Exception) {
        }
    }
}
