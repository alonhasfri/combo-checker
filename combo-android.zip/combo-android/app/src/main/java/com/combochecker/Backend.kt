package com.combochecker

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

/**
 * Tiny Firebase backend (free Spark plan). The app signs in anonymously, records one "install"
 * document per device (written once), and publishes the device's best profile to a global
 * leaderboard. Only anonymous data is stored (an anon id, a display name/emoji, points, a
 * timestamp). Everything else about the app stays on the phone.
 */
object Backend {
    private fun db() = FirebaseFirestore.getInstance()
    private fun auth() = FirebaseAuth.getInstance()

    /** Run [block] with a signed-in anonymous uid (signing in first if needed). */
    private fun withUid(block: (String) -> Unit) {
        try {
            val u = auth().currentUser
            if (u != null) { block(u.uid); return }
            auth().signInAnonymously().addOnSuccessListener { it.user?.uid?.let(block) }
        } catch (e: Exception) {
        }
    }

    /** Ensure this device is signed in and recorded (write only once per install). */
    fun init(c: Context) {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        if (sp.getBoolean("fbRegistered", false)) { withUid { } ; return }
        withUid { uid ->
            db().collection("installs").document(uid)
                .set(mapOf("ts" to FieldValue.serverTimestamp()), SetOptions.merge())
                .addOnSuccessListener { sp.edit().putBoolean("fbRegistered", true).apply() }
        }
    }

    /** Make sure the device is recorded, THEN read the global install count (so the first open is
     *  right, not a race). Calls [onResult] on the main thread on success. */
    fun registerThenCount(c: Context, onResult: (Int) -> Unit) {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        withUid { uid ->
            if (sp.getBoolean("fbRegistered", false)) { fetchUserCount(onResult); return@withUid }
            db().collection("installs").document(uid)
                .set(mapOf("ts" to FieldValue.serverTimestamp()), SetOptions.merge())
                .addOnSuccessListener { sp.edit().putBoolean("fbRegistered", true).apply(); fetchUserCount(onResult) }
                .addOnFailureListener { fetchUserCount(onResult) }
        }
    }

    /** Total number of installs (cheap server-side aggregate count). */
    fun fetchUserCount(onResult: (Int) -> Unit) {
        try {
            db().collection("installs").count().get(AggregateSource.SERVER)
                .addOnSuccessListener { snap -> onResult(snap.count.toInt()) }
        } catch (e: Exception) {
        }
    }

    /** Publish this device's best entry to the global leaderboard (one row per device). */
    fun publishLeaderboard(name: String, emoji: String, total: Int, level: Int) {
        withUid { uid ->
            db().collection("leaderboard").document(uid)
                .set(
                    mapOf(
                        "name" to name,
                        "emoji" to emoji,
                        "total" to total,
                        "level" to level,
                        "ts" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
        }
    }

    // ----- cloud backup transfer codes (move data between phones, no login needed) -----
    private fun genCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no ambiguous chars
        val sb = StringBuilder("CMB-")
        repeat(6) { sb.append(alphabet[(Math.random() * alphabet.length).toInt()]) }
        return sb.toString()
    }

    /** Upload a backup JSON string; calls back with the transfer code (or null on failure). */
    fun cloudBackup(json: String, onResult: (String?) -> Unit) {
        withUid {
            val code = genCode()
            db().collection("backups").document(code)
                .set(mapOf("data" to json, "ts" to FieldValue.serverTimestamp()))
                .addOnSuccessListener { onResult(code) }
                .addOnFailureListener { onResult(null) }
        }
    }

    /** Download a backup by its transfer code; calls back with the JSON string (or null). */
    fun cloudRestore(code: String, onResult: (String?) -> Unit) {
        withUid {
            db().collection("backups").document(code.trim().uppercase())
                .get()
                .addOnSuccessListener { onResult(if (it.exists()) it.getString("data") else null) }
                .addOnFailureListener { onResult(null) }
        }
    }

    data class LbRow(val name: String, val emoji: String, val total: Int, val level: Int)

    /** Read the global top players by points. Calls [onResult] on success. */
    fun fetchLeaderboard(limit: Long, onResult: (List<LbRow>) -> Unit) {
        try {
            db().collection("leaderboard")
                .orderBy("total", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .addOnSuccessListener { qs ->
                    val rows = qs.documents.map {
                        LbRow(
                            it.getString("name") ?: "Player",
                            it.getString("emoji") ?: "⭐",
                            (it.getLong("total") ?: 0L).toInt(),
                            (it.getLong("level") ?: 1L).toInt()
                        )
                    }
                    onResult(rows)
                }
        } catch (e: Exception) {
        }
    }
}
