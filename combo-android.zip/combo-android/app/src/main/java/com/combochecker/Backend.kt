package com.combochecker

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.AggregateSource
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

/**
 * Tiny Firebase backend (free Spark plan). The app signs in anonymously, records one "install"
 * document per device (written once), and publishes the device's best profile to a global
 * leaderboard. Only anonymous data is stored (an anon id, a display name/emoji, points, a
 * timestamp). Everything else about the app stays on the phone.
 */
object Backend {
    private fun db() = FirebaseFirestore.getInstance()
    private fun auth() = FirebaseAuth.getInstance()

    /** Run [block] with a signed-in anonymous uid (signing in first if needed). */
    private fun withUid(block: (String) -> Unit) {
        try {
            val u = auth().currentUser
            if (u != null) { block(u.uid); return }
            auth().signInAnonymously().addOnSuccessListener { it.user?.uid?.let(block) }
        } catch (e: Exception) {
        }
    }

    /** Ensure this device is signed in and recorded (write only once per install). */
    fun init(c: Context) {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        if (sp.getBoolean("fbRegistered", false)) { withUid { } ; return }
        withUid { uid ->
            db().collection("installs").document(uid)
                .set(mapOf("ts" to FieldValue.serverTimestamp()), SetOptions.merge())
                .addOnSuccessListener { sp.edit().putBoolean("fbRegistered", true).apply() }
        }
    }

    /** Make sure the device is recorded, THEN read the global install count (so the first open is
     *  right, not a race). Calls [onResult] on the main thread on success. */
    fun registerThenCount(c: Context, onResult: (Int) -> Unit) {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        withUid { uid ->
            if (sp.getBoolean("fbRegistered", false)) { fetchUserCount(onResult); return@withUid }
            db().collection("installs").document(uid)
                .set(mapOf("ts" to FieldValue.serverTimestamp()), SetOptions.merge())
                .addOnSuccessListener { sp.edit().putBoolean("fbRegistered", true).apply(); fetchUserCount(onResult) }
                .addOnFailureListener { fetchUserCount(onResult) }
        }
    }

    /** Total number of installs (cheap server-side aggregate count). */
    fun fetchUserCount(onResult: (Int) -> Unit) {
        try {
            db().collection("installs").count().get(AggregateSource.SERVER)
                .addOnSuccessListener { snap -> onResult(snap.count.toInt()) }
        } catch (e: Exception) {
        }
    }

    /** Publish this device's best entry to the global leaderboard (one row per device). */
    fun publishLeaderboard(name: String, emoji: String, total: Int, level: Int) {
        withUid { uid ->
            db().collection("leaderboard").document(uid)
                .set(
                    mapOf(
                        "name" to name,
                        "emoji" to emoji,
                        "total" to total,
                        "level" to level,
                        "ts" to FieldValue.serverTimestamp()
                    ),
                    SetOptions.merge()
                )
        }
    }

    /** Save this device's best-ever global placement (1..3) on its leaderboard row. */
    fun setBestTop(n: Int) {
        withUid { uid -> db().collection("leaderboard").document(uid).set(mapOf("bestTop" to n), SetOptions.merge()) }
    }

    // ----- cloud backup transfer codes (move data between phones, no login needed) -----
    private fun genCode(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no ambiguous chars
        val sb = StringBuilder("CMB-")
        repeat(6) { sb.append(alphabet[(Math.random() * alphabet.length).toInt()]) }
        return sb.toString()
    }

    /** Upload a backup JSON string; calls back with the transfer code (or null on failure). */
    fun cloudBackup(json: String, onResult: (String?) -> Unit) {
        withUid {
            val code = genCode()
            db().collection("backups").document(code)
                .set(mapOf("data" to json, "ts" to FieldValue.serverTimestamp()))
                .addOnSuccessListener { onResult(code) }
                .addOnFailureListener { onResult(null) }
        }
    }

    /** Download a backup by its transfer code; calls back with the JSON string (or null). */
    fun cloudRestore(code: String, onResult: (String?) -> Unit) {
        withUid {
            db().collection("backups").document(code.trim().uppercase())
                .get()
                .addOnSuccessListener { onResult(if (it.exists()) it.getString("data") else null) }
                .addOnFailureListener { onResult(null) }
        }
    }

    data class LbRow(val name: String, val emoji: String, val total: Int, val level: Int, val uid: String = "", val bestTop: Int = 0)

    /** Read the global top players by points. Calls [onResult] on success. */
    fun fetchLeaderboard(limit: Long, onResult: (List<LbRow>) -> Unit) {
        try {
            db().collection("leaderboard")
                .orderBy("total", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .addOnSuccessListener { qs ->
                    val rows = qs.documents.map {
                        LbRow(
                            it.getString("name") ?: "Player",
                            it.getString("emoji") ?: "⭐",
                            (it.getLong("total") ?: 0L).toInt(),
                            (it.getLong("level") ?: 1L).toInt(),
                            it.id,
                            (it.getLong("bestTop") ?: 0L).toInt()
                        )
                    }
                    onResult(rows)
                }
        } catch (e: Exception) {
        }
    }
    // =====================================================================
    // Groups (class / family / friends), world stats, news, friend codes.
    // Everything is pulled when the app opens (no paid push needed).
    // =====================================================================
    fun uidNow(): String? = try { auth().currentUser?.uid } catch (e: Exception) { null }
    fun ensureUid(cb: (String) -> Unit) = withUid(cb)

    private fun code6(prefix: String): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val sb = StringBuilder(prefix)
        repeat(6) { sb.append(alphabet[(Math.random() * alphabet.length).toInt()]) }
        return sb.toString()
    }

    private fun group(code: String) = db().collection("groups").document(code.trim().uppercase())

    /** Create a group owned by this device. type = "class" | "family" | "friends". */
    fun createGroup(name: String, type: String, onResult: (String?) -> Unit) {
        withUid { uid ->
            val code = code6(when (type) { "class" -> "CLS-"; "family" -> "FAM-"; else -> "FRN-" })
            group(code).set(mapOf(
                "name" to name, "type" to type, "owner" to uid,
                "approvals" to (type == "family"), "news" to "", "goalTitle" to "", "goalTarget" to 0,
                "ts" to FieldValue.serverTimestamp()
            )).addOnSuccessListener { onResult(code) }.addOnFailureListener { onResult(null) }
        }
    }

    /** Read a group's settings (null if it doesn't exist / no connection). */
    fun groupInfo(code: String, onResult: (Map<String, Any?>?) -> Unit) {
        withUid {
            group(code).get()
                .addOnSuccessListener { onResult(if (it.exists()) it.data else null) }
                .addOnFailureListener { onResult(null) }
        }
    }

    fun updateGroup(code: String, fields: Map<String, Any?>, onDone: (Boolean) -> Unit = {}) {
        withUid { group(code).set(fields, SetOptions.merge()).addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) } }
    }

    /** Write/refresh this profile's row in a group (doc id = uid_profileId). */
    fun pushMember(code: String, profileId: String, fields: Map<String, Any?>, onDone: (Boolean) -> Unit = {}) {
        withUid { uid ->
            val data = HashMap(fields); data["uid"] = uid; data["pid"] = profileId; data["seen"] = FieldValue.serverTimestamp()
            group(code).collection("members").document(uid + "_" + profileId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
        }
    }

    fun removeMember(code: String, memberId: String, onDone: (Boolean) -> Unit = {}) {
        withUid { group(code).collection("members").document(memberId).delete().addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) } }
    }

    data class Doc(val id: String, val data: Map<String, Any?>)

    fun listMembers(code: String, onResult: (List<Doc>?) -> Unit) {
        withUid {
            group(code).collection("members").get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }) }
                .addOnFailureListener { onResult(null) }
        }
    }

    /** Post to a group's feed (wins, high-fives). */
    fun postFeed(code: String, fields: Map<String, Any?>) {
        withUid { uid ->
            val data = HashMap(fields); data["fromUid"] = uid; data["ts"] = System.currentTimeMillis()
            group(code).collection("feed").add(data)
        }
    }

    fun listFeed(code: String, limit: Long, onResult: (List<Doc>?) -> Unit) {
        withUid {
            group(code).collection("feed").orderBy("ts", Query.Direction.DESCENDING).limit(limit).get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }) }
                .addOnFailureListener { onResult(null) }
        }
    }

    // --- remote approvals ---
    fun createPending(code: String, fields: Map<String, Any?>, onResult: (String?) -> Unit) {
        withUid { uid ->
            val data = HashMap(fields); data["uid"] = uid; data["status"] = "pending"; data["ts"] = System.currentTimeMillis()
            group(code).collection("pending").add(data)
                .addOnSuccessListener { onResult(it.id) }.addOnFailureListener { onResult(null) }
        }
    }

    fun listPending(code: String, onResult: (List<Doc>?) -> Unit) {
        withUid {
            group(code).collection("pending").whereEqualTo("status", "pending").get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }.sortedBy { (it.data["ts"] as? Long) ?: 0L }) }
                .addOnFailureListener { onResult(null) }
        }
    }

    fun pendingStatus(code: String, id: String, onResult: (String?) -> Unit) {
        withUid {
            group(code).collection("pending").document(id).get()
                .addOnSuccessListener { onResult(if (it.exists()) it.getString("status") else "gone") }
                .addOnFailureListener { onResult(null) }
        }
    }

    fun setPendingStatus(code: String, id: String, status: String, onDone: (Boolean) -> Unit = {}) {
        withUid {
            group(code).collection("pending").document(id).update("status", status)
                .addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
        }
    }

    // --- world stats + community challenge ---
    fun weekKey(): String {
        val c = java.util.Calendar.getInstance()
        return "" + c.get(java.util.Calendar.YEAR) + "w" + c.get(java.util.Calendar.WEEK_OF_YEAR)
    }

    fun bumpWorldTask() {
        withUid {
            val inc = mapOf("tasks" to FieldValue.increment(1))
            db().collection("stats").document("day_" + Progress.todayKey()).set(inc, SetOptions.merge())
            db().collection("stats").document("week_" + weekKey()).set(inc, SetOptions.merge())
        }
    }

    /** Tasks finished worldwide today and this week. */
    fun fetchWorld(onResult: (Int, Int) -> Unit) {
        withUid {
            db().collection("stats").document("day_" + Progress.todayKey()).get().addOnSuccessListener { d ->
                val day = (d.getLong("tasks") ?: 0L).toInt()
                db().collection("stats").document("week_" + weekKey()).get().addOnSuccessListener { w ->
                    onResult(day, (w.getLong("tasks") ?: 0L).toInt())
                }
            }
        }
    }

    /** Developer news: a doc news/current {id, text} you can edit in the Firebase console. */
    fun fetchNews(onResult: (String, String) -> Unit) {
        withUid {
            db().collection("news").document("current").get().addOnSuccessListener { d ->
                val text = d.getString("text") ?: ""
                if (text.isNotBlank()) onResult(d.getString("id") ?: text.hashCode().toString(), text)
            }
        }
    }

    // --- friend codes + prank inbox ---
    /** This install's friend code (created once). */
    fun friendCode(c: Context, onResult: (String) -> Unit) {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val have = sp.getString("friendCode", "") ?: ""
        withUid { uid ->
            if (have.isNotEmpty() && sp.getBoolean("friendCodeSaved", false)) { onResult(have); return@withUid }
            val code = have.ifEmpty { code6("") }
            sp.edit().putString("friendCode", code).apply()
            db().collection("friends").document(code).set(mapOf("uid" to uid))
                .addOnSuccessListener { sp.edit().putBoolean("friendCodeSaved", true).apply(); onResult(code) }
        }
    }

    fun sendToInbox(friendCode: String, key: String, onDone: (Boolean) -> Unit) {
        withUid {
            val code = friendCode.trim().uppercase()
            db().collection("friends").document(code).get().addOnSuccessListener { d ->
                if (!d.exists()) { onDone(false); return@addOnSuccessListener }
                db().collection("inbox").document(code).collection("items")
                    .add(mapOf("key" to key, "ts" to System.currentTimeMillis()))
                    .addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
            }.addOnFailureListener { onDone(false) }
        }
    }

    /** Take (and delete) everything waiting in this device's inbox. */
    fun takeInbox(code: String, onResult: (List<String>) -> Unit) {
        withUid {
            val col = db().collection("inbox").document(code).collection("items")
            col.get().addOnSuccessListener { qs ->
                val keys = qs.documents.mapNotNull { it.getString("key") }
                for (d in qs.documents) d.reference.delete()
                if (keys.isNotEmpty()) onResult(keys)
            }
        }
    }

    // --- daily automatic backup (same code every day, overwritten) ---
    fun autoBackup(code: String, json: String, onDone: (Boolean) -> Unit) {
        withUid { uid ->
            db().collection("backups").document(code)
                .set(mapOf("data" to json, "uid" to uid, "ts" to FieldValue.serverTimestamp()))
                .addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
        }
    }

    fun newBackupCode() = genCode()
    // =====================================================================
    // Task board (claimable tasks in a group) and partner offers.
    // =====================================================================
    fun tasksCol(code: String) = group(code).collection("tasks")

    fun listTasks(code: String, onResult: (List<Doc>?) -> Unit) {
        withUid {
            tasksCol(code).get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }) }
                .addOnFailureListener { onResult(null) }
        }
    }

    fun postTask(code: String, title: String, coins: Int, hours: Int, onDone: (Boolean) -> Unit) {
        withUid {
            tasksCol(code).add(mapOf("title" to title, "coins" to coins, "hours" to hours, "state" to "open",
                "by" to "", "byName" to "", "until" to 0L, "thumb" to null, "paid" to false, "ts" to System.currentTimeMillis()))
                .addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
        }
    }

    /** Claim a task atomically: only if it's open, or the previous claim ran out of time. */
    fun claimTask(code: String, id: String, mid: String, name: String, onResult: (String) -> Unit) {
        withUid {
            val ref = tasksCol(code).document(id)
            db().runTransaction { tx ->
                val d = tx.get(ref)
                val state = d.getString("state") ?: "open"
                val until = d.getLong("until") ?: 0L
                val free = state == "open" || (state == "claimed" && until < System.currentTimeMillis())
                if (!free) return@runTransaction (d.getString("byName") ?: "")
                val hours = (d.getLong("hours") ?: 24L)
                tx.update(ref, mapOf("state" to "claimed", "by" to mid, "byName" to name,
                    "until" to System.currentTimeMillis() + hours * 3600 * 1000))
                "OK"
            }.addOnSuccessListener { onResult(it) }.addOnFailureListener { onResult("ERR") }
        }
    }

    fun updateTask(code: String, id: String, fields: Map<String, Any?>, onDone: (Boolean) -> Unit = {}) {
        withUid { tasksCol(code).document(id).update(fields).addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) } }
    }

    fun deleteTask(code: String, id: String, onDone: (Boolean) -> Unit = {}) {
        withUid { tasksCol(code).document(id).delete().addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) } }
    }

    /** Approved tasks of mine that haven't been paid into my coins yet. */
    fun myApprovedTasks(code: String, mid: String, onResult: (List<Doc>) -> Unit) {
        withUid {
            tasksCol(code).whereEqualTo("by", mid).whereEqualTo("state", "approved").get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }) }
        }
    }

    // --- partner offers (managed by admins) ---
    fun listPartners(onResult: (List<Doc>?) -> Unit) {
        withUid {
            db().collection("partners").get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }) }
                .addOnFailureListener { onResult(null) }
        }
    }

    fun savePartner(id: String?, fields: Map<String, Any?>, onDone: (Boolean) -> Unit) {
        withUid {
            val col = db().collection("partners")
            val t = if (id == null) col.add(fields).continueWith { } else col.document(id).set(fields, SetOptions.merge()).continueWith { }
            t.addOnSuccessListener { onDone(true) }.addOnFailureListener { onDone(false) }
        }
    }

    fun isAdmin(onResult: (Boolean) -> Unit) {
        withUid { uid ->
            db().collection("admins").document(uid).get()
                .addOnSuccessListener { onResult(it.exists()) }.addOnFailureListener { onResult(false) }
        }
    }

    /** Record a redemption with its coupon code (so it can be verified later). */
    fun redeem(fields: Map<String, Any?>, onResult: (String?) -> Unit) {
        withUid { uid ->
            val code = code6("CP-")
            val data = HashMap(fields); data["uid"] = uid; data["code"] = code; data["ts"] = System.currentTimeMillis(); data["used"] = false
            db().collection("redemptions").document(code).set(data)
                .addOnSuccessListener { onResult(code) }.addOnFailureListener { onResult(null) }
        }
    }

    fun listRedemptions(onResult: (List<Doc>?) -> Unit) {
        withUid {
            db().collection("redemptions").orderBy("ts", Query.Direction.DESCENDING).limit(100).get()
                .addOnSuccessListener { qs -> onResult(qs.documents.map { Doc(it.id, it.data ?: emptyMap()) }) }
                .addOnFailureListener { onResult(null) }
        }
    }
}
