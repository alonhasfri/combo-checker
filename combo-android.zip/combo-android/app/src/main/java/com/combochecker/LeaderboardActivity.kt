package com.combochecker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Ranking: family (this week / all-time) and a worldwide global board from the backend. */
class LeaderboardActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private var mode = "week" // "week" | "all" | "global"
    private var pad = 0
    private lateinit var root: LinearLayout

    private val ranks = listOf(
        "Rookie", "Apprentice", "Doer", "Achiever", "Pro",
        "Expert", "Master", "Champion", "Legend", "Mythic"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private data class Row(val name: String, val emoji: String, val color: String, val week: Int, val total: Int, val level: Int)

    private fun render() {
        root.removeAllViews()
        val isHe = Lang.isHebrew(this)
        root.addView(TextView(this).apply {
            text = Lang.t(this@LeaderboardActivity, "🏆 Leaderboard"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })

        // Toggle: this week · all time · global
        val toggle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, pad / 2, 0, pad / 2) }
        fun tab(label: String, value: String) = Button(this).apply {
            text = Lang.t(this@LeaderboardActivity, label); isEnabled = mode != value
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { mode = value; render() }
        }
        toggle.addView(tab("This week", "week"))
        toggle.addView(tab("All time", "all"))
        toggle.addView(tab("🌍 Global", "global"))
        root.addView(toggle)

        if (mode == "global") renderGlobal(isHe) else renderLocal(isHe)

        root.addView(Button(this).apply { text = Lang.t(this@LeaderboardActivity, "Done"); setOnClickListener { finish() } })
    }

    private fun card(rankLabel: String, emoji: String, color: String, title: String, value: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        c.addView(TextView(this).apply {
            text = rankLabel; textSize = 22f; width = (46 * resources.displayMetrics.density).toInt()
        })
        val sz = (42 * resources.displayMetrics.density).toInt()
        c.addView(TextView(this).apply {
            text = emoji; textSize = 20f; gravity = Gravity.CENTER
            width = sz; height = sz
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(color)) }
        })
        c.addView(TextView(this).apply {
            text = title
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        c.addView(TextView(this).apply {
            text = value; textSize = 16f; gravity = Gravity.END; setTypeface(typeface, Typeface.BOLD)
        })
        return c
    }

    private fun rankName(level: Int) = Lang.t(this, ranks[minOf(level, ranks.size) - 1])
    private val medals = listOf("🥇", "🥈", "🥉")

    private fun renderLocal(isHe: Boolean) {
        val byWeek = mode == "week"
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val profiles = Profiles.list(this)
        val rows = ArrayList<Row>()
        for (i in 0 until profiles.length()) {
            val p = profiles.getJSONObject(i)
            val id = p.optString("id")
            val st = try { JSONObject(sp().getString("state__$id", "") ?: "") } catch (e: Exception) { JSONObject() }
            val total = st.optInt("total", 0)
            val level = Math.floor(Math.sqrt(total / 25.0)).toInt() + 1
            val gallery = try { JSONArray(sp().getString("gallery__$id", "[]")) } catch (e: Exception) { JSONArray() }
            var week = 0
            for (j in 0 until gallery.length()) if (gallery.getJSONObject(j).optLong("time") >= weekAgo) week++
            rows.add(Row(p.optString("name"), p.optString("emoji", "⭐"), p.optString("color", "#3a66d6"), week, total, level))
        }
        rows.sortByDescending { if (byWeek) it.week else it.total }
        rows.forEachIndexed { idx, r ->
            val title = "  " + r.name + "\n  " + (if (isHe) "רמה " else "Lv ") + r.level + " · " + rankName(r.level)
            val value = if (byWeek) (r.week.toString() + "\n" + (if (isHe) "משימות" else "tasks"))
                        else (r.total.toString() + "\n" + (if (isHe) "נק'" else "pts"))
            root.addView(card(if (idx < 3) medals[idx] else "#${idx + 1}", r.emoji, r.color, title, value))
        }
        root.addView(TextView(this).apply {
            text = Lang.t(this@LeaderboardActivity, if (byWeek) "Tasks finished in the last 7 days." else "Total points earned, all time.")
            textSize = 13f; setPadding(0, pad / 2, 0, 0)
        })
    }

    private fun renderGlobal(isHe: Boolean) {
        val loading = TextView(this).apply {
            text = Lang.t(this@LeaderboardActivity, "🌍 Loading players worldwide…"); textSize = 14f; setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(loading)
        Backend.fetchLeaderboard(50) { rows ->
            if (mode != "global") return@fetchLeaderboard // user switched tabs
            loading.text = if (rows.isEmpty())
                Lang.t(this@LeaderboardActivity, "No players yet — be the first! Finish a task to join the global board.")
            else Lang.t(this@LeaderboardActivity, "Top players worldwide, by points.")
            rows.forEachIndexed { idx, r ->
                val title = "  " + r.name + "\n  " + (if (isHe) "רמה " else "Lv ") + r.level + " · " + rankName(r.level)
                val value = r.total.toString() + "\n" + (if (isHe) "נק'" else "pts")
                // insert each card just above the Done button (which is the last child)
                root.addView(card(if (idx < 3) medals[idx] else "#${idx + 1}", r.emoji, "#3a66d6", title, value), root.childCount - 1)
            }
        }
    }
}
