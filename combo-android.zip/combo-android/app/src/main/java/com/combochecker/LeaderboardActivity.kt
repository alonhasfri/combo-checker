package com.combochecker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Friendly family ranking across all profiles — this week and all-time. */
class LeaderboardActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private var byWeek = true
    private var pad = 0
    private lateinit var root: LinearLayout

    private val ranks = listOf(
        "Rookie", "Apprentice", "Doer", "Achiever", "Pro",
        "Expert", "Master", "Champion", "Legend", "Mythic"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private data class Row(val name: String, val emoji: String, val color: String, val week: Int, val total: Int, val level: Int)

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "🏆 Leaderboard"; textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })

        // Toggle: this week vs all-time
        val toggle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, pad / 2, 0, pad / 2) }
        toggle.addView(Button(this).apply {
            text = "This week"; isEnabled = !byWeek
            setOnClickListener { byWeek = true; render() }
        })
        toggle.addView(Button(this).apply {
            text = "All time"; isEnabled = byWeek
            setOnClickListener { byWeek = false; render() }
        })
        root.addView(toggle)

        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val profiles = Profiles.list(this)
        val rows = ArrayList<Row>()
        for (i in 0 until profiles.length()) {
            val p = profiles.getJSONObject(i)
            val id = p.optString("id")
            val st = try { JSONObject(sp().getString("state__$id", "") ?: "") } catch (e: Exception) { JSONObject() }
            val total = st.optInt("total", 0)
            val level = Math.floor(Math.sqrt(total / 25.0)).toInt() + 1
            val gallery = try { JSONArray(sp().getString("gallery__$id", "[]")) } catch (e: Exception) { JSONArray() }
            var week = 0
            for (j in 0 until gallery.length()) if (gallery.getJSONObject(j).optLong("time") >= weekAgo) week++
            rows.add(Row(p.optString("name"), p.optString("emoji", "⭐"), p.optString("color", "#3a66d6"), week, total, level))
        }
        rows.sortByDescending { if (byWeek) it.week else it.total }

        val medals = listOf("🥇", "🥈", "🥉")
        rows.forEachIndexed { idx, r ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
            }
            card.addView(TextView(this).apply {
                text = if (idx < 3) medals[idx] else "#${idx + 1}"
                textSize = 22f; width = (46 * resources.displayMetrics.density).toInt()
            })
            val sz = (42 * resources.displayMetrics.density).toInt()
            card.addView(TextView(this).apply {
                text = r.emoji; textSize = 20f; gravity = Gravity.CENTER
                width = sz; height = sz
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(r.color)) }
            })
            card.addView(TextView(this).apply {
                text = "  " + r.name + "\n  Lv " + r.level + " · " + ranks[minOf(r.level, ranks.size) - 1]
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            card.addView(TextView(this).apply {
                text = if (byWeek) (r.week.toString() + "\ntasks") else (r.total.toString() + "\npts")
                textSize = 16f; gravity = Gravity.END; setTypeface(typeface, Typeface.BOLD)
            })
            root.addView(card)
        }

        root.addView(TextView(this).apply {
            text = if (byWeek) "Tasks finished in the last 7 days." else "Total points earned, all time."
            textSize = 13f; setPadding(0, pad / 2, 0, 0)
        })
        root.addView(Button(this).apply { text = "Done"; setOnClickListener { finish() } })
    }
}
