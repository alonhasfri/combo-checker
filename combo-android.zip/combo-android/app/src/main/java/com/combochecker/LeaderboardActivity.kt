package com.combochecker

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Ranking: family (this week / all-time) and a worldwide global board from the backend. */
class LeaderboardActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private var mode = "week" // "week" | "all" | "global"
    private var pad = 0
    private lateinit var root: LinearLayout

    private val ranks = listOf(
        "Rookie", "Apprentice", "Doer", "Achiever", "Pro",
        "Expert", "Master", "Champion", "Legend", "Mythic"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        modern = !sp().getBoolean("classicMenu", false)
        if (!modern) setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private var modern = false

    private data class Row(val name: String, val emoji: String, val color: String, val week: Int, val total: Int, val level: Int)

    private fun render() {
        if (modern) { renderModern(); return }
        root.removeAllViews()
        val isHe = Lang.isHebrew(this)
        root.addView(TextView(this).apply {
            text = Lang.t(this@LeaderboardActivity, "🏆 Leaderboard"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })

        // Toggle: this week · all time · global
        val toggle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, pad / 2, 0, pad / 2) }
        fun tab(label: String, value: String) = Button(this).apply {
            text = Lang.t(this@LeaderboardActivity, label); isEnabled = mode != value
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnClickListener { mode = value; render() }
        }
        toggle.addView(tab("This week", "week"))
        toggle.addView(tab("All time", "all"))
        toggle.addView(tab("🌍 Global", "global"))
        root.addView(toggle)

        if (mode == "global") renderGlobal(isHe) else renderLocal(isHe)

        root.addView(Button(this).apply { text = Lang.t(this@LeaderboardActivity, "Done"); setOnClickListener { finish() } })
    }

    private fun card(rankLabel: String, emoji: String, color: String, title: String, value: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        c.addView(TextView(this).apply {
            text = rankLabel; textSize = 22f; width = (46 * resources.displayMetrics.density).toInt()
        })
        val sz = (42 * resources.displayMetrics.density).toInt()
        c.addView(TextView(this).apply {
            text = emoji; textSize = 20f; gravity = Gravity.CENTER
            width = sz; height = sz
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(color)) }
        })
        c.addView(TextView(this).apply {
            text = title
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        c.addView(TextView(this).apply {
            text = value; textSize = 16f; gravity = Gravity.END; setTypeface(typeface, Typeface.BOLD)
        })
        return c
    }

    private fun rankName(level: Int) = Lang.t(this, ranks[minOf(level, ranks.size) - 1])
    private val medals = listOf("🥇", "🥈", "🥉")

    private fun renderLocal(isHe: Boolean) {
        val byWeek = mode == "week"
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val profiles = Profiles.list(this)
        val rows = ArrayList<Row>()
        for (i in 0 until profiles.length()) {
            val p = profiles.getJSONObject(i)
            val id = p.optString("id")
            val st = try { JSONObject(sp().getString("state__$id", "") ?: "") } catch (e: Exception) { JSONObject() }
            val total = st.optInt("total", 0)
            val level = Math.floor(Math.sqrt(total / 25.0)).toInt() + 1
            val gallery = try { JSONArray(sp().getString("gallery__$id", "[]")) } catch (e: Exception) { JSONArray() }
            var week = 0
            for (j in 0 until gallery.length()) if (gallery.getJSONObject(j).optLong("time") >= weekAgo) week++
            rows.add(Row(p.optString("name"), p.optString("emoji", "⭐"), p.optString("color", "#3a66d6"), week, total, level))
        }
        rows.sortByDescending { if (byWeek) it.week else it.total }
        rows.forEachIndexed { idx, r ->
            val title = "  " + r.name + "\n  " + (if (isHe) "רמה " else "Lv ") + r.level + " · " + rankName(r.level)
            val value = if (byWeek) (r.week.toString() + "\n" + (if (isHe) "משימות" else "tasks"))
                        else (r.total.toString() + "\n" + (if (isHe) "נק'" else "pts"))
            root.addView(card(if (idx < 3) medals[idx] else "#${idx + 1}", r.emoji, r.color, title, value))
        }
        root.addView(TextView(this).apply {
            text = Lang.t(this@LeaderboardActivity, if (byWeek) "Tasks finished in the last 7 days." else "Total points earned, all time.")
            textSize = 13f; setPadding(0, pad / 2, 0, 0)
        })
    }

    private fun renderGlobal(isHe: Boolean) {
        val loading = TextView(this).apply {
            text = Lang.t(this@LeaderboardActivity, "🌍 Loading players worldwide…"); textSize = 14f; setPadding(0, pad / 2, 0, pad / 2)
        }
        root.addView(loading)
        Backend.fetchLeaderboard(50) { rows ->
            if (mode != "global") return@fetchLeaderboard // user switched tabs
            loading.text = if (rows.isEmpty())
                Lang.t(this@LeaderboardActivity, "No players yet — be the first! Finish a task to join the global board.")
            else Lang.t(this@LeaderboardActivity, "Top players worldwide, by points.")
            rows.forEachIndexed { idx, r ->
                val title = "  " + r.name + "\n  " + (if (isHe) "רמה " else "Lv ") + r.level + " · " + rankName(r.level)
                val value = r.total.toString() + "\n" + (if (isHe) "נק'" else "pts")
                // insert each card just above the Done button (which is the last child)
                root.addView(card(if (idx < 3) medals[idx] else "#${idx + 1}", r.emoji, "#3a66d6", title, value), root.childCount - 1)
            }
        }
    }

    // ===================== redesigned ranks (new menu) =====================
    private data class Entry(val name: String, val emoji: String, val color: String, val value: Int, val level: Int, val unit: String)
    private fun d(v: Int) = Ui.dp(this, v)
    private fun t(s: String) = Voice.say(this, s)

    private fun renderModern() {
        val p = Ui.pal(this)
        root = Ui.page(this)
        root.addView(Ui.header(this, t("Ranks"), gear = true))
        if (sp().getBoolean("hideLeaderboard", false)) {
            root.addView(Ui.text(this, t("The leaderboard is turned off by a parent."), 15f, p.muted, bold = false).apply { setPaddingRelative(0, d(24), 0, 0) })
            Ui.tabScreen(this, root, "ranks"); return
        }
        val modes = listOf("week", "all", "global")
        root.addView(Ui.segmented(this, listOf(t("This week"), t("All time"), t("Global")), maxOf(0, modes.indexOf(mode))) {
            mode = modes[it]; renderModern()
        }, Ui.lp(this, 14))
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(body, Ui.lp(this, 6))
        val isHe = Lang.isHebrew(this)
        val pts = if (isHe) "נק׳" else "pts"
        if (mode == "global") {
            body.addView(Ui.text(this, t("🌍 Loading players worldwide…"), 14f, p.muted, bold = false).apply { setPaddingRelative(0, d(16), 0, 0) })
            val want = mode
            Backend.fetchLeaderboard(50) { rows ->
                if (mode != want || isFinishing) return@fetchLeaderboard
                body.removeAllViews()
                if (rows.isEmpty()) {
                    body.addView(Ui.text(this, t("No players yet — be the first! Finish a task to join the global board."), 14f, p.muted, bold = false).apply { setPaddingRelative(0, d(16), 0, 0) })
                } else fillBoard(body, rows.map { Entry(it.name, it.emoji, "#3a66d6", it.total, it.level, pts) }, t("Top players worldwide, by points."))
            }
        } else {
            val byWeek = mode == "week"
            val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
            val profiles = Profiles.list(this)
            val list = ArrayList<Entry>()
            for (i in 0 until profiles.length()) {
                val pr = profiles.getJSONObject(i)
                val id = pr.optString("id")
                val st = try { JSONObject(sp().getString("state__$id", "") ?: "") } catch (e: Exception) { JSONObject() }
                val total = st.optInt("total", 0)
                val gallery = try { JSONArray(sp().getString("gallery__$id", "[]")) } catch (e: Exception) { JSONArray() }
                var week = 0
                for (j in 0 until gallery.length()) if (gallery.getJSONObject(j).optLong("time") >= weekAgo) week++
                list.add(Entry(pr.optString("name"), pr.optString("emoji", "⭐"), pr.optString("color", "#3a66d6"),
                    if (byWeek) week else total, Progress.level(total), if (byWeek) (if (isHe) "משימות" else "tasks") else pts))
            }
            list.sortByDescending { it.value }
            fillBoard(body, list, t(if (byWeek) "Tasks finished in the last 7 days." else "Total points earned, all time."))
        }
        Ui.tabScreen(this, root, "ranks")
    }

    private fun avatarOf(e: Entry, size: Int) = Ui.avatar(this, JSONObject().put("emoji", e.emoji).put("color", e.color), size)

    private fun fillBoard(body: LinearLayout, list: List<Entry>, note: String) {
        val p = Ui.pal(this)
        // podium: 2nd · 1st · 3rd
        if (list.isNotEmpty()) {
            val podium = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
            val order = listOf(1, 0, 2)
            val heights = mapOf(0 to 96, 1 to 72, 2 to 56)
            val tones = mapOf(0 to "gold", 1 to "gray", 2 to "orange")
            for (idx in order) {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                if (idx < list.size) {
                    val e = list[idx]
                    col.addView(avatarOf(e, if (idx == 0) 60 else 48))
                    col.addView(Ui.text(this, e.name, 14f, p.ink).apply { maxLines = 1; gravity = Gravity.CENTER; setPaddingRelative(d(2), d(6), d(2), 0) })
                    col.addView(Ui.text(this, String.format("%,d", e.value) + " " + e.unit, 12f, p.muted, bold = false).apply { gravity = Gravity.CENTER; setPaddingRelative(0, 0, 0, d(6)) })
                    val (bg, ink) = Ui.tone(this, tones[idx]!!)
                    col.addView(Ui.text(this, (idx + 1).toString(), 24f, ink).apply {
                        gravity = Gravity.CENTER
                        background = Ui.rounded(bg, d(14).toFloat())
                    }, LinearLayout.LayoutParams(Ui.MATCH, d(heights[idx]!!)))
                }
                podium.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = d(4); marginEnd = d(4) })
            }
            body.addView(podium, Ui.lp(this, 18))
        }
        // the rest as a list
        if (list.size > 3) {
            val rows = ArrayList<android.view.View>()
            for (i in 3 until list.size) {
                val e = list[i]
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(14), d(10), d(14), d(10)) }
                r.addView(Ui.text(this, (i + 1).toString(), 15f, p.muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(d(30), Ui.WRAP))
                r.addView(avatarOf(e, 36))
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
                col.addView(Ui.text(this, e.name, 15f, p.ink).apply { maxLines = 1 })
                col.addView(Ui.text(this, t("Level") + " " + e.level + " · " + rankName(e.level), 12f, p.muted, bold = false))
                r.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                r.addView(Ui.text(this, String.format("%,d", e.value) + " " + e.unit, 14f, p.ink))
                rows.add(r)
            }
            body.addView(Ui.group(this, rows), Ui.lp(this, 16))
        }
        body.addView(Ui.text(this, note, 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(12), d(4), 0) })
    }
}
