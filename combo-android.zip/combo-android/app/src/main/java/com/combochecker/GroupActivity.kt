package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import org.json.JSONObject

/** One group: members/students, activity feed, approvals and (for the owner) management. */
class GroupActivity : Activity() {
    private var code = ""
    private var info: Map<String, Any?>? = null
    private var members: List<Backend.Doc> = emptyList()
    private var feed: List<Backend.Doc> = emptyList()
    private var pending: List<Backend.Doc> = emptyList()
    private var tasks: List<Backend.Doc> = emptyList()
    private var owner = false
    private var tab = 0
    private var loaded = false
    private var viewMid: String? = null  // a parent following one child in a class (read-only)

    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)
    private fun num(m: Map<String, Any?>, k: String) = (m[k] as? Number)?.toInt() ?: 0
    private fun str(m: Map<String, Any?>, k: String) = m[k] as? String ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        code = intent.getStringExtra("code") ?: ""
        viewMid = intent.getStringExtra("viewMid")
        render()
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        Backend.groupInfo(code) { gi ->
            if (isFinishing) return@groupInfo
            info = gi
            if (gi == null) { loaded = true; render(); return@groupInfo }
            // Teacher/parent controls only when opened from the owner's own lists (Teacher mode is PIN-locked).
            // Profiles on the owner's phone share its server id, so opening from Me → Groups is always the student view.
            owner = viewMid == null && intent.getBooleanExtra("asOwner", false) && gi["owner"] == Backend.uidNow()
            Backend.listMembers(code) { ms ->
                members = (ms ?: emptyList()).sortedByDescending { num(it.data, "weekPoints") }
                Backend.listFeed(code, 40) { fs ->
                    feed = fs ?: emptyList()
                    Backend.listTasks(code) { ts -> tasks = ts ?: emptyList(); if (loaded) render() }
                    if (owner) Backend.listPending(code) { ps -> pending = ps ?: emptyList(); loaded = true; render() }
                    else { loaded = true; render() }
                }
            }
        }
    }

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val gi = info
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(14), 0, 0, 0) }
        col.addView(Ui.text(this, gi?.let { str(it, "name") } ?: code, 24f, p.ink).apply { maxLines = 1 })
        if (gi != null) col.addView(Ui.text(this, Groups.typeLabel(this, str(gi, "type")) + " · " + members.size + " " + t("members"), 13f, p.muted, bold = false))
        head.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        head.addView(Ui.iconButton(this, R.drawable.ui_reset, t("Refresh")) { load() })
        page.addView(head)

        if (!loaded) {
            page.addView(Ui.text(this, t("Loading…"), 15f, p.muted, bold = false).apply { setPaddingRelative(0, d(24), 0, 0) })
            show(page); return
        }
        if (gi == null) {
            page.addView(Ui.text(this, t("Couldn't load this group. It may have been deleted, or you're offline."), 15f, p.muted, bold = false).apply { setPaddingRelative(0, d(24), 0, d(12)) })
            page.addView(Ui.button(this, t("Remove it from my list"), R.drawable.ui_trash, p.track, p.danger) {
                Groups.leave(this, code); Groups.removeOwned(this, code); finish()
            })
            show(page); return
        }

        // join code
        val codeCard = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(16), d(12), d(12), d(12)) }
        val cc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cc.addView(Ui.text(this, t("Join code"), 12f, p.muted, bold = false))
        cc.addView(Ui.text(this, code, 22f, p.accentInk).apply { typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD); setTextIsSelectable(true) })
        codeCard.addView(cc, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        codeCard.addView(Ui.button(this, t("Share"), R.drawable.ui_share, p.accentSoft, p.accentInk, 42) { shareCode(str(gi, "name")) })
        page.addView(codeCard, Ui.lp(this, 16))

        // news
        val news = str(gi, "news")
        if (news.isNotBlank()) page.addView(Ui.card(this).apply {
            setPaddingRelative(d(16), d(12), d(16), d(14))
            val h = LinearLayout(this@GroupActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            h.addView(Ui.tile(this@GroupActivity, R.drawable.ui_megaphone, "orange"))
            h.addView(Ui.text(this@GroupActivity, t("News"), 15f, p.ink).apply { setPaddingRelative(d(10), 0, 0, 0) })
            addView(h)
            addView(Ui.text(this@GroupActivity, news, 15f, p.ink, bold = false).apply { setPaddingRelative(0, d(8), 0, 0) })
        }, Ui.lp(this, 10))

        // team goal
        val target = num(gi, "goalTarget")
        if (target > 0) {
            val sum = members.sumOf { num(it.data, "weekPoints") }
            page.addView(Ui.card(this).apply {
                setPaddingRelative(d(16), d(12), d(16), d(14))
                val h = LinearLayout(this@GroupActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                h.addView(Ui.tile(this@GroupActivity, R.drawable.ui_target, "green"))
                h.addView(Ui.text(this@GroupActivity, t("Team goal") + ": " + str(gi, "goalTitle").ifBlank { t("this week") }, 15f, p.ink).apply { setPaddingRelative(d(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                h.addView(Ui.text(this@GroupActivity, "$sum / $target", 14f, if (sum >= target) p.good else p.muted))
                addView(h)
                addView(Ui.bar(this@GroupActivity, sum.toFloat() / target, Ui.tone(this@GroupActivity, "green").second, p.track), Ui.lp(this@GroupActivity, 10))
                addView(Ui.text(this@GroupActivity, t(if (sum >= target) "Goal reached! 🎉" else "Points everyone earned in the last 7 days."), 12f, p.muted, bold = false).apply { setPaddingRelative(0, d(6), 0, 0) })
            }, Ui.lp(this, 10))
        }

        if (viewMid != null) { viewerPage(page, gi); show(page); return }
        val tabs = if (owner) listOf(t(if (str(gi, "type") == "class") "Students" else "Members") + if (pending.isNotEmpty()) " (${pending.size})" else "", t("Class"), t("Activity"), t("Manage"))
                   else listOf(t("Members"), t("Class"), t("Activity"))
        if (tab >= tabs.size) tab = 0
        page.addView(Ui.segmented(this, tabs, tab) { tab = it; render() }, Ui.lp(this, 16))
        val key = if (owner) listOf("members", "class", "feed", "manage")[tab] else listOf("members", "class", "feed")[tab]
        when (key) {
            "members" -> { if (owner && pending.isNotEmpty()) { page.addView(Ui.sectionTitle(this, t("Waiting for approval") + " (${pending.size})")); approvalsTab(page) }
                if (owner && gi["nudges"] == true) nudgeCard(page)
                membersTab(page) }
            "class" -> classTab(page, gi)
            "approvals" -> approvalsTab(page)
            "feed" -> feedTab(page)
            else -> manageTab(page, gi)
        }
        show(page)
    }

    private fun show(page: View) {
        val p = Ui.pal(this)
        val old = (findViewById<View>(android.R.id.content) as? android.view.ViewGroup)?.getChildAt(0) as? ScrollView
        val y = old?.scrollY ?: 0
        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) }
        setContentView(scroll)
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun ago(ms: Long): String {
        if (ms <= 0) return t("never")
        val mins = (System.currentTimeMillis() - ms) / 60000
        val he = Lang.isHebrew(this)
        return when {
            mins < 1 -> if (he) "עכשיו" else "just now"
            mins < 60 -> if (he) "לפני $mins דק׳" else "${mins}m ago"
            mins < 1440 -> if (he) "לפני ${mins / 60} שע׳" else "${mins / 60}h ago"
            else -> if (he) "לפני ${mins / 1440} ימים" else "${mins / 1440}d ago"
        }
    }

    private fun membersTab(page: LinearLayout) {
        val p = Ui.pal(this)
        // Profiles on this phone that are in the group but not on the server yet.
        val uid = Backend.uidNow() ?: ""
        val onServer = members.map { it.id }.toSet()
        val missing = Groups.localMembers(this, code).filter { !onServer.contains(uid + "_" + it.optString("id")) }
        if (missing.isNotEmpty()) {
            val c = Ui.card(this).apply { setPaddingRelative(d(16), d(12), d(16), d(14)) }
            c.addView(Ui.text(this, t("Not synced yet:") + " " + missing.joinToString(", ") { it.optString("name") }, 14f, p.ink, bold = false))
            c.addView(Ui.button(this, t("Sync now"), R.drawable.ui_upload, p.accent, Color.WHITE, 44) { syncLocal(missing) }, Ui.lp(this, 10))
            page.addView(c, Ui.lp(this, 12))
        }
        if (members.isEmpty()) {
            page.addView(Ui.text(this, t("No one has joined yet. Share the join code."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(16), 0, 0) })
        } else {
            val rows = ArrayList<View>()
            members.forEachIndexed { i, m ->
                val dta = m.data
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(14), d(10), d(14), d(10)) }
                r.addView(Ui.text(this, (i + 1).toString(), 14f, p.muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(d(26), Ui.WRAP))
                r.addView(Ui.avatar(this, JSONObject().put("emoji", str(dta, "emoji")).put("color", str(dta, "color").ifEmpty { "#3a66d6" }), 38))
                val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
                c.addView(Ui.text(this, str(dta, "name"), 15f, p.ink).apply { maxLines = 1 })
                val today = num(dta, "today"); val goal = maxOf(1, num(dta, "goal"))
                val line = t("Lv") + " " + num(dta, "level") + " · " + t("today") + " $today/$goal · " + ago((dta["lastWin"] as? Number)?.toLong() ?: 0L)
                c.addView(Ui.text(this, line, 12f, if (today >= goal) p.good else p.muted, bold = false).apply { maxLines = 1 })
                r.addView(c, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
                v.addView(Ui.text(this, num(dta, "weekPoints").toString(), 15f, p.ink))
                v.addView(Ui.text(this, t("pts / week"), 11f, p.muted, bold = false))
                r.addView(v)
                r.isClickable = true; Ui.ripple(this, r)
                r.setOnClickListener { memberDialog(m) }
                rows.add(r)
            }
            page.addView(Ui.group(this, rows), Ui.lp(this, 12))
        }
        if (!owner) page.addView(Ui.button(this, t("Leave group"), null, p.track, p.danger, 44) {
            AlertDialog.Builder(this).setTitle(t("Leave group?"))
                .setPositiveButton(t("Leave")) { _, _ -> Groups.leave(this, code); finish() }
                .setNegativeButton(t("Cancel"), null).show()
        }, Ui.lp(this, 16))
    }

    private fun memberDialog(m: Backend.Doc) {
        val dta = m.data
        val name = str(dta, "name")
        val myMid = Groups.memberId(Profiles.currentId(this))
        val msg = t("Level") + " " + num(dta, "level") + " · " + num(dta, "total") + " " + t("points") + "\n" +
            t("This week") + ": " + num(dta, "weekTasks") + " " + t("tasks") + ", " + num(dta, "weekPoints") + " " + t("points") + "\n" +
            t("Today") + ": " + num(dta, "today") + "/" + num(dta, "goal") + "\n" +
            t("Last win") + ": " + ago((dta["lastWin"] as? Number)?.toLong() ?: 0L)
        val b = AlertDialog.Builder(this).setTitle(str(dta, "emoji") + "  " + name).setMessage(msg)
        val inGroup = Groups.find(this, code) != null
        if (m.id != myMid && (inGroup || owner)) b.setPositiveButton(t("Send a high-five 🙌")) { _, _ ->
            if (inGroup) Groups.highFive(this, code, m.id, name)
            else Backend.postFeed(code, mapOf("type" to "highfive", "mid" to "owner", "name" to t("Teacher"), "emoji" to "🍎", "to" to m.id, "toName" to name))
            Toast.makeText(this, t("High-five sent!"), Toast.LENGTH_SHORT).show()
        }
        if (owner) b.setNeutralButton(t("Remove")) { _, _ ->
            AlertDialog.Builder(this).setTitle(t("Remove") + " " + name + "?")
                .setPositiveButton(t("Remove")) { _, _ -> Backend.removeMember(code, m.id) { load() } }
                .setNegativeButton(t("Cancel"), null).show()
        }
        b.setNegativeButton(t("Close"), null).show()
    }

    private fun approvalsTab(page: LinearLayout) {
        val p = Ui.pal(this)
        if (pending.isEmpty()) { page.addView(Ui.text(this, t("Nothing waiting."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), 0, 0) }); return }
        for (pd in pending) {
            val dta = pd.data
            val c = Ui.card(this)
            Groups.decodeThumb(dta["thumb"] as? String)?.let { bmp ->
                c.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(p.track) },
                    LinearLayout.LayoutParams(Ui.MATCH, d(180)))
            }
            val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(16), d(12), d(16), d(14)) }
            inner.addView(Ui.text(this, str(dta, "task").ifBlank { t("Task") }, 16f, p.ink))
            inner.addView(Ui.text(this, str(dta, "emoji") + " " + str(dta, "name") + " · " + num(dta, "coins") + " " + t("coins") +
                (if (dta["study"] == true) " · " + t("study") else "") + " · " + ago((dta["ts"] as? Number)?.toLong() ?: 0L), 13f, p.muted, bold = false))
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(Ui.button(this, t("Approve"), R.drawable.ui_check, Ui.tone(this, "green").first, p.good, 44) { decide(pd.id, "approved") },
                LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginEnd = d(5) })
            btns.addView(Ui.button(this, t("Reject"), R.drawable.ui_trash, Ui.tone(this, "red").first, p.danger, 44) { decide(pd.id, "rejected") },
                LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = d(5) })
            inner.addView(btns, Ui.lp(this, 12))
            c.addView(inner)
            page.addView(c, Ui.lp(this, 12))
        }
        if (pending.size > 1) page.addView(Ui.button(this, t("Approve all"), R.drawable.ui_check, p.accent, Color.WHITE) {
            for (pd in pending) Backend.setPendingStatus(code, pd.id, "approved")
            Toast.makeText(this, t("Approved"), Toast.LENGTH_SHORT).show()
            pending = emptyList(); render()
        }, Ui.lp(this, 12))
    }

    private fun decide(id: String, status: String) {
        Backend.setPendingStatus(code, id, status) { ok ->
            Toast.makeText(this, t(if (!ok) "Couldn't save. Check your connection." else if (status == "approved") "Approved" else "Rejected"), Toast.LENGTH_SHORT).show()
            if (ok) { pending = pending.filter { it.id != id }; render() }
        }
    }

    private fun feedTab(page: LinearLayout) {
        val p = Ui.pal(this)
        if (feed.isEmpty()) { page.addView(Ui.text(this, t("No activity yet."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), 0, 0) }); return }
        for (f in feed) feedCard(page, f, p)
    }

    private fun feedCard(page: LinearLayout, f: Backend.Doc, p: Ui.Pal) {
        val dta = f.data
        val type = str(dta, "type")
        val c = Ui.card(this)
        if (type == "win" || type == "hw") Groups.decodeThumb(dta["thumb"] as? String)?.let { bmp ->
            c.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(p.track) },
                LinearLayout.LayoutParams(Ui.MATCH, d(150)))
        }
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(14), d(10), d(14), d(10)) }
        val (res, tone) = when (type) {
            "win" -> Pair(R.drawable.ui_trophy, "gold"); "hw" -> Pair(R.drawable.ui_book, "purple"); "redeem" -> Pair(R.drawable.ui_gift, "gold")
            "comment" -> Pair(R.drawable.ui_mail, "blue"); "nudge" -> Pair(R.drawable.ui_bell, "orange"); "cert" -> Pair(R.drawable.ui_star, "gold")
            else -> Pair(R.drawable.ui_spark, "purple")
        }
        r.addView(Ui.tile(this, res, tone))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
        val who = str(dta, "emoji") + " " + str(dta, "name")
        val title = when (type) {
            "win" -> who + " · " + str(dta, "task").ifBlank { t("Task") }
            "hw" -> who + " · " + t("Homework done:") + " " + str(dta, "task")
            "redeem" -> who + " · " + t("bought") + " " + str(dta, "task")
            "comment" -> who + " → " + str(dta, "toName") + ": " + str(dta, "text")
            "nudge" -> who + " → " + str(dta, "toName") + ": " + str(dta, "text")
            "cert" -> "🏅 " + str(dta, "toName") + " · " + t("Student of the week")
            else -> who + " → " + str(dta, "toName") + " 🙌"
        }
        col.addView(Ui.text(this, title, 14f, p.ink).apply { maxLines = 3 })
        val sub = when (type) { "win" -> "+" + num(dta, "points") + " " + t("pts") + " · "; "redeem" -> num(dta, "points").toString() + " " + t("coins") + " · "; else -> "" }
        col.addView(Ui.text(this, sub + ago((dta["ts"] as? Number)?.toLong() ?: 0L), 12f, p.muted, bold = false))
        r.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        if (owner && (type == "win" || type == "hw")) r.addView(Ui.iconButton(this, R.drawable.ui_mail, t("Comment")) { commentDialog(dta) })
        c.addView(r)
        page.addView(c, Ui.lp(this, 10))
    }

    /** As the teacher/parent: a short note on a win that the student sees next time they open the app. */
    private fun commentDialog(win: Map<String, Any?>) {
        val f = field(t("e.g. Great handwriting!"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        AlertDialog.Builder(this).setTitle(t("Comment to") + " " + str(win, "name")).setView(boxed(f))
            .setPositiveButton(t("Send")) { _, _ ->
                val text = f.text.toString().trim(); if (text.isEmpty()) return@setPositiveButton
                Backend.postFeed(code, mapOf("type" to "comment", "mid" to "owner", "name" to ownerName(), "emoji" to ownerEmoji(),
                    "to" to str(win, "mid"), "toName" to str(win, "name"), "task" to str(win, "task"), "text" to text))
                Toast.makeText(this, t("Sent"), Toast.LENGTH_SHORT).show(); load()
            }.setNegativeButton(t("Cancel"), null).show()
    }

    private fun ownerName() = t(if (str(info ?: emptyMap(), "type") == "class") "Teacher" else "Parent")
    private fun ownerEmoji() = if (str(info ?: emptyMap(), "type") == "class") "🍎" else "👪"

    private fun lastActive(m: Map<String, Any?>) = (m["lastWin"] as? Number)?.toLong() ?: 0L

    /** Quiet nudges: who hasn't finished a task in 3 days. */
    private fun nudgeCard(page: LinearLayout) {
        val p = Ui.pal(this)
        val cutoff = System.currentTimeMillis() - 3L * 24 * 3600 * 1000
        val quiet = members.filter { lastActive(it.data) < cutoff }
        if (quiet.isEmpty()) return
        val c = Ui.card(this).apply { setPaddingRelative(d(16), d(12), d(16), d(14)) }
        val h = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        h.addView(Ui.tile(this, R.drawable.ui_bell, "orange"))
        h.addView(Ui.text(this, t("Quiet for 3+ days"), 15f, p.ink).apply { setPaddingRelative(d(10), 0, 0, 0) })
        c.addView(h)
        c.addView(Ui.text(this, quiet.joinToString(", ") { str(it.data, "name") }, 14f, p.ink, bold = false).apply { setPaddingRelative(0, d(8), 0, d(10)) })
        c.addView(Ui.button(this, t("Send a friendly nudge"), R.drawable.ui_bell, Ui.tone(this, "orange").first, Ui.tone(this, "orange").second, 44) {
            val f = field(t("Message"), t("We miss you! One small task today? 💪"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            AlertDialog.Builder(this).setTitle(t("Send a friendly nudge")).setView(boxed(f))
                .setPositiveButton(t("Send")) { _, _ ->
                    for (m in quiet) Backend.postFeed(code, mapOf("type" to "nudge", "mid" to "owner", "name" to ownerName(), "emoji" to ownerEmoji(),
                        "to" to m.id, "toName" to str(m.data, "name"), "text" to f.text.toString().trim()))
                    Toast.makeText(this, t("Sent"), Toast.LENGTH_SHORT).show()
                }.setNegativeButton(t("Cancel"), null).show()
        })
        page.addView(c, Ui.lp(this, 4))
    }

    @Suppress("UNCHECKED_CAST")
    private fun items(gi: Map<String, Any?>, key: String): List<Map<String, Any?>> =
        ((gi[key] as? List<*>) ?: emptyList<Any>()).mapNotNull { it as? Map<String, Any?> }

    private fun newId() = java.lang.Long.toString(System.currentTimeMillis(), 36)
    private fun myMid() = Groups.memberId(Profiles.currentId(this))

    private fun classTab(page: LinearLayout, gi: Map<String, Any?>) {
        val p = Ui.pal(this)
        val inGroup = Groups.find(this, code) != null

        // --- student of the week ---
        if (gi["certificate"] == true && members.isNotEmpty()) {
            val top = members.maxByOrNull { num(it.data, "weekPoints") }!!
            if (num(top.data, "weekPoints") > 0) {
                val c = Ui.card(this).apply { setPaddingRelative(d(16), d(14), d(16), d(14)); gravity = Gravity.CENTER_HORIZONTAL }
                c.addView(Ui.text(this, "🏅", 36f, p.ink).apply { gravity = Gravity.CENTER })
                c.addView(Ui.text(this, t("Student of the week"), 13f, p.muted).apply { gravity = Gravity.CENTER })
                c.addView(Ui.text(this, str(top.data, "emoji") + " " + str(top.data, "name"), 20f, p.ink).apply { gravity = Gravity.CENTER })
                c.addView(Ui.text(this, num(top.data, "weekPoints").toString() + " " + t("points this week"), 13f, p.muted, bold = false).apply { gravity = Gravity.CENTER })
                if (owner) c.addView(Ui.button(this, t("Award the certificate"), R.drawable.ui_star, Ui.tone(this, "gold").first, Ui.tone(this, "gold").second, 44) {
                    Backend.postFeed(code, mapOf("type" to "cert", "mid" to "owner", "name" to ownerName(), "emoji" to ownerEmoji(), "to" to top.id, "toName" to str(top.data, "name")))
                    Toast.makeText(this, t("Sent"), Toast.LENGTH_SHORT).show()
                }, Ui.lp(this, 12))
                else if (top.id == myMid()) c.addView(Ui.button(this, t("Share my certificate"), R.drawable.ui_share, p.accent, Color.WHITE, 44) {
                    val msg = "🏅 " + str(top.data, "name") + " — " + t("Student of the week") + " · " + str(gi, "name") + " (Comboed)"
                    try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), t("Share"))) } catch (e: Exception) {}
                }, Ui.lp(this, 12))
                page.addView(c, Ui.lp(this, 4))
            }
        }

        // --- task board (claimable: first to take it gets it) ---
        taskBoard(page, inGroup)

        // --- homework ---
        page.addView(Ui.sectionTitle(this, t("Homework")))
        val hw = items(gi, "homework").sortedBy { (it["due"] as? Number)?.toLong() ?: 0L }
        val hwRows = ArrayList<View>()
        val myDone = Groups.hwDoneLocal(this, code)
        for (h in hw) {
            val id = str(h, "id"); val due = (h["due"] as? Number)?.toLong() ?: 0L
            val dueTxt = if (due > 0) t("due") + " " + java.text.SimpleDateFormat("EEE d MMM", java.util.Locale.getDefault()).format(java.util.Date(due)) else ""
            if (owner) {
                val doneCount = members.count { ((it.data["hwDone"] as? Map<*, *>)?.containsKey(id)) == true }
                hwRows.add(Ui.row(this, R.drawable.ui_book, "purple", str(h, "title"), "$doneCount/${members.size}" + if (dueTxt.isNotEmpty()) " · $dueTxt" else "") { homeworkDetail(gi, h) })
            } else {
                val done = myDone.contains(id)
                hwRows.add(Ui.row(this, if (done) R.drawable.ui_check else R.drawable.ui_book, if (done) "green" else "purple", str(h, "title"),
                    if (done) t("Done") else dueTxt, if (done) p.good else null) {
                    if (!done && inGroup) markHomeworkDialog(id, str(h, "title"))
                })
            }
        }
        if (owner) hwRows.add(Ui.row(this, R.drawable.ui_spark, "blue", t("Assign homework"), null) { assignHomework(gi) })
        if (hwRows.isEmpty()) page.addView(Ui.text(this, t("No homework right now."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), 0, 0, 0) })
        else page.addView(Ui.group(this, hwRows))

        // --- teams ---
        val teams = items(gi, "teams")
        if (teams.isNotEmpty() || owner) {
            page.addView(Ui.sectionTitle(this, t("Teams")))
            val byMid = members.associateBy { it.id }
            val scored = teams.map { tm ->
                val ids = ((tm["members"] as? List<*>) ?: emptyList<Any>()).mapNotNull { it as? String }
                Triple(tm, ids, ids.sumOf { byMid[it]?.let { m -> num(m.data, "weekPoints") } ?: 0 })
            }.sortedByDescending { it.third }
            val rows = ArrayList<View>()
            scored.forEachIndexed { i, (tm, ids, pts) ->
                val mine = ids.contains(myMid())
                rows.add(Ui.row(this, R.drawable.ui_users, listOf("gold", "gray", "orange", "teal", "purple")[minOf(i, 4)],
                    (if (i == 0 && pts > 0) "🏆 " else "") + str(tm, "name") + if (mine) "  (" + t("you") + ")" else "",
                    "$pts " + t("pts") + " · " + ids.size) { if (owner) teamDialog(gi, tm) else teamInfo(tm, ids) })
            }
            if (owner) rows.add(Ui.row(this, R.drawable.ui_spark, "blue", t("Create a team"), null) {
                val fl = field(t("Team name"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
                AlertDialog.Builder(this).setTitle(t("Create a team")).setView(boxed(fl))
                    .setPositiveButton(t("Create")) { _, _ ->
                        val n = fl.text.toString().trim(); if (n.isEmpty()) return@setPositiveButton
                        save(mapOf("teams" to teams + mapOf("id" to newId(), "name" to n, "members" to emptyList<String>())))
                    }.setNegativeButton(t("Cancel"), null).show()
            })
            if (rows.isNotEmpty()) page.addView(Ui.group(this, rows))
            page.addView(Ui.text(this, t("Team score = points its members earned in the last 7 days."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })
        }

        // --- class rewards shop ---
        val rewards = items(gi, "rewards")
        if (rewards.isNotEmpty() || owner) {
            page.addView(Ui.sectionTitle(this, t("Class rewards")))
            val rows = ArrayList<View>()
            for (rw in rewards) rows.add(Ui.row(this, R.drawable.ui_gift, "gold", str(rw, "name"), num(rw, "cost").toString() + " " + t("coins")) {
                if (owner) AlertDialog.Builder(this).setTitle(str(rw, "name")).setMessage(t("Delete this reward?"))
                    .setPositiveButton(t("Delete")) { _, _ -> save(mapOf("rewards" to rewards.filter { it["id"] != rw["id"] })) }
                    .setNegativeButton(t("Cancel"), null).show()
                else if (inGroup) buyClassReward(rw)
            })
            if (owner) rows.add(Ui.row(this, R.drawable.ui_spark, "blue", t("Add class reward"), null) {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(6), d(20), 0) }
                val n = field(t("e.g. Homework pass, Sit anywhere"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                val cst = field(t("Coin cost"), "", InputType.TYPE_CLASS_NUMBER)
                col.addView(n); col.addView(cst)
                AlertDialog.Builder(this).setTitle(t("Add class reward")).setView(col)
                    .setPositiveButton(t("Add")) { _, _ ->
                        val name = n.text.toString().trim(); val cost = cst.text.toString().toIntOrNull() ?: 0
                        if (name.isEmpty() || cost <= 0) return@setPositiveButton
                        save(mapOf("rewards" to rewards + mapOf("id" to newId(), "name" to name, "cost" to cost)))
                    }.setNegativeButton(t("Cancel"), null).show()
            })
            page.addView(Ui.group(this, rows))
            if (!owner) page.addView(Ui.text(this, t("Buy with your coins, then show your teacher the note."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })
        }
    }

    private fun assignHomework(gi: Map<String, Any?>) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(6), d(20), 0) }
        val title = field(t("What to do (e.g. Math page 42)"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val days = field(t("Due in how many days?"), "1", InputType.TYPE_CLASS_NUMBER)
        col.addView(title); col.addView(days)
        AlertDialog.Builder(this).setTitle(t("Assign homework")).setView(col)
            .setPositiveButton(t("Assign")) { _, _ ->
                val tt = title.text.toString().trim(); if (tt.isEmpty()) return@setPositiveButton
                val cal = java.util.Calendar.getInstance(); cal.add(java.util.Calendar.DAY_OF_MONTH, (days.text.toString().toIntOrNull() ?: 1).coerceIn(0, 60))
                cal.set(java.util.Calendar.HOUR_OF_DAY, 23); cal.set(java.util.Calendar.MINUTE, 59)
                val list = items(gi, "homework").filter { ((it["due"] as? Number)?.toLong() ?: Long.MAX_VALUE) > System.currentTimeMillis() - 14L * 24 * 3600 * 1000 }
                save(mapOf("homework" to list + mapOf("id" to newId(), "title" to tt, "due" to cal.timeInMillis)))
            }.setNegativeButton(t("Cancel"), null).show()
    }

    private fun homeworkDetail(gi: Map<String, Any?>, h: Map<String, Any?>) {
        val id = str(h, "id")
        val done = members.filter { ((it.data["hwDone"] as? Map<*, *>)?.containsKey(id)) == true }.map { str(it.data, "name") }
        val notDone = members.filter { ((it.data["hwDone"] as? Map<*, *>)?.containsKey(id)) != true }.map { str(it.data, "name") }
        val msg = "✅ " + t("Done") + " (${done.size}): " + done.joinToString(", ").ifEmpty { "—" } + "\n\n⏳ " + t("Not yet") + " (${notDone.size}): " + notDone.joinToString(", ").ifEmpty { "—" }
        AlertDialog.Builder(this).setTitle(str(h, "title")).setMessage(msg)
            .setPositiveButton(t("Close"), null)
            .setNeutralButton(t("Delete")) { _, _ -> save(mapOf("homework" to items(gi, "homework").filter { it["id"] != id })) }
            .show()
    }

    /** Mark homework done by attaching one of your recent wins as proof. */
    private fun markHomeworkDialog(hwId: String, title: String) {
        val g = Progress.gallery(this)
        val wins = ArrayList<org.json.JSONObject>()
        var i = g.length() - 1
        while (i >= 0 && wins.size < 10) { g.optJSONObject(i)?.let { wins.add(it) }; i-- }
        if (wins.isEmpty()) {
            AlertDialog.Builder(this).setTitle(title).setMessage(t("Finish it first with Checkpoint or a photo check, then come back and attach it as proof."))
                .setPositiveButton(t("OK"), null).show(); return
        }
        AlertDialog.Builder(this).setTitle(t("Which task was it?"))
            .setItems(wins.map { it.optString("task").ifBlank { t("Task") } + " · " + ago(it.optLong("time")) }.toTypedArray()) { _, w ->
                val win = wins[w]
                Thread {
                    val pic = Groups.thumb(this, win.optString("file"))
                    runOnUiThread {
                        Groups.markHwDone(this, code, hwId, title, pic)
                        Toast.makeText(this, t("Homework marked done ✅"), Toast.LENGTH_SHORT).show()
                        render()
                    }
                }.start()
            }.setNegativeButton(t("Cancel"), null).show()
    }

    private fun teamInfo(tm: Map<String, Any?>, ids: List<String>) {
        val byMid = members.associateBy { it.id }
        val names = ids.mapNotNull { byMid[it] }.joinToString("\n") { str(it.data, "emoji") + " " + str(it.data, "name") + " · " + num(it.data, "weekPoints") + " " + t("pts") }
        AlertDialog.Builder(this).setTitle(str(tm, "name")).setMessage(names.ifEmpty { "—" }).setPositiveButton(t("Close"), null).show()
    }

    private fun teamDialog(gi: Map<String, Any?>, tm: Map<String, Any?>) {
        val teams = items(gi, "teams")
        val current = ((tm["members"] as? List<*>) ?: emptyList<Any>()).mapNotNull { it as? String }.toSet()
        val labels = members.map { str(it.data, "emoji") + " " + str(it.data, "name") }.toTypedArray()
        val checked = BooleanArray(members.size) { current.contains(members[it].id) }
        AlertDialog.Builder(this).setTitle(str(tm, "name"))
            .setMultiChoiceItems(labels, checked) { _, w, on -> checked[w] = on }
            .setPositiveButton(t("Save")) { _, _ ->
                val chosen = members.filterIndexed { i, _ -> checked[i] }.map { it.id }
                // a student is in one team at a time
                val updated = teams.map { other ->
                    if (other["id"] == tm["id"]) other + ("members" to chosen)
                    else other + ("members" to ((other["members"] as? List<*>) ?: emptyList<Any>()).filter { it !in chosen })
                }
                save(mapOf("teams" to updated))
            }
            .setNeutralButton(t("Delete")) { _, _ -> save(mapOf("teams" to teams.filter { it["id"] != tm["id"] })) }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun buyClassReward(rw: Map<String, Any?>) {
        val cost = num(rw, "cost"); val name = str(rw, "name")
        AlertDialog.Builder(this).setTitle(name).setMessage(t("Buy for") + " $cost " + t("coins") + "?")
            .setPositiveButton(t("Buy")) { _, _ ->
                if (!Groups.spend(this, cost)) { Toast.makeText(this, t("Not enough coins"), Toast.LENGTH_LONG).show(); return@setPositiveButton }
                Groups.post(this, code, mapOf("type" to "redeem", "task" to name, "points" to cost))
                AlertDialog.Builder(this).setTitle("🎁 " + name).setMessage(t("Bought! Show this to your teacher.") + "\n\n" + Profiles.current(this).optString("name") + " · " +
                    java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date()))
                    .setPositiveButton(t("OK"), null).show()
            }.setNegativeButton(t("Cancel"), null).show()
    }

    /** A parent following their child in a class (read-only). */
    private fun viewerPage(page: LinearLayout, gi: Map<String, Any?>) {
        val p = Ui.pal(this)
        if (gi["parentView"] != true) {
            page.addView(Ui.text(this, t("The teacher has turned off parent view for this class."), 15f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(20), 0, 0) })
            return
        }
        val child = members.firstOrNull { it.id == viewMid }
        if (child == null) { page.addView(Ui.text(this, t("Your child isn't in this class any more."), 15f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(20), 0, 0) }); return }
        val dta = child.data
        val c = Ui.card(this).apply { setPaddingRelative(d(16), d(16), d(16), d(16)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.avatar(this, JSONObject().put("emoji", str(dta, "emoji")).put("color", str(dta, "color").ifEmpty { "#3a66d6" }), 52))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, 0, 0) }
        col.addView(Ui.text(this, str(dta, "name"), 20f, p.ink))
        col.addView(Ui.text(this, t("Level") + " " + num(dta, "level") + " · " + t("last win") + " " + ago(lastActive(dta)), 13f, p.muted, bold = false))
        top.addView(col); c.addView(top)
        c.addView(Ui.text(this, t("This week") + ": " + num(dta, "weekTasks") + " " + t("tasks") + ", " + num(dta, "weekPoints") + " " + t("points") + "\n" +
            t("Today") + ": " + num(dta, "today") + "/" + num(dta, "goal"), 14f, p.ink, bold = false).apply { setPaddingRelative(0, d(12), 0, 0) })
        page.addView(c, Ui.lp(this, 16))
        val hw = items(gi, "homework")
        if (hw.isNotEmpty()) {
            page.addView(Ui.sectionTitle(this, t("Homework")))
            val done = (dta["hwDone"] as? Map<*, *>) ?: emptyMap<String, Any>()
            page.addView(Ui.group(this, hw.map { h ->
                val ok = done.containsKey(str(h, "id"))
                Ui.row(this, if (ok) R.drawable.ui_check else R.drawable.ui_book, if (ok) "green" else "purple", str(h, "title"), if (ok) t("Done") else t("Not yet"), if (ok) p.good else null, chevron = false)
            }))
        }
        val mine = feed.filter { it.data["mid"] == viewMid || it.data["to"] == viewMid }
        if (mine.isNotEmpty()) {
            page.addView(Ui.sectionTitle(this, t("Recent activity")))
            for (f in mine.take(15)) feedCard(page, f, p)
        }
    }

    private fun field(hintText: String, value: String, type: Int) = EditText(this).apply { hint = hintText; inputType = type; setText(value) }
    private fun boxed(v: View) = FrameLayout(this).apply { setPaddingRelative(d(20), d(6), d(20), 0); addView(v) }

    private fun manageTab(page: LinearLayout, gi: Map<String, Any?>) {
        val p = Ui.pal(this)
        val isClass = str(gi, "type") == "class"
        page.addView(Ui.sectionTitle(this, t("Group")))
        page.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_megaphone, "orange", t("Post news"), str(gi, "news").ifBlank { t("None") }) {
                val f = field(t("A message everyone sees"), str(gi, "news"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                AlertDialog.Builder(this).setTitle(t("Post news")).setView(boxed(f))
                    .setPositiveButton(t("Post")) { _, _ -> save(mapOf("news" to f.text.toString().trim())) }
                    .setNeutralButton(t("Clear")) { _, _ -> save(mapOf("news" to "")) }
                    .setNegativeButton(t("Cancel"), null).show()
            },
            Ui.row(this, R.drawable.ui_target, "green", t("Team goal"), if (num(gi, "goalTarget") > 0) num(gi, "goalTarget").toString() + " " + t("pts") else t("None")) {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(6), d(20), 0) }
                val title = field(t("Reward / title (e.g. Pizza party)"), str(gi, "goalTitle"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                val target = field(t("Points the whole group needs in 7 days"), if (num(gi, "goalTarget") > 0) num(gi, "goalTarget").toString() else "", InputType.TYPE_CLASS_NUMBER)
                col.addView(title); col.addView(target)
                AlertDialog.Builder(this).setTitle(t("Team goal")).setView(col)
                    .setPositiveButton(t("Save")) { _, _ -> save(mapOf("goalTitle" to title.text.toString().trim(), "goalTarget" to (target.text.toString().toIntOrNull() ?: 0))) }
                    .setNeutralButton(t("Clear")) { _, _ -> save(mapOf("goalTitle" to "", "goalTarget" to 0)) }
                    .setNegativeButton(t("Cancel"), null).show()
            },
            Ui.switchRow(this, R.drawable.ui_check, "blue", t("Approvals"), t("Coins wait for your OK before they land"), gi["approvals"] == true) { on -> save(mapOf("approvals" to on), quiet = true) },
            Ui.switchRow(this, R.drawable.ui_bell, "orange", t("Quiet nudges"), t("Show who's been quiet for 3+ days, with a nudge button"), gi["nudges"] == true) { on -> save(mapOf("nudges" to on), quiet = true) },
            Ui.switchRow(this, R.drawable.ui_star, "gold", t("Student of the week"), t("Top points this week gets a certificate"), gi["certificate"] == true) { on -> save(mapOf("certificate" to on), quiet = true) },
            Ui.switchRow(this, R.drawable.ui_users, "green", t("Parents can view"), t("Parents follow their own child with this code (read-only)"), gi["parentView"] == true) { on -> save(mapOf("parentView" to on), quiet = true) },
            Ui.row(this, R.drawable.ui_layout, "gray", t("Rename"), str(gi, "name")) {
                val f = field(t("Name"), str(gi, "name"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
                AlertDialog.Builder(this).setTitle(t("Rename")).setView(boxed(f))
                    .setPositiveButton(t("Save")) { _, _ -> val n = f.text.toString().trim(); if (n.isNotEmpty()) save(mapOf("name" to n)) }
                    .setNegativeButton(t("Cancel"), null).show()
            }
        )))

        page.addView(Ui.sectionTitle(this, t(if (isClass) "Students" else "Members")))
        page.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_users, "purple", t("Add profiles on this device"), null) { bulkAddDialog() },
            Ui.row(this, R.drawable.ui_user, "blue", t("Add existing profiles"), null) { addExistingDialog() },
            Ui.row(this, R.drawable.ui_file, "teal", t("Share a progress report"), null) { shareReport(gi) },
            Ui.row(this, R.drawable.ui_download, "teal", t("Export spreadsheet (CSV)"), null) { exportCsv(gi) }
        )))
        page.addView(Ui.text(this, t("“Add profiles on this device” is for a shared class tablet: type one name per line and each gets a profile already in this group."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })

        page.addView(Ui.button(this, t("Delete group"), R.drawable.ui_trash, p.track, p.danger, 46) {
            AlertDialog.Builder(this).setTitle(t("Delete group?")).setMessage(t("Members will no longer see it. This can't be undone."))
                .setPositiveButton(t("Delete")) { _, _ ->
                    Backend.ensureUid { com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("groups").document(code).delete() }
                    Groups.removeOwned(this, code); Groups.leave(this, code); finish()
                }
                .setNegativeButton(t("Cancel"), null).show()
        }, Ui.lp(this, 20))
    }

    private fun save(fields: Map<String, Any?>, quiet: Boolean = false) {
        Backend.updateGroup(code, fields) { ok ->
            if (!quiet || !ok) Toast.makeText(this, t(if (ok) "Saved" else "Couldn't save. Check your connection."), Toast.LENGTH_SHORT).show()
            load()
        }
    }

    /** Publish these local profiles to the group, then reload. */
    private fun syncLocal(profiles: List<JSONObject>) {
        val gi = info ?: return
        if (profiles.isEmpty()) return
        var done = 0; var failed = 0
        Toast.makeText(this, t("Syncing…"), Toast.LENGTH_SHORT).show()
        for (pr in profiles) {
            Groups.joinKnown(this, code, str(gi, "name"), str(gi, "type"), gi["approvals"] == true, pr.optString("id")) { ok ->
                done++; if (!ok) failed++
                if (done == profiles.size) {
                    if (failed > 0) Toast.makeText(this, t("Couldn't save. Check your connection.") + " ($failed)", Toast.LENGTH_LONG).show()
                    else Toast.makeText(this, t("Added") + " ${profiles.size}", Toast.LENGTH_SHORT).show()
                    tab = 0; load()
                }
            }
        }
    }

    /** Pick profiles that already exist on this device and put them in the group. */
    private fun addExistingDialog() {
        val all = Profiles.list(this)
        val choices = ArrayList<JSONObject>()
        for (i in 0 until all.length()) { val pr = all.optJSONObject(i) ?: continue; if (Groups.find(this, code, pr.optString("id")) == null) choices.add(pr) }
        if (choices.isEmpty()) { Toast.makeText(this, t("Every profile on this device is already in the group."), Toast.LENGTH_LONG).show(); return }
        val checked = BooleanArray(choices.size)
        AlertDialog.Builder(this).setTitle(t("Add existing profiles"))
            .setMultiChoiceItems(choices.map { it.optString("emoji") + "  " + it.optString("name") }.toTypedArray(), checked) { _, w, on -> checked[w] = on }
            .setPositiveButton(t("Add")) { _, _ -> syncLocal(choices.filterIndexed { i, _ -> checked[i] }) }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun bulkAddDialog() {
        val f = field(t("One name per line"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_WORDS).apply { minLines = 4 }
        AlertDialog.Builder(this).setTitle(t("Add profiles on this device")).setView(boxed(f))
            .setPositiveButton(t("Add")) { _, _ ->
                val names = f.text.toString().split("\n").map { it.trim() }.filter { it.isNotEmpty() }.take(60)
                if (names.isEmpty()) return@setPositiveButton
                val emojis = listOf("⭐", "🚀", "🐱", "🐶", "🦄", "🐧", "🦊", "🐉", "🎈", "🎮", "🌟", "🔥")
                val colors = listOf("#3a66d6", "#2a7d46", "#D62F9B", "#E8491D", "#6A2FE8", "#E8B500", "#0a9cc0", "#c0392b")
                val made = names.mapIndexed { i, n ->
                    val pid = Profiles.add(this, n, emojis[i % emojis.size], colors[i % colors.size])
                    Profiles.find(this, pid) ?: JSONObject().put("id", pid).put("name", n)
                }
                syncLocal(made)
            }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun shareCode(name: String) {
        val msg = (if (Lang.isHebrew(this)) "הצטרפו ל־\"$name\" ב‑Comboed: אני ← קבוצות ← הצטרפות עם קוד, והקלידו " else "Join \"$name\" on Comboed: Me → Groups → Join with a code, and type ") + code +
            "\n" + UpdateCheck.LATEST_APK
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), t("Share"))) } catch (e: Exception) {}
    }

    private fun shareReport(gi: Map<String, Any?>) {
        val sb = StringBuilder()
        sb.append(str(gi, "name")).append(" — ").append(t("weekly report")).append("\n\n")
        for (m in members) {
            val dta = m.data
            sb.append(str(dta, "emoji")).append(" ").append(str(dta, "name")).append(": ")
                .append(num(dta, "weekTasks")).append(" ").append(t("tasks")).append(", ")
                .append(num(dta, "weekPoints")).append(" ").append(t("pts")).append(", ")
                .append(t("Lv")).append(" ").append(num(dta, "level")).append(", ")
                .append(t("last win")).append(" ").append(ago((dta["lastWin"] as? Number)?.toLong() ?: 0L)).append("\n")
        }
        val quiet = members.filter { num(it.data, "weekTasks") == 0 }
        if (quiet.isNotEmpty()) sb.append("\n").append(t("No tasks this week:")).append(" ").append(quiet.joinToString(", ") { str(it.data, "name") })
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sb.toString()), t("Share"))) } catch (e: Exception) {}
    }

    /** Spreadsheet export: one row per student, homework columns included. Opens the share sheet. */
    private fun exportCsv(gi: Map<String, Any?>) {
        fun q(x: String) = "\"" + x.replace("\"", "\"\"") + "\""
        val hw = items(gi, "homework")
        val sb = StringBuilder()
        sb.append(listOf("Name", "Level", "Total points", "Tasks (7 days)", "Points (7 days)", "Today", "Daily goal", "Last win").plus(hw.map { "HW: " + str(it, "title") }).joinToString(",") { q(it) }).append("\n")
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
        for (m in members) {
            val dta = m.data
            val done = (dta["hwDone"] as? Map<*, *>) ?: emptyMap<String, Any>()
            val row = listOf(str(dta, "name"), num(dta, "level").toString(), num(dta, "total").toString(), num(dta, "weekTasks").toString(),
                num(dta, "weekPoints").toString(), num(dta, "today").toString(), num(dta, "goal").toString(),
                lastActive(dta).let { if (it > 0) fmt.format(java.util.Date(it)) else "" }) + hw.map { if (done.containsKey(str(it, "id"))) "done" else "" }
            sb.append(row.joinToString(",") { q(it) }).append("\n")
        }
        try {
            val safe = str(gi, "name").replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "class" }
            val f = java.io.File(cacheDir, "comboed-$safe.csv")
            f.writeText("\uFEFF" + sb.toString()) // BOM so Excel reads Hebrew correctly
            val uri = android.net.Uri.parse("content://$packageName.capture/${f.name}")
            val i = Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_SUBJECT, str(gi, "name") + " — Comboed").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, t("Share")))
        } catch (e: Exception) { Toast.makeText(this, e.message ?: "Error", Toast.LENGTH_LONG).show() }
    }

    // ===================== task board =====================
    private fun effState(dta: Map<String, Any?>): String {
        val st = str(dta, "state").ifEmpty { "open" }
        val until = (dta["until"] as? Number)?.toLong() ?: 0L
        return if (st == "claimed" && until < System.currentTimeMillis()) "open" else st
    }

    private fun left(ms: Long): String {
        val mins = ((ms - System.currentTimeMillis()) / 60000).coerceAtLeast(0)
        val he = Lang.isHebrew(this)
        return if (mins >= 60) (if (he) "עוד ${mins / 60} שע׳" else "${mins / 60}h left") else (if (he) "עוד $mins דק׳" else "${mins}m left")
    }

    private fun taskBoard(page: LinearLayout, inGroup: Boolean) {
        val p = Ui.pal(this)
        page.addView(Ui.sectionTitle(this, t("Task board")))
        val me = myMid()
        val now = System.currentTimeMillis()
        val shown = tasks.filter { str(it.data, "state") != "done" || now - ((it.data["ts"] as? Number)?.toLong() ?: 0L) < 3L * 24 * 3600 * 1000 }
            .sortedBy { listOf("open", "claimed", "submitted", "approved", "done").indexOf(effState(it.data)) }
        val rows = ArrayList<View>()
        for (tk in shown) {
            val d = tk.data
            val st = effState(d)
            val coins = num(d, "coins")
            val mine = str(d, "by") == me && st != "open"
            val (res, tone) = when (st) {
                "open" -> Pair(R.drawable.ui_target, "blue"); "claimed" -> Pair(R.drawable.ui_lock, if (mine) "green" else "orange")
                "submitted" -> Pair(R.drawable.ui_upload, "purple"); else -> Pair(R.drawable.ui_check, "green")
            }
            val value = when (st) {
                "open" -> "+$coins · " + t("Open")
                "claimed" -> (if (mine) t("Yours") else str(d, "byName")) + " · " + left((d["until"] as? Number)?.toLong() ?: 0L)
                "submitted" -> (if (mine) t("Yours") + " · " else str(d, "byName") + " · ") + t("Waiting for OK")
                else -> t("Done") + " ✓"
            }
            rows.add(Ui.row(this, res, tone, str(d, "title"), value, if (st == "open") p.good else null) { taskTap(tk, st, mine, inGroup) })
        }
        if (owner) rows.add(Ui.row(this, R.drawable.ui_spark, "blue", t("Post a task"), null) { postTaskDialog() })
        if (rows.isEmpty()) page.addView(Ui.text(this, t("No tasks on the board right now."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), 0, 0, 0) })
        else page.addView(Ui.group(this, rows))
        page.addView(Ui.text(this, t("First to take a task gets it. It's locked to them until they finish, give it up, or run out of time."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })
    }

    private fun postTaskDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(6), d(20), 0) }
        val title = field(t("What needs doing (e.g. Take out the trash)"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        val coins = field(t("Coin reward"), "30", InputType.TYPE_CLASS_NUMBER)
        val hours = field(t("Hours to finish once taken"), "24", InputType.TYPE_CLASS_NUMBER)
        col.addView(title); col.addView(coins); col.addView(hours)
        AlertDialog.Builder(this).setTitle(t("Post a task")).setView(col)
            .setPositiveButton(t("Post")) { _, _ ->
                val tt = title.text.toString().trim(); if (tt.isEmpty()) return@setPositiveButton
                Backend.postTask(code, tt, (coins.text.toString().toIntOrNull() ?: 30).coerceIn(1, 100000), (hours.text.toString().toIntOrNull() ?: 24).coerceIn(1, 24 * 30)) { ok ->
                    Toast.makeText(this, t(if (ok) "Posted" else "Couldn't save. Check your connection."), Toast.LENGTH_SHORT).show(); load()
                }
            }.setNegativeButton(t("Cancel"), null).show()
    }

    private fun taskTap(tk: Backend.Doc, st: String, mine: Boolean, inGroup: Boolean) {
        val dt = tk.data
        val title = str(dt, "title"); val coins = num(dt, "coins"); val hours = num(dt, "hours")
        if (owner) {
            val b = AlertDialog.Builder(this).setTitle(title)
            val info = "+$coins " + t("coins") + "\n" + when (st) {
                "open" -> t("Open — waiting for someone to take it.")
                "claimed" -> str(dt, "byName") + " · " + left((dt["until"] as? Number)?.toLong() ?: 0L)
                "submitted" -> str(dt, "byName") + " " + t("says it's done. Approve to pay the coins.")
                "approved" -> t("Approved — coins land on their phone next time it opens.")
                else -> t("Done") + " ✓ " + str(dt, "byName")
            }
            val pic = if (st == "submitted") Groups.decodeThumb(dt["thumb"] as? String) else null
            if (pic != null) b.setView(ImageView(this).apply { setImageBitmap(pic); adjustViewBounds = true; setPaddingRelative(d(20), d(8), d(20), 0) })
            b.setMessage(info)
            when (st) {
                "submitted" -> {
                    b.setPositiveButton(t("Approve")) { _, _ -> Backend.updateTask(code, tk.id, mapOf("state" to "approved")) { load() } }
                    b.setNeutralButton(t("Send back")) { _, _ -> Backend.updateTask(code, tk.id, mapOf("state" to "claimed", "until" to System.currentTimeMillis() + hours * 3600_000L)) { load() } }
                }
                "claimed" -> b.setNeutralButton(t("Reopen it")) { _, _ -> Backend.updateTask(code, tk.id, mapOf("state" to "open", "by" to "", "byName" to "", "until" to 0L)) { load() } }
            }
            b.setNegativeButton(t("Delete")) { _, _ -> Backend.deleteTask(code, tk.id) { load() } }
            b.show(); return
        }
        if (!inGroup) return
        when {
            st == "open" -> AlertDialog.Builder(this).setTitle(title)
                .setMessage("+$coins " + t("coins") + "\n\n" + (if (Lang.isHebrew(this)) "יהיו לך $hours שעות לסיים. בזמן הזה אף אחד אחר לא יכול לקחת אותה." else "You'll have $hours hours to finish it. Nobody else can take it meanwhile."))
                .setPositiveButton(t("Take it")) { _, _ ->
                    Backend.claimTask(code, tk.id, myMid(), Profiles.current(this).optString("name")) { r ->
                        Toast.makeText(this, when (r) { "OK" -> t("It's yours! ✅"); "ERR" -> t("Couldn't save. Check your connection."); else -> t("Someone was faster:") + " " + r }, Toast.LENGTH_LONG).show()
                        load()
                    }
                }.setNegativeButton(t("Cancel"), null).show()
            mine && st == "claimed" -> AlertDialog.Builder(this).setTitle(title)
                .setMessage("+$coins " + t("coins") + " · " + left((dt["until"] as? Number)?.toLong() ?: 0L))
                .setPositiveButton(t("I finished it")) { _, _ -> submitTask(tk.id, title) }
                .setNeutralButton(t("Give it up")) { _, _ ->
                    Backend.updateTask(code, tk.id, mapOf("state" to "open", "by" to "", "byName" to "", "until" to 0L)) { load() }
                }.setNegativeButton(t("Close"), null).show()
            else -> AlertDialog.Builder(this).setTitle(title).setMessage(
                when (st) {
                    "claimed" -> str(dt, "byName") + " " + t("has it.") + " " + t("It opens again if they give it up or run out of time") + " (" + left((dt["until"] as? Number)?.toLong() ?: 0L) + ")."
                    "submitted" -> t("Waiting for OK")
                    else -> t("Done") + " ✓"
                }).setPositiveButton(t("OK"), null).show()
        }
    }

    /** Attach one of your recent wins as proof and hand the task in. */
    private fun submitTask(id: String, title: String) {
        val g = Progress.gallery(this)
        val wins = ArrayList<org.json.JSONObject>()
        var i = g.length() - 1
        while (i >= 0 && wins.size < 10) { g.optJSONObject(i)?.let { wins.add(it) }; i-- }
        if (wins.isEmpty()) {
            AlertDialog.Builder(this).setTitle(title).setMessage(t("Finish it first with Checkpoint or a photo check, then come back and attach it as proof."))
                .setPositiveButton(t("OK"), null).show(); return
        }
        AlertDialog.Builder(this).setTitle(t("Which task was it?"))
            .setItems(wins.map { it.optString("task").ifBlank { t("Task") } + " · " + ago(it.optLong("time")) }.toTypedArray()) { _, w ->
                Thread {
                    val pic = Groups.thumb(this, wins[w].optString("file"))
                    runOnUiThread {
                        Backend.updateTask(code, id, mapOf("state" to "submitted", "thumb" to pic)) { ok ->
                            Toast.makeText(this, t(if (ok) "Sent for approval ✅" else "Couldn't save. Check your connection."), Toast.LENGTH_SHORT).show(); load()
                        }
                    }
                }.start()
            }.setNegativeButton(t("Cancel"), null).show()
    }
}
