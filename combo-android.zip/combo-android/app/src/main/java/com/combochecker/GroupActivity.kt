package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import org.json.JSONObject

/** One group: members/students, activity feed, approvals and (for the owner) management. */
class GroupActivity : Activity() {
    private var code = ""
    private var info: Map<String, Any?>? = null
    private var members: List<Backend.Doc> = emptyList()
    private var feed: List<Backend.Doc> = emptyList()
    private var pending: List<Backend.Doc> = emptyList()
    private var owner = false
    private var tab = 0
    private var loaded = false

    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)
    private fun num(m: Map<String, Any?>, k: String) = (m[k] as? Number)?.toInt() ?: 0
    private fun str(m: Map<String, Any?>, k: String) = m[k] as? String ?: ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        code = intent.getStringExtra("code") ?: ""
        render()
    }

    override fun onResume() { super.onResume(); load() }

    private fun load() {
        Backend.groupInfo(code) { gi ->
            if (isFinishing) return@groupInfo
            info = gi
            if (gi == null) { loaded = true; render(); return@groupInfo }
            owner = gi["owner"] == Backend.uidNow()
            Backend.listMembers(code) { ms ->
                members = (ms ?: emptyList()).sortedByDescending { num(it.data, "weekPoints") }
                Backend.listFeed(code, 40) { fs ->
                    feed = fs ?: emptyList()
                    if (owner) Backend.listPending(code) { ps -> pending = ps ?: emptyList(); loaded = true; render() }
                    else { loaded = true; render() }
                }
            }
        }
    }

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val gi = info
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(14), 0, 0, 0) }
        col.addView(Ui.text(this, gi?.let { str(it, "name") } ?: code, 24f, p.ink).apply { maxLines = 1 })
        if (gi != null) col.addView(Ui.text(this, Groups.typeLabel(this, str(gi, "type")) + " · " + members.size + " " + t("members"), 13f, p.muted, bold = false))
        head.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        head.addView(Ui.iconButton(this, R.drawable.ui_reset, t("Refresh")) { load() })
        page.addView(head)

        if (!loaded) {
            page.addView(Ui.text(this, t("Loading…"), 15f, p.muted, bold = false).apply { setPaddingRelative(0, d(24), 0, 0) })
            show(page); return
        }
        if (gi == null) {
            page.addView(Ui.text(this, t("Couldn't load this group. It may have been deleted, or you're offline."), 15f, p.muted, bold = false).apply { setPaddingRelative(0, d(24), 0, d(12)) })
            page.addView(Ui.button(this, t("Remove it from my list"), R.drawable.ui_trash, p.track, p.danger) {
                Groups.leave(this, code); Groups.removeOwned(this, code); finish()
            })
            show(page); return
        }

        // join code
        val codeCard = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(16), d(12), d(12), d(12)) }
        val cc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cc.addView(Ui.text(this, t("Join code"), 12f, p.muted, bold = false))
        cc.addView(Ui.text(this, code, 22f, p.accentInk).apply { typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD); setTextIsSelectable(true) })
        codeCard.addView(cc, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        codeCard.addView(Ui.button(this, t("Share"), R.drawable.ui_share, p.accentSoft, p.accentInk, 42) { shareCode(str(gi, "name")) })
        page.addView(codeCard, Ui.lp(this, 16))

        // news
        val news = str(gi, "news")
        if (news.isNotBlank()) page.addView(Ui.card(this).apply {
            setPaddingRelative(d(16), d(12), d(16), d(14))
            val h = LinearLayout(this@GroupActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            h.addView(Ui.tile(this@GroupActivity, R.drawable.ui_megaphone, "orange"))
            h.addView(Ui.text(this@GroupActivity, t("News"), 15f, p.ink).apply { setPaddingRelative(d(10), 0, 0, 0) })
            addView(h)
            addView(Ui.text(this@GroupActivity, news, 15f, p.ink, bold = false).apply { setPaddingRelative(0, d(8), 0, 0) })
        }, Ui.lp(this, 10))

        // team goal
        val target = num(gi, "goalTarget")
        if (target > 0) {
            val sum = members.sumOf { num(it.data, "weekPoints") }
            page.addView(Ui.card(this).apply {
                setPaddingRelative(d(16), d(12), d(16), d(14))
                val h = LinearLayout(this@GroupActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                h.addView(Ui.tile(this@GroupActivity, R.drawable.ui_target, "green"))
                h.addView(Ui.text(this@GroupActivity, t("Team goal") + ": " + str(gi, "goalTitle").ifBlank { t("this week") }, 15f, p.ink).apply { setPaddingRelative(d(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                h.addView(Ui.text(this@GroupActivity, "$sum / $target", 14f, if (sum >= target) p.good else p.muted))
                addView(h)
                addView(Ui.bar(this@GroupActivity, sum.toFloat() / target, Ui.tone(this@GroupActivity, "green").second, p.track), Ui.lp(this@GroupActivity, 10))
                addView(Ui.text(this@GroupActivity, t(if (sum >= target) "Goal reached! 🎉" else "Points everyone earned in the last 7 days."), 12f, p.muted, bold = false).apply { setPaddingRelative(0, d(6), 0, 0) })
            }, Ui.lp(this, 10))
        }

        val tabs = if (owner) listOf(t(if (str(gi, "type") == "class") "Students" else "Members"), t("Approvals") + if (pending.isNotEmpty()) " (${pending.size})" else "", t("Activity"), t("Manage"))
                   else listOf(t("Members"), t("Activity"))
        if (tab >= tabs.size) tab = 0
        page.addView(Ui.segmented(this, tabs, tab) { tab = it; render() }, Ui.lp(this, 16))
        val key = if (owner) listOf("members", "approvals", "feed", "manage")[tab] else listOf("members", "feed")[tab]
        when (key) {
            "members" -> membersTab(page)
            "approvals" -> approvalsTab(page)
            "feed" -> feedTab(page)
            else -> manageTab(page, gi)
        }
        show(page)
    }

    private fun show(page: View) {
        val p = Ui.pal(this)
        val old = (findViewById<View>(android.R.id.content) as? android.view.ViewGroup)?.getChildAt(0) as? ScrollView
        val y = old?.scrollY ?: 0
        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) }
        setContentView(scroll)
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun ago(ms: Long): String {
        if (ms <= 0) return t("never")
        val mins = (System.currentTimeMillis() - ms) / 60000
        val he = Lang.isHebrew(this)
        return when {
            mins < 1 -> if (he) "עכשיו" else "just now"
            mins < 60 -> if (he) "לפני $mins דק׳" else "${mins}m ago"
            mins < 1440 -> if (he) "לפני ${mins / 60} שע׳" else "${mins / 60}h ago"
            else -> if (he) "לפני ${mins / 1440} ימים" else "${mins / 1440}d ago"
        }
    }

    private fun membersTab(page: LinearLayout) {
        val p = Ui.pal(this)
        if (members.isEmpty()) {
            page.addView(Ui.text(this, t("No one has joined yet. Share the join code."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(16), 0, 0) })
        } else {
            val rows = ArrayList<View>()
            members.forEachIndexed { i, m ->
                val dta = m.data
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(14), d(10), d(14), d(10)) }
                r.addView(Ui.text(this, (i + 1).toString(), 14f, p.muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(d(26), Ui.WRAP))
                r.addView(Ui.avatar(this, JSONObject().put("emoji", str(dta, "emoji")).put("color", str(dta, "color").ifEmpty { "#3a66d6" }), 38))
                val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
                c.addView(Ui.text(this, str(dta, "name"), 15f, p.ink).apply { maxLines = 1 })
                val today = num(dta, "today"); val goal = maxOf(1, num(dta, "goal"))
                val line = t("Lv") + " " + num(dta, "level") + " · " + t("today") + " $today/$goal · " + ago((dta["lastWin"] as? Number)?.toLong() ?: 0L)
                c.addView(Ui.text(this, line, 12f, if (today >= goal) p.good else p.muted, bold = false).apply { maxLines = 1 })
                r.addView(c, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
                v.addView(Ui.text(this, num(dta, "weekPoints").toString(), 15f, p.ink))
                v.addView(Ui.text(this, t("pts / week"), 11f, p.muted, bold = false))
                r.addView(v)
                r.isClickable = true; Ui.ripple(this, r)
                r.setOnClickListener { memberDialog(m) }
                rows.add(r)
            }
            page.addView(Ui.group(this, rows), Ui.lp(this, 12))
        }
        if (!owner) page.addView(Ui.button(this, t("Leave group"), null, p.track, p.danger, 44) {
            AlertDialog.Builder(this).setTitle(t("Leave group?"))
                .setPositiveButton(t("Leave")) { _, _ -> Groups.leave(this, code); finish() }
                .setNegativeButton(t("Cancel"), null).show()
        }, Ui.lp(this, 16))
    }

    private fun memberDialog(m: Backend.Doc) {
        val dta = m.data
        val name = str(dta, "name")
        val myMid = Groups.memberId(Profiles.currentId(this))
        val msg = t("Level") + " " + num(dta, "level") + " · " + num(dta, "total") + " " + t("points") + "\n" +
            t("This week") + ": " + num(dta, "weekTasks") + " " + t("tasks") + ", " + num(dta, "weekPoints") + " " + t("points") + "\n" +
            t("Today") + ": " + num(dta, "today") + "/" + num(dta, "goal") + "\n" +
            t("Last win") + ": " + ago((dta["lastWin"] as? Number)?.toLong() ?: 0L)
        val b = AlertDialog.Builder(this).setTitle(str(dta, "emoji") + "  " + name).setMessage(msg)
        val inGroup = Groups.find(this, code) != null
        if (m.id != myMid && (inGroup || owner)) b.setPositiveButton(t("Send a high-five 🙌")) { _, _ ->
            if (inGroup) Groups.highFive(this, code, m.id, name)
            else Backend.postFeed(code, mapOf("type" to "highfive", "mid" to "owner", "name" to t("Teacher"), "emoji" to "🍎", "to" to m.id, "toName" to name))
            Toast.makeText(this, t("High-five sent!"), Toast.LENGTH_SHORT).show()
        }
        if (owner) b.setNeutralButton(t("Remove")) { _, _ ->
            AlertDialog.Builder(this).setTitle(t("Remove") + " " + name + "?")
                .setPositiveButton(t("Remove")) { _, _ -> Backend.removeMember(code, m.id) { load() } }
                .setNegativeButton(t("Cancel"), null).show()
        }
        b.setNegativeButton(t("Close"), null).show()
    }

    private fun approvalsTab(page: LinearLayout) {
        val p = Ui.pal(this)
        if (info?.get("approvals") != true) page.addView(Ui.text(this, t("Approvals are off for this group. Turn them on in Manage."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), 0, 0) })
        if (pending.isEmpty()) { page.addView(Ui.text(this, t("Nothing waiting."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), 0, 0) }); return }
        for (pd in pending) {
            val dta = pd.data
            val c = Ui.card(this)
            Groups.decodeThumb(dta["thumb"] as? String)?.let { bmp ->
                c.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(p.track) },
                    LinearLayout.LayoutParams(Ui.MATCH, d(180)))
            }
            val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(16), d(12), d(16), d(14)) }
            inner.addView(Ui.text(this, str(dta, "task").ifBlank { t("Task") }, 16f, p.ink))
            inner.addView(Ui.text(this, str(dta, "emoji") + " " + str(dta, "name") + " · " + num(dta, "coins") + " " + t("coins") +
                (if (dta["study"] == true) " · " + t("study") else "") + " · " + ago((dta["ts"] as? Number)?.toLong() ?: 0L), 13f, p.muted, bold = false))
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(Ui.button(this, t("Approve"), R.drawable.ui_check, Ui.tone(this, "green").first, p.good, 44) { decide(pd.id, "approved") },
                LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginEnd = d(5) })
            btns.addView(Ui.button(this, t("Reject"), R.drawable.ui_trash, Ui.tone(this, "red").first, p.danger, 44) { decide(pd.id, "rejected") },
                LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = d(5) })
            inner.addView(btns, Ui.lp(this, 12))
            c.addView(inner)
            page.addView(c, Ui.lp(this, 12))
        }
        if (pending.size > 1) page.addView(Ui.button(this, t("Approve all"), R.drawable.ui_check, p.accent, Color.WHITE) {
            for (pd in pending) Backend.setPendingStatus(code, pd.id, "approved")
            Toast.makeText(this, t("Approved"), Toast.LENGTH_SHORT).show()
            pending = emptyList(); render()
        }, Ui.lp(this, 12))
    }

    private fun decide(id: String, status: String) {
        Backend.setPendingStatus(code, id, status) { ok ->
            Toast.makeText(this, t(if (!ok) "Couldn't save. Check your connection." else if (status == "approved") "Approved" else "Rejected"), Toast.LENGTH_SHORT).show()
            if (ok) { pending = pending.filter { it.id != id }; render() }
        }
    }

    private fun feedTab(page: LinearLayout) {
        val p = Ui.pal(this)
        if (feed.isEmpty()) { page.addView(Ui.text(this, t("No activity yet."), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(14), 0, 0) }); return }
        for (f in feed) {
            val dta = f.data
            val c = Ui.card(this)
            val isWin = dta["type"] == "win"
            if (isWin) Groups.decodeThumb(dta["thumb"] as? String)?.let { bmp ->
                c.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(p.track) },
                    LinearLayout.LayoutParams(Ui.MATCH, d(150)))
            }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(14), d(10), d(14), d(10)) }
            r.addView(Ui.tile(this, if (isWin) R.drawable.ui_trophy else R.drawable.ui_spark, if (isWin) "gold" else "purple"))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
            val who = str(dta, "emoji") + " " + str(dta, "name")
            col.addView(Ui.text(this, if (isWin) who + " · " + str(dta, "task").ifBlank { t("Task") } else who + " → " + str(dta, "toName") + " 🙌", 14f, p.ink).apply { maxLines = 2 })
            col.addView(Ui.text(this, (if (isWin) "+" + num(dta, "points") + " " + t("pts") + " · " else t("High-five") + " · ") + ago((dta["ts"] as? Number)?.toLong() ?: 0L), 12f, p.muted, bold = false))
            r.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            c.addView(r)
            page.addView(c, Ui.lp(this, 10))
        }
    }

    private fun field(hintText: String, value: String, type: Int) = EditText(this).apply { hint = hintText; inputType = type; setText(value) }
    private fun boxed(v: View) = FrameLayout(this).apply { setPaddingRelative(d(20), d(6), d(20), 0); addView(v) }

    private fun manageTab(page: LinearLayout, gi: Map<String, Any?>) {
        val p = Ui.pal(this)
        val isClass = str(gi, "type") == "class"
        page.addView(Ui.sectionTitle(this, t("Group")))
        page.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_megaphone, "orange", t("Post news"), str(gi, "news").ifBlank { t("None") }) {
                val f = field(t("A message everyone sees"), str(gi, "news"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                AlertDialog.Builder(this).setTitle(t("Post news")).setView(boxed(f))
                    .setPositiveButton(t("Post")) { _, _ -> save(mapOf("news" to f.text.toString().trim())) }
                    .setNeutralButton(t("Clear")) { _, _ -> save(mapOf("news" to "")) }
                    .setNegativeButton(t("Cancel"), null).show()
            },
            Ui.row(this, R.drawable.ui_target, "green", t("Team goal"), if (num(gi, "goalTarget") > 0) num(gi, "goalTarget").toString() + " " + t("pts") else t("None")) {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(6), d(20), 0) }
                val title = field(t("Reward / title (e.g. Pizza party)"), str(gi, "goalTitle"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
                val target = field(t("Points the whole group needs in 7 days"), if (num(gi, "goalTarget") > 0) num(gi, "goalTarget").toString() else "", InputType.TYPE_CLASS_NUMBER)
                col.addView(title); col.addView(target)
                AlertDialog.Builder(this).setTitle(t("Team goal")).setView(col)
                    .setPositiveButton(t("Save")) { _, _ -> save(mapOf("goalTitle" to title.text.toString().trim(), "goalTarget" to (target.text.toString().toIntOrNull() ?: 0))) }
                    .setNeutralButton(t("Clear")) { _, _ -> save(mapOf("goalTitle" to "", "goalTarget" to 0)) }
                    .setNegativeButton(t("Cancel"), null).show()
            },
            Ui.switchRow(this, R.drawable.ui_check, "blue", t("Approvals"), t("Coins wait for your OK before they land"), gi["approvals"] == true) { on -> save(mapOf("approvals" to on), quiet = true) },
            Ui.row(this, R.drawable.ui_layout, "gray", t("Rename"), str(gi, "name")) {
                val f = field(t("Name"), str(gi, "name"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
                AlertDialog.Builder(this).setTitle(t("Rename")).setView(boxed(f))
                    .setPositiveButton(t("Save")) { _, _ -> val n = f.text.toString().trim(); if (n.isNotEmpty()) save(mapOf("name" to n)) }
                    .setNegativeButton(t("Cancel"), null).show()
            }
        )))

        page.addView(Ui.sectionTitle(this, t(if (isClass) "Students" else "Members")))
        page.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_users, "purple", t("Add profiles on this device"), null) { bulkAddDialog() },
            Ui.row(this, R.drawable.ui_file, "teal", t("Share a progress report"), null) { shareReport(gi) }
        )))
        page.addView(Ui.text(this, t("“Add profiles on this device” is for a shared class tablet: type one name per line and each gets a profile already in this group."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })

        page.addView(Ui.button(this, t("Delete group"), R.drawable.ui_trash, p.track, p.danger, 46) {
            AlertDialog.Builder(this).setTitle(t("Delete group?")).setMessage(t("Members will no longer see it. This can't be undone."))
                .setPositiveButton(t("Delete")) { _, _ ->
                    Backend.ensureUid { com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("groups").document(code).delete() }
                    Groups.removeOwned(this, code); Groups.leave(this, code); finish()
                }
                .setNegativeButton(t("Cancel"), null).show()
        }, Ui.lp(this, 20))
    }

    private fun save(fields: Map<String, Any?>, quiet: Boolean = false) {
        Backend.updateGroup(code, fields) { ok ->
            if (!quiet || !ok) Toast.makeText(this, t(if (ok) "Saved" else "Couldn't save. Check your connection."), Toast.LENGTH_SHORT).show()
            load()
        }
    }

    private fun bulkAddDialog() {
        val f = field(t("One name per line"), "", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_WORDS).apply { minLines = 4 }
        AlertDialog.Builder(this).setTitle(t("Add profiles on this device")).setView(boxed(f))
            .setPositiveButton(t("Add")) { _, _ ->
                val names = f.text.toString().split("\n").map { it.trim() }.filter { it.isNotEmpty() }.take(60)
                if (names.isEmpty()) return@setPositiveButton
                val emojis = listOf("⭐", "🚀", "🐱", "🐶", "🦄", "🐧", "🦊", "🐉", "🎈", "🎮", "🌟", "🔥")
                val colors = listOf("#3a66d6", "#2a7d46", "#D62F9B", "#E8491D", "#6A2FE8", "#E8B500", "#0a9cc0", "#c0392b")
                var done = 0
                names.forEachIndexed { i, n ->
                    val pid = Profiles.add(this, n, emojis[i % emojis.size], colors[i % colors.size])
                    Groups.join(this, code, pid) { _, _ -> done++; if (done == names.size) { Toast.makeText(this, t("Added") + " ${names.size}", Toast.LENGTH_SHORT).show(); load() } }
                }
            }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun shareCode(name: String) {
        val msg = (if (Lang.isHebrew(this)) "הצטרפו ל־\"$name\" ב‑Comboed: אני ← קבוצות ← הצטרפות עם קוד, והקלידו " else "Join \"$name\" on Comboed: Me → Groups → Join with a code, and type ") + code +
            "\nhttps://github.com/alonhasfri/combo-checker/releases/latest"
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), t("Share"))) } catch (e: Exception) {}
    }

    private fun shareReport(gi: Map<String, Any?>) {
        val sb = StringBuilder()
        sb.append(str(gi, "name")).append(" — ").append(t("weekly report")).append("\n\n")
        for (m in members) {
            val dta = m.data
            sb.append(str(dta, "emoji")).append(" ").append(str(dta, "name")).append(": ")
                .append(num(dta, "weekTasks")).append(" ").append(t("tasks")).append(", ")
                .append(num(dta, "weekPoints")).append(" ").append(t("pts")).append(", ")
                .append(t("Lv")).append(" ").append(num(dta, "level")).append(", ")
                .append(t("last win")).append(" ").append(ago((dta["lastWin"] as? Number)?.toLong() ?: 0L)).append("\n")
        }
        val quiet = members.filter { num(it.data, "weekTasks") == 0 }
        if (quiet.isNotEmpty()) sb.append("\n").append(t("No tasks this week:")).append(" ").append(quiet.joinToString(", ") { str(it.data, "name") })
        try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, sb.toString()), t("Share"))) } catch (e: Exception) {}
    }
}
