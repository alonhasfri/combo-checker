package com.combochecker

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class BubbleService : Service() {

    companion object {
        const val ACTION_STOP = "com.combochecker.STOP"

        @Volatile
        var instance: BubbleService? = null

        /** Show or hide the floating star (hidden while capturing so it isn't in the screenshot). */
        fun setBubbleVisible(visible: Boolean) {
            val s = instance ?: return
            s.handler.post {
                s.bubble?.let { b ->
                    if (visible) s.applyStarSkin(b)
                    val wasHidden = b.visibility != View.VISIBLE
                    b.visibility = if (visible) View.VISIBLE else View.GONE
                    if (visible && wasHidden) b.animateCheck() // back after a check: draw the check in
                }
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var bubble: CheckpointView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification(this, "Tap Checkpoint to check a task", true)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        instance = this
        val b = bubble
        if (b == null) {
            addBubble()
        } else if (b.parent == null) {
            runCatching { wm.removeView(b) }
            bubble = null
            addBubble()
        } else {
            b.visibility = View.VISIBLE
            applyStarSkin(b) // pick up a style bought while Checkpoint was running
        }
        return START_STICKY
    }

    private fun addBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val d = resources.displayMetrics
        val size = (56 * d.density).toInt()

        val view = CheckpointView(this).apply {
            alpha = 0.8f
            elevation = 6 * d.density
            contentDescription = "Checkpoint"
        }
        applyStarSkin(view)

        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = d.widthPixels - size - (16 * d.density).toInt()
            y = (d.heightPixels * 0.35).toInt()
        }

        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var dragging = false
        val slop = 12 * d.density

        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    dragging = false
                    view.alpha = 1f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) dragging = true
                    if (dragging) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(view, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    view.alpha = 0.8f
                    if (!dragging) onTap()
                    true
                }
                else -> false
            }
        }

        wm.addView(view, lp)
        bubble = view
    }

    fun applyStarSkin(view: CheckpointView) {
        // The current profile's save (state__<profileId>), not the old pre-profiles "state" key.
        val raw = getSharedPreferences("combo", MODE_PRIVATE).getString(Profiles.stateKey(this), "") ?: ""
        val st = try { if (raw.isBlank()) org.json.JSONObject() else org.json.JSONObject(raw) } catch (e: Exception) { org.json.JSONObject() }
        view.colors = Checkpoint.colorsFor(st.optString("star", "star_default"))
        view.lit = Checkpoint.litFor(st)
    }

    private fun onTap() {
        // Start the capture flow first (needs a visible overlay to be allowed from the background), then hide the star.
        startActivity(
            Intent(this, CaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        handler.postDelayed({ bubble?.visibility = View.GONE }, 100)
    }

    override fun onDestroy() {
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        instance = null
        super.onDestroy()
    }
}
