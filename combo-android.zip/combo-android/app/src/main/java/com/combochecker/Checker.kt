package com.combochecker

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.max
import kotlin.math.min

/** Sends the circled crop to Claude and returns the result as a JSON string. Never throws. */
object Checker {

    fun check(
        ctx: Context,
        task: String,
        profileJson: String,
        shot: Bitmap,
        fx: Double, fy: Double, fw: Double, fh: Double
    ): String {
        return try {
            val profile = JSONObject(profileJson)
            val key = ctx.getSharedPreferences("combo", Context.MODE_PRIVATE)
                .getString("key", "")?.trim().orEmpty()
            if (key.isEmpty()) return mock(profile).toString()

            val crop = cropBitmap(shot, fx, fy, fw, fh)
            val out = ByteArrayOutputStream()
            crop.compress(Bitmap.CompressFormat.JPEG, 85, out)
            val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)

            val bonuses = profile.getJSONArray("bonuses")
            val lines = StringBuilder()
            for (i in 0 until bonuses.length()) {
                val b = bonuses.getJSONObject(i)
                lines.append("- ${b.getString("name")}: ${b.getString("rule")}\n")
            }
            val prompt = """You are a strict but fair task checker. The image is a screenshot crop that the user circled as proof.
Task the user says they finished: "${task.ifBlank { "(not specified)" }}"

1. Decide whether the image shows convincing evidence the task is done.
2. Judge each bonus using only what is visible. Earn a bonus only if its rule is clearly met. If done is false, earn none.

Bonuses:
$lines
Reply with ONLY this JSON, no other text:
{"done": true or false, "bonuses": [{"name": "...", "earned": true or false}], "comment": "one short sentence explaining the verdict"}"""

            // Google AI Studio keys start with "AIza": use the free Gemini API for those.
            if (key.startsWith("AIza")) return geminiCall(ctx, key, prompt, b64)

            val body = JSONObject()
                .put("model", "claude-sonnet-5-5")
                .put("max_tokens", 600)
                .put(
                    "messages", JSONArray().put(
                        JSONObject()
                            .put("role", "user")
                            .put(
                                "content", JSONArray()
                                    .put(
                                        JSONObject().put("type", "image").put(
                                            "source", JSONObject()
                                                .put("type", "base64")
                                                .put("media_type", "image/jpeg")
                                                .put("data", b64)
                                        )
                                    )
                                    .put(JSONObject().put("type", "text").put("text", prompt))
                            )
                    )
                )

            val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                .bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                return JSONObject().put("error", "API error $code: ${text.take(200)}").toString()
            }

            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val c = content.getJSONObject(i)
                if (c.optString("type") == "text") sb.append(c.getString("text"))
            }
            val reply = sb.toString()
            val s = reply.indexOf('{')
            val e = reply.lastIndexOf('}')
            if (s == -1 || e == -1) return JSONObject().put("error", "No JSON in model reply").toString()
            JSONObject(reply.substring(s, e + 1)).toString()
        } catch (e: Exception) {
            JSONObject().put("error", e.message ?: e.toString()).toString()
        }
    }

    /** Same check, but through Google's Gemini API (has a free tier, no card needed). */
    private fun geminiCall(ctx: Context, key: String, prompt: String, b64: String): String {
        val model = ctx.getSharedPreferences("combo", Context.MODE_PRIVATE)
            .getString("gmodel", "")?.trim().orEmpty().ifEmpty { "gemini-2.5-flash" }

        val body = JSONObject()
            .put(
                "contents", JSONArray().put(
                    JSONObject().put(
                        "parts", JSONArray()
                            .put(
                                JSONObject().put(
                                    "inline_data", JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", b64)
                                )
                            )
                            .put(JSONObject().put("text", prompt))
                    )
                )
            )
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader().use { it.readText() }
        if (code == 429) {
            return JSONObject().put("error", "Free limit reached. Wait a minute and try again.").toString()
        }
        if (code !in 200..299) {
            return JSONObject().put("error", "Gemini error $code: ${text.take(200)}").toString()
        }

        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val reply = sb.toString()
        val s = reply.indexOf('{')
        val e = reply.lastIndexOf('}')
        if (s == -1 || e == -1) return JSONObject().put("error", "No JSON in model reply").toString()
        return JSONObject(reply.substring(s, e + 1)).toString()
    }

    private fun cropBitmap(src: Bitmap, fx: Double, fy: Double, fw: Double, fh: Double): Bitmap {
        val x = (fx * src.width).toInt().coerceIn(0, src.width - 1)
        val y = (fy * src.height).toInt().coerceIn(0, src.height - 1)
        val w = (fw * src.width).toInt().coerceIn(1, src.width - x)
        val h = (fh * src.height).toInt().coerceIn(1, src.height - y)
        val cropped = Bitmap.createBitmap(src, x, y, w, h)
        val scale = min(1.0, 1568.0 / max(w, h))
        return if (scale < 1.0) {
            Bitmap.createScaledBitmap(cropped, (w * scale).toInt(), (h * scale).toInt(), true)
        } else cropped
    }

    /** Test mode when no API key is saved: random bonuses so the animation can be tried. */
    private fun mock(profile: JSONObject): JSONObject {
        val bonuses = profile.getJSONArray("bonuses")
        val arr = JSONArray()
        for (i in 0 until bonuses.length()) {
            arr.put(
                JSONObject()
                    .put("name", bonuses.getJSONObject(i).getString("name"))
                    .put("earned", Math.random() > 0.3)
            )
        }
        return JSONObject()
            .put("done", true)
            .put("bonuses", arr)
            .put("comment", "Test mode: save an API key in the app for real checks.")
    }
}
