package com.combochecker

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Sends the circled crop to Claude and returns the result as a JSON string. Never throws. */
object Checker {

    /**
     * Full check: anti-cheat (same proof twice), the model call, and saving winning proofs for the gallery.
     * Never throws; errors come back as {"error": "..."}.
     */
    fun check(
        ctx: Context,
        task: String,
        profileJson: String,
        shot: Bitmap,
        fx: Double, fy: Double, fw: Double, fh: Double,
        extraPages: List<String> = emptyList()
    ): String {
        val prefs = ctx.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val proofsKey = Profiles.proofsKey(ctx)
        val testMode = prefs.getString("key", "")?.trim().orEmpty().isEmpty()
        return try {
            val crop = cropBitmap(shot, fx, fy, fw, fh)
            val thumb = thumbOf(crop)
            val taskKey = task.trim().lowercase()

            // Anti-cheat: the same task with a near-identical proof is refused (only with a real key).
            if (!testMode && isDuplicate(prefs, proofsKey, taskKey, thumb)) {
                return JSONObject()
                    .put("done", false)
                    .put("duplicate", true)
                    .put("bonuses", JSONArray())
                    .put("comment", "You already used this proof for this task. Show something new.")
                    .toString()
            }

            val result = JSONObject(runModel(ctx, task, profileJson, shot, fx, fy, fw, fh, extraPages))
            if (result.optBoolean("done", false) && !result.has("error")) {
                if (!testMode) rememberProof(prefs, proofsKey, taskKey, thumb)
                result.put("proof", saveProofImage(ctx, crop))
            }
            result.toString()
        } catch (e: Exception) {
            JSONObject().put("error", e.message ?: e.toString()).toString()
        }
    }

    // ----- anti-cheat helpers: a tiny 16x16 grey fingerprint of each winning proof -----

    private fun thumbOf(bmp: Bitmap): ByteArray {
        val s = Bitmap.createScaledBitmap(bmp, 16, 16, true)
        val out = ByteArray(256)
        for (y in 0 until 16) {
            for (x in 0 until 16) {
                val p = s.getPixel(x, y)
                val g = (0.299 * Color.red(p) + 0.587 * Color.green(p) + 0.114 * Color.blue(p)).toInt()
                out[y * 16 + x] = g.toByte()
            }
        }
        return out
    }

    private fun isDuplicate(prefs: SharedPreferences, proofsKey: String, taskKey: String, thumb: ByteArray): Boolean {
        val arr = JSONArray(prefs.getString(proofsKey, "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getString("task") != taskKey) continue
            val other = Base64.decode(o.getString("h"), Base64.NO_WRAP)
            if (other.size != thumb.size) continue
            var sum = 0
            for (j in thumb.indices) {
                sum += abs((thumb[j].toInt() and 0xFF) - (other[j].toInt() and 0xFF))
            }
            if (sum / thumb.size.toDouble() <= 3.0) return true
        }
        return false
    }

    private fun rememberProof(prefs: SharedPreferences, proofsKey: String, taskKey: String, thumb: ByteArray) {
        val arr = JSONArray(prefs.getString(proofsKey, "[]"))
        arr.put(
            JSONObject()
                .put("task", taskKey)
                .put("h", Base64.encodeToString(thumb, Base64.NO_WRAP))
        )
        while (arr.length() > 100) arr.remove(0)
        prefs.edit().putString(proofsKey, arr.toString()).apply()
    }

    private fun saveProofImage(ctx: Context, bmp: Bitmap): String {
        val dir = File(ctx.filesDir, "proofs")
        dir.mkdirs()
        val name = "proof_${System.currentTimeMillis()}.jpg"
        FileOutputStream(File(dir, name)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        return name
    }

    private fun runModel(
        ctx: Context,
        task: String,
        profileJson: String,
        shot: Bitmap,
        fx: Double, fy: Double, fw: Double, fh: Double,
        extraPages: List<String>
    ): String {
        return try {
            val profile = JSONObject(profileJson)
            val key = ctx.getSharedPreferences("combo", Context.MODE_PRIVATE)
                .getString("key", "")?.trim().orEmpty()
            if (key.isEmpty()) return mock(profile).toString()

            val crop = cropBitmap(shot, fx, fy, fw, fh)
            val out = ByteArrayOutputStream()
            crop.compress(Bitmap.CompressFormat.JPEG, 85, out)
            val images = ArrayList<String>()
            images.add(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
            for (p in extraPages) {
                try {
                    val page = scaleDown(android.graphics.BitmapFactory.decodeFile(p) ?: continue)
                    val po = ByteArrayOutputStream()
                    page.compress(Bitmap.CompressFormat.JPEG, 85, po)
                    images.add(Base64.encodeToString(po.toByteArray(), Base64.NO_WRAP))
                } catch (e: Exception) {}
            }

            val bonuses = profile.getJSONArray("bonuses")
            val lines = StringBuilder()
            for (i in 0 until bonuses.length()) {
                val b = bonuses.getJSONObject(i)
                lines.append("- ${b.getString("name")}: ${b.getString("rule")}\n")
            }
            val desc = profile.optString("desc", "").trim()
            val descLine = if (desc.isNotEmpty()) "\nWhat the task is: \"$desc\"" else ""
            val hint = profile.optBoolean("hint", false)
            val hintInstr = if (hint) "\n4. For each bonus that is NOT earned, give one short, specific tip on how to earn it next time." else ""
            val tipsField = if (hint) ", \"tips\": [\"short tip\", \"...\"]" else ""
            val prompt = """You are a strict but fair task checker. The images are screenshots the user gave as proof (the first is the circled crop; any others are extra pages of the same work).
Task the user says they finished: "${task.ifBlank { "(not specified)" }}"$descLine

1. Decide whether the image shows convincing evidence the task is done.
2. Judge each bonus using only what is visible. Earn a bonus only if its rule is clearly met. If done is false, earn none.

Bonuses:
$lines
3. Also estimate how likely the shown work (text, image or screen) was generated by AI, or faked or edited to look finished. Use 0 for clearly genuine human work and 100 for clearly AI-made or fake. This is only a rough guess, so be honest about uncertainty and keep the reason short.$hintInstr

Reply with ONLY this JSON, no other text:
{"done": true or false, "bonuses": [{"name": "...", "earned": true or false}], "comment": "one short sentence explaining the verdict", "ai_suspect": {"score": 0 to 100, "reason": "short reason"}$tipsField}"""

            // OpenRouter keys start with "sk-or-": free, OpenAI-compatible vision models.
            if (key.startsWith("sk-or-")) return openRouterCall(ctx, key, prompt, images)
            // Anthropic keys start with "sk-ant"; route those to Claude. Everything else
            // (classic "AIza" keys and the newer "AQ." Gemini auth keys) uses the Gemini API.
            if (!key.startsWith("sk-ant")) return geminiCall(ctx, key, prompt, images)

            val aContent = JSONArray()
            for (b64 in images) {
                aContent.put(
                    JSONObject().put("type", "image").put(
                        "source", JSONObject()
                            .put("type", "base64").put("media_type", "image/jpeg").put("data", b64)
                    )
                )
            }
            aContent.put(JSONObject().put("type", "text").put("text", prompt))
            val body = JSONObject()
                .put("model", "claude-sonnet-5-5")
                .put("max_tokens", 600)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", aContent)))

            val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                .bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                return JSONObject().put("error", "API error $code: ${text.take(200)}").toString()
            }

            val content = JSONObject(text).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                val c = content.getJSONObject(i)
                if (c.optString("type") == "text") sb.append(c.getString("text"))
            }
            val reply = sb.toString()
            val s = reply.indexOf('{')
            val e = reply.lastIndexOf('}')
            if (s == -1 || e == -1) return JSONObject().put("error", "No JSON in model reply").toString()
            JSONObject(reply.substring(s, e + 1)).toString()
        } catch (e: Exception) {
            JSONObject().put("error", e.message ?: e.toString()).toString()
        }
    }

    /** Same check, but through Google's Gemini API (has a free tier, no card needed). */
    private fun geminiCall(ctx: Context, key: String, prompt: String, images: List<String>): String {
        val model = ctx.getSharedPreferences("combo", Context.MODE_PRIVATE)
            .getString("gmodel", "")?.trim().orEmpty().ifEmpty { "gemini-flash-latest" }

        val imgParts = JSONArray()
        for (b64 in images) {
            imgParts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        }
        imgParts.put(JSONObject().put("text", prompt))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", imgParts)))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader().use { it.readText() }
        if (code == 429) {
            return JSONObject().put("error", "Free limit reached. Wait a minute and try again.").toString()
        }
        if (code !in 200..299) {
            return JSONObject().put("error", "Gemini error $code: ${text.take(200)}").toString()
        }

        val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val reply = sb.toString()
        val s = reply.indexOf('{')
        val e = reply.lastIndexOf('}')
        if (s == -1 || e == -1) return JSONObject().put("error", "No JSON in model reply").toString()
        return JSONObject(reply.substring(s, e + 1)).toString()
    }

    /** Same check through OpenRouter's OpenAI-compatible API (free vision models, no card). */
    private fun openRouterCall(ctx: Context, key: String, prompt: String, images: List<String>): String {
        val model = ctx.getSharedPreferences("combo", Context.MODE_PRIVATE)
            .getString("gmodel", "")?.trim().orEmpty()
            .ifEmpty { "nvidia/nemotron-3.5-super-vl:free" }

        val content = JSONArray().put(JSONObject().put("type", "text").put("text", prompt))
        for (b64 in images) {
            content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
        }
        val body = JSONObject()
            .put("model", model)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val conn = URL("https://openrouter.ai/api/v1/chat/completions")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("authorization", "Bearer $key")
        conn.setRequestProperty("http-referer", "https://github.com/alonhasfri/combo-checker")
        conn.setRequestProperty("x-title", "Combo Checker")
        conn.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
            .bufferedReader().use { it.readText() }
        if (code == 429) {
            return JSONObject().put("error", "Free limit reached. Wait a minute and try again.").toString()
        }
        if (code !in 200..299) {
            return JSONObject().put("error", "OpenRouter error $code: ${text.take(200)}").toString()
        }

        val reply = JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content")
        val s = reply.indexOf('{')
        val e = reply.lastIndexOf('}')
        if (s == -1 || e == -1) return JSONObject().put("error", "No JSON in model reply").toString()
        return JSONObject(reply.substring(s, e + 1)).toString()
    }

    private fun scaleDown(src: Bitmap): Bitmap {
        val scale = min(1.0, 1568.0 / max(src.width, src.height))
        return if (scale < 1.0)
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        else src
    }

    private fun cropBitmap(src: Bitmap, fx: Double, fy: Double, fw: Double, fh: Double): Bitmap {
        val x = (fx * src.width).toInt().coerceIn(0, src.width - 1)
        val y = (fy * src.height).toInt().coerceIn(0, src.height - 1)
        val w = (fw * src.width).toInt().coerceIn(1, src.width - x)
        val h = (fh * src.height).toInt().coerceIn(1, src.height - y)
        val cropped = Bitmap.createBitmap(src, x, y, w, h)
        val scale = min(1.0, 1568.0 / max(w, h))
        return if (scale < 1.0) {
            Bitmap.createScaledBitmap(cropped, (w * scale).toInt(), (h * scale).toInt(), true)
        } else cropped
    }

    /** Test mode when no API key is saved: random bonuses so the animation can be tried. */
    private fun mock(profile: JSONObject): JSONObject {
        val bonuses = profile.getJSONArray("bonuses")
        val arr = JSONArray()
        for (i in 0 until bonuses.length()) {
            arr.put(
                JSONObject()
                    .put("name", bonuses.getJSONObject(i).getString("name"))
                    .put("earned", Math.random() > 0.3)
            )
        }
        return JSONObject()
            .put("done", true)
            .put("bonuses", arr)
            .put("comment", "Test mode: save an API key in the app for real checks.")
    }
}
