package com.combochecker

import android.content.Context

/**
 * Prank "voices" that reword the app's text. One can be on at a time (priority Gen Z → Baby →
 * Shakespeare). Each has a small dictionary for the loud menu labels plus a general transform so
 * even un-listed text changes, so the whole app — not just the AI — talks in the voice.
 */
object Voice {
    private fun on(c: Context, key: String) =
        c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean(key, false)

    /** "genz" | "baby" | "shakespeare" | "" */
    fun active(c: Context): String = when {
        on(c, "genz") -> "genz"
        on(c, "baby") -> "baby"
        on(c, "shakespeare") -> "shakespeare"
        else -> ""
    }

    private val genzEmoji = listOf("💔", "✌️", "🥀", "😭")

    private val genzDict = mapOf(
        "▶  Start the floating star" to "▶  deploy the lil guy",
        "Stop floating star" to "kill the star",
        "📷  Check a real-life photo" to "📷  scan ur irl grind",
        "📸  Before & after (clean-up)" to "📸  glow-up check",
        "🛍️  Shop — skins & abilities" to "🛍️  the drip shop",
        "🏆  Proof gallery" to "🧾  ur receipts",
        "📊  Stats & badges" to "📊  the lore & dubs",
        "📅  My week (recap)" to "📅  weekly wrapped",
        "🔊  Sound shop" to "🎧  aux shop",
        "😈  Prank a friend" to "😈  cook an opp",
        "🥇  Leaderboard" to "🥇  who's cracked",
        "Switch profile" to "swap accounts",
        "⚙  Settings & setup" to "⚙  the settings arc",
        "⚙  Hide settings" to "⚙  hide the arc",
        "AI key" to "the robot's password",
        "Save settings" to "lock it in",
        "Feedback" to "spill the tea"
    )
    private val babyDict = mapOf(
        "▶  Start the floating star" to "▶  stawt da wittwe staw",
        "Stop floating star" to "stop da staw",
        "🛍️  Shop — skins & abilities" to "🛍️  da toy stowe",
        "🏆  Proof gallery" to "🏆  my pwetty pics",
        "😈  Prank a friend" to "😈  siwwy fwiend twick",
        "⚙  Settings & setup" to "⚙  da setuppy stuff"
    )
    private val shakeDict = mapOf(
        "▶  Start the floating star" to "▶  Summon yon floating star",
        "Stop floating star" to "Banish the star",
        "📷  Check a real-life photo" to "📷  Judge a portrait from life",
        "📸  Before & after (clean-up)" to "📸  Before & after, a cleansing",
        "🛍️  Shop — skins & abilities" to "🛍️  Ye Olde Shoppe",
        "🏆  Proof gallery" to "🏆  Gallery of Deeds",
        "📊  Stats & badges" to "📊  Chronicles & Honours",
        "📅  My week (recap)" to "📅  Mine week in revue",
        "🔊  Sound shop" to "🔊  Hall of Sounds",
        "😈  Prank a friend" to "😈  Vex a fellow",
        "🥇  Leaderboard" to "🥇  Roll of Champions",
        "Switch profile" to "Change thy guise",
        "⚙  Settings & setup" to "⚙  Ye Settings",
        "⚙  Hide settings" to "⚙  Conceal ye settings",
        "AI key" to "The oracle's key",
        "Goals and checks" to "Quests and judgements",
        "Save settings" to "Preserve thy wishes",
        "Feedback" to "Send word",
        "Appearance" to "Thy raiment",
        "Backup & restore" to "Chronicle & restore",
        "Back up my data" to "Chronicle mine deeds",
        "Hear my cheers" to "Hear mine hurrahs",
        "Delete my recordings" to "Destroy mine recordings",
        "Unlock creator features" to "Unseal hidden arts"
    )

    fun say(c: Context, text: String): String = transform(active(c), text)

    fun transform(voice: String, text: String): String = when (voice) {
        "genz" -> spray(genzDict[text] ?: text)
        "baby" -> babyTalk(babyDict[text] ?: text)
        "shakespeare" -> shakespeare(shakeDict[text] ?: text)
        else -> text
    }

    private fun spray(text: String): String {
        if (text.isBlank()) return text
        return text.trim().split(Regex("(?<=[.!?])\\s+"))
            .joinToString(" ") { it.trim() + " " + genzEmoji.random() }
    }

    /** Baby talk: r/l become w. */
    fun babyTalk(s: String): String =
        s.replace('r', 'w').replace('l', 'w').replace('R', 'W').replace('L', 'W')

    /** Light Shakespeare word-swaps so sentences and labels feel olde. */
    fun shakespeare(s: String): String {
        var out = s
        val swaps = listOf(
            "you're" to "thou art", "your" to "thy", "you" to "thou", "are" to "art",
            "my" to "mine", "the" to "ye", "yes" to "aye", "no" to "nay",
            "hello" to "hark", "please" to "prithee", "friend" to "fellow", "here" to "hither"
        )
        for ((a, b) in swaps) {
            out = Regex("(?i)\\b" + Regex.escape(a) + "\\b").replace(out) { m ->
                if (m.value.firstOrNull()?.isUpperCase() == true) b.replaceFirstChar { it.uppercase() } else b
            }
        }
        return out
    }
}
