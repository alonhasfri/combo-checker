package com.combochecker

import android.content.Context
import kotlin.random.Random

/**
 * Consensual friend pranks as combinable "creator keys". A key looks like an official unlock code
 * (CRK-XXXX-XXXX) but secretly carries a SET of trolls — any mix of persistent modes and one-shot
 * gags. The set is packed into a 40-bit value (5-bit checksum | 12-bit nonce | 23 flag bits),
 * XOR-scrambled and base32-encoded, so a code looks random, varies every time, and a typed-in
 * random string is almost always rejected.
 *
 * IMPORTANT: never reorder or remove entries in [trolls]; a flag's bit is its index. Add new
 * trolls only at the end so old codes keep decoding.
 */
object Pranks {
    /** persist = a mode toggled on (pref key == id); otherwise a one-shot gag played by prank.html. */
    data class Troll(val id: String, val label: String, val persist: Boolean, val implemented: Boolean)

    val trolls = listOf(
        // ---- persistent modes ----
        Troll("genz", "🧠 Gen Z mode", true, true),
        Troll("baby", "🍼 Baby mode", true, true),
        Troll("shakespeare", "🎭 Shakespeare mode", true, true),
        Troll("update", "🔄 Fake “update available”", true, true),
        Troll("gaslight", "😵‍💫 Gaslight mode", true, true),
        Troll("ghostcoins", "🪙 Ghost coins", true, true),
        Troll("stickyrename", "🏷️ Sticky rename", true, true),
        Troll("achievespam", "🏅 Fake achievements", true, true),
        Troll("ads_banner", "🪧 Fake ad banner", true, false),
        Troll("ads_dodge", "❌ Dodging-X ad", true, false),
        Troll("ads_remove", "💸 “Remove ads” troll", true, false),
        Troll("ads_escalate", "📈 Ad escalation", true, false),
        Troll("ads_click", "👆 Clickable ads", true, false),
        // ---- one-shot gags ----
        Troll("confetti", "🎉 Confetti bomb", false, true),
        Troll("fart", "💨 Fart sound", false, true),
        Troll("levelup", "🆙 Fake LEVEL 99", false, true),
        Troll("flip", "🙃 Upside-down screen", false, true),
        Troll("rainbow", "🌈 Rainbow freak-out", false, true),
        Troll("police", "🚨 Police “BUSTED”", false, true),
        Troll("cash", "🤑 “You won $1,000,000!”", false, true),
        Troll("earthquake", "🌍 Screen earthquake", false, true),
        Troll("lovebomb", "😘 Secret admirer", false, true),
        Troll("crack", "💥 Fake cracked screen", false, true)
    )

    val persistentModes get() = trolls.filter { it.persist }

    private val B32 = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"
    private const val SECRET = 0x9E3779B97FL // 40-bit scramble constant
    private const val FLAG_BITS = 23
    private const val NONCE_BITS = 12

    private fun checksum(raw: Long): Int =
        ((raw xor (raw ushr 7) xor (raw ushr 17) xor (raw ushr 29)).toInt()) and 31

    fun flagsFor(ids: Collection<String>): Long {
        var f = 0L
        trolls.forEachIndexed { i, t -> if (ids.contains(t.id)) f = f or (1L shl i) }
        return f
    }

    /** Build a shareable code for a set of troll ids. */
    fun codeFor(ids: Collection<String>): String {
        val flags = flagsFor(ids) and ((1L shl FLAG_BITS) - 1)
        val nonce = Random.nextLong(1L shl NONCE_BITS)
        val raw = (nonce shl FLAG_BITS) or flags
        val value = ((checksum(raw).toLong() shl 35) or raw) xor SECRET
        val sb = StringBuilder()
        for (i in 7 downTo 0) sb.append(B32[((value ushr (i * 5)) and 31L).toInt()])
        val s = sb.toString()
        return "CRK-" + s.substring(0, 4) + "-" + s.substring(4, 8)
    }

    /** Decode a code to its trolls, or null if it isn't a valid creator key. */
    fun decode(code: String): List<Troll>? {
        val up = code.trim().uppercase().replace(" ", "").replace("-", "")
        if (!up.startsWith("CRK")) return null
        val body = up.substring(3)
        if (body.length < 8) return null
        var value = 0L
        for (i in 0 until 8) {
            val idx = B32.indexOf(body[i])
            if (idx < 0) return null
            value = (value shl 5) or idx.toLong()
        }
        val dec = value xor SECRET
        val raw = dec and ((1L shl 35) - 1)
        if (checksum(raw) != ((dec ushr 35) and 31L).toInt()) return null
        val flags = raw and ((1L shl FLAG_BITS) - 1)
        return trolls.filterIndexed { i, _ -> (flags and (1L shl i)) != 0L }
    }

    /** Turn on every persistent mode in the set; return the first one-shot gag id to play, if any. */
    fun applyPersistent(c: Context, set: List<Troll>): String? {
        val e = c.getSharedPreferences("combo", Context.MODE_PRIVATE).edit()
        var gag: String? = null
        for (t in set) {
            if (t.persist) e.putBoolean(t.id, true) else if (gag == null) gag = t.id
        }
        e.apply()
        return gag
    }
}
