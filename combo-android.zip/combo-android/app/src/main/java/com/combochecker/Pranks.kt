package com.combochecker

import kotlin.random.Random

/**
 * Consensual friend pranks. A "creator key" looks like an official unlock code, but it secretly
 * encodes one outcome. The outcome is hidden in the digit-sum of the code (mod 11), so the code
 * looks random and doesn't give the joke away. Outcomes 0-9 are one-shot gags; outcome 10 is the
 * silent "Gen Z mode" that quietly stays on until someone turns it off in Settings.
 */
object Pranks {
    data class Gag(val id: String, val label: String)

    val gags = listOf(
        Gag("confetti", "🎉 Confetti bomb"),
        Gag("fart", "💨 Fart sound"),
        Gag("levelup", "🆙 Fake LEVEL 99"),
        Gag("flip", "🙃 Upside-down screen"),
        Gag("rainbow", "🌈 Rainbow freak-out"),
        Gag("police", "🚨 Police siren “BUSTED”"),
        Gag("cash", "🤑 “You won $1,000,000!”"),
        Gag("earthquake", "🌍 Screen earthquake"),
        Gag("lovebomb", "😘 Secret admirer hearts"),
        Gag("crack", "💥 Fake cracked screen")
    )
    const val GENZ = "genz"
    private const val OUTCOMES = 11 // 10 gags + Gen Z

    /** Make an official-looking code like CRK-4471-8832 for an outcome (0-9 = gag, 10 = Gen Z). */
    fun codeForOutcome(outcome: Int): String {
        val target = ((outcome % OUTCOMES) + OUTCOMES) % OUTCOMES
        while (true) {
            val d = IntArray(8) { Random.nextInt(10) }
            val rest = (0..6).sumOf { d[it] }
            // Need (rest + d[7]) % 11 == target, with d[7] in 0..9.
            val need = ((target - rest) % OUTCOMES + OUTCOMES) % OUTCOMES
            if (need <= 9) {
                d[7] = need
                val s = d.joinToString("")
                return "CRK-" + s.substring(0, 4) + "-" + s.substring(4, 8)
            }
        }
    }

    fun codeForGag(index: Int): String = codeForOutcome(index)
    fun codeForGenZ(): String = codeForOutcome(10)

    /** Decode a typed code to a gag id, "genz", or null if it isn't a valid creator key. */
    fun gagForCode(raw: String): String? {
        val up = raw.trim().uppercase().replace(" ", "")
        if (!up.startsWith("CRK")) return null
        val digits = up.filter { it.isDigit() }
        if (digits.length < 8) return null
        val outcome = digits.sumOf { it - '0' } % OUTCOMES
        return if (outcome == 10) GENZ else gags[outcome].id
    }
}
