package com.combochecker

import kotlin.random.Random

/**
 * Consensual friend pranks. A "creator key" looks like an official unlock code, but it secretly
 * encodes one harmless gag. The gag is hidden in the digit-sum of the code (mod 10), so the code
 * looks random and doesn't give the joke away. There are exactly 10 gags so each sum maps to one.
 */
object Pranks {
    data class Gag(val id: String, val label: String)

    val gags = listOf(
        Gag("confetti", "🎉 Confetti bomb"),
        Gag("fart", "💨 Fart sound"),
        Gag("levelup", "🆙 Fake LEVEL 99"),
        Gag("flip", "🙃 Upside-down screen"),
        Gag("rainbow", "🌈 Rainbow freak-out"),
        Gag("police", "🚨 Police siren “BUSTED”"),
        Gag("cash", "🤑 “You won $1,000,000!”"),
        Gag("earthquake", "🌍 Screen earthquake"),
        Gag("lovebomb", "😘 Secret admirer hearts"),
        Gag("crack", "💥 Fake cracked screen")
    )

    /** Make an official-looking code like CRK-4471-8832 that hides the given gag. */
    fun codeFor(index: Int): String {
        val g = ((index % gags.size) + gags.size) % gags.size
        val d = IntArray(8) { Random.nextInt(10) }
        // Set the last digit so the digit-sum mod 10 equals the gag index.
        val restSum = (0..6).sumOf { d[it] }
        d[7] = ((g - restSum) % 10 + 10) % 10
        val s = d.joinToString("")
        return "CRK-" + s.substring(0, 4) + "-" + s.substring(4, 8)
    }

    /** Decode a typed code back to a gag id, or null if it isn't a valid creator key. */
    fun gagForCode(raw: String): String? {
        val up = raw.trim().uppercase().replace(" ", "")
        if (!up.startsWith("CRK")) return null
        val digits = up.filter { it.isDigit() }
        if (digits.length < 8) return null
        val sum = digits.sumOf { it - '0' }
        return gags[sum % 10].id
    }
}
