package com.combochecker

import android.content.Context

/**
 * Global leaderboard titles. Being in the worldwide top 3 gives "Top 1/2/3"; anyone who held a
 * top-3 spot and dropped out keeps "Retired Top N" (their best spot). The title belongs to the
 * profile this phone publishes to the leaderboard (its highest-scoring profile).
 */
object Titles {
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
    var lastCheck = 0L

    fun medal(n: Int) = when (n) { 1 -> "🥇"; 2 -> "🥈"; else -> "🥉" }

    /** Text for a live spot (n = 1..3) or a retired one. */
    fun label(c: Context, n: Int, retired: Boolean): String {
        val he = Lang.isHebrew(c)
        return if (!retired) medal(n) + (if (he) " מקום $n" else " Top $n")
        else "🎖️ " + (if (he) "מקום $n לשעבר" else "Retired Top $n")
    }

    /** This phone's title for [pid] ("" if none). */
    fun forProfile(c: Context, pid: String = Profiles.currentId(c)): String {
        if (sp(c).getString("lbPid", "") != pid) return ""
        val pos = sp(c).getInt("lbPos", 0); val best = sp(c).getInt("lbBest", 0)
        return when { pos in 1..3 -> label(c, pos, false); best in 1..3 -> label(c, best, true); else -> "" }
    }

    /** Title for someone else's row on the global board (idx = 0-based position). */
    fun forRow(c: Context, idx: Int, bestTop: Int): String = when {
        idx < 3 -> label(c, idx + 1, false)
        bestTop in 1..3 -> label(c, bestTop, true)
        else -> ""
    }

    /** Look at the global top 3 (at most once every 30 min) and update this phone's spot. */
    fun refresh(c: Context, onChanged: () -> Unit) {
        val now = System.currentTimeMillis()
        if (now - lastCheck < 30 * 60 * 1000L) return
        lastCheck = now
        Backend.fetchLeaderboard(3) { rows -> apply(c, rows); onChanged() }
    }

    /** Update from a fetched board (also used by the Ranks screen). */
    fun apply(c: Context, rows: List<Backend.LbRow>) {
        val me = Backend.uidNow() ?: return
        val idx = rows.take(3).indexOfFirst { it.uid == me }
        val pos = if (idx >= 0) idx + 1 else 0
        val e = sp(c).edit().putInt("lbPos", pos)
        val best = sp(c).getInt("lbBest", 0)
        if (pos > 0 && (best == 0 || pos < best)) { e.putInt("lbBest", pos); Backend.setBestTop(pos) }
        e.apply()
    }
}
