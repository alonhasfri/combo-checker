package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** What's in each update (newest first). Each line is English | Hebrew. */
object Changelog {
    class Entry(val title: String, val titleHe: String, val date: String, val items: List<Pair<String, String>>)

    val entries = listOf(
        Entry("v1.4", "גרסה 1.4", "Nov 20", listOf(
            "Gemini AQ. keys: automatic fallback if Google refuses the usual way" to "מפתחות Gemini מסוג AQ.: מעבר אוטומטי לדרך אחרת אם Google מסרבת",
            "\"Test my key\" button in the AI key setup" to "כפתור \"בדיקת המפתח שלי\" בהגדרת מפתח ה‑AI",
            "When Google's AI is busy, the app tries other free Gemini models automatically" to "כשה‑AI של Google עמוס, האפליקציה מנסה אוטומטית מודלים חינמיים אחרים של Gemini",
            "Updates now have version names like v1.4" to "לעדכונים יש עכשיו שמות גרסה כמו v1.4"
        )),
        Entry("v1.3", "גרסה 1.3", "Nov 16", listOf(
            "Built as a proper release version (not a developer build)" to "נבנית כגרסה רשמית (לא גרסת מפתחים)",
            "Two versions: Safe (no pranks, fewer Google warnings) and Full" to "שתי גרסאות: בטוחה (בלי מתיחות, פחות אזהרות של Google) ומלאה"
        )),
        Entry("v1.2", "גרסה 1.2", "Nov 6", listOf(
            "One To-do list on Home: homework, tasks you took, quests" to "רשימת לעשות אחת במסך הבית: שיעורי בית, משימות שלקחת, משימות יומיות",
            "Reminders: homework due tomorrow, 2 hours left on a task" to "תזכורות: שיעורי בית למחר, נשארו שעתיים למשימה",
            "Repeating chores on the task board (daily / weekly)" to "מטלות חוזרות בלוח המשימות (יומי / שבועי)",
            "Smarter coach with tips from your own data" to "מאמן חכם עם טיפים מהנתונים שלך",
            "Family overview at the top of the Parent zone" to "סקירה משפחתית בראש אזור ההורים",
            "Celebrations for new ranks and streaks, with a shareable picture" to "חגיגות לדרגה חדשה ולרצפים, עם תמונה לשיתוף",
            "Short 3-step intro for new users" to "היכרות קצרה ב‑3 צעדים למשתמשים חדשים",
            "Developer tests for every new feature" to "בדיקות מפתח לכל תכונה חדשה",
            "Demo samples + demo mode for showing the app (developer)" to "דוגמאות הדגמה ומצב הדגמה להצגת האפליקציה (מפתח)"
        )),
        Entry("v1.1", "גרסה 1.1", "Nov 6", listOf(
            "Task board: first to take a task gets it, locked until done, given up or out of time" to "לוח משימות: מי שלוקח ראשון — המשימה שלו, נעולה עד שמסיים, מוותר או שנגמר הזמן",
            "Partner offers: redeem coins for experiences and services, with a coupon code" to "הטבות משותפים: מממשים מטבעות לחוויות ושירותים, עם קוד קופון",
            "Class rewards now also in Shop → Rewards" to "פרסים כיתתיים מופיעים עכשיו גם בחנות ← פרסים",
            "Students no longer see teacher controls (teacher view only through Teacher mode)" to "תלמידים כבר לא רואים כלי מורה (תצוגת מורה רק דרך מצב מורה)"
        )),
        Entry("v1.0", "גרסה 1.0", "Nov 6", listOf(
            "Cleaner Checkpoint logo: thinner lines, more space, smaller check" to "לוגו Checkpoint נקי יותר: קווים דקים, יותר מרווח, סימן קטן יותר",
            "Developer tests screen (developer mode)" to "מסך בדיקות מפתח (במצב מפתח)"
        )),
        Entry("v0.9", "גרסה 0.9", "Nov 6", listOf(
            "New look: the Checkpoint button replaces the floating star" to "עיצוב חדש: כפתור Checkpoint מחליף את הכוכב הצף",
            "Checkpoint styles in the Shop work again" to "הסגנונות של Checkpoint בחנות עובדים שוב",
            "Redesigned check screen: stat chips, cleaner fields and buttons" to "מסך בדיקה מעוצב מחדש: תגיות נתונים, שדות וכפתורים נקיים",
            "10 new ranks after Mythic, up to level 20 (Comboed)" to "10 דרגות חדשות אחרי מיתולוגי, עד שלב 20 (Comboed)",
            "Leaderboard titles: Top 1 / 2 / 3, and Retired Top N" to "תארים בטבלת המובילים: מקום 1/2/3, ומקום לשעבר",
            "Checkpoint button is solid and the check sits lower" to "כפתור Checkpoint אטום והסימן ממוקם נמוך יותר",
            "Automatic crash reports, so problems get fixed faster" to "דיווחי קריסה אוטומטיים, כדי שבעיות יתוקנו מהר יותר"
        )),
        Entry("v0.8", "גרסה 0.8", "Nov 6", listOf(
            "One permanent download link that always gets the newest version" to "קישור הורדה קבוע שתמיד מביא את הגרסה החדשה ביותר",
            "The app checks for updates and notifies you, with step-by-step instructions" to "האפליקציה בודקת עדכונים ומתריעה, עם הוראות צעד אחר צעד"
        )),
        Entry("v0.7", "גרסה 0.7", "Nov 6", listOf(
            "Teacher tools: assign homework, class rewards shop, teams, teacher comments" to "כלים למורים: שיעורי בית, חנות פרסים כיתתית, קבוצות, הערות מורה",
            "Optional: quiet nudges, Student of the week certificate, parent view" to "אפשרי: תזכורות עדינות, תעודת תלמיד השבוע, צפיית הורים",
            "Compare classes and export a spreadsheet (CSV)" to "השוואת כיתות וייצוא לגיליון (CSV)",
            "First-open AI key setup with step-by-step links" to "הגדרת מפתח AI בפתיחה הראשונה עם קישורים והסבר",
            "This screen: see your version, check for updates, and what's new" to "המסך הזה: הגרסה שלכם, בדיקת עדכונים ומה חדש"
        )),
        Entry("v0.6", "גרסה 0.6", "Nov 6", listOf(
            "Groups: classes, families and friends with join codes" to "קבוצות: כיתות, משפחות וחברים עם קוד הצטרפות",
            "Teacher mode: see every student's progress, wins and streaks" to "מצב מורה: התקדמות, הצלחות ורצפים של כל תלמיד",
            "Parents approve coins from their own phone" to "הורים מאשרים מטבעות מהטלפון שלהם",
            "High-fives, team goals, group news" to "כיף, יעדים קבוצתיים, הודעות לקבוצה",
            "Community challenge and live world stats on Home" to "אתגר קהילתי ונתוני עולם חיים במסך הבית",
            "Daily automatic cloud backup" to "גיבוי אוטומטי יומי לענן",
            "New profile picker and pop-ups; Settings keeps its place" to "בחירת פרופיל וחלונות חדשים; ההגדרות שומרות על המקום"
        )),
        Entry("v0.5", "גרסה 0.5", "Nov 6", listOf(
            "Brand-new design: Home dashboard and bottom tabs (Home · Shop · Ranks · Me)" to "עיצוב חדש לגמרי: מסך בית ולשוניות (בית · חנות · דירוג · אני)",
            "Grouped Settings screen with real icons" to "מסך הגדרות מסודר עם אייקונים אמיתיים",
            "Shop tabs, Ranks podium, Me screen, new Parent zone" to "לשוניות בחנות, פודיום דירוג, מסך אני, אזור הורים חדש"
        )),
        Entry("v0.4", "גרסה 0.4", "Nov 5", listOf(
            "Free online server: live user counter and global leaderboard" to "שרת חינמי: מונה משתמשים חי וטבלת מובילים עולמית",
            "Move your data to a new phone with a cloud code" to "העברת נתונים לטלפון חדש עם קוד ענן",
            "Daily reminder, invite friends, home-screen widget, weekly coach" to "תזכורת יומית, הזמנת חברים, וידג׳ט למסך הבית, מאמן שבועי"
        )),
        Entry("v0.3", "גרסה 0.3", "Oct 30", listOf(
            "Full Hebrew support" to "תמיכה מלאה בעברית",
            "Help guide and the classic menu option" to "מדריך עזרה ואפשרות לתפריט הקלאסי",
            "Study coins and general coins" to "מטבעות לימוד ומטבעות רגילים",
            "Start fresh (PIN-locked, hold to confirm)" to "התחלה מחדש (נעול בקוד, לחיצה ארוכה לאישור)"
        )),
        Entry("v0.2", "גרסה 0.2", "Oct 29", listOf(
            "Shop with skins and powers, achievements, daily quests, stats" to "חנות עם סקינים וכוחות, הישגים, משימות יומיות, סטטיסטיקה",
            "Profiles with PIN locks, Parent zone, approvals and weekly report" to "פרופילים עם נעילה, אזור הורים, אישורים ודוח שבועי",
            "Camera checks, before & after, light/dark/kid themes, sound shop" to "בדיקות במצלמה, לפני ואחרי, ערכות נושא, חנות צלילים"
        )),
        Entry("v0.1", "גרסה 0.1", "Oct 27", listOf(
            "The floating button: circle a finished task and the AI checks it" to "הכפתור הצף: מקיפים משימה שהסתיימה והבינה המלאכותית בודקת",
            "Points, combos and bonuses" to "נקודות, קומבו ובונוסים"
        ))
    )

    /** The version name shown to people, e.g. "v1.4" (falls back to "build N"). */
    fun name(c: Context): String = try {
        val v = c.packageManager.getPackageInfo(c.packageName, 0).versionName ?: ""
        if (v.startsWith("v")) v else "build " + build(c)
    } catch (e: Exception) { "build " + build(c) }

    fun build(c: Context): Int = try {
        @Suppress("DEPRECATION") c.packageManager.getPackageInfo(c.packageName, 0).versionCode
    } catch (e: Exception) { 0 }

    /** Show "what's new" once after an update (not on a fresh install). */
    fun maybeShow(a: Activity) {
        val sp = a.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val now = build(a)
        val seen = sp.getInt("lastSeenBuild", 0)
        sp.edit().putInt("lastSeenBuild", now).apply()
        if (seen == 0 || now <= seen) return
        val he = Lang.isHebrew(a)
        val e = entries.first()
        val msg = e.items.joinToString("\n") { "• " + if (he) it.second else it.first }
        AlertDialog.Builder(a).setTitle(Lang.t(a, "What's new") + " — " + (if (he) e.titleHe else e.title)).setMessage(msg)
            .setPositiveButton(Lang.t(a, "Nice!"), null)
            .setNeutralButton(Lang.t(a, "All updates")) { _, _ -> a.startActivity(Intent(a, UpdatesActivity::class.java)) }
            .show()
    }
}

/** Your version, a check for a newer build, and the full list of what each update added. */
class UpdatesActivity : Activity() {
    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)
    private var status: TextView? = null
    private var action: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val p = Ui.pal(this)
        val he = Lang.isHebrew(this)
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        head.addView(Ui.text(this, t("Updates"), 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        page.addView(head)

        val build = Changelog.build(this)
        val card = Ui.card(this).apply { setPaddingRelative(d(18), d(16), d(18), d(16)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.tile(this, R.drawable.ui_download, "blue", 44, 24))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, 0, 0) }
        col.addView(Ui.text(this, t("You're on") + " " + Changelog.name(this), 18f, p.ink))
        col.addView(Ui.text(this, "build $build", 12f, p.muted, bold = false))
        val st = Ui.text(this, t("Checking for updates…"), 13f, p.muted, bold = false); status = st
        col.addView(st)
        top.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        card.addView(top)
        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; action = act
        card.addView(act)
        page.addView(card, Ui.lp(this, 16))
        page.addView(Ui.button(this, t("Share the app link"), R.drawable.ui_share, p.accentSoft, p.accentInk) {
            val msg = t("Get Comboed (always the newest version):") + " " + UpdateCheck.LATEST_APK
            try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), t("Share"))) } catch (e: Exception) {}
        }, Ui.lp(this, 10))

        for (e in Changelog.entries) {
            page.addView(Ui.sectionTitle(this, (if (he) e.titleHe else e.title) + " · " + e.date))
            val c = Ui.card(this).apply { setPaddingRelative(d(16), d(12), d(16), d(14)) }
            for ((en, hb) in e.items) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPaddingRelative(0, d(4), 0, d(4)) }
                r.addView(Ui.icon(this, R.drawable.ui_check, p.good), LinearLayout.LayoutParams(d(16), d(16)).apply { topMargin = d(3) })
                r.addView(Ui.text(this, if (he) hb else en, 14f, p.ink, bold = false).apply { setPaddingRelative(d(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                c.addView(r)
            }
            page.addView(c)
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
        check(build)
    }

    /** Ask GitHub for the latest release and compare build numbers. */
    private fun check(build: Int) {
        Thread {
            var latest = -1; var url = ""; var latestName = ""
            try {
                val c = URL("https://api.github.com/repos/alonhasfri/combo-checker/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                latest = o.optString("tag_name").substringAfter("build-").toIntOrNull() ?: -1
                latestName = Regex("v\\d+(\\.\\d+)+").find(o.optString("name"))?.value ?: ""
                if (latestName.isNotEmpty()) getSharedPreferences("combo", MODE_PRIVATE).edit().putString("latestName", latestName).apply()
                url = UpdateCheck.editionLink()
                if (latest > 0) getSharedPreferences("combo", MODE_PRIVATE).edit().putInt("latestBuild", latest).putLong("updateCheckedAt", System.currentTimeMillis()).apply()
            } catch (e: Exception) {}
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                val p = Ui.pal(this)
                when {
                    latest < 0 -> status?.text = t("Couldn't check right now (no connection?)")
                    latest <= build -> { status?.text = t("You're up to date ✓"); status?.setTextColor(p.good) }
                    else -> {
                        val nm = latestName.ifEmpty { "build $latest" }
                        status?.text = (if (Lang.isHebrew(this)) "גרסה $nm זמינה!" else "$nm is available!")
                        status?.setTextColor(p.accentInk)
                        action?.addView(Ui.button(this, t("Download the update"), R.drawable.ui_download, p.accent, Color.WHITE) {
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                        }, Ui.lp(this, 14))
                        action?.addView(Ui.text(this, UpdateCheck.steps(this), 13f, p.ink, bold = false).apply { setPaddingRelative(0, d(10), 0, 0); setLineSpacing(0f, 1.2f) })
                    }
                }
            }
        }.start()
    }
}
