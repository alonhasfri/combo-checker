package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** What's in each update (newest first). Each line is English | Hebrew. */
object Changelog {
    class Entry(val title: String, val titleHe: String, val date: String, val items: List<Pair<String, String>>)

    val entries = listOf(
        Entry("Build 72", "גרסה 72", "Nov 6", listOf(
            "One permanent download link that always gets the newest version" to "קישור הורדה קבוע שתמיד מביא את הגרסה החדשה ביותר",
            "The app checks for updates and notifies you, with step-by-step instructions" to "האפליקציה בודקת עדכונים ומתריעה, עם הוראות צעד אחר צעד"
        )),
        Entry("Build 71", "גרסה 71", "Nov 6", listOf(
            "Teacher tools: assign homework, class rewards shop, teams, teacher comments" to "כלים למורים: שיעורי בית, חנות פרסים כיתתית, קבוצות, הערות מורה",
            "Optional: quiet nudges, Student of the week certificate, parent view" to "אפשרי: תזכורות עדינות, תעודת תלמיד השבוע, צפיית הורים",
            "Compare classes and export a spreadsheet (CSV)" to "השוואת כיתות וייצוא לגיליון (CSV)",
            "First-open AI key setup with step-by-step links" to "הגדרת מפתח AI בפתיחה הראשונה עם קישורים והסבר",
            "This screen: see your version, check for updates, and what's new" to "המסך הזה: הגרסה שלכם, בדיקת עדכונים ומה חדש"
        )),
        Entry("Builds 68–70", "גרסאות 68–70", "Nov 6", listOf(
            "Groups: classes, families and friends with join codes" to "קבוצות: כיתות, משפחות וחברים עם קוד הצטרפות",
            "Teacher mode: see every student's progress, wins and streaks" to "מצב מורה: התקדמות, הצלחות ורצפים של כל תלמיד",
            "Parents approve coins from their own phone" to "הורים מאשרים מטבעות מהטלפון שלהם",
            "High-fives, team goals, group news" to "כיף, יעדים קבוצתיים, הודעות לקבוצה",
            "Community challenge and live world stats on Home" to "אתגר קהילתי ונתוני עולם חיים במסך הבית",
            "Daily automatic cloud backup" to "גיבוי אוטומטי יומי לענן",
            "New profile picker and pop-ups; Settings keeps its place" to "בחירת פרופיל וחלונות חדשים; ההגדרות שומרות על המקום"
        )),
        Entry("Builds 64–66", "גרסאות 64–66", "Nov 6", listOf(
            "Brand-new design: Home dashboard and bottom tabs (Home · Shop · Ranks · Me)" to "עיצוב חדש לגמרי: מסך בית ולשוניות (בית · חנות · דירוג · אני)",
            "Grouped Settings screen with real icons" to "מסך הגדרות מסודר עם אייקונים אמיתיים",
            "Shop tabs, Ranks podium, Me screen, new Parent zone" to "לשוניות בחנות, פודיום דירוג, מסך אני, אזור הורים חדש"
        )),
        Entry("Builds 47–62", "גרסאות 47–62", "Nov 5", listOf(
            "Free online server: live user counter and global leaderboard" to "שרת חינמי: מונה משתמשים חי וטבלת מובילים עולמית",
            "Move your data to a new phone with a cloud code" to "העברת נתונים לטלפון חדש עם קוד ענן",
            "Daily reminder, invite friends, home-screen widget, weekly coach" to "תזכורת יומית, הזמנת חברים, וידג׳ט למסך הבית, מאמן שבועי"
        )),
        Entry("October 30", "30 באוקטובר", "Oct 30", listOf(
            "Full Hebrew support" to "תמיכה מלאה בעברית",
            "Help guide and the classic menu option" to "מדריך עזרה ואפשרות לתפריט הקלאסי",
            "Study coins and general coins" to "מטבעות לימוד ומטבעות רגילים",
            "Start fresh (PIN-locked, hold to confirm)" to "התחלה מחדש (נעול בקוד, לחיצה ארוכה לאישור)"
        )),
        Entry("October 29", "29 באוקטובר", "Oct 29", listOf(
            "Shop with skins and powers, achievements, daily quests, stats" to "חנות עם סקינים וכוחות, הישגים, משימות יומיות, סטטיסטיקה",
            "Profiles with PIN locks, Parent zone, approvals and weekly report" to "פרופילים עם נעילה, אזור הורים, אישורים ודוח שבועי",
            "Camera checks, before & after, light/dark/kid themes, sound shop" to "בדיקות במצלמה, לפני ואחרי, ערכות נושא, חנות צלילים"
        )),
        Entry("First version", "הגרסה הראשונה", "Oct 27", listOf(
            "The floating star: circle a finished task and the AI checks it" to "הכוכב הצף: מקיפים משימה שהסתיימה והבינה המלאכותית בודקת",
            "Points, combos and bonuses" to "נקודות, קומבו ובונוסים"
        ))
    )

    fun build(c: Context): Int = try {
        @Suppress("DEPRECATION") c.packageManager.getPackageInfo(c.packageName, 0).versionCode
    } catch (e: Exception) { 0 }

    /** Show "what's new" once after an update (not on a fresh install). */
    fun maybeShow(a: Activity) {
        val sp = a.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val now = build(a)
        val seen = sp.getInt("lastSeenBuild", 0)
        sp.edit().putInt("lastSeenBuild", now).apply()
        if (seen == 0 || now <= seen) return
        val he = Lang.isHebrew(a)
        val e = entries.first()
        val msg = e.items.joinToString("\n") { "• " + if (he) it.second else it.first }
        AlertDialog.Builder(a).setTitle(Lang.t(a, "What's new") + " — " + (if (he) e.titleHe else e.title)).setMessage(msg)
            .setPositiveButton(Lang.t(a, "Nice!"), null)
            .setNeutralButton(Lang.t(a, "All updates")) { _, _ -> a.startActivity(Intent(a, UpdatesActivity::class.java)) }
            .show()
    }
}

/** Your version, a check for a newer build, and the full list of what each update added. */
class UpdatesActivity : Activity() {
    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)
    private var status: TextView? = null
    private var action: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val p = Ui.pal(this)
        val he = Lang.isHebrew(this)
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        head.addView(Ui.text(this, t("Updates"), 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        page.addView(head)

        val build = Changelog.build(this)
        val card = Ui.card(this).apply { setPaddingRelative(d(18), d(16), d(18), d(16)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.tile(this, R.drawable.ui_download, "blue", 44, 24))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, 0, 0) }
        col.addView(Ui.text(this, t("You're on") + " " + (if (he) "גרסה" else "build") + " " + build, 18f, p.ink))
        val st = Ui.text(this, t("Checking for updates…"), 13f, p.muted, bold = false); status = st
        col.addView(st)
        top.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        card.addView(top)
        val act = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; action = act
        card.addView(act)
        page.addView(card, Ui.lp(this, 16))
        page.addView(Ui.button(this, t("Share the app link"), R.drawable.ui_share, p.accentSoft, p.accentInk) {
            val msg = t("Get Comboed (always the newest version):") + " " + UpdateCheck.LATEST_APK
            try { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg), t("Share"))) } catch (e: Exception) {}
        }, Ui.lp(this, 10))

        for (e in Changelog.entries) {
            page.addView(Ui.sectionTitle(this, (if (he) e.titleHe else e.title) + " · " + e.date))
            val c = Ui.card(this).apply { setPaddingRelative(d(16), d(12), d(16), d(14)) }
            for ((en, hb) in e.items) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPaddingRelative(0, d(4), 0, d(4)) }
                r.addView(Ui.icon(this, R.drawable.ui_check, p.good), LinearLayout.LayoutParams(d(16), d(16)).apply { topMargin = d(3) })
                r.addView(Ui.text(this, if (he) hb else en, 14f, p.ink, bold = false).apply { setPaddingRelative(d(10), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
                c.addView(r)
            }
            page.addView(c)
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
        check(build)
    }

    /** Ask GitHub for the latest release and compare build numbers. */
    private fun check(build: Int) {
        Thread {
            var latest = -1; var url = ""
            try {
                val c = URL("https://api.github.com/repos/alonhasfri/combo-checker/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 8000; c.readTimeout = 8000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                val o = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                latest = o.optString("tag_name").substringAfter("build-").toIntOrNull() ?: -1
                url = UpdateCheck.LATEST_APK
                if (latest > 0) getSharedPreferences("combo", MODE_PRIVATE).edit().putInt("latestBuild", latest).putLong("updateCheckedAt", System.currentTimeMillis()).apply()
            } catch (e: Exception) {}
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                val p = Ui.pal(this)
                when {
                    latest < 0 -> status?.text = t("Couldn't check right now (no connection?)")
                    latest <= build -> { status?.text = t("You're up to date ✓"); status?.setTextColor(p.good) }
                    else -> {
                        status?.text = (if (Lang.isHebrew(this)) "גרסה $latest זמינה!" else "Build $latest is available!")
                        status?.setTextColor(p.accentInk)
                        action?.addView(Ui.button(this, t("Download the update"), R.drawable.ui_download, p.accent, Color.WHITE) {
                            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) {}
                        }, Ui.lp(this, 14))
                        action?.addView(Ui.text(this, UpdateCheck.steps(this), 13f, p.ink, bold = false).apply { setPaddingRelative(0, d(10), 0, 0); setLineSpacing(0f, 1.2f) })
                    }
                }
            }
        }.start()
    }
}
