package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * Fake "sign in to continue" wall that always rejects the login. It covers the whole app, so the
 * only way out is the secret escape: press and HOLD the Log in button for 3 seconds. Developer mode
 * skips it entirely (so the owner is never locked out), and the parent "Block pranks" setting keeps
 * it from ever activating. Nothing typed is read, stored or sent, and no email is ever sent.
 */
object LoginWall {
    private fun on(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("login", false)

    private fun isDeveloper(c: Context): Boolean {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val id = Profiles.currentId(c)
        val st = try { org.json.JSONObject(sp.getString("state__$id", "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        return st.optBoolean("debug", false)
    }

    /** Returns true if the wall was shown (so the caller can skip other pop-ups this open). */
    @SuppressLint("ClickableViewAccessibility")
    fun maybeShow(a: Activity): Boolean {
        if (!on(a) || isDeveloper(a)) return false

        val dlg = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val d = a.resources.displayMetrics.density
        val pad = (24 * d).toInt()

        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        col.addView(TextView(a).apply {
            text = "Comboed"; textSize = 32f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        col.addView(TextView(a).apply {
            text = "Sign in to continue"; textSize = 15f; setTextColor(Color.parseColor("#aaaaaa"))
            gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, (6 * d).toInt(), 0, pad)
        })

        fun field(hintText: String, type: Int) = EditText(a).apply {
            hint = hintText; inputType = type
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#777777"))
        }
        val emailF = field("Email", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val passF = field("Password", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        col.addView(emailF); col.addView(passF)

        val error = TextView(a).apply {
            textSize = 14f; setTextColor(Color.parseColor("#ff6b6b")); setPadding(0, (8 * d).toInt(), 0, 0)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val loginBtn = Button(a).apply { text = "Log in" }
        col.addView(loginBtn)
        col.addView(error)

        // Secret escape: hold "Log in" for 3 seconds.
        val handler = Handler(Looper.getMainLooper())
        val escape = Runnable { runCatching { dlg.dismiss() } }
        loginBtn.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { handler.postDelayed(escape, 3000); true }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(escape)
                    error.text = "Wrong password or email. Try again."
                    true
                }
                MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(escape); true }
                else -> false
            }
        }

        // Forgot password → "we sent an email" (that never sends) with a 5-minute resend cooldown.
        val forgot = TextView(a).apply {
            text = "I forgot my password"; textSize = 14f; setTextColor(Color.parseColor("#4a9eff"))
            setPadding(0, pad, 0, 0); isClickable = true; gravity = Gravity.CENTER_HORIZONTAL
        }
        val resendBtn = Button(a).apply { text = "Resend email"; isEnabled = false; visibility = android.view.View.GONE }
        var timer: CountDownTimer? = null
        fun startCooldown() {
            resendBtn.visibility = android.view.View.VISIBLE
            resendBtn.isEnabled = false
            timer?.cancel()
            timer = object : CountDownTimer(5 * 60 * 1000, 1000) {
                override fun onTick(ms: Long) {
                    val s = ms / 1000; resendBtn.text = "Resend email (${s / 60}:${(s % 60).toString().padStart(2, '0')})"
                }
                override fun onFinish() { resendBtn.isEnabled = true; resendBtn.text = "Resend email" }
            }.start()
        }
        fun sentMessage() {
            val to = emailF.text?.toString()?.trim().orEmpty().ifEmpty { "your email" }
            error.setTextColor(Color.parseColor("#7dff6b"))
            error.text = "We sent a password reset link to $to."
            startCooldown()
        }
        forgot.setOnClickListener { sentMessage() }
        resendBtn.setOnClickListener { if (resendBtn.isEnabled) sentMessage() }
        col.addView(forgot); col.addView(resendBtn)

        dlg.setContentView(ScrollView(a).apply { addView(col) })
        dlg.setCancelable(false)
        dlg.setOnDismissListener { timer?.cancel(); handler.removeCallbacks(escape) }
        runCatching { dlg.show() }
        return true
    }
}
