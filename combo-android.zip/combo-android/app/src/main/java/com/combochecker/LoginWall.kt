package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * A believable multi-screen fake auth wall that blocks the whole app. Sign in always fails; you can
 * "sign up" (date of birth, state, terms + marketing checkboxes) and it says the account was created
 * but still won't log in; "forgot password" opens a separate "enter the 6-letter code" screen that
 * also never works. The ONLY way out is the secret escape: press and HOLD "Log in" for 3 seconds.
 *
 * Developer mode skips it (owner is never locked out) and the parent "Block pranks" setting prevents
 * it. Nothing typed is ever read, stored or sent, and no email is ever sent.
 */
object LoginWall {
    private fun on(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("login", false)

    private fun isDeveloper(c: Context): Boolean {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val id = Profiles.currentId(c)
        val st = try { org.json.JSONObject(sp.getString("state__$id", "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        return st.optBoolean("debug", false)
    }

    @SuppressLint("ClickableViewAccessibility")
    fun maybeShow(a: Activity): Boolean {
        if (!on(a) || isDeveloper(a)) return false
        val dlg = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.setCancelable(false)
        val handler = Handler(Looper.getMainLooper())
        dlg.setOnDismissListener { handler.removeCallbacksAndMessages(null) }
        signIn(a, dlg, handler)
        runCatching { dlg.show() }
        return true
    }

    // ---- shared builders ----
    private fun screen(a: Activity): Pair<ScrollView, LinearLayout> {
        val d = a.resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val col = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        return Pair(ScrollView(a).apply { addView(col) }, col)
    }

    private fun title(a: Activity, col: LinearLayout, sub: String) {
        val d = a.resources.displayMetrics.density
        col.addView(TextView(a).apply {
            text = "Comboed"; textSize = 32f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        col.addView(TextView(a).apply {
            text = sub; textSize = 15f; setTextColor(Color.parseColor("#aaaaaa"))
            gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, (6 * d).toInt(), 0, (24 * d).toInt())
        })
    }

    private fun field(a: Activity, hintText: String, type: Int): EditText = EditText(a).apply {
        hint = hintText; inputType = type
        setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#777777"))
    }

    private fun link(a: Activity, txt: String, onClick: () -> Unit) = TextView(a).apply {
        text = txt; textSize = 14f; setTextColor(Color.parseColor("#4a9eff"))
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, (20 * a.resources.displayMetrics.density).toInt(), 0, 0)
        isClickable = true; setOnClickListener { onClick() }
    }

    private fun errorView(a: Activity) = TextView(a).apply {
        textSize = 14f; setTextColor(Color.parseColor("#ff6b6b")); gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, (8 * a.resources.displayMetrics.density).toInt(), 0, 0)
    }

    // ---- sign in (the only screen with the secret escape) ----
    @SuppressLint("ClickableViewAccessibility")
    private fun signIn(a: Activity, dlg: Dialog, handler: Handler) {
        val (scroll, col) = screen(a)
        title(a, col, "Sign in to continue")
        val email = field(a, "Email", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pass = field(a, "Password", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        col.addView(email); col.addView(pass)
        val error = errorView(a)
        val loginBtn = Button(a).apply { text = "Log in" }
        col.addView(loginBtn); col.addView(error)

        val escape = Runnable { runCatching { dlg.dismiss() } }
        loginBtn.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { handler.postDelayed(escape, 3000); true } // hold 3s to escape
                MotionEvent.ACTION_UP -> { handler.removeCallbacks(escape); error.text = "Wrong password or email. Try again."; true }
                MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(escape); true }
                else -> false
            }
        }
        col.addView(link(a, "I forgot my password") { forgotCode(a, dlg, handler) })
        col.addView(link(a, "Don't have an account? Sign up") { signUp(a, dlg, handler) })
        dlg.setContentView(scroll)
    }

    // ---- sign up ----
    private fun signUp(a: Activity, dlg: Dialog, handler: Handler) {
        val (scroll, col) = screen(a)
        title(a, col, "Create your account")
        val email = field(a, "Email", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val pass = field(a, "Password", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val dob = field(a, "Date of birth (MM/DD/YYYY)", InputType.TYPE_CLASS_DATETIME)
        val state = field(a, "What state do you live in?", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        col.addView(email); col.addView(pass); col.addView(dob); col.addView(state)
        val terms = CheckBox(a).apply { text = "I accept the Terms and Conditions"; setTextColor(Color.parseColor("#dddddd")) }
        val marketing = CheckBox(a).apply { text = "I want to receive marketing emails"; setTextColor(Color.parseColor("#dddddd")) }
        col.addView(terms); col.addView(marketing)
        val error = errorView(a); col.addView(error)
        col.addView(Button(a).apply {
            text = "Create account"
            setOnClickListener {
                if (!terms.isChecked) { error.text = "You must accept the Terms and Conditions."; return@setOnClickListener }
                Toast.makeText(a, "Account created! Please log in.", Toast.LENGTH_LONG).show()
                signIn(a, dlg, handler)
            }
        })
        col.addView(link(a, "Already have an account? Log in") { signIn(a, dlg, handler) })
        dlg.setContentView(scroll)
    }

    // ---- forgot password: a separate "enter the 6-letter code" screen ----
    private fun forgotCode(a: Activity, dlg: Dialog, handler: Handler) {
        val (scroll, col) = screen(a)
        title(a, col, "Check your email")
        col.addView(TextView(a).apply {
            text = "We sent an email with a code.\nWhat's the code?"; textSize = 16f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, (16 * a.resources.displayMetrics.density).toInt())
        })
        val code = field(a, "6-letter code", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS).apply {
            filters = arrayOf(InputFilter.LengthFilter(6)) // 6 characters only
            gravity = Gravity.CENTER
        }
        col.addView(code)
        val error = errorView(a); col.addView(error)
        col.addView(Button(a).apply {
            text = "Verify code"
            setOnClickListener { error.text = "That code didn't work. Try again." }
        })
        col.addView(link(a, "Resend code") {
            Toast.makeText(a, "A new code has been sent to your email.", Toast.LENGTH_SHORT).show()
        })
        col.addView(link(a, "Back to sign in") { signIn(a, dlg, handler) })
        dlg.setContentView(scroll)
    }
}
