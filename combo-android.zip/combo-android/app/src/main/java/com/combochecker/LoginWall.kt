package com.combochecker

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * A believable, nicely styled multi-screen fake auth wall that blocks the whole app. Sign in always
 * fails; you can sign up (it says the account was made but still won't log in); forgot-password opens
 * a separate "enter the 6-letter code" screen that also never works and references the email you
 * typed. The ONLY way out is the secret escape: press and HOLD "Log in" for 3 seconds.
 *
 * Developer mode skips it (owner is never locked out), the parent "Block pranks" setting prevents it,
 * and nothing typed is ever read, stored or sent — no email is ever sent.
 */
object LoginWall {
    private class Session { var email = "" }

    private fun on(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("login", false)

    private fun isDeveloper(c: Context): Boolean {
        val sp = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
        val id = Profiles.currentId(c)
        val st = try { org.json.JSONObject(sp.getString("state__$id", "") ?: "") } catch (e: Exception) { org.json.JSONObject() }
        return st.optBoolean("debug", false)
    }

    @SuppressLint("ClickableViewAccessibility")
    fun maybeShow(a: Activity): Boolean {
        if (!on(a) || isDeveloper(a)) return false
        val dlg = Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.setCancelable(false)
        runCatching {
            dlg.window?.decorView?.layoutDirection =
                if (Lang.rtl(a)) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        val handler = Handler(Looper.getMainLooper())
        dlg.setOnDismissListener { handler.removeCallbacksAndMessages(null) }
        signIn(a, dlg, handler, Session())
        runCatching { dlg.show() }
        return true
    }

    // ---------- styling helpers ----------
    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply { setColor(color); cornerRadius = radius }

    /** A gradient background + a centered card; returns (scroll-to-set-as-content, card-column). */
    private fun screen(a: Activity): Pair<View, LinearLayout> {
        val pad = dp(a, 24)
        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#171c30"), dp(a, 20).toFloat())
            setPadding(pad, pad + dp(a, 8), pad, pad + dp(a, 8))
        }
        val outer = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, dp(a, 48), pad, dp(a, 48))
            addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val scroll = ScrollView(a).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#0d0f1a"), Color.parseColor("#141a2e")))
            addView(outer)
        }
        return Pair(scroll, card)
    }

    private fun LinearLayout.spaced(v: View, a: Activity, topDp: Int = 12) {
        addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(a, topDp) })
    }

    private fun brand(a: Activity, card: LinearLayout, sub: String) {
        card.addView(TextView(a).apply {
            text = "Comboed"; textSize = 30f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        card.spaced(TextView(a).apply {
            text = sub; textSize = 14f; setTextColor(Color.parseColor("#9aa3bf")); gravity = Gravity.CENTER_HORIZONTAL
        }, a, 6)
    }

    private fun input(a: Activity, hintText: String, type: Int): EditText = EditText(a).apply {
        hint = hintText; inputType = type; textSize = 16f
        setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#8089a8"))
        background = rounded(Color.parseColor("#1c2138"), dp(a, 12).toFloat())
        val p = dp(a, 14); setPadding(p, p, p, p)
    }

    private fun primary(a: Activity, label: String): Button = Button(a).apply {
        text = label; setAllCaps(false); textSize = 16f; setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.parseColor("#3a66d6"), dp(a, 12).toFloat())
        stateListAnimator = null
        val p = dp(a, 12); setPadding(p, p, p, p)
    }

    private fun link(a: Activity, txt: String, onClick: () -> Unit) = TextView(a).apply {
        text = txt; textSize = 14f; setTextColor(Color.parseColor("#6ea8ff")); gravity = Gravity.CENTER_HORIZONTAL
        isClickable = true; setOnClickListener { onClick() }
    }

    private fun errorView(a: Activity) = TextView(a).apply {
        textSize = 14f; setTextColor(Color.parseColor("#ff6b6b")); gravity = Gravity.CENTER_HORIZONTAL
    }

    private fun check(a: Activity, label: String) = CheckBox(a).apply {
        text = label; setTextColor(Color.parseColor("#c9cfe0"))
    }

    // ---------- sign in (holds the secret escape) ----------
    @SuppressLint("ClickableViewAccessibility")
    private fun signIn(a: Activity, dlg: Dialog, handler: Handler, s: Session) {
        val (scroll, card) = screen(a)
        brand(a, card, Lang.t(a, "Sign in to continue"))
        val email = input(a, Lang.t(a, "Email"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS).apply { setText(s.email) }
        val pass = input(a, Lang.t(a, "Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        card.spaced(email, a, 20); card.spaced(pass, a)
        val error = errorView(a)
        val loginBtn = primary(a, Lang.t(a, "Log in"))
        card.spaced(loginBtn, a, 16); card.spaced(error, a, 8)

        val escape = Runnable { runCatching { dlg.dismiss() } }
        // Hold "Log in" for 3s to escape. Keep the ScrollView from stealing the long press (that was
        // making the escape fail intermittently), and don't cancel the timer on small finger moves.
        loginBtn.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    handler.removeCallbacks(escape)
                    handler.postDelayed(escape, 3000)
                    true
                }
                MotionEvent.ACTION_MOVE -> true // keep holding; ignore jitter
                MotionEvent.ACTION_UP -> {
                    v.parent?.requestDisallowInterceptTouchEvent(false)
                    handler.removeCallbacks(escape)
                    error.text = Lang.t(a, "Wrong password or email. Try again.")
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    v.parent?.requestDisallowInterceptTouchEvent(false)
                    handler.removeCallbacks(escape)
                    true
                }
                else -> false
            }
        }
        // Also allow a normal long-press as a fallback escape, for devices where the touch gesture
        // gets intercepted anyway.
        loginBtn.setOnLongClickListener { runCatching { dlg.dismiss() }; true }
        card.spaced(link(a, Lang.t(a, "I forgot my password")) { s.email = email.text.toString().trim(); forgotCode(a, dlg, handler, s) }, a, 20)
        card.spaced(link(a, Lang.t(a, "Don't have an account?  Sign up")) { s.email = email.text.toString().trim(); signUp(a, dlg, handler, s) }, a, 14)
        dlg.setContentView(scroll)
    }

    // ---------- sign up ----------
    private fun signUp(a: Activity, dlg: Dialog, handler: Handler, s: Session) {
        val (scroll, card) = screen(a)
        brand(a, card, Lang.t(a, "Create your account"))
        val email = input(a, Lang.t(a, "Email"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS).apply { setText(s.email) }
        val pass = input(a, Lang.t(a, "Password"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val dob = input(a, Lang.t(a, "Date of birth (MM/DD/YYYY)"), InputType.TYPE_CLASS_DATETIME)
        val state = input(a, Lang.t(a, "What state do you live in?"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        card.spaced(email, a, 20); card.spaced(pass, a); card.spaced(dob, a); card.spaced(state, a)
        val terms = check(a, Lang.t(a, "I accept the Terms and Conditions"))
        val marketing = check(a, Lang.t(a, "I want to receive marketing emails"))
        card.spaced(terms, a, 14); card.spaced(marketing, a, 2)
        val error = errorView(a); card.spaced(error, a, 8)
        val createBtn = primary(a, Lang.t(a, "Create account"))
        card.spaced(createBtn, a, 14)
        createBtn.setOnClickListener {
            if (!terms.isChecked) { error.text = Lang.t(a, "You must accept the Terms and Conditions."); return@setOnClickListener }
            s.email = email.text.toString().trim()
            Toast.makeText(a, Lang.t(a, "Account created! Please log in."), Toast.LENGTH_LONG).show()
            signIn(a, dlg, handler, s)
        }
        card.spaced(link(a, Lang.t(a, "Already have an account?  Log in")) { s.email = email.text.toString().trim(); signIn(a, dlg, handler, s) }, a, 18)
        dlg.setContentView(scroll)
    }

    // ---------- forgot password: separate "enter the 6-letter code" screen ----------
    private fun forgotCode(a: Activity, dlg: Dialog, handler: Handler, s: Session) {
        val (scroll, card) = screen(a)
        brand(a, card, Lang.t(a, "Check your email"))
        val to = s.email.ifEmpty { Lang.t(a, "your email") }
        card.spaced(TextView(a).apply {
            text = if (Lang.isHebrew(a)) "שלחנו קוד בן 6 אותיות אל\n$to.\nהזינו אותו למטה כדי לאפס את הסיסמה."
                   else "We sent a 6-letter code to\n$to.\nEnter it below to reset your password."
            textSize = 15f; setTextColor(Color.parseColor("#c9cfe0")); gravity = Gravity.CENTER_HORIZONTAL
        }, a, 16)
        val code = input(a, Lang.t(a, "6-letter code"), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS).apply {
            filters = arrayOf(InputFilter.LengthFilter(6)); gravity = Gravity.CENTER; textSize = 22f
        }
        card.spaced(code, a, 16)
        val error = errorView(a); card.spaced(error, a, 8)
        val verify = primary(a, Lang.t(a, "Verify code"))
        card.spaced(verify, a, 14)
        verify.setOnClickListener { error.text = Lang.t(a, "That code didn't work. Try again.") }
        card.spaced(link(a, Lang.t(a, "Resend code")) {
            Toast.makeText(a, if (Lang.isHebrew(a)) "קוד חדש נשלח אל $to." else "A new code has been sent to $to.", Toast.LENGTH_SHORT).show()
        }, a, 18)
        card.spaced(link(a, Lang.t(a, "Back to sign in")) { signIn(a, dlg, handler, s) }, a, 12)
        dlg.setContentView(scroll)
    }
}
