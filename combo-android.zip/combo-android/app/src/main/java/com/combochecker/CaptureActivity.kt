package com.combochecker

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast

/** Invisible activity that asks for screen-capture permission, runs the capture, then opens the result screen. */
class CaptureActivity : Activity() {

    private val requestCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), requestCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(req, resultCode, data)
        if (req != requestCode) return

        if (resultCode != RESULT_OK || data == null) {
            BubbleService.setBubbleVisible(true)
            finish()
            return
        }

        CaptureService.onDone = { path ->
            runOnUiThread {
                if (path != null) {
                    startActivity(Intent(this, ResultActivity::class.java).putExtra("path", path))
                } else {
                    BubbleService.setBubbleVisible(true)
                    Toast.makeText(this, "Couldn't capture the screen", Toast.LENGTH_SHORT).show()
                }
                finish()
            }
        }
        startForegroundService(
            Intent(this, CaptureService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
        )
    }
}
