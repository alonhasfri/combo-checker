package com.combochecker

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * Free, on-device daily reminder (no server). When the user turns it on, a repeating alarm fires once
 * a day and posts a friendly "do a task" notification. Everything is local — nothing is sent anywhere.
 */
object Reminders {
    const val CHANNEL = "comboed_reminders"
    private const val REQ = 7001
    const val HOUR = 17 // 5 PM

    fun isOn(c: Context) =
        c.getSharedPreferences("combo", Context.MODE_PRIVATE).getBoolean("reminderOn", false)

    fun setEnabled(c: Context, on: Boolean) {
        c.getSharedPreferences("combo", Context.MODE_PRIVATE).edit().putBoolean("reminderOn", on).apply()
        if (on) schedule(c) else cancel(c)
    }

    fun ensureChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            val name = if (Lang.isHebrew(c)) "תזכורות" else "Reminders"
            nm?.createNotificationChannel(NotificationChannel(CHANNEL, name, NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun pending(c: Context): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(c, REQ, i, flags)
    }

    fun schedule(c: Context) {
        ensureChannel(c)
        val am = c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, HOUR); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_MONTH, 1)
        }
        // Inexact repeating is battery-friendly and needs no special "exact alarm" permission.
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pending(c))
    }

    fun cancel(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        am.cancel(pending(c))
    }

    fun rescheduleIfOn(c: Context) { if (isOn(c)) schedule(c) }
}

/** Fired by the daily alarm: posts the reminder notification. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent?) {
        Reminders.ensureChannel(c)
        val he = Lang.isHebrew(c)
        val text = if (he) "אל תשברו את הרצף — סיימו משימה היום! 🔥" else "Don't break your streak — finish a task today! 🔥"
        var flags = PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(c, 0, Intent(c, ProfileActivity::class.java), flags)
        val n = Notification.Builder(c, Reminders.CHANNEL)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("Comboed")
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1001, n)
        } catch (e: Exception) {
        }
    }
}

/** Re-arms the daily reminder after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent?) {
        Reminders.rescheduleIfOn(c)
    }
}
