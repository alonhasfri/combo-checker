package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/**
 * Lists groups. mode = "me" (the kid's own groups: join / start a friend group),
 * "teacher" (classes this device runs) or "family" (family groups for remote approvals).
 */
class GroupsActivity : Activity() {
    private var mode = "me"
    private fun t(s: String) = Lang.t(this, s)
    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        Profiles.ensureDefault(this)
        mode = intent.getStringExtra("mode") ?: "me"
    }

    override fun onResume() { super.onResume(); render() }

    private fun render() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        val title = when (mode) { "teacher" -> "Teacher mode"; "family" -> "Family group"; else -> "Groups" }
        head.addView(Ui.text(this, t(title), 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        page.addView(head)

        // intro
        val intro = when (mode) {
            "teacher" -> "Create a class and share its code. Students join from Me → Groups on their phones (or add them on this device). You'll see everyone's progress, wins and streaks, approve tasks, post news and set a class goal."
            "family" -> "Create a family group and share the code. On your child's phone: Me → Groups → Join with a code. Their coins then wait for your OK — approve from your own phone."
            else -> "Join your class, family or friends with a code, send high-fives and work toward team goals."
        }
        page.addView(Ui.card(this).apply {
            setPaddingRelative(d(16), d(14), d(16), d(14))
            val r = LinearLayout(this@GroupsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            r.addView(Ui.tile(this@GroupsActivity, if (mode == "teacher") R.drawable.ui_book else R.drawable.ui_users, if (mode == "teacher") "purple" else "green", 40, 22))
            r.addView(Ui.text(this@GroupsActivity, t(intro), 14f, p.ink, bold = false).apply { setPaddingRelative(d(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            addView(r)
        }, Ui.lp(this, 16))

        if (mode == "me") {
            val mine = Groups.memberships(this)
            page.addView(Ui.sectionTitle(this, t("My groups")))
            if (mine.length() == 0) page.addView(Ui.card(this).apply {
                setPaddingRelative(d(16), d(16), d(16), d(16))
                addView(Ui.text(this@GroupsActivity, t("You're not in a group yet."), 14f, p.muted, bold = false))
            }) else {
                val rows = ArrayList<View>()
                for (i in 0 until mine.length()) {
                    val m = mine.getJSONObject(i)
                    rows.add(groupRow(m.optString("code"), m.optString("name"), m.optString("type")))
                }
                page.addView(Ui.group(this, rows))
            }
            page.addView(Ui.sectionTitle(this, t("Add")))
            page.addView(Ui.group(this, listOf(
                Ui.row(this, R.drawable.ui_key, "blue", t("Join with a code"), null) { joinDialog() },
                Ui.row(this, R.drawable.ui_spark, "orange", t("Start a friend group"), null) { createDialog("friends") }
            )))
            // groups this device started (friend groups)
            val own = ownedOfType("friends")
            if (own.isNotEmpty()) {
                page.addView(Ui.sectionTitle(this, t("Groups I started")))
                page.addView(Ui.group(this, own.map { groupRow(it.first, it.second, "friends") }))
            }
        } else {
            val type = if (mode == "teacher") "class" else "family"
            val own = ownedOfType(type)
            page.addView(Ui.sectionTitle(this, t(if (type == "class") "My classes" else "My family groups")))
            if (own.isEmpty()) page.addView(Ui.card(this).apply {
                setPaddingRelative(d(16), d(16), d(16), d(16))
                addView(Ui.text(this@GroupsActivity, t("Nothing here yet."), 14f, p.muted, bold = false))
            }) else page.addView(Ui.group(this, own.map { groupRow(it.first, it.second, type) }))
            page.addView(Ui.button(this, t(if (type == "class") "Create a class" else "Create a family group"), R.drawable.ui_spark, p.accent, android.graphics.Color.WHITE) {
                createDialog(type)
            }, Ui.lp(this, 14))
            if (type == "class" && own.size >= 2) compareCard(page, own)
            if (type == "family") {
                page.addView(Ui.sectionTitle(this, t("My child's class")))
                val fl = Groups.follows(this)
                val rows = ArrayList<View>()
                for (i in 0 until fl.length()) {
                    val o = fl.optJSONObject(i) ?: continue
                    rows.add(Ui.row(this, R.drawable.ui_book, "purple", o.optString("child"), o.optString("name")) {
                        startActivity(Intent(this, GroupActivity::class.java).putExtra("code", o.optString("code")).putExtra("viewMid", o.optString("mid")))
                    }.apply {
                        setOnLongClickListener {
                            AlertDialog.Builder(this@GroupsActivity).setTitle(t("Stop following?"))
                                .setPositiveButton(t("Remove")) { _, _ -> Groups.removeFollow(this@GroupsActivity, o.optString("code"), o.optString("mid")); render() }
                                .setNegativeButton(t("Cancel"), null).show(); true
                        }
                    })
                }
                rows.add(Ui.row(this, R.drawable.ui_key, "blue", t("Follow my child's class"), null) { followDialog() })
                page.addView(Ui.group(this, rows))
                page.addView(Ui.text(this, t("Ask the teacher for the class code. You'll see your child's progress, homework and activity (if the teacher allows parent view)."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })
            }
        }

        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) }
        setContentView(scroll)
    }

    private fun ownedOfType(type: String): List<Pair<String, String>> {
        val a = Groups.owned(this); val out = ArrayList<Pair<String, String>>()
        for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; if (o.optString("type") == type) out.add(Pair(o.optString("code"), o.optString("name"))) }
        return out
    }

    private fun groupRow(code: String, name: String, type: String): View {
        val (res, tone) = when (type) { "class" -> Pair(R.drawable.ui_book, "purple"); "family" -> Pair(R.drawable.ui_home, "green"); else -> Pair(R.drawable.ui_users, "orange") }
        return Ui.row(this, res, tone, name, Groups.typeLabel(this, type)) {
            startActivity(Intent(this, GroupActivity::class.java).putExtra("code", code))
        }
    }

    private fun field(hintText: String, type: Int) = EditText(this).apply { hint = hintText; inputType = type }
    private fun boxed(v: View) = FrameLayout(this).apply { setPaddingRelative(d(20), d(6), d(20), 0); addView(v) }

    private fun joinDialog() {
        val f = field("CLS-XXXXXX", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)
        AlertDialog.Builder(this).setTitle(t("Join with a code")).setMessage(t("Ask your teacher, parent or friend for the group code."))
            .setView(boxed(f))
            .setPositiveButton(t("Join")) { _, _ ->
                Toast.makeText(this, t("Joining…"), Toast.LENGTH_SHORT).show()
                Groups.join(this, f.text.toString(), Profiles.currentId(this)) { ok, msg ->
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                    if (ok) render()
                }
            }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun createDialog(type: String) {
        val f = field(t(when (type) { "class" -> "Class name (e.g. 5B Math)"; "family" -> "Family name"; else -> "Group name" }), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS)
        AlertDialog.Builder(this).setTitle(t(when (type) { "class" -> "Create a class"; "family" -> "Create a family group"; else -> "Start a friend group" }))
            .setView(boxed(f))
            .setPositiveButton(t("Create")) { _, _ ->
                val name = f.text.toString().trim().ifEmpty { Groups.typeLabel(this, type) }
                Toast.makeText(this, t("Creating…"), Toast.LENGTH_SHORT).show()
                Backend.createGroup(name, type) { code ->
                    if (code == null) { Toast.makeText(this, t("Couldn't create it. Check your connection."), Toast.LENGTH_LONG).show(); return@createGroup }
                    Groups.addOwned(this, code, name, type)
                    if (type == "friends") Groups.join(this, code, Profiles.currentId(this)) { _, _ -> render() } else render()
                    startActivity(Intent(this, GroupActivity::class.java).putExtra("code", code))
                }
            }
            .setNegativeButton(t("Cancel"), null).show()
    }

    /** Teacher: all classes side by side. */
    private fun compareCard(page: LinearLayout, own: List<Pair<String, String>>) {
        val p = Ui.pal(this)
        page.addView(Ui.sectionTitle(this, t("Compare classes")))
        val box = Ui.card(this).apply { setPaddingRelative(d(16), d(12), d(16), d(14)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun cell(s: String, w: Float, bold: Boolean, color: Int) = Ui.text(this, s, 13f, color, bold).apply { maxLines = 1 }.also { it.layoutParams = LinearLayout.LayoutParams(0, Ui.WRAP, w) }
        head.addView(cell(t("Class"), 2f, true, p.muted)); head.addView(cell(t("Students"), 1f, true, p.muted))
        head.addView(cell(t("Active today"), 1.2f, true, p.muted)); head.addView(cell(t("Avg pts"), 1f, true, p.muted))
        box.addView(head)
        page.addView(box)
        for ((code, name) in own) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPaddingRelative(0, d(8), 0, 0) }
            line.addView(cell(name, 2f, true, p.ink)); line.addView(cell("…", 1f, false, p.ink))
            line.addView(cell("…", 1.2f, false, p.ink)); line.addView(cell("…", 1f, false, p.ink))
            box.addView(line)
            Backend.listMembers(code) { ms ->
                val m = ms ?: return@listMembers
                val n = m.size
                val active = m.count { ((it.data["today"] as? Number)?.toInt() ?: 0) > 0 }
                val avg = if (n == 0) 0 else m.sumOf { (it.data["weekPoints"] as? Number)?.toInt() ?: 0 } / n
                (line.getChildAt(1) as? android.widget.TextView)?.text = n.toString()
                (line.getChildAt(2) as? android.widget.TextView)?.text = "$active / $n"
                (line.getChildAt(3) as? android.widget.TextView)?.text = avg.toString()
            }
        }
    }

    /** Parent: follow one child in a class (read-only), if the teacher allows parent view. */
    private fun followDialog() {
        val f = field("CLS-XXXXXX", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)
        AlertDialog.Builder(this).setTitle(t("Follow my child's class")).setView(boxed(f))
            .setPositiveButton(t("Next")) { _, _ ->
                val code = f.text.toString().trim().uppercase()
                Backend.groupInfo(code) { gi ->
                    if (gi == null) { Toast.makeText(this, t("No group with that code. Check it and your connection."), Toast.LENGTH_LONG).show(); return@groupInfo }
                    if (gi["parentView"] != true) { Toast.makeText(this, t("The teacher has turned off parent view for this class."), Toast.LENGTH_LONG).show(); return@groupInfo }
                    Backend.listMembers(code) { ms ->
                        val m = (ms ?: emptyList()).sortedBy { it.data["name"] as? String ?: "" }
                        if (m.isEmpty()) { Toast.makeText(this, t("No one has joined yet. Share the join code."), Toast.LENGTH_LONG).show(); return@listMembers }
                        AlertDialog.Builder(this).setTitle(t("Which one is your child?"))
                            .setItems(m.map { (it.data["emoji"] as? String ?: "") + " " + (it.data["name"] as? String ?: "") }.toTypedArray()) { _, w ->
                                Groups.addFollow(this, code, gi["name"] as? String ?: code, m[w].id, m[w].data["name"] as? String ?: "")
                                render()
                            }.setNegativeButton(t("Cancel"), null).show()
                    }
                }
            }.setNegativeButton(t("Cancel"), null).show()
    }
}
