package com.combochecker

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews
import org.json.JSONObject

/** Home-screen widget: shows the current profile's streak, coins and level, and opens the app. */
class ComboWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) updateOne(context, manager, id)
    }

    companion object {
        /** Refresh every placed widget (called from the app after things change). */
        fun refresh(c: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(c) ?: return
                val ids = mgr.getAppWidgetIds(ComponentName(c, ComboWidget::class.java))
                for (id in ids) updateOne(c, mgr, id)
            } catch (e: Exception) {
            }
        }

        private fun updateOne(c: Context, mgr: AppWidgetManager, id: Int) {
            val views = RemoteViews(c.packageName, R.layout.widget_combo)
            val prefs = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
            val pid = Profiles.currentId(c)
            val st = try { JSONObject(prefs.getString("state__$pid", "") ?: "") } catch (e: Exception) { JSONObject() }
            val me = Profiles.current(c)
            val total = st.optInt("total", 0)
            val coins = st.optInt("coins", 0)
            val streak = st.optInt("bestStreak", 0)
            val level = Math.floor(Math.sqrt(total / 25.0)).toInt() + 1
            val he = Lang.isHebrew(c)
            views.setTextViewText(R.id.w_title, "⭐ Comboed")
            views.setTextViewText(R.id.w_name, me.optString("emoji", "⭐") + "  " + me.optString("name", "Me"))
            views.setTextViewText(R.id.w_stats, "🔥 $streak   🪙 $coins   " + (if (he) "רמה " else "Lv ") + level)
            views.setTextViewText(R.id.w_btn, if (he) "פתיחה" else "Open")

            var flags = PendingIntent.FLAG_UPDATE_CURRENT
            if (Build.VERSION.SDK_INT >= 23) flags = flags or PendingIntent.FLAG_IMMUTABLE
            val pi = PendingIntent.getActivity(c, 0, Intent(c, ProfileActivity::class.java), flags)
            views.setOnClickPendingIntent(R.id.w_btn, pi)
            views.setOnClickPendingIntent(R.id.w_title, pi)

            mgr.updateAppWidget(id, views)
        }
    }
}
