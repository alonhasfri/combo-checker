package com.combochecker

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Groups on the free server: a class (teacher), a family (remote parent approvals) or friends.
 * Each profile can be in several groups. Membership is stored on the phone; the group itself
 * (members' stats, a feed of wins and high-fives, pending approvals, news, a team goal) lives in
 * Firestore. Nothing is pushed: everything syncs when the app opens or a task passes.
 */
object Groups {
    private fun sp(c: Context) = c.getSharedPreferences("combo", Context.MODE_PRIVATE)
    private fun arr(c: Context, key: String) = try { JSONArray(sp(c).getString(key, "[]")) } catch (e: Exception) { JSONArray() }

    // ---------- local membership ----------
    fun memberships(c: Context, pid: String = Profiles.currentId(c)): JSONArray = arr(c, "groups__$pid")
    private fun saveMemberships(c: Context, pid: String, a: JSONArray) = sp(c).edit().putString("groups__$pid", a.toString()).apply()

    fun find(c: Context, code: String, pid: String = Profiles.currentId(c)): JSONObject? {
        val a = memberships(c, pid)
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optString("code") == code) return a.optJSONObject(i)
        return null
    }

    /** Groups this device created (teacher classes, family groups, friend groups). */
    fun owned(c: Context): JSONArray = arr(c, "ownedGroups")
    fun addOwned(c: Context, code: String, name: String, type: String) {
        val a = owned(c); a.put(JSONObject().put("code", code).put("name", name).put("type", type))
        sp(c).edit().putString("ownedGroups", a.toString()).apply()
    }
    fun removeOwned(c: Context, code: String) {
        val a = owned(c); val out = JSONArray()
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optString("code") != code) out.put(a.optJSONObject(i))
        sp(c).edit().putString("ownedGroups", out.toString()).apply()
    }

    fun memberId(pid: String) = (Backend.uidNow() ?: "") + "_" + pid

    /** Does any group of the current profile ask for a grown-up's approval before coins land? */
    fun needsApproval(c: Context): Boolean {
        val a = memberships(c)
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optBoolean("approvals") == true) return true
        return false
    }

    fun typeLabel(c: Context, type: String) = Lang.t(c, when (type) { "class" -> "Class"; "family" -> "Family"; else -> "Friends" })

    // ---------- stats published for a profile ----------
    private fun statsFor(c: Context, pid: String): Map<String, Any?> {
        val p = Profiles.find(c, pid) ?: JSONObject()
        val st = try { JSONObject(sp(c).getString("state__$pid", "") ?: "") } catch (e: Exception) { JSONObject() }
        val g = try { JSONArray(sp(c).getString("gallery__$pid", "[]")) } catch (e: Exception) { JSONArray() }
        val since = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        var wt = 0; var wp = 0; var last = 0L
        for (i in 0 until g.length()) {
            val o = g.optJSONObject(i) ?: continue
            val t = o.optLong("time"); if (t > last) last = t
            if (t >= since) { wt++; wp += o.optInt("points") }
        }
        val total = st.optInt("total", 0)
        val today = if (st.optString("day") == Progress.todayKey()) st.optInt("dayCount", 0) else 0
        return mapOf(
            "name" to p.optString("name", "Me"), "emoji" to p.optString("emoji", "⭐"), "color" to p.optString("color", "#3a66d6"),
            "total" to total, "level" to Progress.level(total), "weekTasks" to wt, "weekPoints" to wp,
            "today" to today, "goal" to sp(c).getInt("goal", 3), "lastWin" to last
        )
    }

    // ---------- join / leave ----------
    fun join(c: Context, rawCode: String, pid: String, onDone: (Boolean, String) -> Unit) {
        val code = rawCode.trim().uppercase()
        if (code.length < 6) { onDone(false, Lang.t(c, "That code looks too short.")); return }
        if (find(c, code, pid) != null) { onDone(false, Lang.t(c, "Already in this group.")); return }
        Backend.groupInfo(code) { info ->
            if (info == null) { onDone(false, Lang.t(c, "No group with that code. Check it and your connection.")); return@groupInfo }
            val m = JSONObject().put("code", code).put("name", info["name"] as? String ?: code)
                .put("type", info["type"] as? String ?: "friends").put("approvals", info["approvals"] == true)
            val a = memberships(c, pid); a.put(m); saveMemberships(c, pid, a)
            Backend.pushMember(code, pid, statsFor(c, pid)) { ok -> onDone(ok, if (ok) Lang.t(c, "Joined!") else Lang.t(c, "Couldn't join. Check your connection.")) }
        }
    }

    /** Put a profile on this device into a group we already know (teacher bulk add) and publish it. */
    fun joinKnown(c: Context, code: String, name: String, type: String, approvals: Boolean, pid: String, onDone: (Boolean) -> Unit) {
        if (find(c, code, pid) == null) {
            val a = memberships(c, pid)
            a.put(JSONObject().put("code", code).put("name", name).put("type", type).put("approvals", approvals))
            saveMemberships(c, pid, a)
        }
        Backend.pushMember(code, pid, statsFor(c, pid), onDone)
    }

    /** Profiles on this device that are in [code]. */
    fun localMembers(c: Context, code: String): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        val ps = Profiles.list(c)
        for (i in 0 until ps.length()) { val p = ps.optJSONObject(i) ?: continue; if (find(c, code, p.optString("id")) != null) out.add(p) }
        return out
    }

    fun leave(c: Context, code: String, pid: String = Profiles.currentId(c)) {
        val a = memberships(c, pid); val out = JSONArray()
        for (i in 0 until a.length()) if (a.optJSONObject(i)?.optString("code") != code) out.put(a.optJSONObject(i))
        saveMemberships(c, pid, out)
        Backend.ensureUid { Backend.removeMember(code, memberId(pid)) }
    }

    // ---------- hooks from a passed task ----------
    fun thumb(c: Context, proof: String): String? {
        return try {
            val f = File(File(c.filesDir, "proofs"), proof)
            if (!f.exists()) return null
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, b)
            var s = 1; while (maxOf(b.outWidth, b.outHeight) / s > 640) s *= 2
            var bmp = BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
            val scale = 360f / maxOf(bmp.width, bmp.height)
            if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true)
            val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 60, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (e: Exception) { null }
    }

    fun decodeThumb(b64: String?): Bitmap? = try {
        if (b64.isNullOrEmpty()) null else Base64.decode(b64, Base64.DEFAULT).let { BitmapFactory.decodeByteArray(it, 0, it.size) }
    } catch (e: Exception) { null }

    /** A task passed: world counter, a post in each group's feed, refreshed stats. */
    fun onWin(c: Context, task: String, points: Int, bonuses: Int, proof: String) {
        val app = c.applicationContext
        Backend.bumpWorldTask()
        val pid = Profiles.currentId(app)
        val me = Profiles.current(app)
        val a = memberships(app, pid)
        if (a.length() == 0) return
        Thread {
            var pic: String? = null
            for (i in 0 until a.length()) {
                val m = a.optJSONObject(i) ?: continue
                val adults = m.optString("type") != "friends"
                if (adults && pic == null) pic = thumb(app, proof)
                val code = m.optString("code")
                Backend.postFeed(code, mapOf(
                    "type" to "win", "mid" to memberId(pid), "name" to me.optString("name"), "emoji" to me.optString("emoji", "⭐"),
                    "task" to task, "points" to points, "bonuses" to bonuses, "thumb" to (if (adults) pic else null)
                ))
                Backend.pushMember(code, pid, statsFor(app, pid))
            }
        }.start()
    }

    /** Coins were held for approval: also send them to every group that approves remotely. */
    fun onPending(c: Context, rid: String, coins: Int, task: String, proof: String, study: Boolean) {
        val app = c.applicationContext
        val pid = Profiles.currentId(app)
        val me = Profiles.current(app)
        val a = memberships(app, pid)
        Thread {
            val pic = thumb(app, proof)
            for (i in 0 until a.length()) {
                val m = a.optJSONObject(i) ?: continue
                if (!m.optBoolean("approvals")) continue
                val code = m.optString("code")
                Backend.createPending(code, mapOf(
                    "mid" to memberId(pid), "pid" to pid, "name" to me.optString("name"), "emoji" to me.optString("emoji", "⭐"),
                    "task" to task, "coins" to coins, "study" to study, "thumb" to pic, "rid" to rid
                )) { id -> if (id != null) addRemoteRef(app, rid, code, id) }
            }
        }.start()
    }

    @Synchronized private fun addRemoteRef(c: Context, rid: String, code: String, id: String) {
        val p = arr(c, "pending")
        for (i in 0 until p.length()) {
            val o = p.optJSONObject(i) ?: continue
            if (o.optString("rid") == rid) {
                val r = o.optJSONArray("remote") ?: JSONArray()
                r.put(JSONObject().put("code", code).put("id", id)); o.put("remote", r)
            }
        }
        sp(c).edit().putString("pending", p.toString()).apply()
    }

    /** A grown-up approved/rejected on this phone (Parent zone): take it back from the groups. */
    fun withdrawRemote(entry: JSONObject) {
        val r = entry.optJSONArray("remote") ?: return
        for (i in 0 until r.length()) r.optJSONObject(i)?.let { Backend.setPendingStatus(it.optString("code"), it.optString("id"), "withdrawn") }
    }

    fun addCoins(c: Context, profileId: String, amount: Int, study: Boolean) {
        val id = profileId.ifBlank { Profiles.currentId(c) }
        val key = "state__$id"
        val st = try { JSONObject(sp(c).getString(key, "") ?: "") } catch (e: Exception) { JSONObject() }
        val field = if (study) "scoins" else "coins"
        st.put(field, st.optInt(field, 0) + amount)
        sp(c).edit().putString(key, st.toString()).apply()
    }

    fun highFive(c: Context, code: String, toMid: String, toName: String) {
        val me = Profiles.current(c)
        Backend.postFeed(code, mapOf("type" to "highfive", "mid" to memberId(Profiles.currentId(c)), "name" to me.optString("name"),
            "emoji" to me.optString("emoji", "⭐"), "to" to toMid, "toName" to toName))
    }

    // ---------- sync when the app opens ----------
    private var lastSync = 0L

    /** Push my stats, refresh group settings, apply remote approvals, show high-fives, take pranks,
     *  run the daily auto-backup. [onChanged] runs on the UI thread when Home should refresh. */
    fun sync(a: Activity, onChanged: () -> Unit) {
        val now = System.currentTimeMillis()
        if (now - lastSync < 30_000) return
        lastSync = now
        Backend.ensureUid { _ ->
            val pid = Profiles.currentId(a)
            val mine = memberships(a, pid)
            for (i in 0 until mine.length()) {
                val m = mine.optJSONObject(i) ?: continue
                val code = m.optString("code")
                Backend.pushMember(code, pid, statsFor(a, pid))
                Backend.groupInfo(code) { info ->
                    if (info == null) return@groupInfo
                    m.put("name", info["name"] as? String ?: code).put("approvals", info["approvals"] == true)
                        .put("news", info["news"] as? String ?: "").put("goalTitle", info["goalTitle"] as? String ?: "")
                        .put("goalTarget", (info["goalTarget"] as? Number)?.toInt() ?: 0)
                    saveMemberships(a, pid, mine)
                    a.runOnUiThread(onChanged)
                }
                checkHighFives(a, code, pid)
            }
            checkRemoteApprovals(a, onChanged)
            checkInbox(a)
            autoBackupIfDue(a)
        }
    }

    private fun checkHighFives(a: Activity, code: String, pid: String) {
        val seenKey = "feedSeen__${pid}__$code"
        val seen = sp(a).getLong(seenKey, 0L)
        val myMid = memberId(pid)
        Backend.listFeed(code, 30) { docs ->
            if (docs == null) return@listFeed
            var newest = seen
            val names = ArrayList<String>()
            for (d in docs) {
                val ts = (d.data["ts"] as? Number)?.toLong() ?: 0L
                if (ts > newest) newest = ts
                if (ts > seen && d.data["type"] == "highfive" && d.data["to"] == myMid) names.add((d.data["emoji"] as? String ?: "") + " " + (d.data["name"] as? String ?: ""))
            }
            sp(a).edit().putLong(seenKey, newest).apply()
            if (seen == 0L || names.isEmpty() || a.isFinishing) return@listFeed
            val msg = names.distinct().joinToString("\n") + "\n\n" + Lang.t(a, "sent you a high-five! 🙌")
            a.runOnUiThread { runCatching { AlertDialog.Builder(a).setTitle("🙌").setMessage(msg).setPositiveButton(Lang.t(a, "Nice!"), null).show() } }
        }
    }

    private fun checkRemoteApprovals(a: Activity, onChanged: () -> Unit) {
        val p = arr(a, "pending")
        for (i in 0 until p.length()) {
            val o = p.optJSONObject(i) ?: continue
            val r = o.optJSONArray("remote") ?: continue
            val rid = o.optString("rid")
            for (j in 0 until r.length()) {
                val ref = r.optJSONObject(j) ?: continue
                Backend.pendingStatus(ref.optString("code"), ref.optString("id")) { status ->
                    if (status == "approved" || status == "rejected") resolveLocal(a, rid, status == "approved", onChanged)
                }
            }
        }
    }

    @Synchronized private fun resolveLocal(a: Activity, rid: String, approved: Boolean, onChanged: () -> Unit) {
        val p = arr(a, "pending"); val out = JSONArray(); var hit: JSONObject? = null
        for (i in 0 until p.length()) { val o = p.optJSONObject(i) ?: continue; if (hit == null && o.optString("rid") == rid) hit = o else out.put(o) }
        val e = hit ?: return // already handled (e.g. by another group or the Parent zone)
        sp(a).edit().putString("pending", out.toString()).apply()
        if (approved) addCoins(a, e.optString("profileId"), e.optInt("coins"), e.optBoolean("study"))
        withdrawRemote(e) // close it in the other groups too
        val msg = (if (approved) Lang.t(a, "✅ Approved:") + " +" + e.optInt("coins") + " " + Lang.t(a, "coins") else Lang.t(a, "❌ Not approved:")) + "  " + e.optString("task")
        a.runOnUiThread { android.widget.Toast.makeText(a, msg, android.widget.Toast.LENGTH_LONG).show(); onChanged() }
    }

    private fun checkInbox(a: Activity) {
        Backend.friendCode(a) { code ->
            Backend.takeInbox(code) { keys ->
                if (sp(a).getBoolean("trollsBlocked", false)) return@takeInbox
                var gag: String? = null; var persist = false
                for (k in keys) {
                    val set = Pranks.decode(k) ?: continue
                    Pranks.applyPersistent(a, set)?.let { gag = it }
                    if (set.any { it.persist }) persist = true
                    if (set.any { it.id.startsWith("ads_") }) sp(a).edit().putBoolean("adsJustUnlocked", true).apply()
                }
                val g = gag
                a.runOnUiThread {
                    if (g != null) a.startActivity(Intent(a, PrankActivity::class.java).putExtra("gag", g))
                    else if (persist) a.recreate()
                }
            }
        }
    }

    // ---------- daily automatic cloud backup ----------
    /** Device-specific keys that must not travel to another phone in a backup. */
    val NOT_BACKED_UP = setOf("key", "parentPin", "friendCode", "friendCodeSaved", "fbRegistered", "autoBackupDay", "ownedGroups")

    fun autoBackupOn(c: Context) = sp(c).getBoolean("autoBackup", false)
    fun autoBackupCode(c: Context): String {
        var code = sp(c).getString("autoBackupCode", "") ?: ""
        if (code.isEmpty()) { code = Backend.newBackupCode(); sp(c).edit().putString("autoBackupCode", code).apply() }
        return code
    }

    fun backupJson(c: Context): String {
        val all = sp(c).all
        val root = JSONObject()
        for ((k, v) in all) {
            if (k in NOT_BACKED_UP) continue
            val e = JSONObject()
            when (v) {
                is String -> e.put("t", "s").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Boolean -> e.put("t", "b").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                else -> continue
            }
            root.put(k, e)
        }
        return JSONObject().put("combo_backup", 1).put("data", root).toString()
    }

    fun autoBackupIfDue(c: Context, force: Boolean = false) {
        if (!autoBackupOn(c)) return
        val today = Progress.todayKey()
        if (!force && sp(c).getString("autoBackupDay", "") == today) return
        Backend.autoBackup(autoBackupCode(c), backupJson(c)) { ok -> if (ok) sp(c).edit().putString("autoBackupDay", today).apply() }
    }
}
