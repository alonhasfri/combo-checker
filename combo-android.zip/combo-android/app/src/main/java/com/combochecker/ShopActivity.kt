package com.combochecker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Spend coins on abilities and skins. Reads/writes the same "state" JSON the game uses. */
class ShopActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private lateinit var root: LinearLayout
    private var pad = 0
    private var debug = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        modern = !sp().getBoolean("classicMenu", false)
        tab = intent.getIntExtra("tab", 0)
        if (!modern) setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private var modern = false
    private var tab = 0

    override fun onResume() {
        super.onResume()
        if (modern) refresh() // coins can change on other tabs/screens
    }

    private fun loadState(): JSONObject {
        val s = sp().getString(Profiles.stateKey(this), "") ?: ""
        val o = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        if (!o.has("coins")) o.put("coins", 0)
        if (!o.has("scoins")) o.put("scoins", 0)
        if (!o.has("owned")) o.put("owned", JSONArray())
        if (!o.has("star")) o.put("star", "star_default")
        if (!o.has("circle")) o.put("circle", "circle_default")
        if (!o.has("confetti")) o.put("confetti", "confetti_default")
        if (!o.has("banner")) o.put("banner", "banner_default")
        return o
    }

    private fun saveState(o: JSONObject) = sp().edit().putString(Profiles.stateKey(this), o.toString()).apply()

    private fun pool(st: JSONObject) = st.optInt("coins", 0) + st.optInt("scoins", 0)

    /** Can this be afforded? studyOnly items need study coins; otherwise the two balances pool. */
    private fun canAfford(st: JSONObject, cost: Int, studyOnly: Boolean): Boolean =
        debug || (if (studyOnly) st.optInt("scoins", 0) >= cost else pool(st) >= cost)

    /** Pay `cost`, mutating st. studyOnly spends study coins only; otherwise general first then study.
     *  Returns false (no change) if there isn't enough. */
    private fun pay(st: JSONObject, cost: Int, studyOnly: Boolean): Boolean {
        if (debug) return true
        if (studyOnly) {
            val sc = st.optInt("scoins", 0)
            if (sc < cost) return false
            st.put("scoins", sc - cost)
            return true
        }
        if (pool(st) < cost) return false
        val gen = st.optInt("coins", 0)
        val fromGen = minOf(gen, cost)
        st.put("coins", gen - fromGen)
        val rem = cost - fromGen
        if (rem > 0) st.put("scoins", st.optInt("scoins", 0) - rem)
        return true
    }

    private fun owns(o: JSONObject, id: String, cost: Int): Boolean {
        if (debug || cost == 0) return true
        val arr = o.optJSONArray("owned") ?: return false
        for (i in 0 until arr.length()) if (arr.optString(i) == id) return true
        return false
    }

    private fun refresh() {
        if (modern) { refreshModern(); return }
        root.removeAllViews()
        val st = loadState()
        debug = st.optBoolean("debug", false)
        val coins = st.optInt("coins", 0)
        val scoins = st.optInt("scoins", 0)

        root.addView(TextView(this).apply {
            text = tr("🛍️ Shop"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = if (debug) "🪙 ∞   📚 ∞   🛠 debug" else "🪙 $coins   📚 $scoins"
            textSize = 20f; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, pad / 2, 0, pad / 2); setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = tr("🪙 general coins (any task) · 📚 study coins (school work)")
            textSize = 13f; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 0, 0, pad / 4)
        })
        root.addView(TextView(this).apply {
            text = tr("Earn coins every time a task passes. Spend them here. Buying a skin equips it.")
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })

        header("Abilities")
        ability(st, "Double Points", "next check scores x2 points", "dp", "dpActive", ShopCatalog.DOUBLE_POINTS_COST, coins)
        ability(st, "Coin Doubler", "next check earns x2 coins", "cd", "cdActive", ShopCatalog.COIN_DOUBLER_COST, coins)
        ability(st, "Hint", "AI tips for the bonuses you miss, next check", "hint", "hintActive", ShopCatalog.HINT_COST, coins)
        ability(st, "Retry token", "redo a failed check — used automatically", "retry", null, ShopCatalog.RETRY_COST, coins)

        skinSection("Checkpoint style", ShopCatalog.stars, "star", st, coins)
        skinSection("Circle colour", ShopCatalog.circles, "circle", st, coins)
        skinSection("Confetti", ShopCatalog.confetti, "confetti", st, coins)
        skinSection("Win banner", ShopCatalog.banners, "banner", st, coins)

        val rewards = JSONArray(sp().getString("rewards", "[]"))
        if (rewards.length() > 0) {
            header("Real-life rewards")
            root.addView(TextView(this).apply {
                text = tr("Set up by a parent. Redeeming shows a note to show them.")
                textSize = 14f; setPadding(0, 0, 0, pad / 8)
            })
            for (i in 0 until rewards.length()) {
                val rw = rewards.getJSONObject(i)
                val name = rw.optString("name"); val cost = rw.optInt("cost")
                val studyOnly = rw.optBoolean("studyOnly", false)
                root.addView(TextView(this).apply {
                    text = name + "   — " + cost + " " + tr("coins") +
                        (if (studyOnly) "   📚 " + he("study only", "לימוד בלבד") else "")
                    textSize = 16f; setPadding(0, pad / 4, 0, 0)
                })
                row(tr("Redeem") + " " + name, canAfford(st, cost, studyOnly)) {
                    val s = loadState()
                    if (!pay(s, cost, studyOnly)) { toast(if (studyOnly) "Not enough study coins" else "Not enough coins"); return@row }
                    saveState(s)
                    val log = JSONArray(sp().getString("redemptions", "[]"))
                    val me = Profiles.current(this@ShopActivity)
                    log.put(
                        JSONObject().put("name", name).put("cost", cost)
                            .put("time", System.currentTimeMillis())
                            .put("profileId", me.optString("id"))
                            .put("profileName", me.optString("name"))
                    )
                    sp().edit().putString("redemptions", log.toString()).apply()
                    toast(he("Redeemed! Show your parent.", "מומש! הראו להורה."))
                    refresh()
                }
            }
        }

        root.addView(Button(this).apply { text = tr("Done"); setOnClickListener { finish() } })
    }

    private fun ability(st: JSONObject, name: String, desc: String, countKey: String, activeKey: String?, cost: Int, coins: Int) {
        val count = st.optInt(countKey, 0)
        val active = activeKey != null && st.optBoolean(activeKey, false)
        val dispName = tr(name); val dispDesc = tr(desc)
        root.addView(TextView(this).apply {
            text = dispName + " — " + dispDesc + "   (" + he("owned:", "ברשותך:") + " " + (if (debug) "∞" else count.toString()) + ")" +
                if (active) "   ✅ " + he("armed", "דרוך") else ""
            textSize = 15f; setPadding(0, pad / 3, 0, pad / 8)
        })
        row(tr("Buy") + " " + dispName + " (" + cost + " " + tr("coins") + ")", canAfford(st, cost, false)) {
            val s = loadState()
            if (!pay(s, cost, false)) { toast("Not enough coins"); return@row }
            s.put(countKey, s.optInt(countKey, 0) + 1)
            saveState(s); toast(he("Bought", "נקנה") + " " + dispName); refresh()
        }
        if (activeKey != null) {
            row(if (active) "✅ " + he("Armed", "דרוך") else tr("Arm") + " " + dispName, (debug || count > 0) && !active) {
                val s = loadState()
                if (!debug && s.optInt(countKey, 0) <= 0) { toast("Buy one first"); return@row }
                if (s.optBoolean(activeKey, false)) return@row
                if (!debug) s.put(countKey, s.optInt(countKey, 0) - 1)
                s.put(activeKey, true)
                saveState(s); toast(dispName + " " + he("armed for your next check!", "דרוך לבדיקה הבאה!")); refresh()
            }
        }
    }

    private fun skinSection(title: String, items: List<ShopCatalog.Skin>, key: String, st: JSONObject, coins: Int) {
        header(title)
        val equipped = st.optString(key, items.first().id)
        for (sk in items) {
            val owned = owns(st, sk.id, sk.cost)
            val isEq = sk.id == equipped
            val skName = tr(sk.name)
            val tail = when {
                isEq -> "   ✅ " + he("equipped", "מוצמד")
                owned -> "   (" + he("owned", "ברשותך") + ")"
                else -> "   — " + sk.cost + " " + tr("coins")
            }
            root.addView(TextView(this).apply {
                text = (if (sk.extra.isNotEmpty()) sk.extra + "  " else "") + skName + tail
                textSize = 16f; setPadding(0, pad / 4, 0, 0)
            })
            if (isEq) {
                // equipped: no button
            } else if (owned) {
                row(tr("Equip") + " " + skName, true) {
                    val s = loadState(); s.put(key, sk.id); saveState(s); toast(he("Equipped", "הוצמד") + " " + skName); refresh()
                }
            } else {
                row(tr("Buy") + " " + skName + " (" + sk.cost + " " + tr("coins") + ")", canAfford(st, sk.cost, false)) {
                    val s = loadState()
                    if (!pay(s, sk.cost, false)) { toast("Not enough coins"); return@row }
                    val arr = s.optJSONArray("owned") ?: JSONArray()
                    arr.put(sk.id); s.put("owned", arr); s.put(key, sk.id)
                    saveState(s); toast(he("Bought", "נקנה") + " " + skName); refresh()
                }
            }
        }
    }

    private fun header(label: String) {
        root.addView(TextView(this).apply {
            text = Lang.t(this@ShopActivity, label); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
    }

    private fun row(label: String, enabled: Boolean, onClick: () -> Unit) {
        root.addView(Button(this).apply { text = label; isEnabled = enabled; setOnClickListener { onClick() } })
    }

    private fun tr(s: String) = if (modern) Voice.say(this, s) else Lang.t(this, s)
    private fun he(en: String, heb: String) = if (Lang.isHebrew(this)) heb else en

    private fun toast(m: String) = Toast.makeText(this, Lang.t(this@ShopActivity, m), Toast.LENGTH_SHORT).show()

    // ===================== redesigned shop (new menu) =====================
    private fun d(v: Int) = Ui.dp(this, v)

    private val swatch = mapOf(
        "circle_default" to "#FF4FB0", "circle_cyan" to "#2FD0E8", "circle_green" to "#3AD06A",
        "circle_red" to "#E83A3A", "circle_gold" to "#E8B500", "circle_purple" to "#8A4AE8"
    )
    private val skinEmoji = mapOf(
        "confetti_default" to "🎉", "confetti_fire" to "🔥", "confetti_ice" to "❄️", "confetti_gold" to "✨", "confetti_neon" to "💡",
        "banner_default" to "💖", "banner_gold" to "🏆", "banner_cyan" to "💠", "banner_fire" to "🔥", "banner_rainbow" to "🌈"
    )

    private fun refreshModern() {
        val p = Ui.pal(this)
        val st = loadState()
        debug = st.optBoolean("debug", false)
        root = Ui.page(this)
        root.addView(Ui.header(this, tr("Shop"), gear = true))

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = { LinearLayout.LayoutParams(Ui.WRAP, Ui.WRAP).apply { marginEnd = d(8) } }
        chips.addView(Ui.chip(this, R.drawable.ui_coin, Ui.tone(this, "gold").second, if (debug) "∞" else st.optInt("coins", 0).toString()), lp())
        chips.addView(Ui.chip(this, R.drawable.ui_book, Ui.tone(this, "green").second, (if (debug) "∞" else st.optInt("scoins", 0).toString()) + " " + tr("study")), lp())
        root.addView(chips, Ui.lp(this, 14))
        root.addView(Ui.text(this, tr("Coins come from every task that passes. Study coins come from school work."), 13f, p.muted, bold = false).apply { setPaddingRelative(0, d(8), 0, 0) })

        root.addView(Ui.segmented(this, listOf(tr("Skins"), tr("Powers"), tr("Sounds"), tr("Rewards")), tab) { tab = it; refreshModern() }, Ui.lp(this, 16))

        when (tab) {
            0 -> {
                skinGrid("Checkpoint style", ShopCatalog.stars, "star", st)
                skinGrid("Circle colour", ShopCatalog.circles, "circle", st)
                skinGrid("Confetti", ShopCatalog.confetti, "confetti", st)
                skinGrid("Win banner", ShopCatalog.banners, "banner", st)
            }
            1 -> {
                power(st, R.drawable.ui_zap, "blue", "Double Points", "next check scores x2 points", "dp", "dpActive", ShopCatalog.DOUBLE_POINTS_COST)
                power(st, R.drawable.ui_coin, "gold", "Coin Doubler", "next check earns x2 coins", "cd", "cdActive", ShopCatalog.COIN_DOUBLER_COST)
                power(st, R.drawable.ui_help, "purple", "Hint", "AI tips for the bonuses you miss, next check", "hint", "hintActive", ShopCatalog.HINT_COST)
                power(st, R.drawable.ui_reset, "green", "Retry token", "redo a failed check — used automatically", "retry", null, ShopCatalog.RETRY_COST)
            }
            2 -> {
                val c = Ui.card(this).apply { setPaddingRelative(d(18), d(18), d(18), d(18)) }
                val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                top.addView(Ui.tile(this, R.drawable.ui_music, "teal", 44, 24))
                top.addView(Ui.text(this, tr("Sound shop"), 18f, p.ink).apply { setPaddingRelative(d(12), 0, 0, 0) })
                c.addView(top)
                c.addView(Ui.text(this, tr("Pick the sounds that play when a task passes. Hear each one before you buy."), 14f, p.muted, bold = false).apply { setPaddingRelative(0, d(10), 0, d(14)) })
                c.addView(Ui.button(this, tr("Open the sound shop"), R.drawable.ui_play, p.accent, android.graphics.Color.WHITE) {
                    startActivity(android.content.Intent(this, SoundGalleryActivity::class.java))
                })
                root.addView(c, Ui.lp(this, 16))
            }
            else -> rewardsTab(st)
        }
        Ui.tabScreen(this, root, "shop")
    }

    private fun skinGrid(title: String, items: List<ShopCatalog.Skin>, key: String, st: JSONObject) {
        val p = Ui.pal(this)
        root.addView(Ui.sectionTitle(this, tr(title)))
        val equipped = st.optString(key, items.first().id)
        var line: LinearLayout? = null
        items.forEachIndexed { i, sk ->
            if (i % 2 == 0) { line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; root.addView(line, Ui.lp(this, if (i == 0) 0 else 10)) }
            val owned = owns(st, sk.id, sk.cost)
            val isEq = sk.id == equipped
            val name = tr(sk.name)
            val card = Ui.card(this).apply {
                gravity = Gravity.CENTER_HORIZONTAL; setPaddingRelative(d(12), d(14), d(12), d(12))
                if (isEq) background = Ui.rounded(p.card, d(20).toFloat(), p.accent, d(2))
            }
            val preview = TextView(this).apply {
                gravity = Gravity.CENTER; textSize = 26f
                val col = swatch[sk.id] ?: ShopCatalog.starColor[sk.id]
                text = sk.extra.ifEmpty { skinEmoji[sk.id] ?: "" }
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(if (col != null && sk.extra.isEmpty()) android.graphics.Color.parseColor(col) else p.track)
                }
            }
            if (key == "star") card.addView(CheckpointView(this).apply { colors = Checkpoint.colorsFor(sk.id) }, LinearLayout.LayoutParams(d(56), d(56)))
            else card.addView(preview, LinearLayout.LayoutParams(d(56), d(56)))
            card.addView(Ui.text(this, name, 15f, p.ink).apply { gravity = Gravity.CENTER; maxLines = 1; setPaddingRelative(0, d(8), 0, d(10)) })
            val btn = when {
                isEq -> Ui.button(this, he("Equipped", "מוצמד"), R.drawable.ui_check, p.accentSoft, p.accentInk, 40) {}
                owned -> Ui.button(this, tr("Equip"), null, p.track, p.ink, 40) {
                    val s = loadState(); s.put(key, sk.id); saveState(s); toast(he("Equipped", "הוצמד") + " " + name); refreshModern()
                }
                else -> {
                    val can = canAfford(st, sk.cost, false)
                    Ui.button(this, sk.cost.toString(), R.drawable.ui_coin, if (can) p.accent else p.track, if (can) android.graphics.Color.WHITE else p.muted, 40) {
                        val s = loadState()
                        if (!pay(s, sk.cost, false)) { toast("Not enough coins"); return@button }
                        val arr = s.optJSONArray("owned") ?: JSONArray()
                        arr.put(sk.id); s.put("owned", arr); s.put(key, sk.id)
                        saveState(s); toast(he("Bought", "נקנה") + " " + name); refreshModern()
                    }.apply { contentDescription = tr("Buy") + " " + name + ", " + sk.cost + " " + tr("coins") }
                }
            }
            card.addView(btn, LinearLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
            line!!.addView(card, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { if (i % 2 == 0) marginEnd = d(5) else marginStart = d(5) })
            if (i == items.size - 1 && i % 2 == 0) line!!.addView(android.view.View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = d(5) })
        }
    }

    private fun power(st: JSONObject, res: Int, tone: String, name: String, desc: String, countKey: String, activeKey: String?, cost: Int) {
        val p = Ui.pal(this)
        val count = st.optInt(countKey, 0)
        val active = activeKey != null && st.optBoolean(activeKey, false)
        val dispName = tr(name)
        val c = Ui.card(this).apply { setPaddingRelative(d(16), d(14), d(16), d(14)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(Ui.tile(this, res, tone, 42, 22))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
        col.addView(Ui.text(this, dispName, 16f, p.ink))
        col.addView(Ui.text(this, tr(desc), 13f, p.muted, bold = false))
        top.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        top.addView(Ui.text(this, "×" + (if (debug) "∞" else count.toString()), 16f, p.ink))
        c.addView(top)
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val can = canAfford(st, cost, false)
        btns.addView(Ui.button(this, tr("Buy") + " · " + cost, R.drawable.ui_coin, if (can) p.accent else p.track, if (can) android.graphics.Color.WHITE else p.muted, 42) {
            val s = loadState()
            if (!pay(s, cost, false)) { toast("Not enough coins"); return@button }
            s.put(countKey, s.optInt(countKey, 0) + 1)
            saveState(s); toast(he("Bought", "נקנה") + " " + dispName); refreshModern()
        }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        if (activeKey != null) {
            val armLabel = if (active) he("Armed", "דרוך") else tr("Arm")
            btns.addView(Ui.button(this, armLabel, if (active) R.drawable.ui_check else R.drawable.ui_target,
                if (active) Ui.tone(this, "green").first else p.track, if (active) p.good else p.ink, 42) {
                val s = loadState()
                if (s.optBoolean(activeKey, false)) return@button
                if (!debug && s.optInt(countKey, 0) <= 0) { toast("Buy one first"); return@button }
                if (!debug) s.put(countKey, s.optInt(countKey, 0) - 1)
                s.put(activeKey, true)
                saveState(s); toast(dispName + " " + he("armed for your next check!", "דרוך לבדיקה הבאה!")); refreshModern()
            }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { marginStart = d(10) })
        }
        c.addView(btns, Ui.lp(this, 12))
        root.addView(c, Ui.lp(this, 12))
    }

    private fun rewardsTab(st: JSONObject) {
        val p = Ui.pal(this)
        classRewards()
        partnerOffers()
        root.addView(Ui.sectionTitle(this, tr("From your parents")))
        val rewards = try { JSONArray(sp().getString("rewards", "[]")) } catch (e: Exception) { JSONArray() }
        if (rewards.length() == 0) {
            val c = Ui.card(this).apply { setPaddingRelative(d(18), d(18), d(18), d(18)); gravity = Gravity.CENTER_HORIZONTAL }
            c.addView(Ui.tile(this, R.drawable.ui_gift, "gold", 52, 28))
            c.addView(Ui.text(this, tr("No real-life rewards yet"), 16f, p.ink).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(12), 0, d(4)) })
            c.addView(Ui.text(this, tr("A parent can add rewards (like extra screen time) in Settings → Parent zone."), 14f, p.muted, bold = false).apply { gravity = Gravity.CENTER })
            root.addView(c, Ui.lp(this, 16))
            return
        }
        root.addView(Ui.text(this, tr("Set up by a parent. Redeeming shows a note to show them."), 13f, p.muted, bold = false).apply { setPaddingRelative(0, d(14), 0, 0) })
        for (i in 0 until rewards.length()) {
            val rw = rewards.getJSONObject(i)
            val name = rw.optString("name"); val cost = rw.optInt("cost")
            val studyOnly = rw.optBoolean("studyOnly", false)
            val can = canAfford(st, cost, studyOnly)
            val r = Ui.card(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(d(14), d(12), d(14), d(12)) }
            r.addView(Ui.tile(this, R.drawable.ui_gift, "gold", 40, 22))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), 0, d(8), 0) }
            col.addView(Ui.text(this, name, 15f, p.ink))
            col.addView(Ui.text(this, cost.toString() + " " + tr("coins") + if (studyOnly) " · " + he("study only", "לימוד בלבד") else "", 13f, p.muted, bold = false))
            r.addView(col, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
            r.addView(Ui.button(this, tr("Redeem"), null, if (can) p.accent else p.track, if (can) android.graphics.Color.WHITE else p.muted, 40) {
                val s = loadState()
                if (!pay(s, cost, studyOnly)) { toast(if (studyOnly) "Not enough study coins" else "Not enough coins"); return@button }
                saveState(s)
                val log = JSONArray(sp().getString("redemptions", "[]"))
                val me = Profiles.current(this@ShopActivity)
                log.put(JSONObject().put("name", name).put("cost", cost).put("time", System.currentTimeMillis())
                    .put("profileId", me.optString("id")).put("profileName", me.optString("name")))
                sp().edit().putString("redemptions", log.toString()).apply()
                toast(he("Redeemed! Show your parent.", "מומש! הראו להורה."))
                refreshModern()
            })
            root.addView(r, Ui.lp(this, 10))
        }
    }

    // ===================== partner offers =====================
    private fun couponsKey() = "coupons__" + Profiles.currentId(this)

    private val CATEGORIES = listOf("Sports & fitness", "Shows & culture", "Bikes & outdoor", "Games & toys", "Food & treats", "Learning", "Experiences", "Other")

    /** Offers from partner businesses (loaded from the server), grouped by category, plus my coupons. */
    private fun partnerOffers() {
        val p = Ui.pal(this)
        root.addView(Ui.sectionTitle(this, tr("Partner offers")))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(Ui.text(this, tr("Loading…"), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), 0, 0, 0) })
        root.addView(box)
        Backend.listPartners { docs ->
            if (isFinishing) return@listPartners
            box.removeAllViews()
            val list = (docs ?: emptyList()).filter { it.data["active"] != false }
            if (list.isEmpty()) {
                box.addView(Ui.card(this).apply {
                    setPaddingRelative(d(16), d(14), d(16), d(14))
                    addView(Ui.text(this@ShopActivity, tr(if (docs == null) "Couldn't load offers. Check your connection." else "Partner offers are coming soon: sports, shows, bikes and more, at special prices for Comboed."), 14f, p.muted, bold = false))
                })
            } else {
                val byCat = list.groupBy { (it.data["category"] as? String).orEmpty().ifEmpty { "Other" } }
                for (cat in CATEGORIES + byCat.keys.filter { it !in CATEGORIES }) {
                    val items = byCat[cat] ?: continue
                    box.addView(Ui.text(this, tr(cat), 13f, p.muted).apply { setPaddingRelative(d(4), d(10), 0, d(6)) })
                    box.addView(Ui.group(this, items.map { pd ->
                        val dt = pd.data
                        val cost = (dt["cost"] as? Number)?.toInt() ?: 0
                        Ui.row(this, R.drawable.ui_gift, "teal", (dt["emoji"] as? String ?: "🎟️") + "  " + (dt["name"] as? String ?: "") + " — " + (dt["offer"] as? String ?: ""),
                            "$cost " + tr("coins")) { redeemPartner(pd.id, dt) }
                    }))
                }
            }
            myCoupons(box)
        }
    }

    private fun myCoupons(box: LinearLayout) {
        val arr = try { JSONArray(sp().getString(couponsKey(), "[]")) } catch (e: Exception) { JSONArray() }
        if (arr.length() == 0) return
        box.addView(Ui.text(this, tr("My coupons"), 13f, Ui.pal(this).muted).apply { setPaddingRelative(d(4), d(14), 0, d(6)) })
        val rows = ArrayList<android.view.View>()
        for (i in arr.length() - 1 downTo 0) {
            val c = arr.getJSONObject(i)
            rows.add(Ui.row(this, R.drawable.ui_file, "gold", c.optString("partner") + " — " + c.optString("offer"), c.optString("code")) { showCoupon(c) })
        }
        box.addView(Ui.group(this, rows))
    }

    private fun showCoupon(c: JSONObject) {
        val p = Ui.pal(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPaddingRelative(d(20), d(10), d(20), 0) }
        col.addView(Ui.text(this, c.optString("code"), 32f, p.accentInk).apply {
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD); gravity = Gravity.CENTER; setTextIsSelectable(true)
        })
        col.addView(Ui.text(this, c.optString("offer"), 15f, p.ink, bold = false).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(8), 0, d(4)) })
        if (c.optString("howTo").isNotEmpty()) col.addView(Ui.text(this, c.optString("howTo"), 13f, p.muted, bold = false).apply { gravity = Gravity.CENTER })
        col.addView(Ui.text(this, Profiles.current(this).optString("name") + " · " + java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(c.optLong("time"))), 12f, p.muted, bold = false).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(8), 0, 0) })
        android.app.AlertDialog.Builder(this).setTitle("🎟️ " + c.optString("partner")).setView(col).setPositiveButton(tr("OK"), null).show()
    }

    private fun redeemPartner(id: String, dt: Map<String, Any?>) {
        val cost = (dt["cost"] as? Number)?.toInt() ?: 0
        val name = dt["name"] as? String ?: ""; val offer = dt["offer"] as? String ?: ""; val howTo = dt["howTo"] as? String ?: ""
        val msg = offer + "\n\n" + cost + " " + tr("coins") + (if (howTo.isNotEmpty()) "\n\n" + howTo else "") + "\n\n" + tr("You'll get a coupon code to show at the partner.")
        android.app.AlertDialog.Builder(this).setTitle((dt["emoji"] as? String ?: "🎟️") + " " + name).setMessage(msg)
            .setPositiveButton(tr("Redeem")) { _, _ -> withParentOk { doRedeem(id, name, offer, howTo, cost) } }
            .setNegativeButton(tr("Cancel"), null).show()
    }

    /** Real-world offers need a grown-up: ask for the parent PIN when one is set. */
    private fun withParentOk(go: () -> Unit) {
        val pin = sp().getString("parentPin", "") ?: ""
        if (pin.isEmpty()) { go(); return }
        val f = android.widget.EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD; hint = tr("Parent PIN") }
        android.app.AlertDialog.Builder(this).setTitle(tr("Ask a parent")).setMessage(tr("A parent needs to approve this. Enter the parent PIN."))
            .setView(android.widget.FrameLayout(this).apply { setPaddingRelative(d(20), d(4), d(20), 0); addView(f) })
            .setPositiveButton(tr("OK")) { _, _ -> if (f.text.toString().trim() == pin) go() else toast("Wrong PIN") }
            .setNegativeButton(tr("Cancel"), null).show()
    }

    private fun doRedeem(id: String, name: String, offer: String, howTo: String, cost: Int) {
        val s = loadState()
        if (!pay(s, cost, false)) { toast("Not enough coins"); return }
        saveState(s)
        val me = Profiles.current(this)
        Backend.redeem(mapOf("partnerId" to id, "partner" to name, "offer" to offer, "cost" to cost, "profileName" to me.optString("name"))) { code ->
            if (code == null) {
                val back = loadState(); back.put("coins", back.optInt("coins") + cost); saveState(back) // refund
                toast("Couldn't save. Check your connection."); refreshModern(); return@redeem
            }
            val c = JSONObject().put("code", code).put("partner", name).put("offer", offer).put("howTo", howTo).put("time", System.currentTimeMillis())
            val arr = try { JSONArray(sp().getString(couponsKey(), "[]")) } catch (e: Exception) { JSONArray() }
            arr.put(c); sp().edit().putString(couponsKey(), arr.toString()).apply()
            refreshModern(); showCoupon(c)
        }
    }

    // ===================== class / group rewards =====================
    /** Rewards set by the teacher (or group owner) in each group this profile is in. */
    private fun classRewards() {
        val mine = Groups.memberships(this)
        if (mine.length() == 0) return
        val p = Ui.pal(this)
        root.addView(Ui.sectionTitle(this, tr("Class rewards")))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(Ui.text(this, tr("Loading…"), 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), 0, 0, 0) })
        root.addView(box)
        val rows = ArrayList<android.view.View>()
        var left = mine.length()
        for (i in 0 until mine.length()) {
            val m = mine.optJSONObject(i) ?: continue
            val code = m.optString("code"); val gname = m.optString("name")
            Backend.groupInfo(code) { gi ->
                @Suppress("UNCHECKED_CAST")
                val rw = ((gi?.get("rewards") as? List<*>) ?: emptyList<Any>()).mapNotNull { it as? Map<String, Any?> }
                for (r in rw) {
                    val name = r["name"] as? String ?: continue
                    val cost = (r["cost"] as? Number)?.toInt() ?: 0
                    rows.add(Ui.row(this, R.drawable.ui_gift, "purple", name, "$cost " + tr("coins") + " · " + gname) { buyClassReward(code, name, cost) })
                }
                left--
                if (left == 0 && !isFinishing) {
                    box.removeAllViews()
                    if (rows.isEmpty()) box.addView(Ui.card(this).apply {
                        setPaddingRelative(d(16), d(14), d(16), d(14))
                        addView(Ui.text(this@ShopActivity, tr("Your teacher hasn't added class rewards yet."), 14f, p.muted, bold = false))
                    }) else box.addView(Ui.group(this, rows))
                }
            }
        }
    }

    private fun buyClassReward(code: String, name: String, cost: Int) {
        android.app.AlertDialog.Builder(this).setTitle(name).setMessage(tr("Buy for") + " $cost " + tr("coins") + "?")
            .setPositiveButton(tr("Buy")) { _, _ ->
                if (!Groups.spend(this, cost)) { toast("Not enough coins"); return@setPositiveButton }
                Groups.post(this, code, mapOf("type" to "redeem", "task" to name, "points" to cost))
                refreshModern()
                android.app.AlertDialog.Builder(this).setTitle("🎁 $name").setMessage(tr("Bought! Show this to your teacher.") + "\n\n" + Profiles.current(this).optString("name") + " · " +
                    java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.getDefault()).format(java.util.Date())).setPositiveButton(tr("OK"), null).show()
            }.setNegativeButton(tr("Cancel"), null).show()
    }
}
