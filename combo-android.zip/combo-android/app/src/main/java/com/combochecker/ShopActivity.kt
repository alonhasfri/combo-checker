package com.combochecker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Spend coins on skins and the Double Points ability. Reads/writes the same "state" JSON the game uses. */
class ShopActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private lateinit var root: LinearLayout
    private var pad = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun loadState(): JSONObject {
        val s = sp().getString("state", "") ?: ""
        val o = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        if (!o.has("coins")) o.put("coins", 0)
        if (!o.has("owned")) o.put("owned", JSONArray())
        if (!o.has("star")) o.put("star", "star_default")
        if (!o.has("circle")) o.put("circle", "circle_default")
        if (!o.has("confetti")) o.put("confetti", "confetti_default")
        if (!o.has("banner")) o.put("banner", "banner_default")
        if (!o.has("dp")) o.put("dp", 0)
        if (!o.has("dpActive")) o.put("dpActive", false)
        return o
    }

    private fun saveState(o: JSONObject) = sp().edit().putString("state", o.toString()).apply()

    private fun owns(o: JSONObject, id: String, cost: Int): Boolean {
        if (cost == 0) return true
        val arr = o.optJSONArray("owned") ?: return false
        for (i in 0 until arr.length()) if (arr.optString(i) == id) return true
        return false
    }

    private fun refresh() {
        root.removeAllViews()
        val st = loadState()
        val coins = st.optInt("coins", 0)

        root.addView(TextView(this).apply {
            text = "\uD83D\uDECD\uFE0F Shop"
            textSize = 26f
            gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = "$coins \uD83E\uDE99 coins"
            textSize = 20f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, pad / 2, 0, pad / 2)
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Earn coins every time a task passes. Spend them here. Buying a skin equips it."
            textSize = 14f
            setPadding(0, 0, 0, pad / 2)
        })

        header("Ability")
        val dp = st.optInt("dp", 0)
        val dpActive = st.optBoolean("dpActive", false)
        root.addView(TextView(this).apply {
            text = "Double Points \u2014 your next check scores x2. Owned: $dp." +
                if (dpActive) "   \u2705 Armed for your next check!" else ""
            textSize = 15f
            setPadding(0, pad / 4, 0, pad / 8)
        })
        row("Buy Double Points (" + ShopCatalog.DOUBLE_POINTS_COST + " coins)", coins >= ShopCatalog.DOUBLE_POINTS_COST) {
            val s = loadState()
            if (s.optInt("coins", 0) < ShopCatalog.DOUBLE_POINTS_COST) { toast("Not enough coins"); return@row }
            s.put("coins", s.optInt("coins", 0) - ShopCatalog.DOUBLE_POINTS_COST)
            s.put("dp", s.optInt("dp", 0) + 1)
            saveState(s); toast("Bought Double Points"); refresh()
        }
        row(if (dpActive) "Armed \u2705" else "Arm Double Points for next check", dp > 0 && !dpActive) {
            val s = loadState()
            if (s.optInt("dp", 0) <= 0 || s.optBoolean("dpActive", false)) return@row
            s.put("dp", s.optInt("dp", 0) - 1)
            s.put("dpActive", true)
            saveState(s); toast("Armed! Your next check scores x2."); refresh()
        }

        skinSection("Floating star", ShopCatalog.stars, "star", st, coins)
        skinSection("Circle colour", ShopCatalog.circles, "circle", st, coins)
        skinSection("Confetti", ShopCatalog.confetti, "confetti", st, coins)
        skinSection("Win banner", ShopCatalog.banners, "banner", st, coins)

        root.addView(Button(this).apply {
            text = "Done"
            setOnClickListener { finish() }
        })
    }

    private fun skinSection(title: String, items: List<ShopCatalog.Skin>, key: String, st: JSONObject, coins: Int) {
        header(title)
        val equipped = st.optString(key, items.first().id)
        for (sk in items) {
            val owned = owns(st, sk.id, sk.cost)
            val isEq = sk.id == equipped
            val tail = when {
                isEq -> "   \u2705 equipped"
                owned -> "   (owned)"
                else -> "   \u2014 " + sk.cost + " coins"
            }
            root.addView(TextView(this).apply {
                text = (if (sk.extra.isNotEmpty()) sk.extra + "  " else "") + sk.name + tail
                textSize = 16f
                setPadding(0, pad / 4, 0, 0)
            })
            if (isEq) {
                // already equipped: no button
            } else if (owned) {
                row("Equip " + sk.name, true) {
                    val s = loadState(); s.put(key, sk.id); saveState(s); toast("Equipped " + sk.name); refresh()
                }
            } else {
                row("Buy " + sk.name + " (" + sk.cost + " coins)", coins >= sk.cost) {
                    val s = loadState()
                    if (s.optInt("coins", 0) < sk.cost) { toast("Not enough coins"); return@row }
                    s.put("coins", s.optInt("coins", 0) - sk.cost)
                    val arr = s.optJSONArray("owned") ?: JSONArray()
                    arr.put(sk.id); s.put("owned", arr)
                    s.put(key, sk.id)
                    saveState(s); toast("Bought " + sk.name); refresh()
                }
            }
        }
    }

    private fun header(label: String) {
        root.addView(TextView(this).apply {
            text = label
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad, 0, pad / 4)
        })
    }

    private fun row(label: String, enabled: Boolean, onClick: () -> Unit) {
        root.addView(Button(this).apply {
            text = label
            isEnabled = enabled
            setOnClickListener { onClick() }
        })
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
