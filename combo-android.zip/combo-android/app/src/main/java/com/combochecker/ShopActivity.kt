package com.combochecker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

/** Spend coins on abilities and skins. Reads/writes the same "state" JSON the game uses. */
class ShopActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private lateinit var root: LinearLayout
    private var pad = 0
    private var debug = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun loadState(): JSONObject {
        val s = sp().getString(Profiles.stateKey(this), "") ?: ""
        val o = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        if (!o.has("coins")) o.put("coins", 0)
        if (!o.has("scoins")) o.put("scoins", 0)
        if (!o.has("owned")) o.put("owned", JSONArray())
        if (!o.has("star")) o.put("star", "star_default")
        if (!o.has("circle")) o.put("circle", "circle_default")
        if (!o.has("confetti")) o.put("confetti", "confetti_default")
        if (!o.has("banner")) o.put("banner", "banner_default")
        return o
    }

    private fun saveState(o: JSONObject) = sp().edit().putString(Profiles.stateKey(this), o.toString()).apply()

    private fun pool(st: JSONObject) = st.optInt("coins", 0) + st.optInt("scoins", 0)

    /** Can this be afforded? studyOnly items need study coins; otherwise the two balances pool. */
    private fun canAfford(st: JSONObject, cost: Int, studyOnly: Boolean): Boolean =
        debug || (if (studyOnly) st.optInt("scoins", 0) >= cost else pool(st) >= cost)

    /** Pay `cost`, mutating st. studyOnly spends study coins only; otherwise general first then study.
     *  Returns false (no change) if there isn't enough. */
    private fun pay(st: JSONObject, cost: Int, studyOnly: Boolean): Boolean {
        if (debug) return true
        if (studyOnly) {
            val sc = st.optInt("scoins", 0)
            if (sc < cost) return false
            st.put("scoins", sc - cost)
            return true
        }
        if (pool(st) < cost) return false
        val gen = st.optInt("coins", 0)
        val fromGen = minOf(gen, cost)
        st.put("coins", gen - fromGen)
        val rem = cost - fromGen
        if (rem > 0) st.put("scoins", st.optInt("scoins", 0) - rem)
        return true
    }

    private fun owns(o: JSONObject, id: String, cost: Int): Boolean {
        if (debug || cost == 0) return true
        val arr = o.optJSONArray("owned") ?: return false
        for (i in 0 until arr.length()) if (arr.optString(i) == id) return true
        return false
    }

    private fun refresh() {
        root.removeAllViews()
        val st = loadState()
        debug = st.optBoolean("debug", false)
        val coins = st.optInt("coins", 0)
        val scoins = st.optInt("scoins", 0)

        root.addView(TextView(this).apply {
            text = tr("🛍️ Shop"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        root.addView(TextView(this).apply {
            text = if (debug) "🪙 ∞   📚 ∞   🛠 debug" else "🪙 $coins   📚 $scoins"
            textSize = 20f; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, pad / 2, 0, pad / 2); setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = tr("🪙 general coins (any task) · 📚 study coins (school work)")
            textSize = 13f; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, 0, 0, pad / 4)
        })
        root.addView(TextView(this).apply {
            text = tr("Earn coins every time a task passes. Spend them here. Buying a skin equips it.")
            textSize = 14f; setPadding(0, 0, 0, pad / 2)
        })

        header("Abilities")
        ability(st, "Double Points", "next check scores x2 points", "dp", "dpActive", ShopCatalog.DOUBLE_POINTS_COST, coins)
        ability(st, "Coin Doubler", "next check earns x2 coins", "cd", "cdActive", ShopCatalog.COIN_DOUBLER_COST, coins)
        ability(st, "Hint", "AI tips for the bonuses you miss, next check", "hint", "hintActive", ShopCatalog.HINT_COST, coins)
        ability(st, "Retry token", "redo a failed check — used automatically", "retry", null, ShopCatalog.RETRY_COST, coins)

        skinSection("Floating star", ShopCatalog.stars, "star", st, coins)
        skinSection("Circle colour", ShopCatalog.circles, "circle", st, coins)
        skinSection("Confetti", ShopCatalog.confetti, "confetti", st, coins)
        skinSection("Win banner", ShopCatalog.banners, "banner", st, coins)

        val rewards = JSONArray(sp().getString("rewards", "[]"))
        if (rewards.length() > 0) {
            header("Real-life rewards")
            root.addView(TextView(this).apply {
                text = tr("Set up by a parent. Redeeming shows a note to show them.")
                textSize = 14f; setPadding(0, 0, 0, pad / 8)
            })
            for (i in 0 until rewards.length()) {
                val rw = rewards.getJSONObject(i)
                val name = rw.optString("name"); val cost = rw.optInt("cost")
                val studyOnly = rw.optBoolean("studyOnly", false)
                root.addView(TextView(this).apply {
                    text = name + "   — " + cost + " " + tr("coins") +
                        (if (studyOnly) "   📚 " + he("study only", "לימוד בלבד") else "")
                    textSize = 16f; setPadding(0, pad / 4, 0, 0)
                })
                row(tr("Redeem") + " " + name, canAfford(st, cost, studyOnly)) {
                    val s = loadState()
                    if (!pay(s, cost, studyOnly)) { toast(if (studyOnly) "Not enough study coins" else "Not enough coins"); return@row }
                    saveState(s)
                    val log = JSONArray(sp().getString("redemptions", "[]"))
                    val me = Profiles.current(this@ShopActivity)
                    log.put(
                        JSONObject().put("name", name).put("cost", cost)
                            .put("time", System.currentTimeMillis())
                            .put("profileId", me.optString("id"))
                            .put("profileName", me.optString("name"))
                    )
                    sp().edit().putString("redemptions", log.toString()).apply()
                    toast(he("Redeemed! Show your parent.", "מומש! הראו להורה."))
                    refresh()
                }
            }
        }

        root.addView(Button(this).apply { text = tr("Done"); setOnClickListener { finish() } })
    }

    private fun ability(st: JSONObject, name: String, desc: String, countKey: String, activeKey: String?, cost: Int, coins: Int) {
        val count = st.optInt(countKey, 0)
        val active = activeKey != null && st.optBoolean(activeKey, false)
        val dispName = tr(name); val dispDesc = tr(desc)
        root.addView(TextView(this).apply {
            text = dispName + " — " + dispDesc + "   (" + he("owned:", "ברשותך:") + " " + (if (debug) "∞" else count.toString()) + ")" +
                if (active) "   ✅ " + he("armed", "דרוך") else ""
            textSize = 15f; setPadding(0, pad / 3, 0, pad / 8)
        })
        row(tr("Buy") + " " + dispName + " (" + cost + " " + tr("coins") + ")", canAfford(st, cost, false)) {
            val s = loadState()
            if (!pay(s, cost, false)) { toast("Not enough coins"); return@row }
            s.put(countKey, s.optInt(countKey, 0) + 1)
            saveState(s); toast(he("Bought", "נקנה") + " " + dispName); refresh()
        }
        if (activeKey != null) {
            row(if (active) "✅ " + he("Armed", "דרוך") else tr("Arm") + " " + dispName, (debug || count > 0) && !active) {
                val s = loadState()
                if (!debug && s.optInt(countKey, 0) <= 0) { toast("Buy one first"); return@row }
                if (s.optBoolean(activeKey, false)) return@row
                if (!debug) s.put(countKey, s.optInt(countKey, 0) - 1)
                s.put(activeKey, true)
                saveState(s); toast(dispName + " " + he("armed for your next check!", "דרוך לבדיקה הבאה!")); refresh()
            }
        }
    }

    private fun skinSection(title: String, items: List<ShopCatalog.Skin>, key: String, st: JSONObject, coins: Int) {
        header(title)
        val equipped = st.optString(key, items.first().id)
        for (sk in items) {
            val owned = owns(st, sk.id, sk.cost)
            val isEq = sk.id == equipped
            val skName = tr(sk.name)
            val tail = when {
                isEq -> "   ✅ " + he("equipped", "מוצמד")
                owned -> "   (" + he("owned", "ברשותך") + ")"
                else -> "   — " + sk.cost + " " + tr("coins")
            }
            root.addView(TextView(this).apply {
                text = (if (sk.extra.isNotEmpty()) sk.extra + "  " else "") + skName + tail
                textSize = 16f; setPadding(0, pad / 4, 0, 0)
            })
            if (isEq) {
                // equipped: no button
            } else if (owned) {
                row(tr("Equip") + " " + skName, true) {
                    val s = loadState(); s.put(key, sk.id); saveState(s); toast(he("Equipped", "הוצמד") + " " + skName); refresh()
                }
            } else {
                row(tr("Buy") + " " + skName + " (" + sk.cost + " " + tr("coins") + ")", canAfford(st, sk.cost, false)) {
                    val s = loadState()
                    if (!pay(s, sk.cost, false)) { toast("Not enough coins"); return@row }
                    val arr = s.optJSONArray("owned") ?: JSONArray()
                    arr.put(sk.id); s.put("owned", arr); s.put(key, sk.id)
                    saveState(s); toast(he("Bought", "נקנה") + " " + skName); refresh()
                }
            }
        }
    }

    private fun header(label: String) {
        root.addView(TextView(this).apply {
            text = Lang.t(this@ShopActivity, label); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
    }

    private fun row(label: String, enabled: Boolean, onClick: () -> Unit) {
        root.addView(Button(this).apply { text = label; isEnabled = enabled; setOnClickListener { onClick() } })
    }

    private fun tr(s: String) = Lang.t(this, s)
    private fun he(en: String, heb: String) = if (Lang.isHebrew(this)) heb else en

    private fun toast(m: String) = Toast.makeText(this, Lang.t(this@ShopActivity, m), Toast.LENGTH_SHORT).show()
}
