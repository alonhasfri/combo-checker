package com.combochecker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Developer demo: ready-made "perfect" proofs for every task type (essay, homework, video edit,
 * organizing, custom). Open one, start Checkpoint, circle it. With Demo mode on, the check is
 * hard-coded to pass with every bonus, so the whole flow can be tested or shown to people.
 */
class DemoActivity : Activity() {
    private fun d(v: Int) = Ui.dp(this, v)
    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val kind = intent.getStringExtra("sample")
        if (kind == null) menu() else sample(kind)
    }

    override fun onResume() { super.onResume(); if (intent.getStringExtra("sample") == null) menu() }

    private fun menu() {
        val p = Ui.pal(this)
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, "Back") { finish() })
        head.addView(Ui.text(this, "Demo samples", 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        page.addView(head)
        page.addView(Ui.text(this, "Open a sample, tap Checkpoint, pick the same task type in the check panel, and circle the page (or tap Whole page).", 14f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(12), d(4), 0) })

        page.addView(Ui.sectionTitle(this, "Demo mode"))
        page.addView(Ui.group(this, listOf(
            Ui.switchRow(this, R.drawable.ui_star, "gold", "Demo mode: every check passes with all bonuses",
                "No AI is used and no key is needed. The result says DEMO. Turn it off after testing.", sp().getBoolean("demoMode", false)) { on ->
                sp().edit().putBoolean("demoMode", on).apply()
                Toast.makeText(this, if (on) "Demo mode ON — checks are fixed to pass with all bonuses" else "Demo mode OFF — real checks again", Toast.LENGTH_LONG).show()
            }
        )))

        page.addView(Ui.sectionTitle(this, "Samples (pick the same task type when checking)"))
        page.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_file, "blue", "Essay", "Grammar · Spelling · Interesting · Complex · Long") { open("essay") },
            Ui.row(this, R.drawable.ui_book, "green", "Homework", "Complete · Correct · Neat · Showed work") { open("homework") },
            Ui.row(this, R.drawable.ui_play, "purple", "Video edit", "Clean cuts · Audio · Pacing · Long") { open("video") },
            Ui.row(this, R.drawable.ui_layout, "teal", "Organizing", "Tidy · Labeled · Everything in place · Big cleanup") { open("organizing") },
            Ui.row(this, R.drawable.ui_check, "orange", "Custom", "Complete · Quality · Neat · Big effort") { open("custom") }
        )))
        page.addView(Ui.text(this, "Tip: with Demo mode OFF and a real AI key, these samples are also good real tests — they're written to earn every bonus.", 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(12), d(4), 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
    }

    private fun open(kind: String) = startActivity(Intent(this, DemoActivity::class.java).putExtra("sample", kind))

    /** Start (or restart) the Checkpoint button so the sample can be circled. */
    private fun startCheckpoint() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
        }
        startForegroundService(Intent(this, BubbleService::class.java))
        Toast.makeText(this, "Tap Checkpoint, choose the task type, circle the page", Toast.LENGTH_LONG).show()
    }

    // ----- the samples -----
    private fun sample(kind: String) {
        val paper = Color.parseColor("#FFFFFF"); val ink = Color.parseColor("#1B1F2A")
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#E9ECF3")) }
        // slim bar (not part of the proof): start Checkpoint + demo state
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#141A2E")); setPaddingRelative(d(12), d(8), d(8), d(8))
        }
        bar.addView(Ui.text(this, if (sp().getBoolean("demoMode", false)) "🎬 DEMO ON" else "Demo off (real check)", 13f, Color.WHITE), LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        bar.addView(Ui.button(this, "Start Checkpoint", R.drawable.ui_checkpoint, Color.parseColor("#3A5BD9"), Color.WHITE, 38) { startCheckpoint() })
        outer.addView(bar)

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPaddingRelative(d(22), d(22), d(22), d(28))
            background = GradientDrawable().apply { setColor(paper); cornerRadius = d(6).toFloat() }
        }
        when (kind) {
            "essay" -> essay(sheet, ink)
            "homework" -> homework(sheet, ink)
            "video" -> video(sheet)
            "organizing" -> organizing(sheet, ink)
            else -> custom(sheet, ink)
        }
        val scroll = ScrollView(this).apply { addView(FrameLayout(this@DemoActivity).apply { setPaddingRelative(d(10), d(10), d(10), d(10)); addView(sheet) }) }
        outer.addView(scroll, LinearLayout.LayoutParams(Ui.MATCH, 0, 1f))
        setContentView(outer)
    }

    private fun tv(s: String, sp: Float, color: Int, bold: Boolean = false, serif: Boolean = false) = TextView(this).apply {
        text = s; textSize = sp; setTextColor(color); setLineSpacing(0f, 1.25f)
        typeface = Typeface.create(if (serif) Typeface.SERIF else Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun essay(c: LinearLayout, ink: Int) {
        c.addView(tv("Curiosity: The Quiet Engine of Learning", 21f, ink, bold = true, serif = true))
        c.addView(tv("An argumentative essay", 13f, Color.GRAY, serif = true).apply { setPaddingRelative(0, d(4), 0, d(14)) })
        val paras = listOf(
            "Most people describe learning as something that happens to us: a teacher explains, a textbook summarises, and a test confirms what we absorbed. Yet the moments we remember most vividly rarely follow that pattern. We remember the evening we took apart a broken radio, the question we could not stop asking, the rabbit hole that swallowed a whole afternoon. In each case, the driving force was not instruction but curiosity. This essay argues that curiosity is the quiet engine of learning, and that schools, families and individuals should treat it as a skill to be practised rather than a personality trait that some people simply have.",
            "First, curiosity changes how information is stored. Psychologists have shown that when people are genuinely eager to know an answer, they remember it better, and they even remember unrelated details they encountered while waiting for it. In other words, a curious mind is not only more motivated; it is physically better prepared to hold on to knowledge. A student who wonders why bridges do not collapse will remember the idea of tension and compression far longer than one who memorises the definition for Friday's quiz.",
            "Second, curiosity turns mistakes into information. When learning is driven only by grades, an error feels like a verdict. When it is driven by a question, an error is simply a clue that the first guess was wrong. This shift matters, because the willingness to be wrong in public is the price of every real discovery, from a child's first wobbling bicycle ride to a scientist's failed experiment that later becomes a breakthrough.",
            "Critics might reply that curiosity is unreliable. Interests change, attention drifts, and not every subject a student needs will spark wonder. That objection is fair, but it misunderstands the claim. Curiosity can be cultivated deliberately: by asking better questions, by connecting a dry topic to something a learner already cares about, and by leaving room for exploration instead of filling every minute with answers. Even algebra becomes interesting when it explains why a video game character jumps the way it does.",
            "Consider how this plays out in an ordinary classroom. A teacher who opens a history lesson with a puzzling photograph, instead of a list of dates, invites students to form theories before they read a single paragraph. The dates still matter, but now they arrive as answers to questions the students themselves have asked, which is exactly when the mind is most ready to keep them.",
            "Finally, curiosity is a habit that compounds. Each question answered makes the next question easier to ask, because the learner has more knowledge to connect it to. Over months and years, this creates a widening gap between people who wait to be taught and people who go looking. The good news is that the gap is not fixed; anyone can begin by noticing one small thing they do not understand today and refusing to let it go.",
            "In conclusion, curiosity is not a luxury added on top of education; it is the mechanism that makes education stick. If we want learners who remember more, fear mistakes less and keep growing long after the final exam, we should protect the habit of wondering. The most useful question a student can ask is not \"Will this be on the test?\" but \"Why does it work like that?\""
        )
        for (pp in paras) c.addView(tv("      $pp", 15f, ink, serif = true).apply { setPaddingRelative(0, 0, 0, d(12)) })
        c.addView(tv("Word count: 556", 12f, Color.GRAY))
    }

    private fun homework(c: LinearLayout, ink: Int) {
        val blue = Color.parseColor("#1F3FA8")
        c.addView(tv("Math Homework — Linear Equations", 20f, ink, bold = true))
        c.addView(tv("Name: Alex  ·  Class 8B  ·  Page 42, questions 1–6", 13f, Color.GRAY).apply { setPaddingRelative(0, d(4), 0, d(14)) })
        val qs = listOf(
            listOf("1)  2x + 5 = 17", "2x = 17 − 5", "2x = 12", "x = 6", "Check: 2·6 + 5 = 17 ✓"),
            listOf("2)  3(x − 4) = 15", "3x − 12 = 15", "3x = 27", "x = 9", "Check: 3·(9 − 4) = 15 ✓"),
            listOf("3)  5x − 7 = 2x + 8", "5x − 2x = 8 + 7", "3x = 15", "x = 5", "Check: 25 − 7 = 18 = 10 + 8 ✓"),
            listOf("4)  x/4 + 3 = 7", "x/4 = 4", "x = 16", "Check: 16/4 + 3 = 7 ✓"),
            listOf("5)  2(x + 3) − 4 = 10", "2x + 6 − 4 = 10", "2x = 8", "x = 4", "Check: 2·7 − 4 = 10 ✓"),
            listOf("6)  0.5x + 1.5 = 4", "0.5x = 2.5", "x = 5", "Check: 2.5 + 1.5 = 4 ✓")
        )
        for (q in qs) {
            c.addView(tv(q[0], 17f, ink, bold = true).apply { setPaddingRelative(0, d(8), 0, d(2)) })
            for (line in q.drop(1)) c.addView(tv("      $line", 16f, if (line.startsWith("Check")) Color.parseColor("#17663A") else blue))
            c.addView(View(this).apply { setBackgroundColor(Color.parseColor("#E3E7F1")) }, LinearLayout.LayoutParams(Ui.MATCH, d(1)).apply { topMargin = d(8) })
        }
        c.addView(tv("All 6 questions answered, every answer checked.", 13f, Color.GRAY).apply { setPaddingRelative(0, d(12), 0, 0) })
    }

    private fun video(c: LinearLayout) {
        c.background = GradientDrawable().apply { setColor(Color.parseColor("#1E2130")); cornerRadius = d(6).toFloat() }
        val w = Color.WHITE
        c.addView(tv("🎬  Project: \"School Trip 2026\" — Final cut", 16f, w, bold = true))
        c.addView(tv("Timeline · 03:42 · 1080p · 30 fps · 28 clips · 4 tracks", 12f, Color.parseColor("#A3ABC2")).apply { setPaddingRelative(0, d(4), 0, d(10)) })
        // preview frame
        c.addView(FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#4A7BD9"), Color.parseColor("#F2A65A")))
            addView(tv("▶  00:01:27", 14f, w, bold = true).apply { setPaddingRelative(d(10), d(8), 0, 0) })
        }, LinearLayout.LayoutParams(Ui.MATCH, d(150)))
        // ruler
        c.addView(tv("0:00      0:30      1:00      1:30      2:00      2:30      3:00      3:30", 10f, Color.parseColor("#7D86A0")).apply { setPaddingRelative(d(34), d(10), 0, d(4)) })
        val tracks = listOf(
            Triple("V2", "#9B6BFF", listOf(18, 8, 14, 10, 20, 12)),
            Triple("V1", "#3A9BE8", listOf(10, 12, 8, 15, 9, 11, 13, 7, 12, 10)),
            Triple("A1", "#3FD08A", listOf(55, 50)),
            Triple("A2", "#F2C66B", listOf(30, 25, 30))
        )
        for ((name, col, clips) in tracks) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPaddingRelative(0, d(3), 0, d(3)) }
            row.addView(tv(name, 11f, Color.parseColor("#A3ABC2"), bold = true), LinearLayout.LayoutParams(d(30), Ui.WRAP))
            for (len in clips) row.addView(View(this).apply {
                background = GradientDrawable().apply { setColor(Color.parseColor(col)); cornerRadius = d(3).toFloat(); setStroke(d(1), Color.parseColor("#1E2130")) }
            }, LinearLayout.LayoutParams(0, d(if (name.startsWith("A")) 22 else 30), len.toFloat()))
            c.addView(row)
        }
        c.addView(tv("✓ No gaps · ✓ Audio levels −12 dB, balanced · ✓ 28 cuts, varied shots · ✓ Titles + music", 12f, Color.parseColor("#7FD9A6")).apply { setPaddingRelative(0, d(12), 0, 0) })
    }

    private fun organizing(c: LinearLayout, ink: Int) {
        c.addView(tv("📁  My Files — Organized", 20f, ink, bold = true))
        c.addView(tv("312 files sorted into 8 labelled folders · 0 loose files", 13f, Color.GRAY).apply { setPaddingRelative(0, d(4), 0, d(14)) })
        val folders = listOf(
            Triple("📚 School — Math", "#3A5BD9", "48 files"), Triple("📚 School — English", "#3A5BD9", "37 files"),
            Triple("🔬 School — Science", "#3A5BD9", "41 files"), Triple("📷 Photos 2026", "#17A673", "96 files"),
            Triple("🎨 Art projects", "#9B6BFF", "22 files"), Triple("🎮 Game saves", "#E8491D", "15 files"),
            Triple("📄 Documents", "#5B6378", "29 files"), Triple("🎵 Music", "#C98A00", "24 files")
        )
        var row: LinearLayout? = null
        folders.forEachIndexed { i, (name, col, count) ->
            if (i % 2 == 0) { row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; c.addView(row) }
            row!!.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPaddingRelative(d(12), d(12), d(12), d(12))
                background = GradientDrawable().apply { setColor(Color.parseColor("#F4F6FB")); cornerRadius = d(12).toFloat(); setStroke(d(2), Color.parseColor(col)) }
                addView(tv(name, 14f, ink, bold = true))
                addView(tv(count + "  ·  sorted ✓", 12f, Color.GRAY))
            }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f).apply { setMargins(d(4), d(4), d(4), d(4)) })
        }
        c.addView(tv("Before: 312 files on the desktop. After: every file in a labelled folder.", 13f, Color.GRAY).apply { setPaddingRelative(0, d(14), 0, 0) })
    }

    private fun custom(c: LinearLayout, ink: Int) {
        c.addView(tv("🛠️  Project: Build a wooden birdhouse", 20f, ink, bold = true))
        c.addView(tv("Finished Saturday · 6 hours · all steps done", 13f, Color.GRAY).apply { setPaddingRelative(0, d(4), 0, d(14)) })
        val steps = listOf("Measured and marked all 6 panels (±1 mm)", "Cut the panels and sanded every edge smooth", "Drilled the 3 cm entrance hole and ventilation holes",
            "Glued and screwed the walls, base and roof", "Added a hinged roof for cleaning", "Painted 2 coats of weather-proof paint", "Mounted it 2 m high, facing away from the wind")
        for (s in steps) c.addView(tv("✅  $s", 16f, ink).apply { setPaddingRelative(0, d(6), 0, d(6)) })
        c.addView(View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#C98A5A"), Color.parseColor("#8A5A35"))).apply { cornerRadius = d(10).toFloat() } },
            LinearLayout.LayoutParams(Ui.MATCH, d(120)).apply { topMargin = d(12) })
        c.addView(tv("Result: sturdy, neat and already visited by two sparrows 🐦", 14f, ink).apply { setPaddingRelative(0, d(10), 0, 0) })
    }
}
