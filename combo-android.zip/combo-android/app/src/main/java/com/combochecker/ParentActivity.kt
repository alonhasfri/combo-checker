package com.combochecker

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** PIN-gated parent controls: real-life rewards, approval mode, pending approvals, redemption log, weekly report. */
class ParentActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private lateinit var root: LinearLayout
    private var pad = 0
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        Profiles.ensureDefault(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        modern = !sp().getBoolean("classicMenu", false)
        if (!modern) setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private var modern = false

    private fun pin() = sp().getString("parentPin", "") ?: ""

    private fun refresh() {
        if (modern) { refreshModern(); return }
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = Lang.t(this@ParentActivity, "👪 Parent zone"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        when {
            pin().isEmpty() -> buildSetPin()
            !unlocked -> buildUnlock()
            else -> buildControls()
        }
    }

    private fun buildSetPin() {
        root.addView(info("Set a parent PIN. You will need it to change rewards and settings. (Note: this is a soft lock stored on the phone, not high security.)"))
        val p1 = pinField("New PIN (4+ digits)")
        val p2 = pinField("Confirm PIN")
        root.addView(p1); root.addView(p2)
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Save PIN")
            setOnClickListener {
                val a = p1.text.toString().trim(); val b = p2.text.toString().trim()
                if (a.length < 4) { toast("Use at least 4 digits"); return@setOnClickListener }
                if (a != b) { toast("PINs do not match"); return@setOnClickListener }
                sp().edit().putString("parentPin", a).apply()
                unlocked = true; toast("PIN set"); refresh()
            }
        })
    }

    private fun buildUnlock() {
        root.addView(info("Enter the parent PIN."))
        val p = pinField("PIN")
        root.addView(p)
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Unlock")
            setOnClickListener {
                if (p.text.toString().trim() == pin()) { unlocked = true; refresh() } else toast("Wrong PIN")
            }
        })
    }

    private fun buildControls() {
        header("AI art detector")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Strict: no points when a proof looks AI-made (85%+). Off means a warning only. Kids can't change this while a parent PIN is set.")
            isChecked = sp().getBoolean("strict", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("strict", v).apply() }
        })

        header("Approval mode")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Hold coins earned until a parent approves them")
            isChecked = sp().getBoolean("approval", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("approval", v).apply() }
        })

        header("Leaderboard")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Hide the leaderboard from kids (avoids sibling pressure)")
            isChecked = sp().getBoolean("hideLeaderboard", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("hideLeaderboard", v).putBoolean("homeDirty", true).apply() }
        })

        header("Pranks")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Block pranks — kids can't be trolled (ignores update keys and turns off any active troll)")
            isChecked = sp().getBoolean("trollsBlocked", false)
            setOnCheckedChangeListener { _, v ->
                val e = sp().edit().putBoolean("trollsBlocked", v)
                if (v) { for (t in Pranks.persistentModes) e.putBoolean(t.id, false); e.putInt("adLevel", 0) }
                e.putBoolean("homeDirty", true).apply()
            }
        })

        val pending = JSONArray(sp().getString("pending", "[]"))
        header(Lang.t(this, "Pending approvals") + " (" + pending.length() + ")")
        if (pending.length() == 0) root.addView(info("Nothing waiting."))
        for (i in 0 until pending.length()) {
            val o = pending.getJSONObject(i)
            val who = o.optString("profileName").ifBlank { "" }
            root.addView(TextView(this).apply {
                text = "• " + (if (who.isNotEmpty()) who + ": " else "") +
                    (o.optString("task").ifBlank { "(task)" }) + " — " + o.optInt("coins") + " " + he("coins", "מטבעות") + "  (" +ago(o.optLong("time")) + ")"
                textSize = 15f; setPadding(0, pad / 4, 0, 0)
            })
            // Show the proof photo so the parent can see what they're approving.
            val proof = o.optString("proof")
            if (proof.isNotEmpty()) {
                val pf = File(File(filesDir, "proofs"), proof)
                if (pf.exists()) {
                    val bmp = BitmapFactory.decodeFile(pf.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 })
                    if (bmp != null) root.addView(ImageView(this).apply {
                        setImageBitmap(bmp); adjustViewBounds = true
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = pad / 4 }
                        maxHeight = (220 * resources.displayMetrics.density).toInt()
                        scaleType = ImageView.ScaleType.FIT_CENTER
                    })
                }
            }
            val rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowL.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Approve"); setOnClickListener { resolvePending(i, true) } })
            rowL.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Reject"); setOnClickListener { resolvePending(i, false) } })
            root.addView(rowL)
        }
        if (pending.length() > 1) root.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Approve all"); setOnClickListener { approveAll() } })

        header("Real-life rewards")
        root.addView(info("The child buys these with coins in the Shop. Add a name and a coin cost."))
        val rewards = JSONArray(sp().getString("rewards", "[]"))
        for (i in 0 until rewards.length()) {
            val rw = rewards.getJSONObject(i)
            root.addView(TextView(this).apply {
                text = rw.optString("name") + " — " + rw.optInt("cost") + " " + he("coins", "מטבעות") +
                    (if (rw.optBoolean("studyOnly", false)) "   📚 " + he("study only", "לימוד בלבד") else "")
                textSize = 16f; setPadding(0, pad / 4, 0, 0)
            })
            root.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Delete"); setOnClickListener { deleteReward(i) } })
        }
        val nameF = EditText(this).apply { hint = Lang.t(this@ParentActivity, "Reward name (e.g. Ice cream)"); inputType = InputType.TYPE_CLASS_TEXT }
        val costF = EditText(this).apply { hint = Lang.t(this@ParentActivity, "Coin cost"); inputType = InputType.TYPE_CLASS_NUMBER }
        val studyBox = CheckBox(this).apply { text = Lang.t(this@ParentActivity, "Can only be bought with study coins 📚") }
        root.addView(nameF); root.addView(costF); root.addView(studyBox)
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Add reward")
            setOnClickListener {
                val n = nameF.text.toString().trim()
                val c = costF.text.toString().trim().toIntOrNull() ?: 0
                if (n.isEmpty() || c <= 0) { toast("Enter a name and a cost"); return@setOnClickListener }
                val arr = JSONArray(sp().getString("rewards", "[]"))
                arr.put(JSONObject().put("name", n).put("cost", c).put("studyOnly", studyBox.isChecked))
                sp().edit().putString("rewards", arr.toString()).apply()
                toast("Added"); refresh()
            }
        })
        root.addView(info("Skins, abilities and \"both\" rewards can be paid with any mix of general and study coins. Study-only rewards must be paid with study coins."))

        val log = JSONArray(sp().getString("redemptions", "[]"))
        header(Lang.t(this, "Redeemed by child") + " (" + log.length() + ")")
        if (log.length() == 0) root.addView(info("Nothing redeemed yet."))
        for (i in log.length() - 1 downTo maxOf(0, log.length() - 20)) {
            val o = log.getJSONObject(i)
            val who = o.optString("profileName").ifBlank { "" }
            root.addView(TextView(this).apply {
                text = "• " + (if (who.isNotEmpty()) who + ": " else "") +
                    o.optString("name") + " — " + o.optInt("cost") + " " + he("coins", "מטבעות") + "  (" +ago(o.optLong("time")) + ")"
                textSize = 15f; setPadding(0, pad / 4, 0, 0)
            })
        }
        if (log.length() > 0) root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Clear log")
            setOnClickListener {
                android.app.AlertDialog.Builder(this@ParentActivity)
                    .setTitle(Lang.t(this@ParentActivity, "Clear redemption log?"))
                    .setMessage(Lang.t(this@ParentActivity, "This can't be undone."))
                    .setNegativeButton(Lang.t(this@ParentActivity, "Cancel"), null)
                    .setPositiveButton(Lang.t(this@ParentActivity, "Clear")) { _, _ -> sp().edit().putString("redemptions", "[]").apply(); toast("Cleared"); refresh() }
                    .show()
            }
        })

        header("This week")
        root.addView(info(weeklyReport()))

        header("Honesty report")
        root.addView(info(honestyReport()))

        header("PIN")
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Change PIN")
            setOnClickListener { changePinDialog() }
        })

        root.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Done"); setOnClickListener { finish() } })
    }

    private fun resolvePending(index: Int, approve: Boolean) {
        val arr = JSONArray(sp().getString("pending", "[]"))
        if (index < 0 || index >= arr.length()) return
        val o = arr.getJSONObject(index)
        if (approve) addCoins(o.optString("profileId"), o.optInt("coins"), o.optBoolean("study", false))
        val out = JSONArray()
        for (i in 0 until arr.length()) if (i != index) out.put(arr.getJSONObject(i))
        sp().edit().putString("pending", out.toString()).apply()
        toast(if (approve) "Approved" else "Rejected"); refresh()
    }

    private fun approveAll() {
        val arr = JSONArray(sp().getString("pending", "[]"))
        var sum = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            addCoins(o.optString("profileId"), o.optInt("coins"), o.optBoolean("study", false))
            sum += o.optInt("coins")
        }
        sp().edit().putString("pending", "[]").apply()
        toast("Approved all (+" + sum + " coins)"); refresh()
    }

    /** Credit the profile that earned the coins; falls back to the first profile for old entries.
     *  Study coins go to the separate study balance. */
    private fun addCoins(profileId: String, c: Int, study: Boolean) {
        val id = if (profileId.isBlank()) Profiles.list(this).optJSONObject(0)?.optString("id") ?: "p0" else profileId
        val key = Profiles.stateKeyFor(id)
        val s = sp().getString(key, "") ?: ""
        val st = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        val field = if (study) "scoins" else "coins"
        st.put(field, st.optInt(field, 0) + c)
        sp().edit().putString(key, st.toString()).apply()
    }

    private fun deleteReward(index: Int) {
        val arr = JSONArray(sp().getString("rewards", "[]"))
        val out = JSONArray()
        for (i in 0 until arr.length()) if (i != index) out.put(arr.getJSONObject(i))
        sp().edit().putString("rewards", out.toString()).apply()
        toast("Deleted"); refresh()
    }

    private fun weeklyReport(): String {
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val profiles = Profiles.list(this)
        val sb = StringBuilder()
        var totTasks = 0; var totPoints = 0; var totBonuses = 0
        for (p in 0 until profiles.length()) {
            val prof = profiles.getJSONObject(p)
            val gallery = JSONArray(sp().getString("gallery__" + prof.optString("id"), "[]"))
            var tasks = 0; var points = 0; var bonuses = 0
            for (i in 0 until gallery.length()) {
                val o = gallery.getJSONObject(i)
                if (o.optLong("time") >= weekAgo) { tasks++; points += o.optInt("points"); bonuses += o.optInt("bonuses") }
            }
            totTasks += tasks; totPoints += points; totBonuses += bonuses
            if (profiles.length() > 1) {
                sb.append(prof.optString("emoji")).append(" ").append(prof.optString("name"))
                    .append(": ").append(tasks).append(" ").append(he("tasks,", "משימות,")).append(" ")
                    .append(points).append(" ").append(he("pts,", "נק',")).append(" ")
                    .append(bonuses).append(" ").append(he("bonuses", "בונוסים")).append("\n")
            }
        }
        val log = JSONArray(sp().getString("redemptions", "[]"))
        var redeemed = 0; var spent = 0
        for (i in 0 until log.length()) {
            val o = log.getJSONObject(i)
            if (o.optLong("time") >= weekAgo) { redeemed++; spent += o.optInt("cost") }
        }
        if (profiles.length() > 1) sb.append("\n")
        sb.append(he("Total tasks passed: ", "סך משימות שעברו: ")).append(totTasks)
            .append("\n").append(he("Total points earned: ", "סך נקודות שהורווחו: ")).append(totPoints)
            .append("\n").append(he("Total bonuses earned: ", "סך בונוסים שהורווחו: ")).append(totBonuses)
            .append("\n").append(he("Rewards redeemed: ", "פרסים שמומשו: ")).append(redeemed)
            .append(" (").append(spent).append(" ").append(he("coins)", "מטבעות)"))
        return sb.toString()
    }

    /** How often the AI flagged a proof as AI-made or faked, per profile and overall. */
    private fun honestyReport(): String {
        val profiles = Profiles.list(this)
        val sb = StringBuilder()
        var totChecks = 0; var totFlagged = 0
        for (p in 0 until profiles.length()) {
            val prof = profiles.getJSONObject(p)
            val st = try { JSONObject(sp().getString("state__" + prof.optString("id"), "") ?: "") } catch (e: Exception) { JSONObject() }
            val checks = st.optInt("checksTotal", 0)
            val flagged = st.optInt("aiFlagged", 0)
            totChecks += checks; totFlagged += flagged
            if (profiles.length() > 1 && checks > 0) {
                sb.append(prof.optString("emoji")).append(" ").append(prof.optString("name"))
                    .append(": ").append(flagged).append(" ").append(he("of", "מתוך")).append(" ").append(checks)
                    .append(" ").append(he("flagged", "סומנו")).append("\n")
            }
        }
        if (totChecks == 0) return "No checks yet."
        if (profiles.length() > 1) sb.append("\n")
        val pct = (totFlagged * 100) / totChecks
        if (Lang.isHebrew(this)) {
            sb.append(totFlagged).append(" מתוך ").append(totChecks)
                .append(" הוכחות נראו כמעשה AI או מזויפות (").append(pct).append("%).")
            if (totFlagged == 0) sb.append("\nעד כה שום דבר חשוד. 👍")
        } else {
            sb.append(totFlagged).append(" of ").append(totChecks)
                .append(" proofs looked AI-made or faked (").append(pct).append("%).")
            if (totFlagged == 0) sb.append("\nNothing suspicious so far. 👍")
        }
        return sb.toString()
    }

    private fun ago(time: Long): String {
        if (time <= 0) return ""
        val mins = (System.currentTimeMillis() - time) / 60000
        return when {
            mins < 1 -> he("just now", "עכשיו")
            mins < 60 -> he(mins.toString() + "m ago", "לפני " + mins + " דק׳")
            mins < 1440 -> he((mins / 60).toString() + "h ago", "לפני " + (mins / 60) + " שע׳")
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(time))
        }
    }

    private fun pinField(h: String) = EditText(this).apply {
        hint = Lang.t(this@ParentActivity, h)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }

    private fun header(label: String) {
        root.addView(TextView(this).apply {
            text = Lang.t(this@ParentActivity, label); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
    }

    private fun info(t: String) = TextView(this).apply { text = Lang.t(this@ParentActivity, t); textSize = 14f; setPadding(0, pad / 8, 0, pad / 8) }

    /** Pick the English or Hebrew form for a composed (non-dictionary) string. */
    private fun he(en: String, heb: String) = if (Lang.isHebrew(this)) heb else en

    private fun toast(m: String) = Toast.makeText(this, Lang.t(this@ParentActivity, m), Toast.LENGTH_SHORT).show()

    // ===================== redesigned parent zone (new menu) =====================
    private fun d(v: Int) = Ui.dp(this, v)
    private fun t(s: String) = Lang.t(this, s)

    /** Change the PIN without ever leaving the zone unlocked-and-PIN-less: new + confirm, then save. */
    private fun changePinDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(8), d(20), 0) }
        val a = pinField("New PIN (4+ digits)"); val b = pinField("Confirm PIN")
        col.addView(a); col.addView(b)
        android.app.AlertDialog.Builder(this)
            .setTitle(t("Change PIN"))
            .setView(col)
            .setPositiveButton(t("Save PIN")) { _, _ ->
                val x = a.text.toString().trim(); val y = b.text.toString().trim()
                when {
                    x.length < 4 -> toast("Use at least 4 digits")
                    x != y -> toast("PINs do not match")
                    else -> { sp().edit().putString("parentPin", x).apply(); toast("PIN set") }
                }
            }
            .setNegativeButton(t("Cancel"), null).show()
    }

    private fun refreshModern() {
        val p = Ui.pal(this)
        val y = (findViewById<android.view.View>(android.R.id.content) as? ViewGroup)?.getChildAt(0)?.scrollY ?: 0
        root = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, t("Back")) { finish() })
        head.addView(Ui.text(this, t("Parent zone"), 26f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) })
        root.addView(head)
        when {
            pin().isEmpty() -> modernPinCard(setUp = true)
            !unlocked -> modernPinCard(setUp = false)
            else -> modernControls()
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(p.bg); addView(root) }
        setContentView(scroll)
        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun modernPinCard(setUp: Boolean) {
        val p = Ui.pal(this)
        val c = Ui.card(this).apply { setPaddingRelative(d(20), d(22), d(20), d(20)); gravity = Gravity.CENTER_HORIZONTAL }
        c.addView(Ui.tile(this, R.drawable.ui_lock, "green", 56, 30))
        c.addView(Ui.text(this, t(if (setUp) "Set a parent PIN" else "Enter the parent PIN."), 18f, p.ink).apply { gravity = Gravity.CENTER; setPaddingRelative(0, d(14), 0, d(6)) })
        if (setUp) c.addView(Ui.text(this, t("You will need it to change rewards and settings. It's a soft lock stored on this phone."), 14f, p.muted, bold = false).apply { gravity = Gravity.CENTER })
        val f1 = pinField(if (setUp) "New PIN (4+ digits)" else "PIN").apply { gravity = Gravity.CENTER }
        c.addView(f1, Ui.lp(this, 12))
        val f2 = if (setUp) pinField("Confirm PIN").apply { gravity = Gravity.CENTER } else null
        if (f2 != null) c.addView(f2, Ui.lp(this, 4))
        c.addView(Ui.button(this, t(if (setUp) "Save PIN" else "Unlock"), R.drawable.ui_lock, p.accent, android.graphics.Color.WHITE) {
            val a = f1.text.toString().trim()
            if (setUp) {
                val b = f2!!.text.toString().trim()
                if (a.length < 4) { toast("Use at least 4 digits"); return@button }
                if (a != b) { toast("PINs do not match"); return@button }
                sp().edit().putString("parentPin", a).putBoolean("homeDirty", true).apply()
                unlocked = true; toast("PIN set"); refresh()
            } else {
                if (a == pin()) { unlocked = true; refresh() } else { toast("Wrong PIN"); f1.setText("") }
            }
        }, Ui.lp(this, 16))
        root.addView(c, Ui.lp(this, 20))
        f1.requestFocus()
    }

    private fun modernControls() {
        val p = Ui.pal(this)
        fun sw(res: Int, label: String, sub: String, key: String, extra: (Boolean) -> Unit = {}) =
            Ui.switchRow(this, res, "green", t(label), t(sub), sp().getBoolean(key, false)) { v ->
                sp().edit().putBoolean(key, v).putBoolean("homeDirty", true).apply(); extra(v)
            }
        root.addView(Ui.sectionTitle(this, t("Rules")))
        root.addView(Ui.group(this, listOf(
            sw(R.drawable.ui_spark, "Strict AI detector", "No points when a proof looks AI-made (85%+).", "strict"),
            sw(R.drawable.ui_check, "Approval mode", "Hold coins earned until a parent approves them", "approval"),
            sw(R.drawable.ui_trophy, "Hide the leaderboard", "Avoids sibling pressure", "hideLeaderboard"),
            sw(R.drawable.ui_shield, "Block pranks", "Ignores update keys and turns off any active troll", "trollsBlocked") { v ->
                if (v) { val e = sp().edit(); for (tr in Pranks.persistentModes) e.putBoolean(tr.id, false); e.apply(); Ads.turnOff(this) }
            }
        )))

        // pending approvals
        val pending = try { JSONArray(sp().getString("pending", "[]")) } catch (e: Exception) { JSONArray() }
        root.addView(Ui.sectionTitle(this, t("Pending approvals") + " (" + pending.length() + ")"))
        if (pending.length() == 0) root.addView(emptyCard(t("Nothing waiting.")))
        for (i in 0 until pending.length()) {
            val o = pending.getJSONObject(i)
            val c = Ui.card(this)
            val proof = o.optString("proof")
            if (proof.isNotEmpty()) {
                val pf = File(File(filesDir, "proofs"), proof)
                val bmp = if (pf.exists()) try { BitmapFactory.decodeFile(pf.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 }) } catch (e: Exception) { null } else null
                if (bmp != null) c.addView(ImageView(this).apply {
                    setImageBitmap(bmp); scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(p.track)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, d(170)))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(16), d(12), d(16), d(14)) }
            val who = o.optString("profileName")
            info.addView(Ui.text(this, o.optString("task").ifBlank { t("Task") }, 16f, p.ink))
            info.addView(Ui.text(this, (if (who.isNotEmpty()) "$who · " else "") + o.optInt("coins") + " " + t("coins") +
                (if (o.optBoolean("study", false)) " · " + t("study") else "") + " · " + ago(o.optLong("time")), 13f, p.muted, bold = false))
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(Ui.button(this, t("Approve"), R.drawable.ui_check, Ui.tone(this, "green").first, p.good, 44) { resolvePending(i, true) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = d(5) })
            btns.addView(Ui.button(this, t("Reject"), R.drawable.ui_trash, Ui.tone(this, "red").first, p.danger, 44) { resolvePending(i, false) },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = d(5) })
            info.addView(btns, Ui.lp(this, 12))
            c.addView(info)
            root.addView(c, Ui.lp(this, if (i == 0) 0 else 10))
        }
        if (pending.length() > 1) root.addView(Ui.button(this, t("Approve all"), R.drawable.ui_check, p.accent, android.graphics.Color.WHITE) { approveAll() }, Ui.lp(this, 10))

        // rewards
        root.addView(Ui.sectionTitle(this, t("Real-life rewards")))
        val rewards = try { JSONArray(sp().getString("rewards", "[]")) } catch (e: Exception) { JSONArray() }
        val rrows = ArrayList<android.view.View>()
        for (i in 0 until rewards.length()) {
            val rw = rewards.getJSONObject(i)
            val v = rw.optInt("cost").toString() + " " + t("coins") + if (rw.optBoolean("studyOnly", false)) " · " + t("study") else ""
            rrows.add(Ui.row(this, R.drawable.ui_gift, "gold", rw.optString("name"), v, chevron = false) {
                android.app.AlertDialog.Builder(this).setTitle(rw.optString("name"))
                    .setMessage(t("Delete this reward?"))
                    .setNegativeButton(t("Cancel"), null)
                    .setPositiveButton(t("Delete")) { _, _ -> deleteReward(i) }.show()
            })
        }
        rrows.add(Ui.row(this, R.drawable.ui_spark, "blue", t("Add reward"), null) { addRewardDialog() })
        root.addView(Ui.group(this, rrows))
        root.addView(Ui.text(this, t("The child buys these with coins in the Shop. Tap a reward to delete it."), 12f, p.muted, bold = false).apply { setPaddingRelative(d(4), d(8), d(4), 0) })

        // redemption log
        val log = try { JSONArray(sp().getString("redemptions", "[]")) } catch (e: Exception) { JSONArray() }
        root.addView(Ui.sectionTitle(this, t("Redeemed by child") + " (" + log.length() + ")"))
        if (log.length() == 0) root.addView(emptyCard(t("Nothing redeemed yet.")))
        else {
            val lrows = ArrayList<android.view.View>()
            for (i in log.length() - 1 downTo maxOf(0, log.length() - 20)) {
                val o = log.getJSONObject(i)
                val who = o.optString("profileName")
                lrows.add(Ui.row(this, R.drawable.ui_gift, "gold", (if (who.isNotEmpty()) "$who: " else "") + o.optString("name"),
                    o.optInt("cost").toString() + " · " + ago(o.optLong("time")), chevron = false))
            }
            lrows.add(Ui.row(this, R.drawable.ui_trash, "red", t("Clear log"), null, danger = true) {
                android.app.AlertDialog.Builder(this)
                    .setTitle(t("Clear redemption log?")).setMessage(t("This can't be undone."))
                    .setNegativeButton(t("Cancel"), null)
                    .setPositiveButton(t("Clear")) { _, _ -> sp().edit().putString("redemptions", "[]").apply(); toast("Cleared"); refresh() }
                    .show()
            })
            root.addView(Ui.group(this, lrows))
        }

        // reports
        root.addView(Ui.sectionTitle(this, t("Reports")))
        root.addView(reportCard(R.drawable.ui_calendar, "purple", t("This week"), weeklyReport()))
        root.addView(reportCard(R.drawable.ui_shield, "teal", t("Honesty report"), t(honestyReport())), Ui.lp(this, 10))

        root.addView(Ui.sectionTitle(this, t("PIN")))
        root.addView(Ui.group(this, listOf(
            Ui.row(this, R.drawable.ui_key, "green", t("Change PIN"), null) { changePinDialog() },
            Ui.row(this, R.drawable.ui_lock, "gray", t("Lock the parent zone"), null) { unlocked = false; refresh() }
        )))
    }

    private fun emptyCard(msg: String) = Ui.card(this).apply {
        setPaddingRelative(d(16), d(16), d(16), d(16))
        addView(Ui.text(this@ParentActivity, msg, 14f, Ui.pal(this@ParentActivity).muted, bold = false))
    }

    private fun reportCard(res: Int, tone: String, title: String, body: String) = Ui.card(this).apply {
        val p = Ui.pal(this@ParentActivity)
        setPaddingRelative(d(16), d(14), d(16), d(16))
        val h = LinearLayout(this@ParentActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        h.addView(Ui.tile(this@ParentActivity, res, tone))
        h.addView(Ui.text(this@ParentActivity, title, 16f, p.ink).apply { setPaddingRelative(d(12), 0, 0, 0) })
        addView(h)
        addView(Ui.text(this@ParentActivity, body, 14f, p.ink, bold = false).apply { setPaddingRelative(0, d(10), 0, 0); setLineSpacing(0f, 1.2f) })
    }

    private fun addRewardDialog() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPaddingRelative(d(20), d(8), d(20), 0) }
        val nameF = EditText(this).apply { hint = t("Reward name (e.g. Ice cream)"); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        val costF = EditText(this).apply { hint = t("Coin cost"); inputType = InputType.TYPE_CLASS_NUMBER }
        val studyBox = CheckBox(this).apply { text = t("Can only be bought with study coins 📚") }
        col.addView(nameF); col.addView(costF); col.addView(studyBox)
        android.app.AlertDialog.Builder(this)
            .setTitle(t("Add reward"))
            .setView(col)
            .setPositiveButton(t("Add reward")) { _, _ ->
                val n = nameF.text.toString().trim()
                val c = costF.text.toString().trim().toIntOrNull() ?: 0
                if (n.isEmpty() || c <= 0) { toast("Enter a name and a cost"); return@setPositiveButton }
                val arr = try { JSONArray(sp().getString("rewards", "[]")) } catch (e: Exception) { JSONArray() }
                arr.put(JSONObject().put("name", n).put("cost", c).put("studyOnly", studyBox.isChecked))
                sp().edit().putString("rewards", arr.toString()).apply()
                toast("Added"); refresh()
            }
            .setNegativeButton(t("Cancel"), null).show()
    }
}
