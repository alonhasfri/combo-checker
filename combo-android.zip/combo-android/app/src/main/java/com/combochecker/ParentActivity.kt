package com.combochecker

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** PIN-gated parent controls: real-life rewards, approval mode, pending approvals, redemption log, weekly report. */
class ParentActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private lateinit var root: LinearLayout
    private var pad = 0
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        pad = (20 * resources.displayMetrics.density).toInt()
        Profiles.ensureDefault(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun pin() = sp().getString("parentPin", "") ?: ""

    private fun refresh() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = Lang.t(this@ParentActivity, "👪 Parent zone"); textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        when {
            pin().isEmpty() -> buildSetPin()
            !unlocked -> buildUnlock()
            else -> buildControls()
        }
    }

    private fun buildSetPin() {
        root.addView(info("Set a parent PIN. You will need it to change rewards and settings. (Note: this is a soft lock stored on the phone, not high security.)"))
        val p1 = pinField("New PIN (4+ digits)")
        val p2 = pinField("Confirm PIN")
        root.addView(p1); root.addView(p2)
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Save PIN")
            setOnClickListener {
                val a = p1.text.toString().trim(); val b = p2.text.toString().trim()
                if (a.length < 4) { toast("Use at least 4 digits"); return@setOnClickListener }
                if (a != b) { toast("PINs do not match"); return@setOnClickListener }
                sp().edit().putString("parentPin", a).apply()
                unlocked = true; toast("PIN set"); refresh()
            }
        })
    }

    private fun buildUnlock() {
        root.addView(info("Enter the parent PIN."))
        val p = pinField("PIN")
        root.addView(p)
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Unlock")
            setOnClickListener {
                if (p.text.toString().trim() == pin()) { unlocked = true; refresh() } else toast("Wrong PIN")
            }
        })
    }

    private fun buildControls() {
        header("AI art detector")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Strict: no points when a proof looks AI-made (85%+). Off means a warning only. Kids can't change this while a parent PIN is set.")
            isChecked = sp().getBoolean("strict", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("strict", v).apply() }
        })

        header("Approval mode")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Hold coins earned until a parent approves them")
            isChecked = sp().getBoolean("approval", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("approval", v).apply() }
        })

        header("Leaderboard")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Hide the leaderboard from kids (avoids sibling pressure)")
            isChecked = sp().getBoolean("hideLeaderboard", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("hideLeaderboard", v).apply() }
        })

        header("Pranks")
        root.addView(CheckBox(this).apply {
            text = Lang.t(this@ParentActivity, "Block pranks — kids can't be trolled (ignores creator keys and turns off any active troll)")
            isChecked = sp().getBoolean("trollsBlocked", false)
            setOnCheckedChangeListener { _, v ->
                val e = sp().edit().putBoolean("trollsBlocked", v)
                if (v) { for (t in Pranks.persistentModes) e.putBoolean(t.id, false); e.putInt("adLevel", 0) }
                e.apply()
            }
        })

        val pending = JSONArray(sp().getString("pending", "[]"))
        header(Lang.t(this, "Pending approvals") + " (" + pending.length() + ")")
        if (pending.length() == 0) root.addView(info("Nothing waiting."))
        for (i in 0 until pending.length()) {
            val o = pending.getJSONObject(i)
            val who = o.optString("profileName").ifBlank { "" }
            root.addView(TextView(this).apply {
                text = "• " + (if (who.isNotEmpty()) who + ": " else "") +
                    (o.optString("task").ifBlank { "(task)" }) + " — " + o.optInt("coins") + " " + he("coins", "מטבעות") + "  (" +ago(o.optLong("time")) + ")"
                textSize = 15f; setPadding(0, pad / 4, 0, 0)
            })
            // Show the proof photo so the parent can see what they're approving.
            val proof = o.optString("proof")
            if (proof.isNotEmpty()) {
                val pf = File(File(filesDir, "proofs"), proof)
                if (pf.exists()) {
                    val bmp = BitmapFactory.decodeFile(pf.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 })
                    if (bmp != null) root.addView(ImageView(this).apply {
                        setImageBitmap(bmp); adjustViewBounds = true
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { topMargin = pad / 4 }
                        maxHeight = (220 * resources.displayMetrics.density).toInt()
                        scaleType = ImageView.ScaleType.FIT_CENTER
                    })
                }
            }
            val rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowL.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Approve"); setOnClickListener { resolvePending(i, true) } })
            rowL.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Reject"); setOnClickListener { resolvePending(i, false) } })
            root.addView(rowL)
        }
        if (pending.length() > 1) root.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Approve all"); setOnClickListener { approveAll() } })

        header("Real-life rewards")
        root.addView(info("The child buys these with coins in the Shop. Add a name and a coin cost."))
        val rewards = JSONArray(sp().getString("rewards", "[]"))
        for (i in 0 until rewards.length()) {
            val rw = rewards.getJSONObject(i)
            root.addView(TextView(this).apply {
                text = rw.optString("name") + " — " + rw.optInt("cost") + " coins"
                textSize = 16f; setPadding(0, pad / 4, 0, 0)
            })
            root.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Delete"); setOnClickListener { deleteReward(i) } })
        }
        val nameF = EditText(this).apply { hint = Lang.t(this@ParentActivity, "Reward name (e.g. Ice cream)"); inputType = InputType.TYPE_CLASS_TEXT }
        val costF = EditText(this).apply { hint = Lang.t(this@ParentActivity, "Coin cost"); inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(nameF); root.addView(costF)
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Add reward")
            setOnClickListener {
                val n = nameF.text.toString().trim()
                val c = costF.text.toString().trim().toIntOrNull() ?: 0
                if (n.isEmpty() || c <= 0) { toast("Enter a name and a cost"); return@setOnClickListener }
                val arr = JSONArray(sp().getString("rewards", "[]"))
                arr.put(JSONObject().put("name", n).put("cost", c))
                sp().edit().putString("rewards", arr.toString()).apply()
                toast("Added"); refresh()
            }
        })

        val log = JSONArray(sp().getString("redemptions", "[]"))
        header(Lang.t(this, "Redeemed by child") + " (" + log.length() + ")")
        if (log.length() == 0) root.addView(info("Nothing redeemed yet."))
        for (i in log.length() - 1 downTo maxOf(0, log.length() - 20)) {
            val o = log.getJSONObject(i)
            val who = o.optString("profileName").ifBlank { "" }
            root.addView(TextView(this).apply {
                text = "• " + (if (who.isNotEmpty()) who + ": " else "") +
                    o.optString("name") + " — " + o.optInt("cost") + " " + he("coins", "מטבעות") + "  (" +ago(o.optLong("time")) + ")"
                textSize = 15f; setPadding(0, pad / 4, 0, 0)
            })
        }
        if (log.length() > 0) root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Clear log")
            setOnClickListener {
                android.app.AlertDialog.Builder(this@ParentActivity)
                    .setTitle(Lang.t(this@ParentActivity, "Clear redemption log?"))
                    .setMessage(Lang.t(this@ParentActivity, "This can't be undone."))
                    .setNegativeButton(Lang.t(this@ParentActivity, "Cancel"), null)
                    .setPositiveButton(Lang.t(this@ParentActivity, "Clear")) { _, _ -> sp().edit().putString("redemptions", "[]").apply(); toast("Cleared"); refresh() }
                    .show()
            }
        })

        header("This week")
        root.addView(info(weeklyReport()))

        header("Honesty report")
        root.addView(info(honestyReport()))

        header("PIN")
        root.addView(Button(this).apply {
            text = Lang.t(this@ParentActivity, "Change PIN")
            setOnClickListener { sp().edit().remove("parentPin").apply(); unlocked = false; toast("Set a new PIN"); refresh() }
        })

        root.addView(Button(this).apply { text = Lang.t(this@ParentActivity, "Done"); setOnClickListener { finish() } })
    }

    private fun resolvePending(index: Int, approve: Boolean) {
        val arr = JSONArray(sp().getString("pending", "[]"))
        if (index < 0 || index >= arr.length()) return
        val o = arr.getJSONObject(index)
        if (approve) addCoins(o.optString("profileId"), o.optInt("coins"))
        val out = JSONArray()
        for (i in 0 until arr.length()) if (i != index) out.put(arr.getJSONObject(i))
        sp().edit().putString("pending", out.toString()).apply()
        toast(if (approve) "Approved" else "Rejected"); refresh()
    }

    private fun approveAll() {
        val arr = JSONArray(sp().getString("pending", "[]"))
        var sum = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            addCoins(o.optString("profileId"), o.optInt("coins"))
            sum += o.optInt("coins")
        }
        sp().edit().putString("pending", "[]").apply()
        toast("Approved all (+" + sum + " coins)"); refresh()
    }

    /** Credit the profile that earned the coins; falls back to the first profile for old entries. */
    private fun addCoins(profileId: String, c: Int) {
        val id = if (profileId.isBlank()) Profiles.list(this).optJSONObject(0)?.optString("id") ?: "p0" else profileId
        val key = Profiles.stateKeyFor(id)
        val s = sp().getString(key, "") ?: ""
        val st = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        st.put("coins", st.optInt("coins", 0) + c)
        sp().edit().putString(key, st.toString()).apply()
    }

    private fun deleteReward(index: Int) {
        val arr = JSONArray(sp().getString("rewards", "[]"))
        val out = JSONArray()
        for (i in 0 until arr.length()) if (i != index) out.put(arr.getJSONObject(i))
        sp().edit().putString("rewards", out.toString()).apply()
        toast("Deleted"); refresh()
    }

    private fun weeklyReport(): String {
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val profiles = Profiles.list(this)
        val sb = StringBuilder()
        var totTasks = 0; var totPoints = 0; var totBonuses = 0
        for (p in 0 until profiles.length()) {
            val prof = profiles.getJSONObject(p)
            val gallery = JSONArray(sp().getString("gallery__" + prof.optString("id"), "[]"))
            var tasks = 0; var points = 0; var bonuses = 0
            for (i in 0 until gallery.length()) {
                val o = gallery.getJSONObject(i)
                if (o.optLong("time") >= weekAgo) { tasks++; points += o.optInt("points"); bonuses += o.optInt("bonuses") }
            }
            totTasks += tasks; totPoints += points; totBonuses += bonuses
            if (profiles.length() > 1) {
                sb.append(prof.optString("emoji")).append(" ").append(prof.optString("name"))
                    .append(": ").append(tasks).append(" ").append(he("tasks,", "משימות,")).append(" ")
                    .append(points).append(" ").append(he("pts,", "נק',")).append(" ")
                    .append(bonuses).append(" ").append(he("bonuses", "בונוסים")).append("\n")
            }
        }
        val log = JSONArray(sp().getString("redemptions", "[]"))
        var redeemed = 0; var spent = 0
        for (i in 0 until log.length()) {
            val o = log.getJSONObject(i)
            if (o.optLong("time") >= weekAgo) { redeemed++; spent += o.optInt("cost") }
        }
        if (profiles.length() > 1) sb.append("\n")
        sb.append(he("Total tasks passed: ", "סך משימות שעברו: ")).append(totTasks)
            .append("\n").append(he("Total points earned: ", "סך נקודות שהורווחו: ")).append(totPoints)
            .append("\n").append(he("Total bonuses earned: ", "סך בונוסים שהורווחו: ")).append(totBonuses)
            .append("\n").append(he("Rewards redeemed: ", "פרסים שמומשו: ")).append(redeemed)
            .append(" (").append(spent).append(" ").append(he("coins)", "מטבעות)"))
        return sb.toString()
    }

    /** How often the AI flagged a proof as AI-made or faked, per profile and overall. */
    private fun honestyReport(): String {
        val profiles = Profiles.list(this)
        val sb = StringBuilder()
        var totChecks = 0; var totFlagged = 0
        for (p in 0 until profiles.length()) {
            val prof = profiles.getJSONObject(p)
            val st = try { JSONObject(sp().getString("state__" + prof.optString("id"), "") ?: "") } catch (e: Exception) { JSONObject() }
            val checks = st.optInt("checksTotal", 0)
            val flagged = st.optInt("aiFlagged", 0)
            totChecks += checks; totFlagged += flagged
            if (profiles.length() > 1 && checks > 0) {
                sb.append(prof.optString("emoji")).append(" ").append(prof.optString("name"))
                    .append(": ").append(flagged).append(" ").append(he("of", "מתוך")).append(" ").append(checks)
                    .append(" ").append(he("flagged", "סומנו")).append("\n")
            }
        }
        if (totChecks == 0) return "No checks yet."
        if (profiles.length() > 1) sb.append("\n")
        val pct = (totFlagged * 100) / totChecks
        if (Lang.isHebrew(this)) {
            sb.append(totFlagged).append(" מתוך ").append(totChecks)
                .append(" הוכחות נראו כמעשה AI או מזויפות (").append(pct).append("%).")
            if (totFlagged == 0) sb.append("\nעד כה שום דבר חשוד. 👍")
        } else {
            sb.append(totFlagged).append(" of ").append(totChecks)
                .append(" proofs looked AI-made or faked (").append(pct).append("%).")
            if (totFlagged == 0) sb.append("\nNothing suspicious so far. 👍")
        }
        return sb.toString()
    }

    private fun ago(time: Long): String {
        if (time <= 0) return ""
        val mins = (System.currentTimeMillis() - time) / 60000
        return when {
            mins < 1 -> "just now"
            mins < 60 -> mins.toString() + "m ago"
            mins < 1440 -> (mins / 60).toString() + "h ago"
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(time))
        }
    }

    private fun pinField(h: String) = EditText(this).apply {
        hint = Lang.t(this@ParentActivity, h)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }

    private fun header(label: String) {
        root.addView(TextView(this).apply {
            text = Lang.t(this@ParentActivity, label); textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
    }

    private fun info(t: String) = TextView(this).apply { text = Lang.t(this@ParentActivity, t); textSize = 14f; setPadding(0, pad / 8, 0, pad / 8) }

    /** Pick the English or Hebrew form for a composed (non-dictionary) string. */
    private fun he(en: String, heb: String) = if (Lang.isHebrew(this)) heb else en

    private fun toast(m: String) = Toast.makeText(this, Lang.t(this@ParentActivity, m), Toast.LENGTH_SHORT).show()
}
