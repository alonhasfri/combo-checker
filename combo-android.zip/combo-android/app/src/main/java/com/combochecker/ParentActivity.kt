package com.combochecker

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** PIN-gated parent controls: real-life rewards, approval mode, pending approvals, redemption log, weekly report. */
class ParentActivity : Activity() {

    private fun sp() = getSharedPreferences("combo", MODE_PRIVATE)
    private lateinit var root: LinearLayout
    private var pad = 0
    private var unlocked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pad = (20 * resources.displayMetrics.density).toInt()
        Profiles.ensureDefault(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun pin() = sp().getString("parentPin", "") ?: ""

    private fun refresh() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "👪 Parent zone"; textSize = 26f; gravity = Gravity.CENTER_HORIZONTAL
        })
        when {
            pin().isEmpty() -> buildSetPin()
            !unlocked -> buildUnlock()
            else -> buildControls()
        }
    }

    private fun buildSetPin() {
        root.addView(info("Set a parent PIN. You will need it to change rewards and settings. (Note: this is a soft lock stored on the phone, not high security.)"))
        val p1 = pinField("New PIN (4+ digits)")
        val p2 = pinField("Confirm PIN")
        root.addView(p1); root.addView(p2)
        root.addView(Button(this).apply {
            text = "Save PIN"
            setOnClickListener {
                val a = p1.text.toString().trim(); val b = p2.text.toString().trim()
                if (a.length < 4) { toast("Use at least 4 digits"); return@setOnClickListener }
                if (a != b) { toast("PINs do not match"); return@setOnClickListener }
                sp().edit().putString("parentPin", a).apply()
                unlocked = true; toast("PIN set"); refresh()
            }
        })
    }

    private fun buildUnlock() {
        root.addView(info("Enter the parent PIN."))
        val p = pinField("PIN")
        root.addView(p)
        root.addView(Button(this).apply {
            text = "Unlock"
            setOnClickListener {
                if (p.text.toString().trim() == pin()) { unlocked = true; refresh() } else toast("Wrong PIN")
            }
        })
    }

    private fun buildControls() {
        header("AI art detector")
        root.addView(CheckBox(this).apply {
            text = "Strict: no points when a proof looks AI-made (85%+). Off means a warning only. Kids can't change this while a parent PIN is set."
            isChecked = sp().getBoolean("strict", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("strict", v).apply() }
        })

        header("Approval mode")
        root.addView(CheckBox(this).apply {
            text = "Hold coins earned until a parent approves them"
            isChecked = sp().getBoolean("approval", false)
            setOnCheckedChangeListener { _, v -> sp().edit().putBoolean("approval", v).apply() }
        })

        val pending = JSONArray(sp().getString("pending", "[]"))
        header("Pending approvals (" + pending.length() + ")")
        if (pending.length() == 0) root.addView(info("Nothing waiting."))
        for (i in 0 until pending.length()) {
            val o = pending.getJSONObject(i)
            val who = o.optString("profileName").ifBlank { "" }
            root.addView(TextView(this).apply {
                text = "• " + (if (who.isNotEmpty()) who + ": " else "") +
                    (o.optString("task").ifBlank { "(task)" }) + " — " + o.optInt("coins") + " coins  (" + ago(o.optLong("time")) + ")"
                textSize = 15f; setPadding(0, pad / 4, 0, 0)
            })
            val rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowL.addView(Button(this).apply { text = "Approve"; setOnClickListener { resolvePending(i, true) } })
            rowL.addView(Button(this).apply { text = "Reject"; setOnClickListener { resolvePending(i, false) } })
            root.addView(rowL)
        }
        if (pending.length() > 1) root.addView(Button(this).apply { text = "Approve all"; setOnClickListener { approveAll() } })

        header("Real-life rewards")
        root.addView(info("The child buys these with coins in the Shop. Add a name and a coin cost."))
        val rewards = JSONArray(sp().getString("rewards", "[]"))
        for (i in 0 until rewards.length()) {
            val rw = rewards.getJSONObject(i)
            root.addView(TextView(this).apply {
                text = rw.optString("name") + " — " + rw.optInt("cost") + " coins"
                textSize = 16f; setPadding(0, pad / 4, 0, 0)
            })
            root.addView(Button(this).apply { text = "Delete"; setOnClickListener { deleteReward(i) } })
        }
        val nameF = EditText(this).apply { hint = "Reward name (e.g. Ice cream)"; inputType = InputType.TYPE_CLASS_TEXT }
        val costF = EditText(this).apply { hint = "Coin cost"; inputType = InputType.TYPE_CLASS_NUMBER }
        root.addView(nameF); root.addView(costF)
        root.addView(Button(this).apply {
            text = "Add reward"
            setOnClickListener {
                val n = nameF.text.toString().trim()
                val c = costF.text.toString().trim().toIntOrNull() ?: 0
                if (n.isEmpty() || c <= 0) { toast("Enter a name and a cost"); return@setOnClickListener }
                val arr = JSONArray(sp().getString("rewards", "[]"))
                arr.put(JSONObject().put("name", n).put("cost", c))
                sp().edit().putString("rewards", arr.toString()).apply()
                toast("Added"); refresh()
            }
        })

        val log = JSONArray(sp().getString("redemptions", "[]"))
        header("Redeemed by child (" + log.length() + ")")
        if (log.length() == 0) root.addView(info("Nothing redeemed yet."))
        for (i in log.length() - 1 downTo maxOf(0, log.length() - 20)) {
            val o = log.getJSONObject(i)
            val who = o.optString("profileName").ifBlank { "" }
            root.addView(TextView(this).apply {
                text = "• " + (if (who.isNotEmpty()) who + ": " else "") +
                    o.optString("name") + " — " + o.optInt("cost") + " coins  (" + ago(o.optLong("time")) + ")"
                textSize = 15f; setPadding(0, pad / 4, 0, 0)
            })
        }
        if (log.length() > 0) root.addView(Button(this).apply {
            text = "Clear log"
            setOnClickListener {
                android.app.AlertDialog.Builder(this@ParentActivity)
                    .setTitle("Clear redemption log?")
                    .setMessage("This can't be undone.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Clear") { _, _ -> sp().edit().putString("redemptions", "[]").apply(); toast("Cleared"); refresh() }
                    .show()
            }
        })

        header("This week")
        root.addView(info(weeklyReport()))

        header("PIN")
        root.addView(Button(this).apply {
            text = "Change PIN"
            setOnClickListener { sp().edit().remove("parentPin").apply(); unlocked = false; toast("Set a new PIN"); refresh() }
        })

        root.addView(Button(this).apply { text = "Done"; setOnClickListener { finish() } })
    }

    private fun resolvePending(index: Int, approve: Boolean) {
        val arr = JSONArray(sp().getString("pending", "[]"))
        if (index < 0 || index >= arr.length()) return
        val o = arr.getJSONObject(index)
        if (approve) addCoins(o.optString("profileId"), o.optInt("coins"))
        val out = JSONArray()
        for (i in 0 until arr.length()) if (i != index) out.put(arr.getJSONObject(i))
        sp().edit().putString("pending", out.toString()).apply()
        toast(if (approve) "Approved" else "Rejected"); refresh()
    }

    private fun approveAll() {
        val arr = JSONArray(sp().getString("pending", "[]"))
        var sum = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            addCoins(o.optString("profileId"), o.optInt("coins"))
            sum += o.optInt("coins")
        }
        sp().edit().putString("pending", "[]").apply()
        toast("Approved all (+" + sum + " coins)"); refresh()
    }

    /** Credit the profile that earned the coins; falls back to the first profile for old entries. */
    private fun addCoins(profileId: String, c: Int) {
        val id = if (profileId.isBlank()) Profiles.list(this).optJSONObject(0)?.optString("id") ?: "p0" else profileId
        val key = Profiles.stateKeyFor(id)
        val s = sp().getString(key, "") ?: ""
        val st = if (s.isBlank()) JSONObject() else try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        st.put("coins", st.optInt("coins", 0) + c)
        sp().edit().putString(key, st.toString()).apply()
    }

    private fun deleteReward(index: Int) {
        val arr = JSONArray(sp().getString("rewards", "[]"))
        val out = JSONArray()
        for (i in 0 until arr.length()) if (i != index) out.put(arr.getJSONObject(i))
        sp().edit().putString("rewards", out.toString()).apply()
        toast("Deleted"); refresh()
    }

    private fun weeklyReport(): String {
        val weekAgo = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
        val profiles = Profiles.list(this)
        val sb = StringBuilder()
        var totTasks = 0; var totPoints = 0; var totBonuses = 0
        for (p in 0 until profiles.length()) {
            val prof = profiles.getJSONObject(p)
            val gallery = JSONArray(sp().getString("gallery__" + prof.optString("id"), "[]"))
            var tasks = 0; var points = 0; var bonuses = 0
            for (i in 0 until gallery.length()) {
                val o = gallery.getJSONObject(i)
                if (o.optLong("time") >= weekAgo) { tasks++; points += o.optInt("points"); bonuses += o.optInt("bonuses") }
            }
            totTasks += tasks; totPoints += points; totBonuses += bonuses
            if (profiles.length() > 1) {
                sb.append(prof.optString("emoji")).append(" ").append(prof.optString("name"))
                    .append(": ").append(tasks).append(" tasks, ").append(points).append(" pts, ")
                    .append(bonuses).append(" bonuses\n")
            }
        }
        val log = JSONArray(sp().getString("redemptions", "[]"))
        var redeemed = 0; var spent = 0
        for (i in 0 until log.length()) {
            val o = log.getJSONObject(i)
            if (o.optLong("time") >= weekAgo) { redeemed++; spent += o.optInt("cost") }
        }
        if (profiles.length() > 1) sb.append("\n")
        sb.append("Total tasks passed: ").append(totTasks)
            .append("\nTotal points earned: ").append(totPoints)
            .append("\nTotal bonuses earned: ").append(totBonuses)
            .append("\nRewards redeemed: ").append(redeemed).append(" (").append(spent).append(" coins)")
        return sb.toString()
    }

    private fun ago(time: Long): String {
        if (time <= 0) return ""
        val mins = (System.currentTimeMillis() - time) / 60000
        return when {
            mins < 1 -> "just now"
            mins < 60 -> mins.toString() + "m ago"
            mins < 1440 -> (mins / 60).toString() + "h ago"
            else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(time))
        }
    }

    private fun pinField(h: String) = EditText(this).apply {
        hint = h
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }

    private fun header(label: String) {
        root.addView(TextView(this).apply {
            text = label; textSize = 18f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, pad / 4)
        })
    }

    private fun info(t: String) = TextView(this).apply { text = t; textSize = 14f; setPadding(0, pad / 8, 0, pad / 8) }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
