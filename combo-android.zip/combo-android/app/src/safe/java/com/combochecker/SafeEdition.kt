package com.combochecker

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

/*
 * SAFE EDITION. The pranks (fake login, fake crashes, fake ads/payment, update keys, prank voices)
 * are not compiled into this version at all. These objects keep the same names so the rest of the
 * app builds, but they do nothing.
 */

object Pranks {
    data class Troll(val id: String, val label: String, val persist: Boolean, val implemented: Boolean)
    val trolls: List<Troll> = emptyList()
    val persistentModes: List<Troll> get() = trolls
    fun codeFor(ids: Collection<String>): String = ""
    fun decode(code: String): List<Troll>? = null
    fun applyPersistent(c: Context, set: List<Troll>): String? = null
}

object Ads {
    fun anyOn(c: Context) = false
    fun turnOff(c: Context) {}
    fun disableFor300(a: Activity) = false
    fun bannerView(a: Activity): View? = null
    fun maybeInterstitial(a: Activity) {}
    fun forceInterstitial(a: Activity) {}
    fun fakePurchase(a: Activity) {}
}

object LoginWall { fun maybeShow(a: Activity): Boolean = false }

object Crash { fun maybeShow(a: Activity) {} }

/** No prank voices in the safe edition: text is only translated. */
object Voice {
    fun active(c: Context): String = ""
    fun say(c: Context, text: String): String = Lang.t(c, text)
    fun transform(voice: String, text: String): String = text
    fun babyTalk(s: String): String = s
    fun shakespeare(s: String): String = s
}

/** In the safe edition this is simply the real Terms & Privacy page. */
class PrankActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Appearance.apply(this)
        val p = Ui.pal(this); val he = Lang.isHebrew(this)
        val d = { v: Int -> Ui.dp(this, v) }
        val page = Ui.page(this)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(Ui.iconButton(this, R.drawable.ui_back, Lang.t(this, "Back")) { finish() })
        head.addView(Ui.text(this, Lang.t(this, "Terms of Service & Privacy Policy"), 20f, p.ink).apply { setPaddingRelative(d(14), 0, 0, 0) }, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        page.addView(head)
        val text = if (he)
            "גרסה בטוחה של Comboed.\n\n1. אין צורך בהרשמה; אתם מזוהים במזהה אנונימי.\n2. פרופילים, נקודות ותמונות הוכחה נשמרים בטלפון. לשרת (Firebase) נשלחים רק מזהה אנונימי, שם ואימוג׳י לטבלת המובילים, נתוני קבוצות שהצטרפתם אליהן, גיבויים שבחרתם ודיווחי קריסה אנונימיים. מפתח ה‑AI וקוד ההורים לעולם לא נשלחים.\n3. הגרסה הזו לא כוללת מתיחות, פרסומות או מסכי תשלום.\n4. השתמשו באפליקציה בהגינות.\n5. האפליקציה מסופקת \"כפי שהיא\".\n6. שאלות: דרך \"שליחת משוב\" בהגדרות."
        else
            "Comboed — Safe edition.\n\n1. No sign-up is needed; you're identified by an anonymous id.\n2. Profiles, points and proof photos stay on this phone. Our server (Firebase) only gets an anonymous id, the name and emoji you show on the leaderboard, data for groups you join, backups you choose to make, and anonymous crash reports. Your AI key and parent PIN are never uploaded.\n3. This edition contains no pranks, no ads and no payment screens.\n4. Please use the app fairly.\n5. The app is provided \"as is\".\n6. Questions: use \"Send feedback\" in Settings."
        page.addView(Ui.card(this).apply {
            setPaddingRelative(d(16), d(14), d(16), d(14))
            addView(Ui.text(this@PrankActivity, text, 14f, p.ink, bold = false).apply { setLineSpacing(0f, 1.25f) })
        }, Ui.lp(this, 16))
        setContentView(ScrollView(this).apply { setBackgroundColor(p.bg); addView(page) })
    }
}
