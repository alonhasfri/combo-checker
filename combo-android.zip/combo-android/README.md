# Combo Checker for Android

A half-transparent floating star stays on top of every app. Tap it, circle the proof that a
task is done, and Claude checks it. Earned bonuses trigger rising "turun turun turun" cheers
(with phone vibration) and a big SUCCESS explosion.

## Build and install
1. Install Android Studio (free) from developer.android.com/studio.
2. Open this folder (`combo-android`) with File > Open. Let Gradle sync finish (first time downloads things).
3. On your phone: Settings > About phone > tap "Build number" 7 times, then enable
   Developer options > USB debugging. Connect with a USB cable and accept the prompt.
4. Press the green Run button in Android Studio. (Or Build > Build APK(s) and install the APK.)

## First run on the phone
1. Open "Combo Checker".
2. (Optional) paste your Anthropic API key and press "Save key". Without a key the app runs in
   test mode with random bonuses so you can try the animation.
3. Press "Start floating star". The first time, allow "Display over other apps", come back, and press it again.
4. Allow notifications if asked (a small notification keeps the star alive and has a Stop button).

## Using it
- Switch to any app. Drag the star where you like.
- Tap the star. Android asks to record your screen. On Android 14+, choose **Entire screen**, then Start.
  (Android asks every time. That is a system rule and can't be skipped.)
- Pick a profile, type the task, then draw a circle around the proof with your finger.
- Lift your finger and the check runs. Tap anywhere to close afterwards.

## Notes and limits
- Apps that block screenshots (banking apps, some video apps) show up black. Nothing to circle there.
- The API key is stored privately on the phone. Don't share the APK with the key saved in it.
- Only the circled crop is sent, and only after you lift your finger.
- The cheers use the phone's built-in text-to-speech. Pitch goes higher each bonus as far as your TTS engine allows.
- Profiles and bonus rules are in `app/src/main/assets/combo.html` (the `PROFILES` list).
