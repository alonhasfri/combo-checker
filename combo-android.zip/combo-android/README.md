# Combo Checker for Android

A half-transparent floating star stays on top of every app. Tap it, circle the proof that a
task is done, and the AI checks it. Earned bonuses trigger rising bell chimes, a big SUCCESS
explosion, points, combos, levels and ranks.

## Build and install
Build it with GitHub (upload `combo-android.zip` to your repo; the Actions workflow builds the APK)
or with Android Studio. Uninstall the old app before installing a new build.

## First run on the phone
1. Open "Combo Checker".
2. Paste an API key and press "Save settings":
   - a free Google Gemini key (starts with `AIza`, from aistudio.google.com), or
   - an Anthropic key.
   Without a key the app runs in test mode with random bonuses.
3. Press "Start floating star", allow "Display over other apps", then press it again.

## Using it
- Tap the star in any app. Android asks to record your screen (choose **Entire screen**).
- Pick a profile, type the task, and circle the proof with your finger.
- Lift your finger. The check runs and the combo plays. Tap anywhere to close.

## Rewards
- **Points:** 10 per task + 5 per earned bonus.
- **Combo multiplier:** finish tasks within 30 minutes of each other. x1, x1.5, x2, x2.5, up to x3.
- **Daily goal:** set the number of tasks per day in the app (default 3). Reaching it gives +50 points once a day.
- **Levels and ranks:** Rookie, Apprentice, Doer, Achiever, Pro, Expert, Master, Champion, Legend, Mythic.
  Level 2 at 25 points, level 3 at 100, level 4 at 225, and so on.

## Anti-cheat
- With a real key, the same task with a near-identical proof is refused ("ALREADY USED").
- Only winning proofs are remembered, so a failed attempt can be retried.
- If you really changed the work but it looks the same in the circle, change the task text slightly.
- Test mode has no anti-cheat.

## AI detector
- The AI also guesses how likely the proof is AI-made or faked (0 to 100).
- By default you only get a warning at 60%+. Turn on "Strict AI detector" in the app to withhold points at 85%+.
- This is a rough guess and can be wrong in both directions. Don't treat it as proof.

## Proof gallery
- Every winning proof is saved on the phone and shown in "Open proof gallery" (newest first, last 100 kept).
- It can contain private screen content. "Clear gallery" deletes everything.

## My voice
- In the app, record a bonus cheer and a finale cheer (up to 4 seconds each). The microphone permission is asked once.
- The bonus cheer plays higher and faster for each bonus. The finale cheer plays at the end.
- Turn the "Voice" checkbox on in the circle screen. If you recorded cheers, it starts on.
- Delete your recordings in the app to go back to the phone voice.

## Notes and limits
- Apps that block screenshots (banking, some video apps) show up black.
- The API key is stored privately on the phone.
- Only the circled crop is sent to the AI, and only after you lift your finger.
- Profiles and bonus rules are in `app/src/main/assets/combo.html` (the `PROFILES` list).
